import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.FlowMajorantFlags
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.ProdCastLESucc

namespace ReciprocityTheory.ChartRestriction.G.FD

open NumberField Complex Matrix
open scoped ComplexConjugate

variable {E : Type} [Field E] [NumberField E] [NumberField.IsCMField E]

namespace FrameDegreeData

noncomputable section

variable {r : ℕ} (X : Data E r)

lemma upper_of_bor {b : Frame X.Ψ r} (hb : b ∈ Bor X.Ψ r) (τ : X.Ψ) : (mat b τ).BlockTriangular id := by
  intro i j hij
  exact (hb τ).2 i j hij

lemma bdiag_ne {b : Frame X.Ψ r} (hb : b ∈ Bor X.Ψ r) (τ : X.Ψ) (j : Fin r) : b τ j j ≠ 0 := by
  have h1 := (hb τ).1
  rw [Matrix.det_of_upperTriangular (upper_of_bor X hb τ)] at h1
  exact (Finset.prod_ne_zero_iff.1 h1) j (Finset.mem_univ _)

lemma dmin_rmul (x : Frame X.Ψ r) {b : Frame X.Ψ r} (hb : b ∈ Bor X.Ψ r) (τ : X.Ψ) (i : Fin (r + 1)) :
    dmin X.Gm (rmul x b) τ i =
      (∏ j : Fin i, mat b τ (Fin.castLE (Nat.le_of_lt_succ i.isLt) j) (Fin.castLE (Nat.le_of_lt_succ i.isLt) j)) *
        dmin X.Gm x τ i *
        conj (∏ j : Fin i, mat b τ (Fin.castLE (Nat.le_of_lt_succ i.isLt) j) (Fin.castLE (Nat.le_of_lt_succ i.isLt) j)) := by
  have hmat : mat (rmul x b) τ = mat x τ * mat b τ := rfl
  simpa only [dmin, hmat, gram_mul] using
    lminor_conj (A := gram τ.1 X.Gm (mat x τ)) (upper_of_bor X hb τ) i

lemma ratio_rmul (x : Frame X.Ψ r) (hx : x ∈ X.dom) {b : Frame X.Ψ r} (hb : b ∈ Bor X.Ψ r) (τ : X.Ψ) (k : Fin r) :
    ‖dmin X.Gm (rmul x b) τ k.succ / dmin X.Gm (rmul x b) τ k.castSucc‖ =
      ‖b τ k k‖ ^ 2 * ‖dmin X.Gm x τ k.succ / dmin X.Gm x τ k.castSucc‖ := by
  have hsucc : (∏ j : Fin (k.succ : ℕ), mat b τ (Fin.castLE (Nat.le_of_lt_succ k.succ.isLt) j)
      (Fin.castLE (Nat.le_of_lt_succ k.succ.isLt) j)) =
      (∏ j : Fin (k.castSucc : ℕ), mat b τ (Fin.castLE (Nat.le_of_lt_succ k.castSucc.isLt) j)
        (Fin.castLE (Nat.le_of_lt_succ k.castSucc.isLt) j)) * b τ k k := by
    exact prod_castLE_succ k.isLt (fun j => mat b τ j j)
  have hPk : (∏ j : Fin (k.castSucc : ℕ), mat b τ (Fin.castLE (Nat.le_of_lt_succ k.castSucc.isLt) j)
      (Fin.castLE (Nat.le_of_lt_succ k.castSucc.isLt) j)) ≠ 0 :=
    Finset.prod_ne_zero_iff.2 fun j _ => bdiag_ne X hb τ _
  rw [dmin_rmul X x hb τ k.succ, dmin_rmul X x hb τ k.castSucc, hsucc]
  set Pk := (∏ j : Fin (k.castSucc : ℕ), mat b τ (Fin.castLE (Nat.le_of_lt_succ k.castSucc.isLt) j)
      (Fin.castLE (Nat.le_of_lt_succ k.castSucc.isLt) j))
  have hPn : ‖Pk‖ ≠ 0 := norm_ne_zero_iff.2 hPk
  simp [norm_div, norm_mul, Complex.norm_conj]
  by_cases hd : ‖dmin X.Gm x τ k.castSucc‖ = 0
  · simp [hd]
  · field_simp

lemma factor_eq (t q : ℝ) (ht : 0 < t) (hq : 0 ≤ q) (l : ℤ) :
    t ^ l * (t ^ 2 * q) ^ (-(l : ℝ) / 2) = q ^ (-(l : ℝ) / 2) := by
  rw [Real.mul_rpow (by positivity) hq]
  have h1 : (t ^ 2) ^ (-(l : ℝ) / 2) = (t ^ l)⁻¹ := by
    rw [← Real.rpow_natCast, ← Real.rpow_mul ht.le,
      show ((2 : ℕ) : ℝ) * (-(l : ℝ) / 2) = -(l : ℝ) by push_cast; ring,
      Real.rpow_neg ht.le, Real.rpow_intCast]
  rw [h1, ← mul_assoc, mul_inv_cancel₀ (zpow_ne_zero _ ht.ne'), one_mul]

lemma pnorm_rmul (la : Wt X.Ψ r) (P : Frame X.Ψ r → ℂ)
    (hP : ∀ x ∈ X.dom, ∀ b ∈ Bor X.Ψ r, P (rmul x b) = bchar la b * P x) (x : Frame X.Ψ r) (hx : x ∈ X.dom)
    (b : Frame X.Ψ r) (hb : b ∈ Bor X.Ψ r) : X.pnorm la P (rmul x b) = X.pnorm la P x := by
  have hfac : ∀ (τ : X.Ψ) (i : Fin r), ‖b τ i i‖ ^ la τ i *
      (‖b τ i i‖ ^ 2 * ‖dmin X.Gm x τ i.succ / dmin X.Gm x τ i.castSucc‖) ^ (-(la τ i : ℝ) / 2) =
      ‖dmin X.Gm x τ i.succ / dmin X.Gm x τ i.castSucc‖ ^ (-(la τ i : ℝ) / 2) :=
    fun τ i => factor_eq _ _ (norm_pos_iff.2 (bdiag_ne X hb τ i)) (norm_nonneg _) _
  unfold Data.pnorm
  rw [hP x hx b hb, norm_mul]
  simp only [ratio_rmul X x hx hb]
  unfold bchar
  simp only [norm_prod, norm_zpow]
  rw [← Finset.prod_congr rfl fun τ _ => Finset.prod_congr rfl fun i _ => hfac τ i]
  simp only [Finset.prod_mul_distrib]
  ring



lemma ppos_sameFlag {x x' : Frame X.Ψ r} (hx : x ∈ X.dom) (hx' : x' ∈ X.dom) (h : X.SameFlag x x')
    (τ : X.Ψ) (u : Fin r → ℂ) : X.ppos x τ u = X.ppos x' τ u := (FlowMajorantFlags.ppos_flag X hx hx' h τ u).symm

lemma Hf_sameFlag {x x' : Frame X.Ψ r} (hx : x ∈ X.dom) (hx' : x' ∈ X.dom) (h : X.SameFlag x x') :
    X.Hf x = X.Hf x' := by
  funext τ u w
  simp only [Data.Hf, ppos_sameFlag X hx hx' h τ u]

end

end FrameDegreeData

theorem orthonormalFlagTranslate_holds : OrthonormalFlagTranslate (E := E) := by
  intro r X
  refine ⟨fun x hx => ⟨FrameDegreeData.bOf X x, FrameDegreeData.bOf_mem X hx, FrameDegreeData.ortho_bOf X hx⟩,
    fun la P hP x hx b hb => FrameDegreeData.pnorm_rmul X la P hP x hx b hb, fun x hx x' hx' h => ?_⟩
  have hpp := FrameDegreeData.ppos_sameFlag X hx hx' h
  have hJ : X.Jz x = X.Jz x' := by
    funext u τ
    simp [Data.Jz, hpp]
  refine ⟨fun ξ => ⟨hJ, ?_, ?_⟩, ?_⟩
  · simp [Data.Uz, hJ]
  · unfold Data.aproj
    rw [FrameDegreeData.Hf_sameFlag X hx hx' h]
  · funext τ v
    have e : ∀ y : Frame X.Ψ r, X.posPart y τ v = (hermC τ.1 X.Gm (X.ppos y τ v) v).re := by
      intro y
      rw [X.hermC_ppos_self]
      rfl
    simp [Data.maj, e, hpp]

end ReciprocityTheory.ChartRestriction.G.FD
