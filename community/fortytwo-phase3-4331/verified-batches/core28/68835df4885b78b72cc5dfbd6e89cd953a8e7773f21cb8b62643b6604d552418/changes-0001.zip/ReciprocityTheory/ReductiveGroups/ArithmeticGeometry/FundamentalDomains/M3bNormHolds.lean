import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.ModerateCoefficientPositivity
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.MajorantFamilyNorms

namespace ReciprocityTheory.ChartRestriction.G.FD

open Complex ReciprocityTheory.ChartRestriction.G.FD.GramDeterminantReal ReciprocityTheory.ChartRestriction.G.FD.PositiveMinorUnits ReciprocityTheory.ChartRestriction.G.FD.MajorantFamilyNorms


variable {E : Type} [Field E] [NumberField E] [NumberField.IsCMField E]

private theorem log_min_max {q : ℝ} (hq : 0 < q) :
    Real.log (min q q⁻¹) = -|Real.log q| ∧ Real.log (max q q⁻¹) = |Real.log q| := by
  have hm := Real.strictMonoOn_log.monotoneOn
  rw [hm.map_min hq (inv_pos.mpr hq), hm.map_max hq (inv_pos.mpr hq), Real.log_inv,
    abs_eq_max_neg, ← min_neg_neg, neg_neg, min_comm]
  exact ⟨rfl, rfl⟩

private theorem mul_norm_sq_sum_le_re_inner_of_orthogonal_eigen {r p0 : ℕ} (hp0 : p0 ≤ r) (L l : ℕ → ℝ) (hL0 : L 0 = 0) (hLr : L r = 0)
    (hmono : ((∀ i, i < p0 → L i ≤ L (i + 1)) ∧ (∀ i, p0 ≤ i → i < r → L (i + 1) ≤ L i)) ∨
      ((∀ i, i < p0 → L (i + 1) ≤ L i) ∧ (∀ i, p0 ≤ i → i < r → L i ≤ L (i + 1))))
    (M μ : ℝ) (hl : ∀ i, i < r → μ ≤ l i ∧ l i ≤ M) :
    |∑ i ∈ Finset.range r, l i * (L (i + 1) - L i)| ≤ (M - μ) * |L p0| := by
  have hIco : ∑ i ∈ Finset.Ico p0 r, (L (i + 1) - L i) = L r - L p0 := by
    rw [Finset.sum_Ico_eq_sub _ hp0, Finset.sum_range_sub, Finset.sum_range_sub]
    abel
  have variation (s : Finset ℕ)
      (h : (∀ i ∈ s, L i ≤ L (i + 1)) ∨ (∀ i ∈ s, L (i + 1) ≤ L i)) :
      ∑ i ∈ s, |L (i + 1) - L i| = |∑ i ∈ s, (L (i + 1) - L i)| := by
    rcases h with h | h
    · rw [abs_of_nonneg (Finset.sum_nonneg fun i hi => sub_nonneg.mpr (h i hi))]
      exact Finset.sum_congr rfl fun i hi => abs_of_nonneg (sub_nonneg.mpr (h i hi))
    · rw [abs_of_nonpos (Finset.sum_nonpos fun i hi => sub_nonpos.mpr (h i hi)), ← Finset.sum_neg_distrib]
      exact Finset.sum_congr rfl fun i hi => abs_of_nonpos (sub_nonpos.mpr (h i hi))
  have hvar : ∑ i ∈ Finset.range r, |L (i + 1) - L i| = 2 * |L p0| := by
    have ha := variation (Finset.range p0) (by simpa only [Finset.mem_range] using (hmono.imp And.left And.left))
    have hb := variation (Finset.Ico p0 r) (by simpa only [Finset.mem_Ico, and_imp] using (hmono.symm.imp And.right And.right))
    rw [← Finset.sum_range_add_sum_Ico _ hp0, ha, hb, Finset.sum_range_sub, hIco, hL0, hLr, sub_zero, zero_sub, abs_neg, two_mul]
  have hshift : ∑ i ∈ Finset.range r, l i * (L (i + 1) - L i) =
      ∑ i ∈ Finset.range r, (l i - (M + μ) / 2) * (L (i + 1) - L i) := by
    have h0 : ∑ i ∈ Finset.range r, (M + μ) / 2 * (L (i + 1) - L i) = 0 := by
      rw [← Finset.mul_sum, Finset.sum_range_sub, hL0, hLr, sub_zero, mul_zero]
    simp [sub_mul, Finset.sum_sub_distrib, h0, sub_zero]
  rw [hshift]
  calc |∑ i ∈ Finset.range r, (l i - (M + μ) / 2) * (L (i + 1) - L i)|
      ≤ ∑ i ∈ Finset.range r, |(l i - (M + μ) / 2) * (L (i + 1) - L i)| := Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ i ∈ Finset.range r, (M - μ) / 2 * |L (i + 1) - L i| := by
        refine Finset.sum_le_sum fun i hi => ?_
        rw [abs_mul]
        refine mul_le_mul_of_nonneg_right ?_ (abs_nonneg _)
        obtain ⟨h1, h2⟩ := hl i (Finset.mem_range.mp hi)
        rw [abs_le]
        constructor <;> linarith
    _ = (M - μ) * |L p0| := by
        rw [← Finset.mul_sum, hvar]
        ring

private theorem ratio_tau {r : ℕ} (X : Data E r) (e : X.Ψ → Fin r → ℂ) (he : X.IsIsoV e)
    (la : Wt X.Ψ r) {x : Frame X.Ψ r} (hx : x ∈ X.dom) (s : X.Ψ → ℂ) (hT : X.flowV e s x ∈ X.dom)
    (τ : X.Ψ) :
    0 ≤ min (1 + (s τ).im / X.ttV e x τ) (1 + (s τ).im / X.ttV e x τ)⁻¹ ^ (X.spread la τ / 2) ∧
    min (1 + (s τ).im / X.ttV e x τ) (1 + (s τ).im / X.ttV e x τ)⁻¹ ^ (X.spread la τ / 2) ≤
      (∏ i : Fin r, ‖dmin X.Gm x τ i.succ / dmin X.Gm x τ i.castSucc‖ ^ (-(la τ i : ℝ) / 2) /
        ‖dmin X.Gm (X.flowV e s x) τ i.succ / dmin X.Gm (X.flowV e s x) τ i.castSucc‖ ^
          (-(la τ i : ℝ) / 2)) ∧
    (∏ i : Fin r, ‖dmin X.Gm x τ i.succ / dmin X.Gm x τ i.castSucc‖ ^ (-(la τ i : ℝ) / 2) /
        ‖dmin X.Gm (X.flowV e s x) τ i.succ / dmin X.Gm (X.flowV e s x) τ i.castSucc‖ ^
          (-(la τ i : ℝ) / 2)) ≤
      max (1 + (s τ).im / X.ttV e x τ) (1 + (s τ).im / X.ttV e x τ)⁻¹ ^ (X.spread la τ / 2) := by
  classical
  have he0 : hermC τ.1 X.Gm (e τ) (e τ) = 0 := (he τ).1
  set m : ℕ → ℝ := fun i => mN τ.1 X.Gm (mat x τ) (e τ) i with hm
  set a : ℕ → ℝ := fun i => 1 + 2 * X.c τ * (s τ).im * m i with ha
  have hd' : ∀ i : Fin (r + 1),
      dmin X.Gm (X.flowV e s x) τ i = dmin X.Gm x τ i * ((a i : ℝ) : ℂ) := by
    intro i
    rw [dmin_eq, dmin_eq, dmin_flow (X := X) (he := he0) (s := s) (i := (i : ℕ)) (h := Nat.le_of_lt_succ i.isLt) .., ha, hm]
    all_goals first | exact hx | exact hT
  have hapos : ∀ i : ℕ, i ≤ r → 0 < a i := by
    intro i hi
    have h1 := (hx τ).2 ⟨i, Nat.lt_succ_of_le hi⟩
    have h2 := (hT τ).2 ⟨i, Nat.lt_succ_of_le hi⟩
    rw [hd'] at h2
    simp only [Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im, mul_zero, sub_zero,
      Fin.val_mk] at h1 h2
    by_contra hle
    push_neg at hle
    nlinarith [mul_le_mul_of_nonneg_left hle h1.le]
  have hdne : ∀ i : Fin (r + 1), dmin X.Gm x τ i ≠ 0 := by
    intro i h
    have h1 := (hx τ).2 i
    rw [h, Complex.zero_re, mul_zero] at h1
    exact lt_irrefl _ h1
  have hfac : ∀ i : Fin r,
      ‖dmin X.Gm x τ i.succ / dmin X.Gm x τ i.castSucc‖ ^ (-(la τ i : ℝ) / 2) /
        ‖dmin X.Gm (X.flowV e s x) τ i.succ / dmin X.Gm (X.flowV e s x) τ i.castSucc‖ ^
          (-(la τ i : ℝ) / 2) = (a (i + 1) / a i) ^ ((la τ i : ℝ) / 2) := by
    intro i
    have hs := hapos (i + 1) i.isLt
    have hc := hapos i i.isLt.le
    have hX : 0 < ‖dmin X.Gm x τ i.succ / dmin X.Gm x τ i.castSucc‖ :=
      norm_pos_iff.mpr (div_ne_zero (hdne _) (hdne _))
    have hY : 0 < a (i + 1) / a i := div_pos hs hc
    rw [hd', hd', mul_div_mul_comm, ← Complex.ofReal_div, norm_mul, Complex.norm_real]
    simp only [Fin.val_succ, Fin.coe_castSucc]
    rw [Real.norm_of_nonneg hY.le, Real.mul_rpow hX.le hY.le, div_mul_eq_div_div, div_self (Real.rpow_pos_of_pos hX _).ne', one_div,
      ← Real.rpow_neg hY.le]
    congr 1
    ring
  have hq : 1 + (s τ).im / X.ttV e x τ = a X.p0 := by
    rw [ha, hm]
    unfold Data.ttV
    rw [div_div_eq_mul_div, div_one, maj_eq (X := X) (he := he0) ..]
    · ring
    all_goals first | exact hx | exact hT
  simp only [hfac]
  rw [hq]
  have hq0 : 0 < a X.p0 := hapos _ X.p0_le
  have hPpos : 0 < ∏ i : Fin r, (a (i + 1) / a i) ^ ((la τ i : ℝ) / 2) :=
    Finset.prod_pos fun i _ => Real.rpow_pos_of_pos (div_pos (hapos _ i.isLt) (hapos _ i.isLt.le)) _
  set l : ℕ → ℝ := fun k => if h : k < r then (la τ ⟨k, h⟩ : ℝ) else 0 with hl
  have hli : ∀ i : Fin r, l i = (la τ i : ℝ) := by
    intro i
    rw [hl]
    simp [i.isLt]
  have hlogP : Real.log (∏ i : Fin r, (a (i + 1) / a i) ^ ((la τ i : ℝ) / 2)) =
      (∑ k ∈ Finset.range r, l k * (Real.log (a (k + 1)) - Real.log (a k))) / 2 := by
    rw [Real.log_prod (fun i _ =>
      (Real.rpow_pos_of_pos (div_pos (hapos _ i.isLt) (hapos _ i.isLt.le)) _).ne')]
    rw [Finset.sum_div,
      ← Fin.sum_univ_eq_sum_range (fun k => l k * (Real.log (a (k + 1)) - Real.log (a k)) / 2) r]
    refine Finset.sum_congr rfl fun i _ => ?_
    rw [Real.log_rpow (div_pos (hapos _ i.isLt) (hapos _ i.isLt.le)),
      Real.log_div (hapos _ i.isLt).ne' (hapos _ i.isLt.le).ne', hli i]
    ring
  have hlb : ∀ k, k < r → (⨅ i, (la τ i : ℝ)) ≤ l k ∧ l k ≤ ⨆ i, (la τ i : ℝ) := by
    intro k hk
    have h1 := hli ⟨k, hk⟩
    simp only [Fin.val_mk] at h1
    rw [h1]
    exact ⟨ciInf_le (Finite.bddBelow_range _) _, le_ciSup (Finite.bddAbove_range (fun i => (la τ i : ℝ))) ⟨k, hk⟩⟩
  have hxg : ∀ (i : ℕ) (h : i ≤ r),
      0 < psgn X.p0 i * (gramF τ.1 X.Gm (famN (mat x τ) i h)).det.re := by
    intro i h
    have h1 := (hx τ).2 ⟨i, Nat.lt_succ_of_le h⟩
    rw [dmin_eq] at h1
    exact h1
  have hL0 : Real.log (a 0) = 0 := by
    simp only [ha, hm, mN_zero, mul_zero, add_zero, Real.log_one]
  have hLr : Real.log (a r) = 0 := by
    simp only [ha, hm, mN_top (hG_of X τ) X.p0 (mat x τ) (hx τ).1 hxg (e τ) he0,
      mul_zero, add_zero, Real.log_one]
  let slope := 2 * X.c τ * (s τ).im
  have hL (i j) (hi : i ≤ r) (hj : j ≤ r) (hij : m i ≤ m j) :
      (0 ≤ slope → Real.log (a i) ≤ Real.log (a j)) ∧
      (slope ≤ 0 → Real.log (a j) ≤ Real.log (a i)) :=
    ⟨fun h => Real.log_le_log (hapos _ hi) (add_le_add_right (mul_le_mul_of_nonneg_left hij h) 1),
     fun h => Real.log_le_log (hapos _ hj) (add_le_add_right (mul_le_mul_of_nonpos_left hij h) 1)⟩
  have hup (i : ℕ) (hi : i < X.p0) : m i ≤ m (i + 1) :=
    mN_up (hG_of X τ) X.p0 X.p0_le _ hxg _ _ hi _ (Nat.le_succ i)
  have hdown (i : ℕ) (hi : X.p0 ≤ i) (hir : i < r) : m (i + 1) ≤ m i :=
    mN_down (hG_of X τ) X.p0 _ hxg _ _ hi _ (Nat.le_succ i) hir
  have hp0r := X.p0_le
  have hmono : ((∀ i, i < X.p0 → Real.log (a i) ≤ Real.log (a (i + 1))) ∧
        (∀ i, X.p0 ≤ i → i < r → Real.log (a (i + 1)) ≤ Real.log (a i))) ∨
      ((∀ i, i < X.p0 → Real.log (a (i + 1)) ≤ Real.log (a i)) ∧
        (∀ i, X.p0 ≤ i → i < r → Real.log (a i) ≤ Real.log (a (i + 1)))) := by
    rcases le_total 0 slope with hκ | hκ
    · left
      exact ⟨fun i hi => (hL i (i + 1) (by omega) (by omega) (hup i hi)).1 hκ,
        fun i hi hir => (hL (i + 1) i hir (by omega) (hdown i hi hir)).1 hκ⟩
    · right
      exact ⟨fun i hi => (hL i (i + 1) (by omega) (by omega) (hup i hi)).2 hκ,
        fun i hi hir => (hL (i + 1) i hir (by omega) (hdown i hi hir)).2 hκ⟩
  have hbound := mul_norm_sq_sum_le_re_inner_of_orthogonal_eigen X.p0_le (fun k => Real.log (a k)) l hL0 hLr hmono
    (⨆ i, (la τ i : ℝ)) (⨅ i, (la τ i : ℝ)) hlb
  have hsp : X.spread la τ = (⨆ i, (la τ i : ℝ)) - ⨅ i, (la τ i : ℝ) := rfl
  obtain ⟨hmin, hmax⟩ := log_min_max hq0
  have hminpos : 0 < min (a X.p0) (a X.p0)⁻¹ := lt_min hq0 (inv_pos.mpr hq0)
  have hmaxpos : 0 < max (a X.p0) (a X.p0)⁻¹ := lt_max_of_lt_left hq0
  rw [abs_le] at hbound
  refine ⟨(Real.rpow_pos_of_pos hminpos _).le, ?_, ?_⟩
  · rw [Real.rpow_def_of_pos hminpos, ← Real.exp_log hPpos, Real.exp_le_exp, hlogP, hmin, hsp]
    nlinarith [hbound.1]
  · rw [Real.rpow_def_of_pos hmaxpos, ← Real.exp_log hPpos, Real.exp_le_exp, hlogP, hmax, hsp]
    nlinarith [hbound.2]

theorem m3bNorm_holds : FlowNormRatio (E := E) := by
  intro r X e he la x hx s hT
  dsimp only
  simp only [Data.nfac, ← Finset.prod_div_distrib]
  constructor
  · exact Finset.prod_le_prod (fun τ _ => (ratio_tau X e he la hx s hT τ).1)
      (fun τ _ => (ratio_tau X e he la hx s hT τ).2.1)
  · exact Finset.prod_le_prod
      (fun τ _ => (ratio_tau X e he la hx s hT τ).1.trans (ratio_tau X e he la hx s hT τ).2.1)
      (fun τ _ => (ratio_tau X e he la hx s hT τ).2.2)

end ReciprocityTheory.ChartRestriction.G.FD
