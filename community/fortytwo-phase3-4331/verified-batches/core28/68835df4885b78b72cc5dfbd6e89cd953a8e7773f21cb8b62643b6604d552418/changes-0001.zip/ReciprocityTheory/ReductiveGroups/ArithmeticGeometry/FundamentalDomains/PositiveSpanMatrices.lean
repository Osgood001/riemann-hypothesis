import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.FlowMatMulVec
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.ExistsUnitaryBasisSameFlag
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.UnitaryComplementMoveOfIsotropic
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.LminorSubmatrixCastSucc

namespace ReciprocityTheory.ChartRestriction.G.FD.PositiveSpanMatrices

open NumberField Complex Matrix ReciprocityTheory.ChartRestriction.G.FD
open scoped ComplexConjugate

noncomputable section

def kap {n p : ℕ} (hp : p ≤ n) (a : Fin (n - p)) : Fin n := ⟨p + a, by have := a.isLt; omega⟩


lemma sum_split {M : Type*} [AddCommMonoid M] {n p : ℕ} (hp : p ≤ n) (F : Fin n → M) :
    ∑ c : Fin n, F c = ∑ b : Fin p, F (Fin.castLE hp b) + ∑ a : Fin (n - p), F (kap hp a) := by
  obtain ⟨m, rfl⟩ := Nat.exists_eq_add_of_le hp
  have hm : p + m - p = m := by omega
  rw [Fin.sum_univ_add]
  refine congrArg₂ (· + ·) (Finset.sum_congr rfl (fun b _ => congrArg F (Fin.ext rfl))) ?_
  refine Fintype.sum_equiv (finCongr hm.symm) _ _ (fun i => ?_)
  exact congrArg F (Fin.ext (by simp [kap]))

lemma kap_ne_castLE {n p : ℕ} (hp : p ≤ n) (a : Fin (n - p)) (b : Fin p) : kap hp a ≠ Fin.castLE hp b := by
  intro h
  have h1 := congrArg Fin.val h
  have hb := b.isLt
  simp [kap] at h1
  omega

lemma fin_cases_split {n p : ℕ} (hp : p ≤ n) (c : Fin n) :
    (∃ b : Fin p, c = Fin.castLE hp b) ∨ ∃ a : Fin (n - p), c = kap hp a := by
  have hc := c.isLt
  by_cases h : (c : ℕ) < p
  · exact Or.inl ⟨⟨c, h⟩, Fin.ext rfl⟩
  · refine Or.inr ⟨⟨c - p, by omega⟩, Fin.ext ?_⟩
    show (c : ℕ) = p + (c - p)
    omega

lemma span_eq_of_mat {V : Type*} [AddCommGroup V] [Module ℂ V] {n : ℕ} (f g : Fin n → V)
    (A : Matrix (Fin n) (Fin n) ℂ) (hA : A.det ≠ 0) (h : ∀ b, g b = ∑ b', A b' b • f b') :
    Submodule.span ℂ (Set.range g) = Submodule.span ℂ (Set.range f) := by
  have eq : Fintype.linearCombination ℂ g = (Fintype.linearCombination ℂ f).comp A.mulVecLin := by
    ext j
    simp [Fintype.linearCombination_apply, Matrix.mulVecLin_apply, Matrix.mulVec_single, h]
  rw [← Fintype.range_linearCombination, ← Fintype.range_linearCombination, eq]
  apply LinearMap.range_comp_of_range_eq_top
  exact LinearMap.range_eq_top.mpr (Matrix.mulVec_surjective_iff_isUnit.mpr
    ((Matrix.isUnit_iff_isUnit_det A).mpr (isUnit_iff_ne_zero.mpr hA)))


section Ortho

variable {E : Type} [Field E] [NumberField E] [IsCMField E] {r : ℕ} (X : Data E r)

abbrev Spos (x : Frame X.Ψ r) (τ : X.Ψ) : Submodule ℂ (Fin r → ℂ) :=
  Submodule.span ℂ (Set.range fun b : Fin X.p0 => col (mat x τ) (Fin.castLE X.p0_le b))

def Pos (x : Frame X.Ψ r) (τ : X.Ψ) (y : Fin r → ℂ) : ℝ :=
  ∑ b : Fin X.p0, ‖hermC τ.1 X.Gm y (col (mat x τ) (Fin.castLE X.p0_le b))‖ ^ 2

def Neg (x : Frame X.Ψ r) (τ : X.Ψ) (y : Fin r → ℂ) : ℝ :=
  ∑ a : Fin (r - X.p0), ‖hermC τ.1 X.Gm y (col (mat x τ) (kap X.p0_le a))‖ ^ 2

lemma Pos_nonneg (x : Frame X.Ψ r) (τ : X.Ψ) (y : Fin r → ℂ) : 0 ≤ Pos X x τ y := by
  unfold Pos
  exact Finset.sum_nonneg (fun _ _ => by positivity)

lemma Neg_nonneg (x : Frame X.Ψ r) (τ : X.Ψ) (y : Fin r → ℂ) : 0 ≤ Neg X x τ y := by
  unfold Neg
  exact Finset.sum_nonneg (fun _ _ => by positivity)

lemma ortho_apply {x : Frame X.Ψ r} (hx : X.IsOrtho x) (τ : X.Ψ) (c d : Fin r) :
    hermC τ.1 X.Gm (col (mat x τ) c) (col (mat x τ) d) = if c = d then ((sgn X.p0 c : ℝ) : ℂ) else 0 := by
  have h := congrFun (congrFun (hx τ) c) d
  simpa [gram, Matrix.diagonal_apply] using h

lemma expand {x : Frame X.Ψ r} (hx : X.IsOrtho x) (τ : X.Ψ) (hdet : (mat x τ).det ≠ 0) (y : Fin r → ℂ) :
    y = ∑ c : Fin r, (((sgn X.p0 (c : ℕ) : ℝ) : ℂ) * hermC τ.1 X.Gm y (col (mat x τ) c)) • col (mat x τ) c :=
  OrthonormalPerpBasis.expand_of_det X hx τ hdet y

lemma re_self {x : Frame X.Ψ r} (hx : X.IsOrtho x) (τ : X.Ψ) (hdet : (mat x τ).det ≠ 0) (y : Fin r → ℂ) :
    (hermC τ.1 X.Gm y y).re = ∑ c : Fin r, sgn X.p0 (c : ℕ) * ‖hermC τ.1 X.Gm y (col (mat x τ) c)‖ ^ 2 := by
  conv_lhs => rw [expand X hx τ hdet y]
  rw [OrthonormalPerpBasis.comb_comb X hx τ, Complex.re_sum]
  refine Finset.sum_congr rfl (fun c _ => ?_)
  by_cases h : (c : ℕ) < X.p0 <;> simp [sgn, h, Complex.mul_conj, Complex.normSq_eq_norm_sq, ← Complex.ofReal_pow]

lemma sgn_castLE (b : Fin X.p0) : sgn X.p0 (Fin.castLE X.p0_le b : ℕ) = 1 := by
  simp [sgn]

lemma sgn_kap (a : Fin (r - X.p0)) : sgn X.p0 (kap X.p0_le a : ℕ) = -1 := by
  simp [sgn, kap]

lemma re_self_split {x : Frame X.Ψ r} (hx : X.IsOrtho x) (τ : X.Ψ) (hdet : (mat x τ).det ≠ 0)
    (y : Fin r → ℂ) : (hermC τ.1 X.Gm y y).re = Pos X x τ y - Neg X x τ y := by
  rw [re_self X hx τ hdet y, sum_split X.p0_le]
  simp only [sgn_castLE X, sgn_kap X, one_mul, neg_one_mul, Finset.sum_neg_distrib]
  unfold Pos Neg
  ring

lemma eq_zero_of_Pos_Neg {x : Frame X.Ψ r} (hx : X.IsOrtho x) (τ : X.Ψ) (hdet : (mat x τ).det ≠ 0)
    (y : Fin r → ℂ) (hP : Pos X x τ y = 0) (hN : Neg X x τ y = 0) : y = 0 := by
  let z := fun c => hermC τ.1 X.Gm y (col (mat x τ) c)
  have hsum : ∑ c, ‖z c‖ ^ 2 = 0 := by
    rw [sum_split X.p0_le]
    exact add_eq_zero_iff_of_nonneg (Pos_nonneg X x τ y) (Neg_nonneg X x τ y) |>.2 ⟨hP, hN⟩
  have hz (c) : z c = 0 := by
    simpa using (Finset.sum_eq_zero_iff_of_nonneg (fun i _ => sq_nonneg ‖z i‖)).mp hsum c (Finset.mem_univ c)
  rw [expand X hx τ hdet y]
  exact Finset.sum_eq_zero fun c _ => by change (_ * z c) • _ = _; rw [hz, mul_zero, zero_smul]

lemma perp_kap {x : Frame X.Ψ r} (hx : X.IsOrtho x) (τ : X.Ψ) (w : Fin r → ℂ) (hw : w ∈ Spos X x τ)
    (a : Fin (r - X.p0)) : hermC τ.1 X.Gm w (col (mat x τ) (kap X.p0_le a)) = 0 := by
  induction hw using Submodule.span_induction with
  | mem z hz =>
    obtain ⟨b, rfl⟩ := hz
    rw [ortho_apply X hx τ, if_neg (kap_ne_castLE X.p0_le a b).symm]
  | zero => exact hermC_zero_left _ _ _
  | add z1 z2 _ _ h1 h2 => rw [hermC_add_left, h1, h2, add_zero]
  | smul c z _ h => rw [hermC_smul_left, h, mul_zero]

lemma re_self_of_mem {x : Frame X.Ψ r} (hx : X.IsOrtho x) (τ : X.Ψ) (hdet : (mat x τ).det ≠ 0)
    (w : Fin r → ℂ) (hw : w ∈ Spos X x τ) : (hermC τ.1 X.Gm w w).re = Pos X x τ w := by
  rw [re_self_split X hx τ hdet w]
  have hN : Neg X x τ w = 0 := by
    unfold Neg
    exact Finset.sum_eq_zero (fun a _ => by rw [perp_kap X hx τ w hw a]; simp)
  rw [hN, sub_zero]

lemma re_self_of_perp {x : Frame X.Ψ r} (hx : X.IsOrtho x) (τ : X.Ψ) (hdet : (mat x τ).det ≠ 0)
    (w : Fin r → ℂ) (hw : ∀ b : Fin X.p0, hermC τ.1 X.Gm w (col (mat x τ) (Fin.castLE X.p0_le b)) = 0) :
    (hermC τ.1 X.Gm w w).re = -Neg X x τ w := by
  rw [re_self_split X hx τ hdet w]
  have hP : Pos X x τ w = 0 := by
    unfold Pos
    exact Finset.sum_eq_zero (fun b _ => by rw [hw b]; simp)
  rw [hP, zero_sub]

lemma zero_of_mem_self {x : Frame X.Ψ r} (hx : X.IsOrtho x) (τ : X.Ψ) (hdet : (mat x τ).det ≠ 0)
    (w : Fin r → ℂ) (hw : w ∈ Spos X x τ) (h0 : hermC τ.1 X.Gm w w = 0) : w = 0 := by
  have hre := re_self_of_mem X hx τ hdet w hw
  rw [h0, Complex.zero_re] at hre
  have hN : Neg X x τ w = 0 := by
    unfold Neg
    exact Finset.sum_eq_zero (fun a _ => by rw [perp_kap X hx τ w hw a]; simp)
  exact eq_zero_of_Pos_Neg X hx τ hdet w hre.symm hN

lemma ppos_mem (x : Frame X.Ψ r) (τ : X.Ψ) (w : Fin r → ℂ) : X.ppos x τ w ∈ Spos X x τ := by
  unfold Data.ppos
  exact Submodule.sum_mem _ (fun a _ => Submodule.smul_mem _ _ (Submodule.subset_span ⟨a, rfl⟩))

lemma ppos_of_mem {x : Frame X.Ψ r} (hx : x ∈ X.dom) (τ : X.Ψ) (w : Fin r → ℂ) (hw : w ∈ Spos X x τ) :
    X.ppos x τ w = w := by
  obtain ⟨t, rfl⟩ := (Submodule.mem_span_range_iff_exists_fun ℂ).mp hw
  apply X.ppos_eq_of x τ (X.gramPos_det_ne hx τ) _ t
  intro b
  rw [sub_self, hermC_zero_left]

lemma perp_of_ppos_zero {x : Frame X.Ψ r} (hx : x ∈ X.dom) (τ : X.Ψ) (w : Fin r → ℂ)
    (hw : X.ppos x τ w = 0) (b : Fin X.p0) : hermC τ.1 X.Gm w (col (mat x τ) (Fin.castLE X.p0_le b)) = 0 := by
  simpa only [hw, sub_zero] using X.ppos_orth x τ (X.gramPos_det_ne hx τ) w b

end Ortho

end

end ReciprocityTheory.ChartRestriction.G.FD.PositiveSpanMatrices
