import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.ModerateCoefficientPositivity
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.TransvectionPeriodicity

namespace ReciprocityTheory.ChartRestriction.G.FD.BoundedSectionAlgebra

open NumberField Complex MeasureTheory ReciprocityTheory.ChartRestriction.G.FD
open ReciprocityTheory.ChartRestriction.G.FD.EmbeddingHermitianPairs ReciprocityTheory.ChartRestriction.G.FD.AdmissibleHermitianColumns ReciprocityTheory.ChartRestriction.G.FD.TransvectionPeriodicity
open scoped ComplexConjugate

noncomputable section

variable {E : Type} [Field E] [NumberField E] [IsCMField E] {r : ℕ} (X : Data E r)

lemma pnorm_eq (la : Wt X.Ψ r) (P : Frame X.Ψ r → ℂ) (x : Frame X.Ψ r) :
    X.pnorm la P x = ‖P x‖ * X.nfac la x := rfl



lemma dmin_ne {x : Frame X.Ψ r} (hx : x ∈ X.dom) (τ : X.Ψ) (i : Fin (r + 1)) : dmin X.Gm x τ i ≠ 0 := by
  intro h
  have h1 := (hx τ).2 i
  rw [h, Complex.zero_re, mul_zero] at h1
  exact lt_irrefl _ h1

lemma ratio_pos {x : Frame X.Ψ r} (hx : x ∈ X.dom) (τ : X.Ψ) (i : Fin r) :
    0 < ‖dmin X.Gm x τ i.succ / dmin X.Gm x τ i.castSucc‖ :=
  norm_pos_iff.mpr (div_ne_zero (dmin_ne X hx τ _) (dmin_ne X hx τ _))

lemma nfac_pos {x : Frame X.Ψ r} (hx : x ∈ X.dom) (la : Wt X.Ψ r) : 0 < X.nfac la x :=
  Finset.prod_pos fun τ _ => Finset.prod_pos fun i _ => Real.rpow_pos_of_pos (ratio_pos X hx τ i) _

end

theorem bounded_character_has_nonnegative_indices {E : Type} [Field E] [NumberField E] [IsCMField E] {r : ℕ} (X : Data E r) (la : Wt X.Ψ r)
    (e : X.Ψ → Fin r → ℂ) (he : X.IsIsoV e) (ν : X.Ψ → ℝ) (x : Frame X.Ψ r) (hx : x ∈ X.dom)
    (G : Frame X.Ψ r → ℂ) (hne : G x ≠ 0) (C : ℝ) (hC : ∀ z ∈ X.dom, X.pnorm la G z ≤ C)
    (hchar : ∀ s : X.Ψ → ℂ, X.flowV e s x ∈ X.dom →
      G (X.flowV e s x) = cexp (4 * Real.pi * I * ∑ τ, (ν τ : ℂ) * s τ) * G x)
    (hnorm : FlowNormRatio (E := E)) (ht : ∀ τ, 0 < X.ttV e x τ)
    (hadmit : ∀ s : X.Ψ → ℂ, (∀ τ, 0 ≤ (s τ).im) → X.flowV e s x ∈ X.dom) :
    ∀ τ, 0 ≤ ν τ := by
  classical
  intro τ₀
  by_contra! hneg
  let t₀ := X.ttV e x τ₀
  have ht₀ : 0 < t₀ := ht τ₀
  let a := -(4 * Real.pi * ν τ₀) * t₀
  have ha : 0 < a := mul_pos (neg_pos.mpr (mul_neg_of_pos_of_neg (by positivity) hneg)) ht₀
  let w := X.spread la τ₀ / 2
  have hp := nfac_pos X hx la
  have hpos : 0 < ‖G x‖ * X.nfac la x := mul_pos (norm_pos_iff.mpr hne) hp
  let K := C * Real.exp a / (‖G x‖ * X.nfac la x)
  obtain ⟨t, ht, hlarge⟩ := ((Filter.eventually_ge_atTop (1 : ℝ)).and
    ((tendsto_exp_mul_div_rpow_atTop w a ha).eventually_ge_atTop (K + 1))).exists
  let s : X.Ψ → ℂ := fun τ => if τ = τ₀ then ((t₀ * (t - 1) : ℝ) : ℂ) * I else 0
  have him (τ) : (s τ).im = if τ = τ₀ then t₀ * (t - 1) else 0 := by
    by_cases h : τ = τ₀ <;> simp [s, h]
  have hy : X.flowV e s x ∈ X.dom := hadmit s fun τ => by
    rw [him]
    split_ifs
    · exact mul_nonneg ht₀.le (sub_nonneg.mpr ht)
    · exact le_rfl
  have hq (τ) : 1 + (s τ).im / X.ttV e x τ = if τ = τ₀ then t else 1 := by
    rw [him]
    by_cases h : τ = τ₀
    · subst τ; simp only [if_true]; change 1 + t₀ * (t - 1) / t₀ = t
      field_simp [ht₀.ne'] <;> ring
    · simp [h]
  have hr := (hnorm r X _ he la x hx s hy).2
  dsimp only at hr
  simp only [hq] at hr
  rw [Finset.prod_eq_single τ₀ (fun τ _ hτ => by simp [hτ]) (fun h => absurd (Finset.mem_univ _) h)] at hr
  simp only [if_true, max_eq_left ((inv_le_one_of_one_le₀ ht).trans ht)] at hr
  have hsum : ∑ τ, (ν τ : ℂ) * s τ = (ν τ₀ : ℂ) * (((t₀ * (t - 1) : ℝ) : ℂ) * I) := by
    rw [Finset.sum_eq_single τ₀ (fun τ _ hτ => by simp [s, hτ]) (fun h => absurd (Finset.mem_univ _) h)]
    simp [s]
  have heq := congrArg norm (hchar s hy)
  rw [norm_mul, Complex.norm_exp, hsum] at heq
  have hre : (4 * (Real.pi : ℂ) * I * ((ν τ₀ : ℂ) * (((t₀ * (t - 1) : ℝ) : ℂ) * I))).re = a * (t - 1) := by
    simp [Complex.mul_re, Complex.mul_im, a] <;> ring
  rw [hre] at heq
  let y := X.flowV e s x
  have hypos := nfac_pos X hy la
  have hL : Real.exp (a * (t - 1)) * ‖G x‖ * X.nfac la x ≤ C * t ^ w := calc
    _ = ‖G y‖ * X.nfac la x := by rw [← heq]
    _ = X.pnorm la G y * (X.nfac la x / X.nfac la y) := by
      change _ = (‖G y‖ * X.nfac la y) * (X.nfac la x / X.nfac la y)
      have hyne : X.nfac la y ≠ 0 := hypos.ne'
      field_simp [hyne]
    _ ≤ _ := mul_le_mul (hC y hy) hr (div_nonneg hp.le hypos.le) ((mul_nonneg (norm_nonneg (G x)) hp.le).trans (hC x hx))
  have htop : Real.exp (a * t) / t ^ w ≤ K := by
    apply (div_le_div_iff₀ (Real.rpow_pos_of_pos (by linarith) w) hpos).2
    rw [show a * t = a * (t - 1) + a by ring, Real.exp_add]
    calc _ = (Real.exp (a * (t - 1)) * ‖G x‖ * X.nfac la x) * Real.exp a := by ring
      _ ≤ _ := (mul_le_mul_of_nonneg_right hL (Real.exp_pos a).le).trans_eq (by ring)
  exact (not_lt_of_ge htop) (lt_of_lt_of_le (lt_add_one K) hlarge)

end ReciprocityTheory.ChartRestriction.G.FD.BoundedSectionAlgebra
