import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.QuadraticCoefficientForms
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.TransvectionPeriodicity

namespace ReciprocityTheory.ChartRestriction.G.FD.RealEmbeddingCharacters

open NumberField Complex ReciprocityTheory.ChartRestriction.G.FD ReciprocityTheory.ChartRestriction.G.FD.EmbeddingHermitianPairs
open scoped ComplexConjugate

variable {E : Type} [Field E] [NumberField E] [IsCMField E] {r : ℕ}

lemma emb_real {τ : E →+* ℂ} {a : E} (ha : cc a = a) : τ a = ((τ a).re : ℂ) := by
  have h := NumberField.IsCMField.complexEmbedding_complexConj (K := E) τ a
  have h2 : (starRingEnd ℂ) (τ a) = τ a := by
    rw [← h]
    exact congrArg τ ha
  exact (Complex.conj_eq_iff_re.mp h2).symm

lemma cc_add' (a b : E) : cc (a + b) = cc a + cc b := by
  simp [cc]

lemma cc_neg' (a : E) : cc (-a) = -cc a := by
  simp [cc]

lemma cc_zero' : cc (0 : E) = 0 := by
  simp [cc]

variable (X : Data E r) (la : Wt X.Ψ r)

lemma chiOrd_pos : 0 < X.chiOrd la := (X.χ_fin la).choose_spec.1

noncomputable def per (a : E) : X.Ψ → ℝ := fun τ => ((X.m * X.chiOrd la : ℕ) : ℝ) * (τ.1 a).re

lemma per_add (a b : E) : per X la (a + b) = per X la a + per X la b := by
  funext τ
  simp [per, mul_add]

lemma per_neg (a : E) : per X la (-a) = -per X la a := by
  funext τ
  simp [per, Pi.neg_apply, Complex.neg_re, mul_neg]

lemma mem_periods_iff (p : X.Ψ → ℝ) :
    p ∈ X.periods la ↔ ∃ a : E, cc a = a ∧ IsIntegral ℤ a ∧ p = per X la a := by
  constructor
  · intro hp
    unfold Data.periods at hp
    induction hp using AddSubgroup.closure_induction with
    | mem q hq =>
      obtain ⟨a, h1, h2, rfl⟩ := hq
      exact ⟨a, h1, h2, rfl⟩
    | zero =>
      refine ⟨0, cc_zero', isIntegral_zero, ?_⟩
      funext τ
      simp [per]
    | add q q' _ _ hq hq' =>
      obtain ⟨a, ha1, ha2, rfl⟩ := hq
      obtain ⟨b, hb1, hb2, rfl⟩ := hq'
      exact ⟨a + b, by rw [cc_add', ha1, hb1], ha2.add hb2, (per_add X la a b).symm⟩
    | neg q _ hq =>
      obtain ⟨a, ha1, ha2, rfl⟩ := hq
      exact ⟨-a, by rw [cc_neg', ha1], ha2.neg, (per_neg X la a).symm⟩
  · rintro ⟨a, h1, h2, rfl⟩
    exact AddSubgroup.subset_closure ⟨a, h1, h2, rfl⟩

lemma finite_small : {p : X.Ψ → ℝ | p ∈ X.periods la ∧ ‖p‖ < 1}.Finite := by
  have h3 : 1 ≤ X.m * X.chiOrd la := Nat.mul_pos X.m_pos (chiOrd_pos X la)
  have hc : (1 : ℝ) ≤ ((X.m * X.chiOrd la : ℕ) : ℝ) := by exact_mod_cast h3
  have hfin := NumberField.Embeddings.finite_of_norm_le E ℂ 1
  refine (hfin.image (per X la)).subset ?_
  rintro p ⟨hp, hn⟩
  obtain ⟨a, ha, hai, rfl⟩ := (mem_periods_iff X la p).mp hp
  have hΨ : ∀ τ : X.Ψ, ‖τ.1 a‖ ≤ 1 := by
    intro τ
    have h1 : ‖per X la a τ‖ < 1 := lt_of_le_of_lt (norm_le_pi_norm (per X la a) τ) hn
    rw [emb_real (τ := τ.1) ha, Complex.norm_real, Real.norm_eq_abs]
    simp only [per, Real.norm_eq_abs, abs_mul] at h1
    have hc0 : (0 : ℝ) ≤ ((X.m * X.chiOrd la : ℕ) : ℝ) := Nat.cast_nonneg _
    rw [abs_of_nonneg hc0] at h1
    nlinarith [abs_nonneg (τ.1 a).re]
  refine ⟨a, ⟨hai, fun φ => ?_⟩, rfl⟩
  by_cases hφ : φ ∈ X.Ψ
  · exact hΨ ⟨φ, hφ⟩
  · have hc' : NumberField.ComplexEmbedding.conjugate φ ∈ X.Ψ := by
      by_contra hc'
      exact hφ ((X.cmType φ).mpr hc')
    have h4 := hΨ ⟨_, hc'⟩
    change ‖starRingEnd ℂ (φ a)‖ ≤ 1 at h4
    rwa [Complex.norm_conj] at h4

instance periods_discrete : DiscreteTopology (X.periods la) := by

  rw [discreteTopology_iff_isOpen_singleton_zero]
  apply isOpen_singleton_of_finite_mem_nhds (0 : X.periods la) (Metric.ball_mem_nhds _ zero_lt_one)
  apply ((finite_small X la).preimage Subtype.val_injective.injOn).subset
  intro q hq
  exact ⟨q.2, by simpa [Metric.mem_ball] using hq⟩

noncomputable def fixF : Subfield E :=
  (IsCMField.complexConj E).toRingEquiv.toRingHom.eqLocusField (RingHom.id E)

lemma cc_cc' (a : E) : cc (cc a) = a := by
  simp [cc, NumberField.IsCMField.complexConj_apply_apply]

lemma restrict_inj {τ τ' : X.Ψ} (h : ∀ a : E, cc a = a → τ.1 a = τ'.1 a) : τ = τ' := by
  have hp : InfinitePlace.mk τ.1 = InfinitePlace.mk τ'.1 := by
    apply DFunLike.ext
    intro x
    have hfix : cc (x * cc x) = x * cc x := by
      rw [show cc (x * cc x) = cc x * cc (cc x) from map_mul _ _ _, cc_cc', mul_comm]
    have hv := congrArg (fun z : ℂ => ‖z‖) (h (x * cc x) hfix)
    change ‖τ.1 x‖ = ‖τ'.1 x‖
    change ‖τ.1 (x * cc x)‖ = ‖τ'.1 (x * cc x)‖ at hv
    have hc (σ : E →+* ℂ) : σ (cc x) = conj (σ x) := IsCMField.complexEmbedding_complexConj E σ x
    simp [hc, norm_mul, Complex.norm_conj] at hv
    nlinarith [norm_nonneg (τ.1 x), norm_nonneg (τ'.1 x)]
  exact (QuadraticCoefficientForms.toCP_bij X).1 (Subtype.ext hp)

noncomputable def resChar (τ : X.Ψ) : (fixF (E := E)) →* ℂ := (τ.1.comp (fixF (E := E)).subtype).toMonoidHom


open Classical in
lemma periods_span : Submodule.span ℝ (X.periods la : Set (X.Ψ → ℝ)) = ⊤ := by
  by_contra hne
  obtain ⟨f, hf0, hle⟩ := Submodule.exists_le_ker_of_lt_top _ (lt_top_iff_ne_top.mpr hne)
  have hfv : ∀ v : X.Ψ → ℝ, f v = ∑ τ, v τ * f (fun j => if τ = j then 1 else 0) := fun v => by
    rw [LinearMap.pi_apply_eq_sum_univ f v]
    rfl
  have hM : ((X.m * X.chiOrd la : ℕ) : ℝ) ≠ 0 := by
    have h3 : 0 < X.m * X.chiOrd la := Nat.mul_pos X.m_pos (chiOrd_pos X la)
    exact_mod_cast h3.ne'

  have hvan : ∀ a : E, cc a = a → IsIntegral ℤ a →
      ∑ τ : X.Ψ, ((f (fun j => if τ = j then 1 else 0) : ℝ) : ℂ) * τ.1 a = 0 := by
    intro a ha hai
    have hmem : per X la a ∈ Submodule.span ℝ (X.periods la : Set (X.Ψ → ℝ)) :=
      Submodule.subset_span ((mem_periods_iff X la _).mpr ⟨a, ha, hai, rfl⟩)
    have h0 : f (per X la a) = 0 := LinearMap.mem_ker.mp (hle hmem)
    let p : X.Ψ → ℝ := fun τ => (τ.1 a).re
    change f (((X.m * X.chiOrd la : ℕ) : ℝ) • p) = 0 at h0
    rw [map_smul, smul_eq_mul] at h0
    have he := congrArg (fun x : ℝ => (x : ℂ)) ((hfv p).symm.trans ((mul_eq_zero.mp h0).resolve_left hM))
    push_cast at he
    have hre (τ : X.Ψ) : (p τ : ℂ) = τ.1 a := (emb_real ha).symm
    simpa only [hre, mul_comm] using he

  have vanish (u : fixF (E := E)) :
      ∑ τ : X.Ψ, ((f (fun j => if τ = j then 1 else 0) : ℝ) : ℂ) * τ.1 (u : E) = 0 := by
    have halg := (IsFractionRing.isAlgebraic_iff ℤ ℚ E).mpr (Algebra.IsAlgebraic.isAlgebraic (u : E))
    obtain ⟨d,hd,hi⟩ := halg.exists_integral_multiple
    have fixed : cc (d • (u : E)) = d • (u : E) := by
      change (IsCMField.complexConj E) (d • (u : E)) = _
      rw [map_zsmul]
      exact congrArg (d • ·) u.property
    have h := hvan _ fixed hi
    simp_rw [map_zsmul, zsmul_eq_mul, mul_left_comm _ (d : ℂ)] at h
    rw [← Finset.mul_sum] at h
    exact (mul_eq_zero.mp h).resolve_left (by exact_mod_cast hd)
  have inj : Function.Injective (resChar X) := fun _ _ h =>
    restrict_inj X fun a ha => DFunLike.congr_fun h ⟨a,ha⟩
  have hLI := (linearIndependent_monoidHom (fixF (E := E)) ℂ).comp _ inj
  have hsum : ∑ τ : X.Ψ, ((f (fun j => if τ = j then 1 else 0) : ℝ) : ℂ) •
      (resChar X τ : fixF (E := E) → ℂ) = 0 := by
    funext u
    simp [Finset.sum_apply, resChar, smul_eq_mul]
    exact vanish u
  have hzero := Fintype.linearIndependent_iff.mp hLI _ hsum
  apply hf0
  apply LinearMap.ext
  intro v
  rw [hfv v, LinearMap.zero_apply]
  refine Finset.sum_eq_zero fun τ _ => ?_
  rw [Complex.ofReal_eq_zero.mp (hzero τ), mul_zero]

def perL : Submodule ℤ (X.Ψ → ℝ) := (X.periods la).toIntSubmodule

instance perL_discrete : DiscreteTopology (perL X la) := periods_discrete X la

instance perL_isZLattice : IsZLattice ℝ (perL X la) := ⟨periods_span X la⟩


end ReciprocityTheory.ChartRestriction.G.FD.RealEmbeddingCharacters
