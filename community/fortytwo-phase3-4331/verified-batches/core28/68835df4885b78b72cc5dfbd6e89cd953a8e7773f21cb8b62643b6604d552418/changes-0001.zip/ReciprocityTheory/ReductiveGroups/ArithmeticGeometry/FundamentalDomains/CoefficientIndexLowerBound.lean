import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.QuadraticCoefficientForms

namespace ReciprocityTheory.ChartRestriction.G.FD

open Complex
open scoped ComplexConjugate ComplexOrder

variable {E : Type} [Field E] [NumberField E] [NumberField.IsCMField E]

private lemma log_product_gap {ι : Type} [Fintype ι] (v : ι → ℝ) (hv : ∀ i, 0 < v i) :
    Real.log (∏ i, v i) ≤ (∑ i, v i) - Fintype.card ι := by
  rw [Real.log_prod (fun i _ => (hv i).ne')]
  simpa [Finset.sum_sub_distrib] using
    Finset.sum_le_sum (s := Finset.univ) (fun i _ => Real.log_le_sub_one_of_pos (hv i))

private lemma card_le_sum_of_one_le_prod {ι : Type} [Fintype ι] [Nonempty ι] (z : ι → ℝ) (hz : ∀ i, 0 < z i)
    (h1 : 1 ≤ ∏ i, z i) : (Fintype.card ι : ℝ) ≤ ∑ i, z i := by
  linarith [log_product_gap z hz, Real.log_nonneg h1]

private lemma card_sq_div_le_two_mul_sum_of_bounds {ι : Type} [Fintype ι] [Nonempty ι] (d ν A R : ι → ℝ) (N NC k0 c1 ε : ℝ)
    (hN : 0 < N) (hNC : 0 < NC) (hk0 : 0 < k0) (hk2 : k0 ≤ 2) (hε : 0 < ε) (hc1 : 0 < c1)
    (hd : ∀ i, 0 < d i) (hν : ∀ i, 0 < ν i) (hνs : ∑ i, ν i ≤ c1)
    (hprod : 1 ≤ ∏ i, (N ^ 2 * d i))
    (hA : ∀ i, 1 / (NC ^ 2 * k0 * ε) ≤ A i)
    (hq : ∀ i, d i * A i ≤ ν i * R i) :
    (Fintype.card ι : ℝ) ^ 2 / (N ^ 2 * NC ^ 2 * c1 * ε) ≤ 2 * ∑ i, R i := by
  let K := NC ^ 2 * k0 * ε
  have hK : 0 < K := by dsimp [K]; positivity
  have hden (i : ι) : d i ≤ (ν i * R i) * K := (div_le_iff₀ hK).1 (by
    simpa [div_eq_mul_inv, K] using (mul_le_mul_of_nonneg_left (hA i) (hd i).le).trans (hq i))
  have hR (i : ι) : 0 ≤ R i := by
    by_contra! h
    exact (not_lt_of_ge (hd i).le) ((hden i).trans_lt (mul_neg_of_neg_of_pos (mul_neg_of_pos_of_neg (hν i) h) hK))
  have hterm (i : ι) : 0 < N ^ 2 * d i := mul_pos (sq_pos_of_pos hN) (hd i)
  have hn := card_le_sum_of_one_le_prod (fun i => Real.sqrt (N ^ 2 * d i))
    (fun i => Real.sqrt_pos.mpr (hterm i)) (by
      rw [← Real.sqrt_prod Finset.univ (fun i _ => (hterm i).le), Real.one_le_sqrt]; exact hprod)
  have hcs := Finset.sum_sq_le_sum_mul_sum_of_sq_le_mul Finset.univ (r := fun i => Real.sqrt (N ^ 2 * d i))
    (fun i _ => (hν i).le) (fun i _ => mul_nonneg (mul_nonneg (sq_nonneg N) hK.le) (hR i)) (fun i _ => by
      rw [Real.sq_sqrt (hterm i).le]; nlinarith only [mul_le_mul_of_nonneg_left (hden i) (sq_nonneg N)])
  rw [← Finset.mul_sum] at hcs
  have hs := Finset.sum_nonneg (s := Finset.univ) (fun i _ => hR i)
  rw [div_le_iff₀ (by positivity)]
  calc _ ≤ _ := (pow_le_pow_left₀ (Nat.cast_nonneg _) hn 2).trans hcs
       _ ≤ c1 * ((N ^ 2 * (NC ^ 2 * 2 * ε)) * ∑ i, R i) := by dsimp [K]; gcongr
       _ = _ := by ring


theorem coefficient_index_lower_bound (h2 : UnipotentLatticeLift (E := E)) (h3d : FourierCoefficientSupport (E := E))
    (h5 : NonvanishingCoefficientPositivity (E := E)) : CoefficientIndexLowerBound (E := E) := by
  intro r X la P ξ ν c1 w z0 x a ε hS hε hmaj χ hy
  obtain ⟨hH, hxL, hxξ, hxx, hne, hu0, hu⟩ := hS
  obtain ⟨_, hSS, hIso, hc1, hνc1, _, _, _, hchar, hz0, _⟩ := hH
  have hpair := FlowIsotropicPairs.isIsoPair_of X hIso hxξ hxx hne
  have hmem := FlowIsotropicPairs.mem_pair X hIso hxL
  obtain ⟨y, hyd, hy⟩ := hy
  have hHF : IsHermFam χ ∧ X.IsFreqZ X.g χ := by
    by_contra hn
    apply hy
    unfold Data.fz
    rw [if_neg hn]
  have heq := h3d r X ![ξ,(X.NC : E) • x] hpair hmem la P hSS.1.1 hchar ν χ y hyd
  by_cases hcond : ∀ τ, χ τ 0 0 = (ν τ : ℂ)
  swap
  · rw [if_neg hcond] at heq
    exact (hy heq).elim
  rw [if_pos hcond] at heq
  have hy' : X.fz ![ξ,(X.NC : E) • x] X.g χ P y ≠ 0 := fun hz => hy (heq.trans hz)
  have hPD := h5 r X ![ξ, (X.NC : E) • x] hpair hmem la P hSS hchar χ ⟨y, hyd, hy'⟩
  obtain ⟨β, -, hβ, hβint⟩ := (h2 r X ![ξ, (X.NC : E) • x] hpair hmem).2.2 χ hHF.1 hHF.2
  have hne0 : Nonempty X.Ψ := Fintype.card_pos_iff.mp (QuadraticCoefficientForms.card_Psi_pos (X := X.toData))

  have hz0dom : z0 ∈ X.dom := hz0.1
  have hmpos : ∀ τ, 0 < X.maj z0 τ (X.ucomp z0 ξ (X.embV x) τ) :=
    fun τ => X.maj_pos hz0dom τ (hu0 τ)
  have hck : ∀ τ, X.c τ = X.k0 := by
    intro τ
    show 2 * ‖τ.1 X.ξ0‖ = X.k0
    rw [X.ξ0_abs τ]
    ring

  have ha1 : ∀ τ, Complex.normSq (a τ 1) *
      ((X.NC : ℝ) ^ 2 * X.k0 * X.maj z0 τ (X.ucomp z0 ξ (X.embV x) τ)) = 1 := by
    intro τ
    let M := X.maj z0 τ (X.ucomp z0 ξ (X.embV x) τ)
    let T : ℂ := (Real.sqrt (X.c τ * M) : ℂ)⁻¹
    have h := hu τ
    change _ = T • _ at h
    have hV : X.ucomp z0 ξ (X.embV x) τ = Data.emb τ.1 x -
        (X.Hf z0 τ (Data.emb τ.1 x) (Data.emb τ.1 ξ) / X.Hf z0 τ (Data.emb τ.1 ξ) (Data.emb τ.1 ξ)) •
          Data.emb τ.1 ξ := rfl
    have hU : X.uvec ![ξ, (X.NC : E) • x] a τ =
        a τ 0 • Data.emb τ.1 ξ + a τ 1 • ((X.NC : ℂ) • Data.emb τ.1 x) := by
      ext i
      simp [Data.uvec, Data.emb, Fin.sum_univ_two, smul_eq_mul, map_mul, map_natCast]
    rw [hU, hV] at h
    set S := X.Hf z0 τ (Data.emb τ.1 x) (Data.emb τ.1 ξ) / X.Hf z0 τ (Data.emb τ.1 ξ) (Data.emb τ.1 ξ)
    have h0 : (a τ 0 + T * S) • Data.emb τ.1 ξ + (a τ 1 * X.NC - T) • Data.emb τ.1 x = 0 := by
      ext i
      have hi := congrFun h i
      simp only [Pi.add_apply, Pi.smul_apply, Pi.sub_apply, smul_eq_mul, Pi.zero_apply] at hi ⊢
      linear_combination hi
    have hq := QuadraticCoefficientForms.coef_zero hIso.2.2 hne τ.1 _ _ h0
    have hTa : a τ 1 * X.NC = T := sub_eq_zero.mp hq
    have hp : 0 < X.c τ * M := mul_pos (hck τ ▸ X.minWeight_pos) (hmpos τ)
    have hnorm : Complex.normSq (a τ 1) * (X.NC : ℝ)^2 = (X.c τ * M)⁻¹ := by
      have he := congrArg Complex.normSq hTa
      simpa only [Complex.normSq_mul, Complex.normSq_natCast, T, map_inv₀, Complex.normSq_ofReal,
        Real.mul_self_sqrt hp.le, pow_two] using he
    rw [← hck τ]
    change Complex.normSq (a τ 1) * (_ * X.c τ * M) = 1
    linear_combination (X.c τ * M) * hnorm + inv_mul_cancel₀ hp.ne'

  have hχβ : ∀ (τ : X.Ψ) i k, χ τ i k = τ.1 (β i k) := by
    intro τ i k; rw [hβ]; rfl
  have hdpos (τ) := Complex.pos_iff.mp (hPD τ).det_pos
  have hνpos : ∀ τ, 0 < ν τ := by
    intro τ
    have h := (hPD τ).diag_pos (i := 0)
    rw [Matrix.of_apply, hcond τ] at h
    exact_mod_cast h

  set Nn : ℕ := X.g * dEnat E ^ 2 with hNn
  have hdE : dE E = (dEnat E : ℝ) := by
    unfold dE dEnat
    rw [Nat.cast_natAbs, Int.cast_abs]
  have hNpos : 0 < (X.g : ℝ) * dE E ^ 2 := by
    rw [hdE]
    have h1 : 0 < dEnat E := Int.natAbs_pos.mpr (NumberField.discr_ne_zero E)
    have h2 := X.g_pos
    positivity
  have hNcast : ((Nn : ℕ) : ℝ) = (X.g : ℝ) * dE E ^ 2 := by
    rw [hNn, hdE]; push_cast; ring
  set γ : E := ((Nn : E)*β 0 0) * ((Nn : E)*β 1 1) - ((Nn : E)*β 0 1) * ((Nn : E)*β 1 0) with hγ
  have hint : IsIntegral ℤ γ :=
    ((hβint 0 0).mul (hβint 1 1)).sub ((hβint 0 1).mul (hβint 1 0))
  have hγτ : ∀ τ : X.Ψ, τ.1 γ = ((Nn : ℂ)) ^ 2 * (Matrix.of (χ τ)).det := by
    intro τ
    rw [Matrix.det_fin_two, Matrix.of_apply, Matrix.of_apply, Matrix.of_apply, Matrix.of_apply,
      hχβ, hχβ, hχβ, hχβ, hγ]
    simp only [map_sub, map_mul, map_natCast, hNn]
    push_cast
    ring
  have hnorm : ∀ τ : X.Ψ, ‖τ.1 γ‖ = ((X.g : ℝ) * dE E ^ 2) ^ 2 * (Matrix.of (χ τ)).det.re := by
    intro τ
    rw [hγτ τ, norm_mul, norm_pow, Complex.norm_natCast, hNcast,
      ← Complex.abs_re_eq_norm.mpr (hdpos τ).2.symm, abs_of_pos (hdpos τ).1]
  have hγ0 : γ ≠ 0 := by
    intro h0
    obtain ⟨τ⟩ := hne0
    have := hnorm τ
    rw [h0, map_zero, norm_zero] at this
    exact (mul_pos (sq_pos_of_pos hNpos) (hdpos τ).1).ne' this.symm
  have hp := QuadraticCoefficientForms.one_le_prod_norm (X := X.toData) γ hint hγ0
  simp_rw [hnorm] at hp
  rw [Finset.prod_pow] at hp
  have hprod : 1 ≤ ∏ τ : X.Ψ, (((X.g : ℝ) * dE E ^ 2) ^ 2 * (Matrix.of (χ τ)).det.re) := by
    apply (one_le_pow_iff_of_nonneg (Finset.prod_nonneg fun τ _ => mul_nonneg (sq_nonneg _) (hdpos τ).1.le) two_ne_zero).mp
    exact hp

  have hq : ∀ τ : X.Ψ, (Matrix.of (χ τ)).det.re * Complex.normSq (a τ 1) ≤
      ν τ * (X.chiAt χ a τ).re := by
    intro τ
    have h := QuadraticCoefficientForms.quad2 (Matrix.of (χ τ)) (hPD τ).1 (a τ)
    simp only [Matrix.of_apply] at h
    rw [hcond τ, Complex.ofReal_re] at h
    exact h
  have hA : ∀ τ : X.Ψ, 1 / ((X.NC : ℝ) ^ 2 * X.k0 * ε) ≤ Complex.normSq (a τ 1) := by
    intro τ
    have hNC : (0 : ℝ) < X.NC := by exact_mod_cast X.NC_pos
    have hk := X.minWeight_pos
    rw [div_le_iff₀ (by positivity), ← ha1 τ]
    exact mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left (hmaj τ) (by positivity)) (Complex.normSq_nonneg _)
  have key := card_sq_div_le_two_mul_sum_of_bounds (fun τ : X.Ψ => (Matrix.of (χ τ)).det.re) ν (fun τ => Complex.normSq (a τ 1))
    (fun τ => (X.chiAt χ a τ).re) ((X.g : ℝ) * dE E ^ 2) (X.NC : ℝ) X.k0 c1 ε hNpos
    (by exact_mod_cast X.NC_pos) X.minWeight_pos X.k0_le hε hc1 (fun τ => (hdpos τ).1) hνpos hνc1 hprod hA hq
  rw [QuadraticCoefficientForms.card_Psi (X := X.toData)] at key
  exact key

end ReciprocityTheory.ChartRestriction.G.FD
