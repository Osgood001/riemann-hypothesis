import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.UnipotentSubOneMajorantBound

namespace ReciprocityTheory.ChartRestriction.G.FD

open NumberField Complex
open scoped ComplexConjugate

variable {E : Type} [Field E] [NumberField E] [IsCMField E]

namespace Data

variable {r : ℕ} (X : Data E r)

lemma Hf_unitary (x : Frame X.Ψ r) (τ : X.Ψ) (g : Matrix (Fin r) (Fin r) ℂ)
    (hg : ∀ u w, hermC τ.1 X.Gm (Matrix.mulVec g u) (Matrix.mulVec g w) = hermC τ.1 X.Gm u w)
    (hx : x ∈ X.dom) (y w : Fin r → ℂ) :
    X.Hf (X.lmulC (fun _ => g) x) τ (Matrix.mulVec g y) (Matrix.mulVec g w) = X.Hf x τ y w := by
  simpa only [X.Hf_eq_two_ppos, X.ppos_unitary x τ g hg hx, hg]

lemma ppos_mat_eq {x x' : Frame X.Ψ r} {τ : X.Ψ} (h : mat x τ = mat x' τ) (v : Fin r → ℂ) :
    X.ppos x τ v = X.ppos x' τ v := by
  simp [Data.ppos, Data.gramPos, h]

private lemma ppos_at (n : X.Ψ → Matrix (Fin r) (Fin r) ℂ) (x : Frame X.Ψ r) (τ : X.Ψ) (v : Fin r → ℂ) :
    X.ppos (X.lmulC n x) τ v = X.ppos (X.lmulC (fun _ => n τ) x) τ v :=
  X.ppos_mat_eq (show mat (X.lmulC n x) τ = mat (X.lmulC (fun _ => n τ) x) τ from rfl) v

lemma majorant_bound_orthogonal_part (ξ : Fin r → E) (x : Frame X.Ψ r) (hx : x ∈ X.dom)
    (δ : X.Ψ → (Fin r → ℂ) →ₗ[ℂ] ℂ) (κ : ℝ)
    (hδ : ∀ u ∈ X.Uz x ξ, ∀ τ, X.maj x τ (δ τ (u τ) • emb τ.1 ξ) ≤ κ ^ 2 * X.maj x τ (u τ))
    (τ : X.Ψ) (w : Fin r → ℂ) (hw1 : hermC τ.1 X.Gm w (emb τ.1 ξ) = 0)
    (hw2 : hermC τ.1 X.Gm w (X.Jp x τ (emb τ.1 ξ)) = 0) :
    X.maj x τ (δ τ w • emb τ.1 ξ) ≤ κ ^ 2 * X.maj x τ w := by
  classical
  let u : X.Ψ → Fin r → ℂ := fun τ' => if τ' = τ then w else 0
  have hu : u ∈ X.Uz x ξ := by
    refine ⟨fun σ => ?_, fun σ => ?_⟩ <;> by_cases h : σ = τ
    · subst σ; simpa [u] using hw1
    · simp [u, h, hC_zero_left]
    · subst σ
      change hermC τ.1 X.Gm (I • X.Jp x τ (u τ)) _ = 0
      simp [u, hermC_smul_left, X.Jp_adj hx, hw2]
    · simp [Data.Jz, u, h, X.ppos_zero, hC_zero_left]
  have hmain := hδ u hu τ
  simpa [u] using hmain

set_option maxHeartbeats 1000000 in
theorem unipotent_majorant_for_move (X : Data E r) (ξ : Fin r → E) (hξ : X.IsIso ξ)
    (x : Frame X.Ψ r) (hx : x ∈ X.dom) (δ : X.Ψ → (Fin r → ℂ) →ₗ[ℂ] ℂ)
    (κ : ℝ) (hκ0 : 0 ≤ κ) (hκ1 : κ ≤ 1)
    (hδ : ∀ u ∈ X.Uz x ξ, ∀ τ, X.maj x τ (δ τ (u τ) • emb τ.1 ξ) ≤ κ ^ 2 * X.maj x τ (u τ)) :
    ∃ n, X.IsUnitaryC n ∧ (∀ τ, (n τ).mulVec (emb τ.1 ξ) = emb τ.1 ξ) ∧
      (∀ u ∈ X.Iperp ξ, X.aproj (X.lmulC n x) ξ u = X.aproj x ξ u -
        X.lineV ξ (fun τ => δ τ (X.ucomp x ξ u τ))) ∧
      (∀ u ∈ X.Uz x ξ, X.ucomp (X.lmulC n x) ξ (X.Jz x u) =
        X.Jz (X.lmulC n x) (X.ucomp (X.lmulC n x) ξ u)) ∧
      ∀ (τ : X.Ψ) (v : Fin r → ℂ), X.maj x τ ((n τ - 1).mulVec v) ≤ (3 * κ) ^ 2 * X.maj x τ v := by
  have hCsub : ∀ (τ : X.Ψ) (u v w : Fin r → ℂ) (c : ℂ),
      hermC τ.1 X.Gm (u - c • v) w = hermC τ.1 X.Gm u w - c * hermC τ.1 X.Gm v w := by
    intro τ u v w c
    rw [hermC_sub_left, hermC_smul_left]
  have hee (τ : X.Ψ) : hermC τ.1 X.Gm (emb τ.1 ξ) (emb τ.1 ξ) = 0 := by
    rw [← emb_herm, hξ.2.1, map_zero]
  have he0 (τ : X.Ψ) : emb τ.1 ξ ≠ 0 := emb_ne_zero τ.1 hξ.2.2
  have hq : ∀ τ : X.Ψ, X.Hf x τ (emb τ.1 ξ) (emb τ.1 ξ) = (X.maj x τ (emb τ.1 ξ) : ℂ) :=
    fun τ => X.Hf_self hx τ _
  have hqne : ∀ τ : X.Ψ, X.Hf x τ (emb τ.1 ξ) (emb τ.1 ξ) ≠ 0 := by
    intro τ
    rw [hq τ]
    exact_mod_cast (X.maj_pos hx τ (he0 τ)).ne'
  have hHfJ : ∀ τ v, X.Hf x τ v (emb τ.1 ξ) = hermC τ.1 X.Gm v (X.Jp x τ (emb τ.1 ξ)) :=
    fun τ v => by rw [X.Hf_eq x hx]; rfl
  set N : X.Ψ → Matrix (Fin r) (Fin r) ℂ := fun τ => X.d2n x τ (emb τ.1 ξ) (δ τ) with hN
  have hqr : ∀ τ : X.Ψ, conj (X.d2q x τ (emb τ.1 ξ)) = X.d2q x τ (emb τ.1 ξ) := by
    intro τ
    show conj (X.Hf x τ _ _) = X.Hf x τ _ _
    rw [hq τ]
    exact Complex.conj_ofReal _
  have hU : ∀ τ u w, hermC τ.1 X.Gm ((N τ).mulVec u) ((N τ).mulVec w) = hermC τ.1 X.Gm u w :=
    fun τ u w => X.unipotent_transform_unitary (x := x) (τ := τ) (e := emb τ.1 ξ) (δ := δ τ) hx (hee τ) (hqne τ) (hqr τ) u w
  have hNe : ∀ τ, (N τ).mulVec (emb τ.1 ξ) = emb τ.1 ξ :=
    fun τ => X.unipotent_fixes_e (x := x) (τ := τ) (e := emb τ.1 ξ) (δ := δ τ) hx (hee τ) (hqne τ)
  have hHfN : ∀ τ v w, X.Hf (X.lmulC N x) τ ((N τ).mulVec v) ((N τ).mulVec w) = X.Hf x τ v w :=
    fun τ v w => by
      simpa only [Data.Hf, ppos_at X N x τ] using X.Hf_unitary x τ (N τ) (hU τ) hx v w
  have hπsub : ∀ τ v (c : ℂ),
      X.d2pi x τ (emb τ.1 ξ) (v - c • emb τ.1 ξ) = X.d2pi x τ (emb τ.1 ξ) v := by
    intro τ v c
    rw [map_sub, map_smul, X.hyperbolic_projection_e hx (hee τ) (hqne τ), smul_zero, sub_zero]
  have hNinv : ∀ τ v, hermC τ.1 X.Gm v (emb τ.1 ξ) = 0 →
      (N τ).mulVec (v - δ τ (X.d2pi x τ (emb τ.1 ξ) v) • emb τ.1 ξ) = v := by
    intro τ v hv
    have hperp : hermC τ.1 X.Gm (v - δ τ (X.d2pi x τ (emb τ.1 ξ) v) • emb τ.1 ξ) (emb τ.1 ξ) = 0 := by
      rw [hCsub, hv, hee τ, mul_zero, sub_zero]
    rw [X.unipotent_on_orthogonal_e (x := x) (τ := τ) (e := emb τ.1 ξ) (δ := δ τ) hx (hee τ) (hqne τ) hperp, hπsub]
    simp
  have hHfperp : ∀ τ v, hermC τ.1 X.Gm v (emb τ.1 ξ) = 0 →
      X.Hf (X.lmulC N x) τ v (emb τ.1 ξ) = X.Hf x τ v (emb τ.1 ξ) -
        δ τ (X.d2pi x τ (emb τ.1 ξ) v) * X.Hf x τ (emb τ.1 ξ) (emb τ.1 ξ) := by
    intro τ v hv
    have h1 := hHfN τ (v - δ τ (X.d2pi x τ (emb τ.1 ξ) v) • emb τ.1 ξ) (emb τ.1 ξ)
    rw [hNinv τ v hv, hNe τ] at h1
    rw [h1, X.Hf_eq x hx, X.Hf_eq x hx, X.Hf_eq x hx, hCsub]
  have hHfee : ∀ τ, X.Hf (X.lmulC N x) τ (emb τ.1 ξ) (emb τ.1 ξ) =
      X.Hf x τ (emb τ.1 ξ) (emb τ.1 ξ) := by
    intro τ
    have h1 := hHfN τ (emb τ.1 ξ) (emb τ.1 ξ)
    rwa [hNe τ] at h1
  have huz : ∀ u ∈ X.Uz x ξ, ∀ τ, hermC τ.1 X.Gm (u τ) (X.Jp x τ (emb τ.1 ξ)) = 0 := by
    intro u hu τ
    have h := hu.2 τ
    change hermC τ.1 X.Gm (I • X.Jp x τ (u τ)) _ = 0 at h
    simpa [hermC_smul_left, X.Jp_adj hx] using h
  have hπperp : ∀ τ v, hermC τ.1 X.Gm v (emb τ.1 ξ) = 0 →
      X.d2pi x τ (emb τ.1 ξ) v = v - (X.Hf x τ v (emb τ.1 ξ) /
        X.Hf x τ (emb τ.1 ξ) (emb τ.1 ξ)) • emb τ.1 ξ := by
    intro τ v hv
    rw [X.hyperbolic_projection_apply, X.hyperbolic_coeff_a_apply, X.hyperbolic_coeff_b_apply, hv, mul_zero, zero_smul, sub_zero, hHfJ τ v,
      div_eq_inv_mul]
    rfl
  refine ⟨N, hU, hNe, ?_, ?_, ?_⟩
  · intro u hu
    funext τ
    simp only [Data.aproj, Data.lineV, Pi.sub_apply, Data.ucomp]
    rw [hHfperp τ (u τ) (hu τ), hHfee τ, hπperp τ (u τ) (hu τ), ← sub_smul]
    congr 1
    field_simp [hqne τ]
  · intro u hu
    funext τ
    have hw1 : hermC τ.1 X.Gm (u τ) (emb τ.1 ξ) = 0 := hu.1 τ
    have hw2 := huz u hu τ
    have hJw : hermC τ.1 X.Gm (X.Jp x τ (u τ)) (emb τ.1 ξ) = 0 := by
      rw [X.Jp_adj hx]
      exact hw2
    have hIJw : hermC τ.1 X.Gm (I • X.Jp x τ (u τ)) (emb τ.1 ξ) = 0 := by
      rw [hermC_smul_left, hJw, mul_zero]
    have hπw : X.d2pi x τ (emb τ.1 ξ) (u τ) = u τ :=
      X.hyperbolic_projection_of_perp (x := x) (τ := τ) (e := emb τ.1 ξ) hx (hee τ) (hqne τ) hw1 hw2
    have hHfw : X.Hf (X.lmulC N x) τ (u τ) (emb τ.1 ξ) =
        -(δ τ (u τ) * X.Hf x τ (emb τ.1 ξ) (emb τ.1 ξ)) := by
      rw [hHfperp τ (u τ) hw1, hHfJ τ (u τ), hw2, hπw, zero_sub]
    have hHfIJw : X.Hf (X.lmulC N x) τ (I • X.Jp x τ (u τ)) (emb τ.1 ξ) =
        -(δ τ (X.d2pi x τ (emb τ.1 ξ) (I • X.Jp x τ (u τ))) *
          X.Hf x τ (emb τ.1 ξ) (emb τ.1 ξ)) := by
      rw [hHfperp τ _ hIJw, hHfJ τ, hermC_smul_left, X.Jp_adj hx, X.Jp_Jp hx, hw1, mul_zero, zero_sub]
    have hJpN (v) : X.Jp (X.lmulC N x) τ ((N τ).mulVec v) = (N τ).mulVec (X.Jp x τ v) := by
      have hp : X.ppos (X.lmulC N x) τ ((N τ).mulVec v) = (N τ).mulVec (X.ppos x τ v) := by
        rw [ppos_at X N x τ]
        exact X.ppos_unitary x τ (N τ) (hU τ) hx v
      simp only [Data.Jp, hp, Matrix.mulVec_sub, Matrix.mulVec_smul]
    have hNw : (N τ).mulVec (u τ) = u τ + δ τ (u τ) • emb τ.1 ξ :=
      X.unipotent_on_hyperbolic_complement (x := x) (τ := τ) (e := emb τ.1 ξ) (δ := δ τ) hx (hee τ) (hqne τ) hw1 hw2
    have hNJw : (N τ).mulVec (X.Jp x τ (u τ)) = X.Jp x τ (u τ) +
        δ τ (X.d2pi x τ (emb τ.1 ξ) (X.Jp x τ (u τ))) • emb τ.1 ξ :=
      X.unipotent_on_orthogonal_e (x := x) (τ := τ) (e := emb τ.1 ξ) (δ := δ τ) hx (hee τ) (hqne τ) hJw
    have hJz : X.Jz x u τ = I • X.Jp x τ (u τ) := rfl
    have hq0 := hqne τ
    show X.Jz x u τ - (X.Hf (X.lmulC N x) τ (X.Jz x u τ) (emb τ.1 ξ) /
        X.Hf (X.lmulC N x) τ (emb τ.1 ξ) (emb τ.1 ξ)) • emb τ.1 ξ =
      I • X.Jp (X.lmulC N x) τ (u τ - (X.Hf (X.lmulC N x) τ (u τ) (emb τ.1 ξ) /
        X.Hf (X.lmulC N x) τ (emb τ.1 ξ) (emb τ.1 ξ)) • emb τ.1 ξ)
    rw [hJz, hHfIJw, hHfw, hHfee τ, neg_div, neg_div, mul_div_assoc, div_self hq0, mul_one,
      mul_div_assoc, div_self hq0, mul_one, neg_smul, neg_smul, sub_neg_eq_add, sub_neg_eq_add,
      ← hNw, hJpN, hNJw, map_smul, map_smul, smul_eq_mul, smul_add, smul_smul]
  · intro τ v
    exact X.unipotent_sub_one_majorant_bound (x := x) (τ := τ) (e := emb τ.1 ξ) (δ := δ τ) hx (hee τ) (hqne τ)
      (fun v => X.Hf_self hx τ v) (fun v hv => X.maj_pos hx τ hv) κ hκ0 hκ1
      (fun w hw1 hw2 => X.majorant_bound_orthogonal_part ξ x hx δ κ hδ τ w hw1 hw2) v

end Data

end ReciprocityTheory.ChartRestriction.G.FD
