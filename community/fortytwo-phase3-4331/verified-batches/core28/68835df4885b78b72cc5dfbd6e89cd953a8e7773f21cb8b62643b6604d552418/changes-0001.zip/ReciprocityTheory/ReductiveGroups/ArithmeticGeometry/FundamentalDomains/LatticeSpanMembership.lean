import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.MajorantOperators

namespace ReciprocityTheory.ChartRestriction.G.FD

namespace LatticeSpanMembership

open NumberField Complex Module
open scoped ComplexConjugate

variable {E : Type} [Field E] [NumberField E] [IsCMField E] {r : ℕ} {X : Data E r}

theorem span_emb_int (hD3 : IntegerApproximationCount (E := E)) :
    Submodule.span ℝ (Set.range fun α : 𝓞 E => fun τ : X.Ψ => τ.1 (α : E)) = ⊤ := by
  by_contra hne
  obtain ⟨f, hf0, hfW⟩ :=
    Submodule.exists_dual_map_eq_bot_of_lt_top (lt_top_iff_ne_top.mpr hne) inferInstance
  obtain ⟨v, hv⟩ : ∃ v, f v ≠ 0 := by
    by_contra! h
    exact hf0 (LinearMap.ext h)
  let g := LinearMap.toContinuousLinearMap f
  set ρ : ℝ := 2 * (fdeg E : ℝ) ^ 2 * rdE E with hρ
  have hρ0 : 0 ≤ ρ := by
    have : 0 ≤ rdE E := Real.rpow_nonneg (abs_nonneg _) _
    positivity
  set t : ℝ := (‖g‖ * ρ + 1) / f v with ht
  obtain ⟨α, hα⟩ := (hD3 r X).1 (t • v)
  have hfα : f (fun τ : X.Ψ => τ.1 (α : E)) = 0 := by
    exact hfW.le (Submodule.mem_map_of_mem (Submodule.subset_span ⟨α, rfl⟩))
  have hnorm : ‖(fun τ : X.Ψ => τ.1 (α : E)) - t • v‖ ≤ ρ := by
    refine (pi_norm_le_iff_of_nonneg hρ0).mpr fun τ => ?_
    exact hα τ
  have hle := g.le_opNorm ((fun τ : X.Ψ => τ.1 (α : E)) - t • v)
  have hg : g ((fun τ : X.Ψ => τ.1 (α : E)) - t • v) = -(‖g‖ * ρ + 1) := by
    show f ((fun τ : X.Ψ => τ.1 (α : E)) - t • v) = _
    rw [map_sub, map_smul, hfα, smul_eq_mul, ht, div_mul_cancel₀ _ hv, zero_sub]
  rw [hg, norm_neg, Real.norm_eq_abs, abs_of_pos (by positivity)] at hle
  nlinarith [norm_nonneg g, mul_le_mul_of_nonneg_left hnorm (norm_nonneg g)]

theorem exists_nat_mul_int (c : E) : ∃ N : ℕ, 0 < N ∧ IsIntegral ℤ ((N : E) * c) := by
  obtain ⟨y, hy, hi⟩ := ((IsFractionRing.isAlgebraic_iff ℤ ℚ E).mpr
    (Algebra.IsAlgebraic.isAlgebraic c)).exists_integral_multiple
  refine ⟨y.natAbs, Int.natAbs_pos.mpr hy, ?_⟩
  rcases y.natAbs_eq with h | h
  · rw [h] at hi
    simpa only [zsmul_eq_mul, Int.cast_natCast] using hi
  · rw [h, neg_smul] at hi
    simpa only [neg_neg, zsmul_eq_mul, Int.cast_natCast] using hi.neg

theorem exists_nat_smul_mem (v : Fin r → E) : ∃ N : ℕ, 0 < N ∧ (N : E) • v ∈ X.Λ := by
  have hv : v ∈ Submodule.span E (X.Λ : Set (Fin r → E)) := X.Λ_span ▸ Submodule.mem_top
  obtain ⟨d, hd, hmem⟩ := HermitianTraceFormVanishing.exists_smul_mem (F := E) X.Λ hv
  obtain ⟨N, hN, hInt⟩ := exists_nat_mul_int (d : E)⁻¹
  have hdE : (d : E) ≠ 0 := fun h => hd (Subtype.ext h)
  let b : 𝓞 E := ⟨_, hInt⟩
  have h := X.Λ.smul_mem b hmem
  refine ⟨N, hN, ?_⟩
  change ((N : E) * (d : E)⁻¹) • ((d : E) • v) ∈ X.Λ at h
  simpa only [smul_smul, mul_assoc, inv_mul_cancel₀ hdE, mul_one] using h

theorem mem_Λp_iff {ξ μ : Fin r → E} : μ ∈ X.Λp ξ ↔ μ ∈ X.Λ ∧ herm X.Gm μ ξ = 0 := by
  unfold Data.Λp
  rw [AddSubgroup.mem_inf, AddMonoidHom.mem_ker]
  rfl

theorem smul_int_mem {α : E} (hα : IsIntegral ℤ α) {v : Fin r → E} (hv : v ∈ X.Λ) : α • v ∈ X.Λ := by
  exact X.Λ.smul_mem (⟨α, hα⟩ : 𝓞 E) hv

noncomputable def single (a : Fin r) : (X.Ψ → ℂ) →ₗ[ℝ] (X.Ψ → Fin r → ℂ) :=
  (LinearMap.single ℝ (fun _ : Fin r => ℂ) a).compLeft X.Ψ

theorem mem_span_Λ (hD3 : IntegerApproximationCount (E := E)) (v : X.Ψ → Fin r → ℂ) :
    v ∈ Submodule.span ℝ (X.embV '' (X.Λ : Set (Fin r → E))) := by
  classical
  have hsing : ∀ (a : Fin r) (s : X.Ψ → ℂ),
      single (X := X) a s ∈ Submodule.span ℝ (X.embV '' (X.Λ : Set (Fin r → E))) := by
    intro a s
    obtain ⟨N, hN, hNmem⟩ := exists_nat_smul_mem (X := X) (Pi.single a 1)
    have hgen : Submodule.span ℝ (Set.range fun α : 𝓞 E => fun τ : X.Ψ => τ.1 (α : E)) ≤
        (Submodule.span ℝ (X.embV '' (X.Λ : Set (Fin r → E)))).comap (single (X := X) a) := by
      rw [Submodule.span_le]
      rintro _ ⟨α, rfl⟩
      have hmem : (α : E) • ((N : E) • Pi.single a 1) ∈ X.Λ := smul_int_mem α.isIntegral_coe hNmem
      have hN0 : (N : ℝ) ≠ 0 := by exact_mod_cast hN.ne'
      have e : single (X := X) a (fun τ : X.Ψ => τ.1 (α : E)) =
          (N : ℝ)⁻¹ • X.embV ((α : E) • ((N : E) • Pi.single a 1)) := by
        funext τ b
        change (Pi.single a (τ.1 (α : E)) : Fin r → ℂ) b = _
        simp only [Pi.smul_apply, Data.embV, Data.emb,
          smul_eq_mul]
        by_cases hb : b = a
        · subst hb
          have hNc : (N : ℂ) ≠ 0 := by exact_mod_cast hN.ne'
          simp only [Pi.single_eq_same, mul_one, map_mul, map_natCast, Complex.real_smul]
          push_cast
          field_simp
        · simp [Pi.single_eq_of_ne hb]
      rw [SetLike.mem_coe, Submodule.mem_comap]
      show single (X := X) a (fun τ : X.Ψ => τ.1 (α : E)) ∈ _
      rw [e]
      exact Submodule.smul_mem _ _ (Submodule.subset_span ⟨_, hmem, rfl⟩)
    exact hgen (x := s) (by rw [span_emb_int hD3]; exact Submodule.mem_top)
  have hv : v = ∑ a : Fin r, single (X := X) a (fun τ => v τ a) := by
    funext τ b
    simp [single, LinearMap.compLeft, Finset.sum_apply, Pi.single_apply]
  rw [hv]
  exact Submodule.sum_mem _ fun a _ => hsing a _

theorem scal_closed (hD3 : IntegerApproximationCount (E := E)) {ξ : Fin r → E} {w : X.Ψ → Fin r → ℂ}
    (hw : w ∈ Submodule.span ℝ (X.embV '' (X.Λp ξ : Set (Fin r → E)))) (s : X.Ψ → ℂ) :
    (fun τ => s τ • w τ) ∈ Submodule.span ℝ (X.embV '' (X.Λp ξ : Set (Fin r → E))) := by
  set W := Submodule.span ℝ (X.embV '' (X.Λp ξ : Set (Fin r → E))) with hW

  have hα : ∀ (α : 𝓞 E), ∀ v ∈ W, (fun τ : X.Ψ => τ.1 (α : E) • v τ) ∈ W := by
    intro α
    let M : (X.Ψ → Fin r → ℂ) →ₗ[ℝ] (X.Ψ → Fin r → ℂ) :=
      LinearMap.pi fun τ => τ.1 (α : E) • LinearMap.proj τ
    have hle : W ≤ W.comap M := by
      rw [hW, Submodule.span_le]
      rintro _ ⟨μ, hμ, rfl⟩
      rw [SetLike.mem_coe, mem_Λp_iff] at hμ
      have hαμ : (α : E) • μ ∈ X.Λp ξ := by
        rw [mem_Λp_iff]
        exact ⟨smul_int_mem α.isIntegral_coe hμ.1, by rw [HermitianTraceFormVanishing.herm_smul_left, hμ.2, mul_zero]⟩
      rw [SetLike.mem_coe, Submodule.mem_comap]
      have e : M (X.embV μ) = X.embV ((α : E) • μ) := by
        funext τ b
        simp [M, Data.embV, Data.emb]
      rw [e]
      exact Submodule.subset_span ⟨_, hαμ, rfl⟩
    intro v hv
    exact hle hv
  let T : (X.Ψ → ℂ) →ₗ[ℝ] (X.Ψ → Fin r → ℂ) :=
    LinearMap.pi fun τ => ((LinearMap.toSpanSingleton ℂ _ (w τ)).restrictScalars ℝ).comp (LinearMap.proj τ)
  have hle : Submodule.span ℝ (Set.range fun α : 𝓞 E => fun τ : X.Ψ => τ.1 (α : E)) ≤ W.comap T := by
    rw [Submodule.span_le]
    rintro _ ⟨α, rfl⟩
    exact hα α w hw
  exact hle (x := s) (by rw [span_emb_int hD3]; exact Submodule.mem_top)

theorem Iperp_le (hD3 : IntegerApproximationCount (E := E)) {ξ : Fin r → E} (hξ : X.IsIso ξ)
    {v : X.Ψ → Fin r → ℂ} (hv : v ∈ X.Iperp ξ) :
    v ∈ Submodule.span ℝ (X.embV '' (X.Λp ξ : Set (Fin r → E))) := by
  classical
  obtain ⟨hξΛ, -, hξ0⟩ := hξ
  obtain ⟨η, hηΛ, hηξ⟩ : ∃ η ∈ X.Λ, herm X.Gm η ξ ≠ 0 := by
    have hpair : ∃ v, herm X.Gm v ξ ≠ 0 := by
      by_contra! h
      apply hξ0 (HermitianTraceFormVanishing.eq_zero_of_herm X.Gm X.Gm_det _ _)
      intro y
      rw [← HermitianTraceFormVanishing.herm_conj X.Gm X.Gm_herm, h y]
      exact HermitianTraceFormVanishing.cc_zero
    obtain ⟨v,hv⟩ := hpair
    obtain ⟨N,hN,hm⟩ := exists_nat_smul_mem (X := X) v
    exact ⟨_, hm, by rw [HermitianTraceFormVanishing.herm_smul_left]; exact mul_ne_zero (by exact_mod_cast hN.ne') hv⟩
  set d : E := (X.den : E) with hd
  have hcint : IsIntegral ℤ (d * herm X.Gm η ξ) := X.Λ_int η hηΛ ξ hξΛ
  have hc0 : d * herm X.Gm η ξ ≠ 0 := mul_ne_zero (fun h => X.den_ne (by simpa [hd] using h)) hηξ
  set c : E := d * herm X.Gm η ξ with hc
  let P : (X.Ψ → Fin r → ℂ) →ₗ[ℝ] (X.Ψ → Fin r → ℂ) :=
    { toFun := fun v τ => τ.1 c • v τ -
        (τ.1 d * hermC τ.1 X.Gm (v τ) (Data.emb τ.1 ξ)) • Data.emb τ.1 η
      map_add' := fun v v' => by
        funext τ
        simp only [Pi.add_apply, hermC_add_left, smul_add, mul_add, add_smul]
        abel
      map_smul' := fun a v => by
        funext τ
        simp only [Pi.smul_apply, RingHom.id_apply]
        rw [← Complex.coe_smul a (v τ), ← Complex.coe_smul a, hermC_smul_left]
        module }
  have hPΛ : ∀ l ∈ X.Λ, P (X.embV l) ∈ X.embV '' (X.Λp ξ : Set (Fin r → E)) := by
    intro l hl
    refine ⟨c • l - (d * herm X.Gm l ξ) • η, ?_, ?_⟩
    · rw [SetLike.mem_coe, mem_Λp_iff]
      refine ⟨X.Λ.sub_mem (smul_int_mem hcint hl) (smul_int_mem (X.Λ_int l hl ξ hξΛ) hηΛ), ?_⟩
      rw [HermitianTraceFormVanishing.herm_sub_left, HermitianTraceFormVanishing.herm_smul_left, HermitianTraceFormVanishing.herm_smul_left, hc]
      ring
    · funext τ b
      simp [P, Data.embV, Data.emb, hermC_emb]
  have hPv : P v = fun τ => τ.1 c • v τ := by
    funext τ
    simp only [P, LinearMap.coe_mk, AddHom.coe_mk]
    rw [hv τ, mul_zero, zero_smul, sub_zero]
  have hmem : P v ∈ Submodule.span ℝ (X.embV '' (X.Λp ξ : Set (Fin r → E))) := by
    apply (show Submodule.span ℝ _ ≤ (Submodule.span ℝ _).comap P from Submodule.span_le.mpr ?_) (mem_span_Λ hD3 v)
    rintro _ ⟨l, hl, rfl⟩
    exact Submodule.subset_span (hPΛ l hl)
  rw [hPv] at hmem
  simpa only [smul_smul, inv_mul_cancel₀ ((map_ne_zero _).mpr hc0), one_smul] using
    scal_closed hD3 hmem (fun τ => (τ.1 c)⁻¹)

noncomputable def ucompReal (z : Frame X.Ψ r) (ξ : Fin r → E) : (X.Ψ → Fin r → ℂ) →ₗ[ℝ] (X.Ψ → Fin r → ℂ) :=
  { toFun := X.ucomp z ξ
    map_add' u v := by
      funext τ
      simp only [Data.ucomp, Data.lineV, Data.aproj, Pi.add_apply, Pi.sub_apply,
        UnipotentCoefficientShift.Hf_add_left, add_div, add_smul]
      abel
    map_smul' a u := by
      funext τ
      simp only [Data.ucomp, Data.lineV, Data.aproj, Pi.smul_apply, Pi.sub_apply, RingHom.id_apply]
      rw [← Complex.coe_smul a (u τ), UnipotentCoefficientShift.Hf_smul_left,
        ← Complex.coe_smul a, mul_div_assoc]
      module }

theorem Uz_le_span (hD3 : IntegerApproximationCount (E := E)) {z : Frame X.Ψ r} {ξ : Fin r → E}
    (hξ : X.IsIso ξ) {u : X.Ψ → Fin r → ℂ} (hu : u ∈ X.Uz z ξ) :
    u ∈ Submodule.span ℝ (Set.range fun μ : X.Λp ξ => X.ucomp z ξ (X.embV μ)) := by
  let Q := ucompReal (X := X) z ξ
  rw [← MajorantOperators.ucomp_of_mem hu]
  change Q u ∈ _
  apply (show Submodule.span ℝ _ ≤ (Submodule.span ℝ _).comap Q from Submodule.span_le.mpr ?_) (Iperp_le hD3 hξ hu.1)
  rintro _ ⟨μ, hμ, rfl⟩
  exact Submodule.subset_span ⟨⟨μ, hμ⟩, rfl⟩

end LatticeSpanMembership

end ReciprocityTheory.ChartRestriction.G.FD
