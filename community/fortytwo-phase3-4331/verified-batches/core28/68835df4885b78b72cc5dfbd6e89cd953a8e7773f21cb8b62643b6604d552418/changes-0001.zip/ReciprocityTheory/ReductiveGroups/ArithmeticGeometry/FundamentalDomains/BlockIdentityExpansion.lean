import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.PositiveSpanMatrices

namespace ReciprocityTheory.ChartRestriction.G.FD.BlockIdentityExpansion

open NumberField Complex Matrix ReciprocityTheory.ChartRestriction.G.FD ReciprocityTheory.ChartRestriction.G.FD.PositiveSpanMatrices
open scoped ComplexConjugate

noncomputable section

variable {E : Type} [Field E] [NumberField E] [IsCMField E] {r : ℕ}

lemma f_gram_re (X : Data E r) (ξ : Fin r → E) (z0 : Frame X.Ψ r) (f : X.Ψ → Fin (r - 2) → Fin r → ℂ)
    (hf : X.UBasis z0 ξ f) (τ : X.Ψ) (a : Fin (r - 2) → ℂ) :
    (hermC τ.1 X.Gm (∑ k, a k • f τ k) (∑ k, a k • f τ k)).re =
      ∑ k : Fin (r - 2), if (k : ℕ) < X.p0 - 1 then ‖a k‖ ^ 2 else -‖a k‖ ^ 2 := by
  obtain ⟨-, -, hgr, -, -⟩ := hf τ
  rw [GramDeterminantReal.hC_sum_left]
  simp [hermC_sum_right, hermC_smul_right, hgr, mul_ite, Finset.sum_ite_eq, Finset.sum_ite_eq', Finset.mem_univ, if_true, Complex.re_sum]

  refine Finset.sum_congr rfl fun k _ => ?_
  split_ifs <;> simp [Complex.mul_conj, Complex.normSq_eq_norm_sq] <;>
    rw [← Complex.ofReal_pow, Complex.ofReal_re]

theorem key (X : DataX E r) (ξ : Fin r → E) (z0 x0 : Frame X.Ψ r)
    (f : X.Ψ → Fin (r - 2) → Fin r → ℂ) (h1 : X.Ψ → Matrix (Fin r) (Fin r) ℂ) (δ : ℝ)
    (hz : z0 ∈ X.dom) (hx0 : x0 ∈ X.dom) (hortho : X.IsOrtho x0)
    (hflag : X.SameFlag z0 x0) (hf : X.UBasis z0 ξ f)
    (hI : ∀ s t : X.Ψ → ℂ, X.applyV h1 (X.lineV ξ s + X.Jz z0 (X.lineV ξ t)) =
      X.lineV ξ s + X.Jz z0 (X.lineV ξ t))
    (hUz : ∀ u ∈ X.Uz z0 ξ, X.applyV h1 u ∈ X.Uz z0 ξ)
    (hgraph : ∀ τ (v : Fin r → ℂ), v ∈ Submodule.span ℂ (f τ '' {k | (k : ℕ) < X.p0 - 1}) →
      ∀ c : Fin (r - 2) → ℂ, (h1 τ) *ᵥ v = ∑ k, c k • f τ k →
        (∑ k : Fin (r - 2), if (k : ℕ) < X.p0 - 1 then 0 else ‖c k‖ ^ 2) ≤
          δ ^ 2 * ∑ k : Fin (r - 2), if (k : ℕ) < X.p0 - 1 then ‖c k‖ ^ 2 else 0)
    (τ : X.Ψ) (v : Fin r → ℂ) (hv : v ∈ Spos X.toData z0 τ) :
    Neg X.toData x0 τ (h1 τ *ᵥ v) ≤ δ ^ 2 * Pos X.toData x0 τ (h1 τ *ᵥ v) := by
  classical
  obtain ⟨hperp, hJ, hgr, -, hspan⟩ := hf τ
  have hdet0 : (mat x0 τ).det ≠ 0 := (hx0 τ).1
  have hS : Spos X.toData z0 τ = Spos X.toData x0 τ := hflag τ
  have hJt : ∀ u, X.Jt z0 τ u = I • ((2 : ℂ) • X.ppos z0 τ u - u) := fun u => rfl

  have proj (k) : X.ppos z0 τ (f τ k) = if (k : ℕ) < X.p0 - 1 then f τ k else 0 := by
    have h := hJ k
    apply smul_right_injective (Fin r → ℂ) (two_ne_zero : (2 : ℂ) ≠ 0)
    by_cases hk : (k : ℕ) < X.p0 - 1
    · rw [if_pos hk, hJt] at h
      simpa [hk, two_smul] using sub_eq_iff_eq_add.mp (smul_right_injective _ Complex.I_ne_zero h)
    · rw [if_neg hk, hJt, neg_smul, ← smul_neg] at h
      simpa [hk] using sub_eq_iff_eq_add.mp (smul_right_injective _ Complex.I_ne_zero h)
  have hfS : ∀ k : Fin (r - 2), (k : ℕ) < X.p0 - 1 → f τ k ∈ Spos X.toData z0 τ := by
    intro k hk
    rw [← if_pos hk (α := Fin r → ℂ) (t := f τ k) (e := 0), ← proj k]
    exact ppos_mem (X := X.toData) z0 τ _
  have hvP : X.ppos z0 τ v = v := ppos_of_mem (X := X.toData) hz τ v hv
  have hvneg : ∀ k : Fin (r - 2), ¬ (k : ℕ) < X.p0 - 1 → hermC τ.1 X.Gm v (f τ k) = 0 := by
    intro k hk
    rw [← hvP, Data.ppos_selfadj (X := X.toData) hz τ v (f τ k), proj, if_neg hk, hermC_zero_right]

  set a : Fin (r - 2) → ℂ := fun k : Fin (r - 2) => if (k : ℕ) < X.p0 - 1 then hermC τ.1 X.Gm v (f τ k) else 0 with ha
  set w : Fin r → ℂ := ∑ k, a k • f τ k with hw
  have hwspan : w ∈ Submodule.span ℂ (f τ '' {k | (k : ℕ) < X.p0 - 1}) := by
    rw [hw]
    refine Submodule.sum_mem _ fun k _ => ?_
    by_cases hk : (k : ℕ) < X.p0 - 1
    · exact Submodule.smul_mem _ _ (Submodule.subset_span ⟨k, hk, rfl⟩)
    · simp [ha, hk]
  have hwS : w ∈ Spos X.toData z0 τ :=
    (Submodule.span_le.mpr (Set.image_subset_iff.mpr hfS)) hwspan
  have hfw : ∀ k, hermC τ.1 X.Gm (f τ k) w =
      conj (a k) * (if (k : ℕ) < X.p0 - 1 then 1 else -1) := by
    intro k
    rw [hw]
    simp only [hermC_sum_right, hermC_smul_right, hgr, mul_ite, mul_zero, Finset.sum_ite_eq, Finset.mem_univ, if_true]
  have hfp : ∀ k, hermC τ.1 X.Gm (f τ k) (v - w) = 0 := by
    intro k
    rw [hermC_sub_right, hfw]
    by_cases hk : (k : ℕ) < X.p0 - 1
    · rw [if_pos hk, mul_one, ha]
      simp only [if_pos hk]
      rw [hermC_conj τ.1 X.Gm_herm, sub_self]
    · rw [if_neg hk, ha]
      simp only [if_neg hk, map_zero, zero_mul, sub_zero]
      rw [← hermC_conj τ.1 X.Gm_herm, hvneg k hk, map_zero]
  have hskew (u q : Fin r → ℂ) : hermC τ.1 X.Gm (X.Jt z0 τ u) q = -hermC τ.1 X.Gm u (X.Jt z0 τ q) := by
    change hermC τ.1 X.Gm (I • X.toData.jp z0 τ u) q = -hermC τ.1 X.Gm u (I • X.toData.jp z0 τ q)
    rw [hermC_smul_left, hermC_smul_right, X.toData.hermC_jp_left hz, Complex.conj_I, neg_mul, neg_neg]

  let Lq := GramDeterminantReal.hL τ.1 X.Gm
  have hK : ⨅ i, LinearMap.ker (![Lq (Data.emb τ.1 ξ), Lq (X.Jt z0 τ (Data.emb τ.1 ξ))] i) ≤
      LinearMap.ker (Lq (v - w)) := by
    intro u hu
    rw [Submodule.mem_iInf] at hu
    have h0 : hermC τ.1 X.Gm u (Data.emb τ.1 ξ) = 0 := hu 0
    have h1' : hermC τ.1 X.Gm u (X.Jt z0 τ (Data.emb τ.1 ξ)) = 0 := hu 1
    have hJu : hermC τ.1 X.Gm (X.Jt z0 τ u) (Data.emb τ.1 ξ) = 0 := by rw [hskew, h1', neg_zero]
    obtain ⟨c, hc⟩ := (Submodule.mem_span_range_iff_exists_fun ℂ).mp (hspan u h0 hJu)
    show hermC τ.1 X.Gm u (v - w) = 0
    rw [← hc, GramDeterminantReal.hC_sum_left]
    exact Finset.sum_eq_zero fun k _ => by rw [hfp k, mul_zero]
  obtain ⟨c, hc⟩ := (Submodule.mem_span_range_iff_exists_fun ℂ).mp (mem_span_of_iInf_ker_le_ker hK)
  have hc' : ∀ u, hermC τ.1 X.Gm u (v - w) =
      hermC τ.1 X.Gm u (conj (c 0) • Data.emb τ.1 ξ + conj (c 1) • X.Jt z0 τ (Data.emb τ.1 ξ)) := by
    intro u
    have h := LinearMap.congr_fun hc u
    simp only [Fin.sum_univ_two, LinearMap.add_apply, LinearMap.smul_apply, Matrix.cons_val_zero,
      Matrix.cons_val_one, Matrix.head_cons, smul_eq_mul] at h
    rw [hermC_add_right, hermC_smul_right, hermC_smul_right, Complex.conj_conj,
      Complex.conj_conj]
    exact h.symm
  have hnd : ∀ z : Fin r → ℂ, (∀ u, hermC τ.1 X.Gm u z = 0) → z = 0 := by
    intro z hz'
    rw [expand (X := X.toData) hortho τ hdet0 z]
    refine Finset.sum_eq_zero fun d _ => ?_
    rw [← hermC_conj τ.1 X.Gm_herm, hz', map_zero, mul_zero, zero_smul]
  have hpq : v - w = conj (c 0) • Data.emb τ.1 ξ + conj (c 1) • X.Jt z0 τ (Data.emb τ.1 ξ) := by
    refine sub_eq_zero.mp (hnd _ fun u => ?_)
    rw [hermC_sub_right, hc' u, sub_self]
  have hfix : h1 τ *ᵥ (v - w) = v - w := by
    have h := congrFun (hI (fun _ => conj (c 0)) (fun _ => conj (c 1))) τ
    simp only [Data.applyV, Data.lineV, Data.Jz, Pi.add_apply] at h
    rw [hpq]
    change h1 τ *ᵥ (_ + I • X.toData.jp z0 τ (conj (c 1) • Data.emb τ.1 ξ)) = conj (c 0) • Data.emb τ.1 ξ + I • X.toData.jp z0 τ (conj (c 1) • Data.emb τ.1 ξ) at h
    simp only [Data.jp_smul, smul_comm I (conj (c 1))] at h
    exact h

  have hwe : hermC τ.1 X.Gm w (Data.emb τ.1 ξ) = 0 := by
    rw [hw, GramDeterminantReal.hC_sum_left]
    exact Finset.sum_eq_zero fun k _ => by rw [(hperp k).1, mul_zero]
  have hwP : X.ppos z0 τ w = w := ppos_of_mem (X := X.toData) hz τ w hwS
  have hp0 : ∀ τ' : X.Ψ, X.ppos z0 τ' 0 = 0 := fun τ' => by
    simpa using Data.ppos_smul_eq X.toData z0 τ' 0 0
  have hU : (fun τ' => if τ' = τ then w else 0) ∈ X.Uz z0 ξ := by
    refine ⟨fun τ' => ?_, fun τ' => ?_⟩
    · by_cases h : τ' = τ
      · simp only [if_pos h]
        rw [h]
        exact hwe
      · simp only [if_neg h]
        exact hermC_zero_left _ _ _
    · by_cases h : τ' = τ
      · simp only [Data.Jz, if_pos h]
        rw [h, hwP, hermC_smul_left, hermC_sub_left, hermC_smul_left, hwe]
        ring
      · simp only [Data.Jz, if_neg h, hp0, smul_zero, sub_zero]
        exact hermC_zero_left _ _ _
  have hA := hUz _ hU
  obtain ⟨cc, hcc⟩ := (Submodule.mem_span_range_iff_exists_fun ℂ).mp
    (hspan (h1 τ *ᵥ w) (by simpa [Data.applyV] using hA.1 τ)
      (by simpa [Data.applyV, Data.Jz, Data.Jt] using hA.2 τ))
  have hg := hgraph τ w hwspan cc hcc.symm
  have hy : h1 τ *ᵥ v = (v - w) + ∑ k, cc k • f τ k := by
    rw [hcc]
    conv_rhs => rw [← hfix]
    rw [← Matrix.mulVec_add, sub_add_cancel]
  rw [hy]

  have hpS0 : v - w ∈ Spos X.toData x0 τ := hS ▸ Submodule.sub_mem _ hv hwS
  set b : Fin (r - 2) → ℂ := fun k : Fin (r - 2) => if (k : ℕ) < X.p0 - 1 then 0 else cc k with hb
  have hNeq : PositiveSpanMatrices.Neg X.toData x0 τ ((v - w) + ∑ k, cc k • f τ k) =
      PositiveSpanMatrices.Neg X.toData x0 τ (∑ k, b k • f τ k) := by
    unfold PositiveSpanMatrices.Neg
    refine Finset.sum_congr rfl fun a' _ => ?_
    rw [hermC_add_left, perp_kap (X := X.toData) hortho τ _ hpS0 a', zero_add,
      GramDeterminantReal.hC_sum_left, GramDeterminantReal.hC_sum_left]
    congr 2
    refine Finset.sum_congr rfl fun k _ => ?_
    rw [hb]
    by_cases hk : (k : ℕ) < X.p0 - 1
    · simp only [if_pos hk, zero_mul]
      rw [perp_kap (X := X.toData) hortho τ _ (hS ▸ hfS k hk) a', mul_zero]
    · simp only [if_neg hk]
  have hnegperp : ∀ b' : Fin X.p0,
      hermC τ.1 X.Gm (∑ k, b k • f τ k) (col (mat x0 τ) (Fin.castLE X.p0_le b')) = 0 := by
    intro b'
    rw [GramDeterminantReal.hC_sum_left]
    refine Finset.sum_eq_zero fun k _ => ?_
    rw [hb]
    by_cases hk : (k : ℕ) < X.p0 - 1
    · simp only [if_pos hk, zero_mul]
    · simp only [if_neg hk]
      rw [perp_of_ppos_zero (X := X.toData) hx0 τ (f τ k) ?_ b', mul_zero]
      rw [← FrameDegreeData.ppos_sameFlag (X := X.toData) hz hx0 hflag τ]
      simp [proj, hk]
  have hN : PositiveSpanMatrices.Neg X.toData x0 τ ((v - w) + ∑ k, cc k • f τ k) =
      ∑ k : Fin (r - 2), if (k : ℕ) < X.p0 - 1 then 0 else ‖cc k‖ ^ 2 := by
    rw [hNeq]
    have h := re_self_of_perp (X := X.toData) hortho τ hdet0 _ hnegperp
    rw [← neg_eq_iff_eq_neg.mpr h, f_gram_re X.toData ξ z0 f hf τ b, ← Finset.sum_neg_distrib]
    refine Finset.sum_congr rfl fun k _ => ?_
    rw [hb]
    by_cases hk : (k : ℕ) < X.p0 - 1 <;> simp [hk]

  have hre := re_self_split (X := X.toData) hortho τ hdet0 ((v - w) + ∑ k, cc k • f τ k)
  have hpf : ∀ k, hermC τ.1 X.Gm (v - w) (f τ k) = 0 := fun k => by
    rw [← hermC_conj τ.1 X.Gm_herm, hfp k, map_zero]
  have hexp : (hermC τ.1 X.Gm ((v - w) + ∑ k, cc k • f τ k) ((v - w) + ∑ k, cc k • f τ k)).re =
      (hermC τ.1 X.Gm (v - w) (v - w)).re +
        (hermC τ.1 X.Gm (∑ k, cc k • f τ k) (∑ k, cc k • f τ k)).re := by
    rw [hermC_add_left, hermC_add_right, hermC_add_right,
      GramDeterminantReal.hC_sum_left τ.1 X.Gm (f τ) cc (v - w)]
    simp only [hermC_sum_right, hermC_smul_right, hpf, hfp, mul_zero, Finset.sum_const_zero, add_zero, zero_add, Complex.add_re]
  have hSS := f_gram_re X.toData ξ z0 f hf τ cc
  have hPp := re_self_of_mem (X := X.toData) hortho τ hdet0 _ hpS0
  have hP0 := Pos_nonneg (X := X.toData) x0 τ (v - w)
  have hsplit : (∑ k : Fin (r - 2), if (k : ℕ) < X.p0 - 1 then ‖cc k‖ ^ 2 else -‖cc k‖ ^ 2) =
      (∑ k : Fin (r - 2), if (k : ℕ) < X.p0 - 1 then ‖cc k‖ ^ 2 else 0) -
        ∑ k : Fin (r - 2), if (k : ℕ) < X.p0 - 1 then 0 else ‖cc k‖ ^ 2 := by
    rw [← Finset.sum_sub_distrib]
    refine Finset.sum_congr rfl fun k _ => ?_
    split_ifs <;> ring
  rw [hN] at hre ⊢
  refine hg.trans (mul_le_mul_of_nonneg_left ?_ (sq_nonneg δ))
  linarith [hre, hexp, hSS, hPp, hP0, hsplit]

end

end ReciprocityTheory.ChartRestriction.G.FD.BlockIdentityExpansion
