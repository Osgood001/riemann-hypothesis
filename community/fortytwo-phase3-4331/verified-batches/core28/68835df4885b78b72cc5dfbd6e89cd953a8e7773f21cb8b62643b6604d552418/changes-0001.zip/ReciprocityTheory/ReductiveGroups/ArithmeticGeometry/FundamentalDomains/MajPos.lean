import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.UnitaryComplementMoveOfIsotropic
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.LminorSubmatrixCastSucc

namespace ReciprocityTheory.ChartRestriction.G.FD

open NumberField Complex
open scoped ComplexConjugate ComplexOrder

variable {E : Type} [Field E] [NumberField E] [IsCMField E]

namespace Data

variable {r : ℕ} (X : Data E r)

lemma Hf_self {x : Frame X.Ψ r} (hx : x ∈ X.dom) (τ : X.Ψ) (v : Fin r → ℂ) :
    X.Hf x τ v v = (X.maj x τ v : ℂ) := by
  have hr : conj (X.Hf x τ v v) = X.Hf x τ v v := by
    rw [X.Hf_eq_jp, hermC_conj τ.1 X.Gm_herm, X.hermC_jp_left hx]
  calc
    _ = ((X.Hf x τ v v).re : ℂ) := (Complex.conj_eq_iff_re.mp hr).symm
    _ = _ := by
      congr 1
      rw [X.Hf_eq_two_ppos, X.hermC_ppos_self]
      simp [Data.maj, Data.posPart, Complex.mul_re, Data.colP]

lemma maj_pos {x : Frame X.Ψ r} (hx : x ∈ X.dom) (τ : X.Ψ) {v : Fin r → ℂ} (hv : v ≠ 0) :
    0 < X.maj x τ v := by
  classical
  have hG := X.Gm_herm
  have hApd : (X.gramPos x τ).PosDef := X.gramPos_posDef hx τ
  have hquadP (c : Fin X.p0 → ℂ) :
      hermC τ.1 X.Gm (∑ a, c a • X.colP x τ a) (∑ a, c a • X.colP x τ a) =
        ∑ a, ∑ b, c a * X.gramPos x τ a b * conj (c b) := hermC_quad τ.1 X.Gm c _
  let w := v - X.ppos x τ v
  have horth' (a) : hermC τ.1 X.Gm w (X.colP x τ a) = 0 := by
    rw [show w = v - X.ppos x τ v from rfl, hermC_sub_left, X.hermC_ppos_colP hx, sub_self]
  have hwy : hermC τ.1 X.Gm w (X.ppos x τ v) = 0 := by
    rw [show w = v - X.ppos x τ v from rfl, hermC_sub_left, X.hermC_ppos_right hx τ v v, sub_self]
  have hyw : hermC τ.1 X.Gm (X.ppos x τ v) w = 0 := by
    rw [← hermC_conj τ.1 hG, hwy, map_zero]
  have hvdec : v = X.ppos x τ v + w := by
    dsimp [w]
    abel
  have hHf := X.Hf_self hx τ v
  rw [X.Hf_eq_two_ppos] at hHf
  obtain ⟨y, hy⟩ : ∃ y, y = X.ppos x τ v := ⟨_, rfl⟩
  have hyq : y = ∑ a, (∑ b, hermC τ.1 X.Gm v (X.colP x τ b) * (X.gramPos x τ)⁻¹ b a) •
      X.colP x τ a := by
    rw [hy]
    exact X.ppos_eq x τ v
  have hyy_nn : 0 ≤ (hermC τ.1 X.Gm y y).re := by
    rw [hyq, hquadP]
    exact quad_re_nonneg hApd.posSemidef _
  have hyy_pos : y ≠ 0 → 0 < (hermC τ.1 X.Gm y y).re := by
    intro hy0
    rw [hyq, hquadP]
    apply ReciprocityTheory.ChartRestriction.G.FD.quad_re_pos hApd
    intro hc
    apply hy0
    rw [hyq]
    refine Finset.sum_eq_zero fun a _ => ?_
    have h := congrFun hc a
    simp at h
    rw [h, zero_smul]
  rw [← hy] at hHf hyw hwy hvdec
  rw [hvdec] at hHf hv ⊢
  simp [ReciprocityTheory.ChartRestriction.G.FD.hermC_add_left, ReciprocityTheory.ChartRestriction.G.FD.hermC_add_right, hyw, hwy]
 at hHf
  have hmaj : X.maj x τ (y + w) = (hermC τ.1 X.Gm y y).re - (hermC τ.1 X.Gm w w).re := by
    have h := congrArg Complex.re hHf
    simp at h
    linarith
  rw [hmaj]
  by_cases hw0 : w = 0
  · have hy0 : y ≠ 0 := by
      rw [hw0, add_zero] at hv
      exact hv
    have h2 : hermC τ.1 X.Gm w w = 0 := by
      rw [hw0]
      exact ReciprocityTheory.ChartRestriction.G.FD.hermC_zero_left _ _ _
    rw [h2, Complex.zero_re, sub_zero]
    exact hyy_pos hy0
  · have h1 := X.neg_of_perp hx τ hw0 horth'
    linarith

end Data

end ReciprocityTheory.ChartRestriction.G.FD
