import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.ExistsUnitaryBasisSameFlag
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.HermitianPairingAlgebra
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.HermEqZeroOfTraceFormVanish
import ReciprocityTheory.SemistableReduction.TorsionNonvanishStatement

namespace ReciprocityTheory.ChartRestriction.G.FD.PerpBasisExistence

open NumberField Complex Matrix ReciprocityTheory.ChartRestriction.G.FD
open scoped ComplexConjugate

noncomputable section

variable {E : Type} [Field E] [NumberField E] [IsCMField E] {r : ℕ}

lemma herm_add_right' (G : Matrix (Fin r) (Fin r) E) (x y y' : Fin r → E) :
    herm G x (y + y') = herm G x y + herm G x y' := by
  simp only [herm, Pi.add_apply, HermitianPairingAlgebra.cc_add, mul_add, Finset.sum_add_distrib]

def hxi (G : Matrix (Fin r) (Fin r) E) (ξ : Fin r → E) : (Fin r → E) →ₗ[E] E where
  toFun x := herm G x ξ
  map_add' x y := HermitianTraceFormVanishing.herm_add_left G x y ξ
  map_smul' a x := HermitianTraceFormVanishing.herm_smul_left G a x ξ

lemma herm_sum_left' (G : Matrix (Fin r) (Fin r) E) {ι : Type*} (s : Finset ι)
    (f : ι → Fin r → E) (y : Fin r → E) : herm G (∑ i ∈ s, f i) y = ∑ i ∈ s, herm G (f i) y := map_sum (hxi G y) f s

lemma herm_sum_right' (G : Matrix (Fin r) (Fin r) E) {ι : Type*} (s : Finset ι)
    (f : ι → Fin r → E) (x : Fin r → E) : herm G x (∑ i ∈ s, f i) = ∑ i ∈ s, herm G x (f i) := by
  exact map_sum (AddMonoidHom.mk' (herm G x) (herm_add_right' G x)) f s

private theorem basis_starting_at {V : Type*} [AddCommGroup V] [Module E V] [FiniteDimensional E V]
    {m : ℕ} (hdim : Module.finrank E V = m + 1) (v : V) (hv : v ≠ 0) :
    ∃ b : Module.Basis (Fin (m + 1)) E V, b 0 = v := by
  classical
  have hi : LinearIndepOn E id {v} := .singleton hv
  let I := hi.extend (Set.subset_univ _)
  let b : Module.Basis I E V := Module.Basis.extend hi
  letI : Fintype I := FiniteDimensional.fintypeBasisIndex b
  let j : I := ⟨v, Module.Basis.subset_extend hi (Set.mem_singleton v)⟩
  let e : I ≃ Fin (m + 1) := (Fintype.equivFin I).trans (finCongr
    ((Module.finrank_eq_card_basis b).symm.trans hdim))
  refine ⟨b.reindex (e.trans (Equiv.swap (e j) 0)), ?_⟩
  simp [Module.Basis.reindex_apply, b, j]
  exact Module.Basis.extend_apply_self _ _

theorem exists_beta (X : Data E r) {ξ : Fin r → E} (hξξ : herm X.Gm ξ ξ = 0) (hξ0 : ξ ≠ 0) :
    ∃ β : Fin (r - 2) → Fin r → E, (∀ k, herm X.Gm (β k) ξ = 0) ∧
      LinearIndependent E (Fin.cons ξ β : Fin (r - 2 + 1) → Fin r → E) ∧
      (∀ x : Fin r → E, herm X.Gm x ξ = 0 →
        ∃ (c : Fin (r - 2) → E) (e : E), x = ∑ k, c k • β k + e • ξ) := by
  classical
  set f := hxi X.Gm ξ with hf
  have hfx : ∀ x, f x = herm X.Gm x ξ := fun _ => rfl

  have hne : f ≠ 0 := by
    intro h
    apply hξ0 (HermitianTraceFormVanishing.eq_zero_of_herm X.Gm X.Gm_det ξ ?_)
    intro y
    rw [← HermitianTraceFormVanishing.herm_conj X.Gm X.Gm_herm, ← hfx, h]
    simp
  let K := LinearMap.ker f
  let v : K := ⟨ξ, hξξ⟩
  have hv : v ≠ 0 := fun h => hξ0 (congrArg Subtype.val h)
  have hrank : Module.finrank E K + 1 = r := by
    simpa [K] using Module.Dual.finrank_ker_add_one_of_ne_zero hne
  letI : Nontrivial K := nontrivial_of_ne v 0 hv
  have hpos : 0 < Module.finrank E K := Module.finrank_pos
  obtain ⟨b,hb⟩ := basis_starting_at (E := E) (m := r - 2) (by omega) v hv
  refine ⟨fun k => (b k.succ : Fin r → E), fun k => (b k.succ).2, ?_, ?_⟩
  · have eqv : K.subtype ∘ (b : Fin (r - 2 + 1) → K) =
        Fin.cons ξ (fun k : Fin (r - 2) => (b k.succ : Fin r → E)) := by
      funext i
      refine Fin.cases ?_ (fun k => ?_) i <;> simp [hb, v]
    rw [← eqv]
    exact b.linearIndependent.map' K.subtype (Submodule.ker_subtype K)
  · intro x hx
    let y : K := ⟨x, hx⟩
    refine ⟨fun k => b.repr y k.succ, b.repr y 0, ?_⟩
    have h := (b.sum_repr y).symm
    rw [Fin.sum_univ_succ, hb, add_comm] at h
    simpa only [Submodule.coe_add, Submodule.coe_sum, Submodule.coe_smul_of_tower] using
      congrArg Subtype.val h

variable (X : DataX E r)

def LBsub {n : ℕ} (β : Fin n → Fin r → E) (ξ : Fin r → E) : Submodule (𝓞 E) (Fin n → E) where
  carrier := {c | ∃ e : E, ∑ k, c k • β k + e • ξ ∈ X.L'}
  add_mem' := by
    rintro c c' ⟨e, he⟩ ⟨e', he'⟩
    refine ⟨e + e', ?_⟩
    have h : ∑ k, (c + c') k • β k + (e + e') • ξ =
        (∑ k, c k • β k + e • ξ) + (∑ k, c' k • β k + e' • ξ) := by
      simp only [Pi.add_apply, add_smul, Finset.sum_add_distrib]
      abel
    rw [h]
    exact X.L'.add_mem he he'
  zero_mem' := ⟨0, by simp⟩
  smul_mem' := by
    rintro a c ⟨e, he⟩
    refine ⟨(a : E) * e, ?_⟩
    have h : ∑ k, (a • c) k • β k + ((a : E) * e) • ξ = a • (∑ k, c k • β k + e • ξ) := by
      rw [integer_smul_eq_coe_smul a c, integer_smul_eq_coe_smul a (∑ k, c k • β k + e • ξ)]
      simp only [Pi.smul_apply, smul_eq_mul, smul_add, Finset.smul_sum, mul_smul]
    rw [h]
    exact X.L'.smul_mem a he


end

end ReciprocityTheory.ChartRestriction.G.FD.PerpBasisExistence
