import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.ExistsPerpHermitianReduction
import ReciprocityTheory.SemistableReduction.LatAll
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.IsotropicCombinations
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.QuadraticCoefficientForms

namespace ReciprocityTheory.ChartRestriction.G.FD

open NumberField Complex Matrix
open scoped ComplexConjugate

noncomputable section

variable {E : Type} [Field E] [NumberField E] [NumberField.IsCMField E]

private theorem linearIndependent_mulVec_embVec {K : Type} [Field K] [NumberField K] {n : ℕ} (σ : K →+* ℂ)
    (A : Matrix (Fin n) (Fin n) K) (Q : Matrix (Fin n) (Fin n) ℂ) (hA : LinearIndependent K A)
    (hQ : Q.det ≠ 0) : LinearIndependent ℂ (fun j => Q *ᵥ ReciprocityTheory.MultiplicativeHeights.embVec σ (A j)) := by
  have hA' : LinearIndependent ℂ (σ.mapMatrix A) := by
    apply Matrix.linearIndependent_rows_iff_isUnit.mpr
    rw [Matrix.isUnit_iff_isUnit_det, ← RingHom.map_det]
    exact ((Matrix.isUnit_iff_isUnit_det _).mp (Matrix.linearIndependent_rows_iff_isUnit.mp hA)).map σ
  exact hA'.map' Q.mulVecLin (LinearMap.ker_eq_bot.mpr
    (Matrix.mulVec_injective_iff_isUnit.mpr ((Matrix.isUnit_iff_isUnit_det _).mpr (isUnit_iff_ne_zero.mpr hQ))))

theorem reducedLattice_short_bound (hD5 : CoveringRadiusStatement) (r : ℕ) (X : DataX E r) (ξ : Fin r → E) (z0 : Frame X.Ψ r)
    (f : X.Ψ → Fin (r - 2) → Fin r → ℂ) (β : Fin (r - 2) → Fin r → E) (S : ReciprocityTheory.MultiplicativeHeights.HermForm E (r - 2))
    (LB : Submodule (𝓞 E) (Fin (r - 2) → E)) (Q : X.Ψ → Matrix (Fin (r - 2)) (Fin (r - 2)) ℂ) (ep rh : ℝ)
    (hξ : X.IsIso ξ) (hz : z0 ∈ X.dom) (hf : X.UBasis z0 ξ f)
    (hβ : ∀ k, herm X.Gm (β k) ξ = 0)
    (hβind : LinearIndependent E (Fin.cons ξ β : Fin (r - 2 + 1) → Fin r → E))
    (hβspan : ∀ x : Fin r → E, herm X.Gm x ξ = 0 → ∃ (c : Fin (r - 2) → E) (e : E), x = ∑ k, c k • β k + e • ξ)
    (hS : ∀ c c' : Fin (r - 2) → E, S.h c c' = herm X.Gm (∑ k, c' k • β k) (∑ k, c k • β k))
    (hLB : ∀ c : Fin (r - 2) → E, c ∈ LB ↔ ∃ e : E, ∑ k, c k • β k + e • ξ ∈ X.L')
    (hLat : ReciprocityTheory.MultiplicativeHeights.IsLattice LB) (hSD : ReciprocityTheory.MultiplicativeHeights.IsSelfDual S LB)
    (hQ : ∀ τ, (Q τ).det ≠ 0)
    (hSQ : ∀ τ (c c' : Fin (r - 2) → E), τ.1 (S.h c c') =
      ReciprocityTheory.MultiplicativeHeights.jForm (X.p0 - 1) (Q τ *ᵥ ReciprocityTheory.MultiplicativeHeights.embVec τ.1 c) (Q τ *ᵥ ReciprocityTheory.MultiplicativeHeights.embVec τ.1 c'))
    (hQf : ∀ τ (c : Fin (r - 2) → E), X.ucomp z0 ξ (X.embV (∑ k, c k • β k)) τ =
      ∑ k, (Q τ *ᵥ ReciprocityTheory.MultiplicativeHeights.embVec τ.1 c) k • f τ k)
    (hep : 0 < ep) (hep1 : ep ≤ 1) (hrh : 0 < rh) (hrh1 : rh ≤ 1)
    (hD4 : ∀ x ∈ X.L', herm X.Gm x ξ = 0 → (∀ e : E, x ≠ e • ξ) →
      ∃ τ : X.Ψ, ep ≤ X.maj z0 τ (X.ucomp z0 ξ (X.embV x) τ)) :
    ∃ lam : Fin (r - 2) → Fin r → E,
      (∀ j, lam j ∈ X.L' ∧ herm X.Gm (lam j) ξ = 0) ∧
      LinearIndependent E (Fin.cons ξ lam : Fin (r - 2 + 1) → Fin r → E) ∧
      (∀ j k : Fin (r - 2), (j : ℕ) < X.p0 - 1 → X.p0 - 1 ≤ (k : ℕ) → herm X.Gm (lam j) (lam k) = 0) ∧
      (∀ j : Fin (r - 2), (j : ℕ) < X.p0 - 1 → ∀ τ : X.Ψ, 0 < (τ.1 (herm X.Gm (lam j) (lam j))).re) ∧
      (∀ j : Fin (r - 2), X.p0 - 1 ≤ (j : ℕ) → ∀ τ : X.Ψ, (τ.1 (herm X.Gm (lam j) (lam j))).re < 0) ∧
      (∀ j (τ : X.Ψ), ‖τ.1 (herm X.Gm (lam j) (lam j))‖ ≤ d6La r X.p0 (fdeg E) (dE E) ep rh ^ 2) ∧
      (∀ τ, LinearIndependent ℂ fun j => X.ucomp z0 ξ (X.embV (lam j)) τ) ∧
      (∀ τ j, X.ucomp z0 ξ (X.embV (lam j)) τ ∈ Submodule.span ℂ (Set.range (f τ))) ∧
      (∀ τ (j k : Fin (r - 2)), (j : ℕ) < X.p0 - 1 → X.p0 - 1 ≤ (k : ℕ) →
        hermC τ.1 X.Gm (X.ucomp z0 ξ (X.embV (lam j)) τ) (X.ucomp z0 ξ (X.embV (lam k)) τ) = 0) ∧
      (∀ τ (w : Fin (r - 2) → ℂ), (∀ j : Fin (r - 2), X.p0 - 1 ≤ (j : ℕ) → w j = 0) → w ≠ 0 →
        0 < (hermC τ.1 X.Gm (∑ j, w j • X.ucomp z0 ξ (X.embV (lam j)) τ)
          (∑ j, w j • X.ucomp z0 ξ (X.embV (lam j)) τ)).re) ∧
      (∀ τ (w : Fin (r - 2) → ℂ), (∀ j : Fin (r - 2), (j : ℕ) < X.p0 - 1 → w j = 0) → w ≠ 0 →
        (hermC τ.1 X.Gm (∑ j, w j • X.ucomp z0 ξ (X.embV (lam j)) τ)
          (∑ j, w j • X.ucomp z0 ξ (X.embV (lam j)) τ)).re < 0) ∧
      (∀ τ (c : Fin (r - 2) → ℂ), (∑ k, c k • f τ k) ∈ Submodule.span ℂ
          ((fun j => X.ucomp z0 ξ (X.embV (lam j)) τ) '' {j | (j : ℕ) < X.p0 - 1}) →
        (∑ k : Fin (r - 2), if (k : ℕ) < X.p0 - 1 then 0 else ‖c k‖ ^ 2) ≤
          (rh / 120) ^ 2 * ∑ k : Fin (r - 2), if (k : ℕ) < X.p0 - 1 then ‖c k‖ ^ 2 else 0) := by
  classical
  obtain ⟨hξΛ, hξξ, hξ0⟩ := hξ
  have hcardpos := QuadraticCoefficientForms.card_Psi_pos X.toData
  have hcard := QuadraticCoefficientForms.card_Psi X.toData
  haveI : Nonempty X.Ψ := Fintype.card_pos_iff.mp hcardpos
  obtain ⟨τ0⟩ := (inferInstance : Nonempty X.Ψ)
  obtain ⟨hp1, hpr0⟩ := IsotropicIndexSums.isotropicIndex_bounds X.toData hξξ hξ0 τ0
  have hON : ∀ τ : X.Ψ, ∀ k l, hermC τ.1 X.Gm (f τ k) (f τ l) =
      if k = l then (if (k : ℕ) < X.p0 - 1 then 1 else -1) else 0 := fun τ => (hf τ).2.2.1
  have hSsym : ∀ x y : Fin (r - 2) → E, S.h x y = 0 → S.h y x = 0 := by
    intro x y hxy
    rw [hS] at hxy ⊢
    rw [← HermitianTraceFormVanishing.herm_conj X.Gm X.Gm_herm, hxy, cc_zero]
  rcases Nat.eq_zero_or_pos (r - 2) with hn | hn
  · haveI : IsEmpty (Fin (r - 2)) := by rw [hn]; infer_instance
    refine ⟨fun j => ∑ k, (0 : E) • β k + (0 : E) • ξ, fun j => isEmptyElim j, ?_,
      fun j => isEmptyElim j, fun j => isEmptyElim j, fun j => isEmptyElim j,
      fun j => isEmptyElim j, fun _ => linearIndependent_empty_type, fun _ j => isEmptyElim j,
      fun _ j => isEmptyElim j, fun _ w _ hw => absurd (Subsingleton.elim w 0) hw,
      fun _ w _ hw => absurd (Subsingleton.elim w 0) hw, fun _ c _ => by simp⟩
    apply IsotropicCombinations.cons_li (hli := hβind) (hla := linearIndependent_empty_type) <;> assumption
  have hlamξ : ∀ (c : Fin (r - 2) → E) (e : E), herm X.Gm (∑ k, c k • β k + e • ξ) ξ = 0 := by
    intro c e
    apply IsotropicCombinations.herm_lam_ξ <;> assumption
  have hpr : X.p0 - 1 ≤ r - 2 := by omega
  have h_inj : Function.Injective (fun τ : X.Ψ => τ.1) := Subtype.val_injective
  have h_cm : ∀ τ : E →+* ℂ, (∃ i : X.Ψ, (fun τ : X.Ψ => τ.1) i = τ) ↔
      ¬ ∃ i : X.Ψ, (fun τ : X.Ψ => τ.1) i = ComplexEmbedding.conjugate τ := by
    simpa using X.cmType
  have h_short : ∀ v ∈ LB, v ≠ 0 → ∃ i : X.Ψ, Real.sqrt ep ^ 2 ≤
      ReciprocityTheory.MultiplicativeHeights.normSq (Q i *ᵥ ReciprocityTheory.MultiplicativeHeights.embVec i.1 v) := by
    intro v hv hv0
    obtain ⟨e, he⟩ := (hLB v).mp hv
    have hne : ∀ e' : E, ∑ k, v k • β k + e • ξ ≠ e' • ξ := by
      intro e'
      apply IsotropicCombinations.ne_smul_ξ (hli := hβind) (hc := hv0) <;> assumption
    obtain ⟨τ, hτ⟩ := hD4 _ he (hlamξ v e) hne
    refine ⟨τ, ?_⟩
    rw [IsotropicIndexSums.ucomp_drop (hx := hz) (hne := hξ0), hQf, (hf τ).2.2.2.1] at hτ
    rw [Real.sq_sqrt hep.le]
    exact hτ
  have hD := hD5 E X.Ψ (r - 2) (X.p0 - 1) S (fun τ : X.Ψ => τ.1) Q LB (Real.sqrt ep) h_inj h_cm
    hpr (Real.sqrt_pos.mpr hep) hQ hSQ hLat hSD h_short
  obtain ⟨hcov, v, hvL, hvli, hvmaj⟩ := hD
  rw [hcard] at hcov hvmaj
  have hf1 : (1 : ℝ) ≤ (fdeg E : ℝ) := by
    rw [← hcard]; exact_mod_cast Nat.one_le_iff_ne_zero.mpr hcardpos.ne'
  have hnR : (1 : ℝ) ≤ ((r - 2 : ℕ) : ℝ) := by exact_mod_cast Nat.one_le_iff_ne_zero.mpr hn.ne'
  have hd1 : (1 : ℝ) ≤ dE E := by
    unfold dE
    rw [← Int.cast_abs]
    exact_mod_cast Int.one_le_abs (NumberField.discr_ne_zero (K := E))
  have hs : 0 < Real.sqrt ep := Real.sqrt_pos.mpr hep
  have hs1 : Real.sqrt ep ≤ 1 := by simpa using Real.sqrt_le_sqrt hep1
  have hXd := one_le_mul_of_one_le_of_one_le
    (one_le_pow₀ (one_le_mul_of_one_le_of_one_le hf1 hnR) (n := 3)) hd1
  let μ := d5mu (fdeg E) (r - 2) (dE E) (Real.sqrt ep)
  have hμ4 : 4 ≤ μ := by
    change 4 ≤ _ / _
    rw [le_div_iff₀ hs]
    linarith
  have hμpos : 0 < μ := by linarith
  have hA := Real.one_le_sqrt.mpr hnR
  let radius := ReciprocityTheory.MultiplicativeHeights.approxR (r - 2) μ (rh / 40)
  have radius_eq : 2 * radius = 320 * (Real.sqrt ((r - 2 : ℕ) : ℝ) * μ) / rh := by
    unfold radius ReciprocityTheory.MultiplicativeHeights.approxR
    rw [div_div_eq_mul_div]
    ring
  have hT320 : 320 * μ ≤ 2 * radius := by
    rw [radius_eq, le_div_iff₀ hrh]
    nlinarith [mul_le_mul_of_nonneg_left hrh1 hμpos.le, mul_le_mul_of_nonneg_right hA hμpos.le]
  have hT1 : 1 ≤ 2 * radius := by linarith
  have hTμ : 2 * μ ^ 2 ≤ (2 * radius) ^ 2 := by
    nlinarith [mul_le_mul hT320 hT320 (by linarith) (by linarith), sq_nonneg μ]
  obtain ⟨la, hlaL, hlali, hlaorth, hlapos, hlaneg, hlab1, hlab2⟩ :=
    ReciprocityTheory.MultiplicativeHeights.Closed.approx E X.Ψ (r - 2) (X.p0 - 1) S (fun τ : X.Ψ => τ.1) Q LB v
      μ (rh / 40) hpr hμpos (div_pos hrh (by norm_num)) (by linarith) hQ hSQ hSD.1
      hcov hvL hvli hvmaj
  choose ec hec using fun j => (hLB (la j)).mp (hlaL j)
  have hu : ∀ (τ : X.Ψ) (j : Fin (r - 2)), X.ucomp z0 ξ (X.embV (∑ i, la j i • β i + ec j • ξ)) τ =
      ∑ k, (Q τ *ᵥ ReciprocityTheory.MultiplicativeHeights.embVec τ.1 (la j)) k • f τ k := by
    intro τ j
    rw [IsotropicIndexSums.ucomp_drop (hx := hz) (hne := hξ0), hQf]
  have hcomb : ∀ (τ : X.Ψ) (w : Fin (r - 2) → ℂ),
      ∑ j, w j • X.ucomp z0 ξ (X.embV (∑ i, la j i • β i + ec j • ξ)) τ =
        ∑ k, (Q τ *ᵥ ∑ j, w j • ReciprocityTheory.MultiplicativeHeights.embVec τ.1 (la j)) k • f τ k := by
    intro τ w
    simp_rw [hu τ]
    rw [IsotropicCombinations.comb_swap]
    simp_rw [IsotropicCombinations.qcomb]
  have hone : ∀ (τ : X.Ψ) (j : Fin (r - 2)),
      Q τ *ᵥ ∑ i, (Pi.single j (1 : ℂ) : Fin (r - 2) → ℂ) i • ReciprocityTheory.MultiplicativeHeights.embVec τ.1 (la i) =
        Q τ *ᵥ ReciprocityTheory.MultiplicativeHeights.embVec τ.1 (la j) := by
    intro τ j
    congr 1
    simp [Pi.single_apply]
  have hsn : ∀ j : Fin (r - 2), (Pi.single j (1 : ℂ) : Fin (r - 2) → ℂ) ≠ 0 :=
    fun j h => by simpa using congrFun h j
  have hll : ∀ j1 j2 : Fin (r - 2), herm X.Gm (∑ i, la j1 i • β i + ec j1 • ξ) (∑ i, la j2 i • β i + ec j2 • ξ) = S.h (la j2) (la j1) := by
    intro j1 j2
    rw [hS (la j2) (la j1)]
    apply IsotropicCombinations.herm_lam_lam <;> first | assumption | exact X.Gm_herm
  have hM : ∀ τ : X.Ψ, LinearIndependent ℂ (fun j => Q τ *ᵥ ReciprocityTheory.MultiplicativeHeights.embVec τ.1 (la j)) :=
    fun τ => linearIndependent_mulVec_embVec τ.1 la (Q τ) hlali (hQ τ)
  refine ⟨fun j => (∑ i, la j i • β i + ec j • ξ), fun j => ⟨hec j, hlamξ _ _⟩,
    ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · apply IsotropicCombinations.cons_li (hli := hβind) (hla := hlali) <;> assumption

  · intro j k hj hk
    rw [hll, hSsym _ _ (hlaorth j k hj hk)]
  · intro j hj τ
    rw [hll, hSQ, ← hone τ j]
    exact (hlapos τ (Pi.single j (1 : ℂ))
      (fun i hi => by rw [Pi.single_apply, if_neg]; rintro rfl; omega)).2 (hsn j)
  · intro j hj τ
    rw [hll, hSQ, ← hone τ j]
    exact hlaneg τ (Pi.single j (1 : ℂ))
      (fun i hi => by rw [Pi.single_apply, if_neg]; rintro rfl; omega) (hsn j)
  · intro j τ
    rw [hll]
    apply IsotropicCombinations.la_bound (hT := hT1) (hμ := hTμ) (hp0 := hp1)
    by_cases hj : (j : ℕ) < X.p0 - 1
    · exact Or.inl (hlab1 τ j hj)
    · exact Or.inr (hlab2 τ j (not_lt.mp hj))
  · intro τ
    rw [Fintype.linearIndependent_iff]
    intro w hw
    rw [hcomb τ w] at hw
    have h0 : Q τ *ᵥ ∑ j, w j • ReciprocityTheory.MultiplicativeHeights.embVec τ.1 (la j) = 0 :=
      IsotropicIndexSums.coeff_unique (f := f τ) (hf := hON τ)
        (h := hw.trans (by simp : (0 : Fin r → ℂ) = ∑ k, (0 : Fin (r - 2) → ℂ) k • f τ k))
    apply Fintype.linearIndependent_iff.mp (hM τ) w
    simpa only [← Matrix.mulVecLin_apply, map_sum, map_smul] using h0
  · intro τ j
    rw [hu τ j]
    exact Submodule.sum_mem _ fun k _ => Submodule.smul_mem _ _ (Submodule.subset_span ⟨k, rfl⟩)
  · intro τ j k hj hk
    rw [hu τ j, hu τ k, IsotropicCombinations.hC_comb2_ortho (hf := hON τ), ← hSQ,
      hSsym _ _ (hlaorth j k hj hk), map_zero]
  · intro τ w hw hw0
    rw [hcomb τ w, IsotropicIndexSums.hC_comb_ortho (hf := hON τ)]
    exact (hlapos τ w hw).2 hw0
  · intro τ w hw hw0
    rw [hcomb τ w, IsotropicIndexSums.hC_comb_ortho (hf := hON τ)]
    exact hlaneg τ w hw hw0
  · intro τ c hc
    rw [Finsupp.mem_span_image_iff_linearCombination] at hc
    obtain ⟨l, hl, hlc⟩ := hc
    rw [Finsupp.linearCombination_apply, Finsupp.sum_fintype l
      (fun i a => a • X.ucomp z0 ξ (X.embV (∑ k, la i k • β k + ec i • ξ)) τ) (fun _ => zero_smul ℂ _)] at hlc
    rw [hcomb τ l] at hlc
    have hcq := IsotropicIndexSums.coeff_unique (f := f τ) (hf := hON τ) (h := hlc)
    have hws : ∀ j : Fin (r - 2), X.p0 - 1 ≤ (j : ℕ) → l j = 0 := by
      intro j hj
      rw [Finsupp.mem_supported'] at hl
      exact hl j (by simp only [Set.mem_setOf_eq, not_lt]; exact hj)
    have h3 := (hlapos τ l hws).1
    simp only [hcq] at h3
    rw [show rh / 40 / 3 = rh / 120 by ring] at h3
    exact h3

end

end ReciprocityTheory.ChartRestriction.G.FD
