import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.IsotropicOutsideLine
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.RealEmbeddingCharacters

namespace ReciprocityTheory.ChartRestriction.G.FD.FourierCoefficientMatrices

open NumberField Complex ReciprocityTheory.ChartRestriction.G.FD
open scoped ComplexConjugate

noncomputable section

section Fam

variable {ι : Type} [Fintype ι]

def kap (b : ι → Fin 2 → Fin 2 → ℂ) : ι → Fin 2 → Fin 2 → ℝ :=
  fun τ i k => if (i : ℕ) ≤ k then (b τ i k).re else (b τ k i).im

def th (y : ι → Fin 2 → Fin 2 → ℝ) : ι → Fin 2 → Fin 2 → ℂ :=
  fun τ i k => if i = k then (y τ i k : ℂ) else if (i : ℕ) < k then (y τ i k : ℂ) + I * y τ k i
    else (y τ k i : ℂ) - I * y τ i k

def kapL : (ι → Fin 2 → Fin 2 → ℂ) →ₗ[ℝ] (ι → Fin 2 → Fin 2 → ℝ) where
  toFun := kap
  map_add' b c := by
    funext τ i k; simp only [kap, Pi.add_apply]; split_ifs <;> simp
  map_smul' s b := by
    funext τ i k; simp only [kap, Pi.smul_apply, RingHom.id_apply]; split_ifs <;> simp

def thL : (ι → Fin 2 → Fin 2 → ℝ) →ₗ[ℝ] (ι → Fin 2 → Fin 2 → ℂ) where
  toFun := th
  map_add' y z := by
    funext τ i k; simp only [th, Pi.add_apply]; split_ifs <;> push_cast <;> ring
  map_smul' s y := by
    funext τ i k; simp only [th, Pi.smul_apply, RingHom.id_apply, smul_eq_mul, Complex.real_smul]
    split_ifs <;> push_cast <;> ring

lemma th_herm (y : ι → Fin 2 → Fin 2 → ℝ) : IsHermFam (th y) := by
  intro τ i k
  fin_cases i <;> fin_cases k <;> simp [th] <;> ring

lemma kap_th (y : ι → Fin 2 → Fin 2 → ℝ) : kap (th y) = y := by
  funext τ i k
  fin_cases i <;> fin_cases k <;> simp [kap, th]

lemma th_kap {b : ι → Fin 2 → Fin 2 → ℂ} (hb : IsHermFam b) : th (kap b) = b := by
  funext τ i k
  have h00 := hb τ 0 0
  have h11 := hb τ 1 1
  have h01 := hb τ 0 1
  rw [Complex.ext_iff] at h00 h11 h01
  simp at h00 h11 h01
  fin_cases i <;> fin_cases k <;> apply Complex.ext <;> simp [th, kap] <;> linarith

lemma th_zero : th (0 : ι → Fin 2 → Fin 2 → ℝ) = 0 := (thL (ι := ι)).map_zero

lemma conj_herm {χ : ι → Fin 2 → Fin 2 → ℂ} (h : IsHermFam χ) :
    IsHermFam (fun τ i k => conj (χ τ i k)) := by
  intro τ i k
  show conj (χ τ k i) = conj (conj (χ τ i k))
  rw [h τ i k]

def pr (χ b : ι → Fin 2 → Fin 2 → ℂ) : ℝ := (∑ τ, ∑ i, ∑ k, χ τ i k * b τ i k).re

def prL (χ : ι → Fin 2 → Fin 2 → ℂ) : (ι → Fin 2 → Fin 2 → ℂ) →ₗ[ℝ] ℝ where
  toFun := pr χ
  map_add' b c := by simp [pr, mul_add, Finset.sum_add_distrib]
  map_smul' a b := by
    simp only [pr, Pi.smul_apply, Complex.real_smul, RingHom.id_apply, smul_eq_mul,
      mul_left_comm _ (a : ℂ), ← Finset.mul_sum, Complex.re_ofReal_mul]

def prR (b : ι → Fin 2 → Fin 2 → ℂ) : (ι → Fin 2 → Fin 2 → ℂ) →ₗ[ℝ] ℝ :=
  (prL b).copy (fun χ => pr χ b) (by funext χ; change pr χ b = pr b χ; simp [pr,mul_comm])

lemma pr_sum {N : ℕ} (χ : ι → Fin 2 → Fin 2 → ℂ) (c : Fin N → ℝ) (ω : Fin N → ι → Fin 2 → Fin 2 → ℂ) :
    pr χ (∑ j, (c j : ℂ) • ω j) = ∑ j, c j * pr χ (ω j) := by
  simp_rw [Complex.coe_smul]
  change (prL χ) (∑ j, c j • ω j) = _
  simp [map_sum, map_smul]
  rfl

lemma eq_zero_of_pr_conj {χ : ι → Fin 2 → Fin 2 → ℂ}
    (h : pr χ (fun τ i k => conj (χ τ i k)) = 0) : χ = 0 := by
  simp only [pr, Complex.mul_conj] at h
  simp only [← Complex.ofReal_sum, Complex.ofReal_re] at h
  simp only [Complex.normSq_eq_norm_sq] at h
  simp (disch := (intros; positivity)) only [Finset.sum_eq_zero_iff_of_nonneg, Finset.mem_univ,
    forall_const, sq_eq_zero_iff, norm_eq_zero] at h
  exact funext fun τ => funext fun i => funext fun k => h τ i k

lemma finrank_rfam : Module.finrank ℝ (ι → Fin 2 → Fin 2 → ℝ) = 4 * Fintype.card ι := by
  rw [Module.finrank_pi_fintype]
  simp [Module.finrank_pi_fintype, mul_comm]

end Fam

section Basis

variable {ι : Type} [Fintype ι] {N : ℕ} (ω : Fin N → ι → Fin 2 → Fin 2 → ℂ)

lemma kap_li (hω : ∀ j, IsHermFam (ω j)) (hli : LinearIndependent ℝ ω) :
    LinearIndependent ℝ (fun j => kap (ω j)) := by
  apply LinearIndependent.of_comp thL
  have id : thL ∘ (fun j => kap (ω j)) = ω := funext fun j => th_kap (hω j)
  rwa [id]

def basR (hω : ∀ j, IsHermFam (ω j)) (hli : LinearIndependent ℝ ω) (hN : N = 4 * Fintype.card ι) :
    Module.Basis (Fin N) ℝ (ι → Fin 2 → Fin 2 → ℝ) :=
  basisOfLinearIndependentOfCardEqFinrank' _ (kap_li ω hω hli) (by rw [Fintype.card_fin, finrank_rfam, hN])

lemma herm_eq_sum (hω : ∀ j, IsHermFam (ω j)) (hli : LinearIndependent ℝ ω)
    (hN : N = 4 * Fintype.card ι) {b : ι → Fin 2 → Fin 2 → ℂ} (hb : IsHermFam b) :
    ∃ s : Fin N → ℝ, b = ∑ j, (s j : ℂ) • ω j := by
  let B := basR ω hω hli hN
  have hB : ⇑B = fun j => kap (ω j) := coe_basisOfLinearIndependentOfCardEqFinrank' _ _ _
  refine ⟨B.repr (kap b), ?_⟩
  have h := congrArg thL (B.sum_repr (kap b))
  simp [map_sum, map_smul, hB] at h
  change ∑ j, B.repr (kap b) j • th (kap (ω j)) = th (kap b) at h
  simpa only [th_kap hb, fun j => th_kap (hω j), Complex.coe_smul] using h.symm

def phiL : (ι → Fin 2 → Fin 2 → ℝ) →ₗ[ℝ] (Fin N → ℝ) :=
  LinearMap.pi fun j => (2 : ℝ) • ((prR (ω j)).comp thL)

lemma phiL_apply (z : ι → Fin 2 → Fin 2 → ℝ) (j : Fin N) : phiL ω z j = 2 * pr (th z) (ω j) := rfl

lemma phiL_inj (hω : ∀ j, IsHermFam (ω j)) (hli : LinearIndependent ℝ ω)
    (hN : N = 4 * Fintype.card ι) : Function.Injective (phiL ω) := by
  refine (injective_iff_map_eq_zero (phiL ω)).mpr fun z hz => ?_
  have hp : ∀ j, pr (th z) (ω j) = 0 := fun j => by
    have h := congrFun hz j
    rw [phiL_apply] at h
    simpa using h
  obtain ⟨s, hs⟩ := herm_eq_sum ω hω hli hN (conj_herm (th_herm z))
  have h0 : pr (th z) (fun τ i k => conj (th z τ i k)) = 0 := by
    rw [hs, pr_sum]
    simp [hp]
  have hz0 := eq_zero_of_pr_conj h0
  rw [← kap_th z, hz0]
  exact (kapL (ι := ι)).map_zero

lemma phiL_surj (hω : ∀ j, IsHermFam (ω j)) (hli : LinearIndependent ℝ ω)
    (hN : N = 4 * Fintype.card ι) : Function.Surjective (phiL ω) := (LinearMap.injective_iff_surjective_of_finrank_eq_finrank
    (by rw [finrank_rfam, Module.finrank_fin_fun, hN])).mp (phiL_inj ω hω hli hN)

private def coordEquiv (hω : ∀ j, IsHermFam (ω j)) (hli : LinearIndependent ℝ ω)
    (hN : N = 4 * Fintype.card ι) := LinearEquiv.ofBijective (phiL ω)
      ⟨phiL_inj ω hω hli hN, phiL_surj ω hω hli hN⟩

def chiOf (hω : ∀ j, IsHermFam (ω j)) (hli : LinearIndependent ℝ ω)
    (hN : N = 4 * Fintype.card ι) (m : Fin N → ℝ) : ι → Fin 2 → Fin 2 → ℂ :=
  th ((coordEquiv ω hω hli hN).symm m)

variable (hω : ∀ j, IsHermFam (ω j)) (hli : LinearIndependent ℝ ω) (hN : N = 4 * Fintype.card ι)

lemma chiOf_herm (m : Fin N → ℝ) : IsHermFam (chiOf ω hω hli hN m) := th_herm _

lemma chiOf_pair (m : Fin N → ℝ) (j : Fin N) : 2 * pr (chiOf ω hω hli hN m) (ω j) = m j := by
  unfold chiOf
  exact congrFun (LinearEquiv.apply_symm_apply
    (coordEquiv ω hω hli hN) m) j

lemma chiOf_eq {χ : ι → Fin 2 → Fin 2 → ℂ} (hχ : IsHermFam χ) {m : Fin N → ℝ}
    (hm : ∀ j, 2 * pr χ (ω j) = m j) : χ = chiOf ω hω hli hN m := by
  unfold chiOf
  have he : phiL ω (kap χ) = m := funext fun j => by rw [phiL_apply, th_kap hχ, hm j]
  rw [← th_kap hχ]
  congr 1
  rw [← he]
  exact ((coordEquiv ω hω hli hN).symm_apply_apply
    (kap χ)).symm

lemma chiOf_inj : Function.Injective (chiOf ω hω hli hN) := by
  intro m m' h
  funext j
  rw [← chiOf_pair ω hω hli hN m j, ← chiOf_pair ω hω hli hN m' j, h]

end Basis

section ZbFacts

variable {E : Type} [Field E] [NumberField E] [IsCMField E] {r : ℕ} (X : Data E r)
  (u : Fin 2 → Fin r → E)

lemma mat_Zb (b : X.Ψ → Fin 2 → Fin 2 → ℂ) (x : Frame X.Ψ r) (τ : X.Ψ) :
    mat (X.Zb u b x) τ = X.zmat u b τ * mat x τ := rfl

lemma zmat_zero (τ : X.Ψ) : X.zmat u 0 τ = 1 := by
  ext a j
  simp [Data.zmat, Matrix.one_apply]

lemma Zb_zero (x : Frame X.Ψ r) : X.Zb u 0 x = x := by
  funext τ
  show X.zmat u 0 τ * mat x τ = x τ
  rw [zmat_zero, one_mul]
  rfl


def fac (la : Wt X.Ψ r) (x : Frame X.Ψ r) : ℝ :=
  ∏ τ, ∏ i : Fin r, ‖dmin X.Gm x τ i.succ / dmin X.Gm x τ i.castSucc‖ ^ (-(la τ i : ℝ) / 2)

lemma pnorm_eq (la : Wt X.Ψ r) (P : Frame X.Ψ r → ℂ) (x : Frame X.Ψ r) :
    X.pnorm la P x = ‖P x‖ * fac X la x := rfl

lemma fac_nonneg (la : Wt X.Ψ r) (x : Frame X.Ψ r) : 0 ≤ fac X la x := Finset.prod_nonneg fun _ _ => Finset.prod_nonneg fun _ _ => Real.rpow_nonneg (norm_nonneg _) _

end ZbFacts

end

end ReciprocityTheory.ChartRestriction.G.FD.FourierCoefficientMatrices
