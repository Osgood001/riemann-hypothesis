import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.BabaiCovering
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.RealTangentSpace
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.DiscriminantTraceBounds
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.HermEqZeroOfTraceFormVanish

namespace ReciprocityTheory.ChartRestriction.G.FD

namespace DiscreteLatticeMinimum

open NumberField Complex Module RealTangentSpace
open scoped ComplexConjugate

variable {E : Type} [Field E] [NumberField E] [IsCMField E] {r : ℕ} {Y : DataX E r}
  (z : Frame Y.Ψ r) (ξ : Fin r → E) [hz : Fact (z ∈ Y.dom)]

noncomputable def Bmap : VT (X := Y.toData) z ξ →ₗ[ℝ] VT (X := Y.toData) z ξ where
  toFun u := VT.mk (MajorantOperators.Bop z u.val) (MajorantOperators.Bop_mem hz.out u.val_mem)
  map_add' u v := VT.ext (by simp [MajorantOperators.Bop_add])
  map_smul' c u := VT.ext (by simp [MajorantOperators.Bop_smul])

theorem Bmap_val (u : VT (X := Y.toData) z ξ) : (Bmap z ξ u).val = MajorantOperators.Bop z u.val := rfl

theorem Bmap_Bmap (u : VT (X := Y.toData) z ξ) : Bmap z ξ (Bmap z ξ u) = (-(Y.k0 ^ 2)) • u := by
  apply VT.ext
  rw [Bmap_val, Bmap_val, MajorantOperators.Bop_Bop hz.out]
  rfl

theorem inner_Bmap_right (u v : VT (X := Y.toData) z ξ) :
    inner ℝ u (Bmap z ξ v) = -inner ℝ (Bmap z ξ u) v := by
  rw [inner_eq, inner_eq, Bmap_val, Bmap_val, MajorantOperators.gI_Bop_right hz.out]

theorem norm_Bmap (u : VT (X := Y.toData) z ξ) : ‖Bmap z ξ u‖ = Y.k0 * ‖u‖ := by
  have h : ‖Bmap z ξ u‖ ^ 2 = (Y.k0 * ‖u‖) ^ 2 := by
    rw [← real_inner_self_eq_norm_sq, mul_pow, ← real_inner_self_eq_norm_sq, inner_eq, inner_eq,
      Bmap_val, MajorantOperators.gI_Bop_self hz.out]
  exact (pow_left_inj₀ (norm_nonneg _) (mul_nonneg Y.minWeight_pos.le (norm_nonneg _))
    two_ne_zero).1 h

theorem Bmap_injective : Function.Injective (Bmap z ξ) := by
  rw [← LinearMap.ker_eq_bot, LinearMap.ker_eq_bot']
  intro u hu
  exact norm_eq_zero.mp ((mul_eq_zero.mp (by simpa [hu] using (norm_Bmap z ξ u).symm)).resolve_left
    Y.minWeight_pos.ne')

noncomputable def Bequiv : VT (X := Y.toData) z ξ ≃ₗ[ℝ] VT (X := Y.toData) z ξ :=
  LinearEquiv.ofBijective (Bmap z ξ) ⟨Bmap_injective z ξ,
    LinearMap.surjective_of_injective (Bmap_injective z ξ)⟩

variable {ξ} (hξ : Y.IsIso ξ)

theorem mem_Lat_of_int (hD3 : IntegerApproximationCount (E := E)) (y : VT (X := Y.toData) z ξ)
    (hy : ∀ a ∈ Lat z ξ hξ, ∃ m : ℤ, inner ℝ y (Bmap z ξ a) = m) : y ∈ Lat z ξ hξ := by
  classical
  choose f hf using fun ν : Y.Λp ξ => hy (phi z ξ hξ ν) ((mem_Lat z ξ hξ).mpr ⟨ν,rfl⟩)
  let ψ : Y.Λp ξ →+ ℤ := AddMonoidHom.mk' f fun a b => by
    apply Int.cast_injective (α := ℝ)
    rw [Int.cast_add, ← hf, ← hf, ← hf, map_add, map_add, inner_add_right]
  have hψ (ν) : (ψ ν : ℝ) = inner ℝ y (Bmap z ξ (phi z ξ hξ ν)) := (hf ν).symm
  have hvan : ∀ ν : Y.Λp ξ, (∃ e : E, (ν : Fin r → E) = e • ξ) → ψ ν = 0 := by
    rintro ν ⟨e, he⟩
    have h0 : phi z ξ hξ ν = 0 := VT.ext (by rw [phi_val, he, ucomp_line z ξ hξ e]; rfl)
    have := hψ ν
    rw [h0, map_zero, inner_zero_right] at this
    exact_mod_cast this
  obtain ⟨μ, hμ⟩ := (hermitian_dual_lattice_identity r Y ξ hξ).1 ψ hvan
  have hEF : ∀ ν : Y.Λp ξ,
      inner ℝ (Bmap z ξ y + Bmap z ξ (phi z ξ hξ μ)) (phi z ξ hξ ν) = 0 := by
    intro ν
    have h1 := hμ ν
    have h2 : ((EFf Y.ξ0 Y.Gm μ ν : ℚ) : ℝ) =
        inner ℝ (Bmap z ξ (phi z ξ hξ μ)) (phi z ξ hξ ν) := by
      rw [inner_eq, Bmap_val, phi_val, phi_val]
      exact MajorantOperators.EF_eq hz.out hξ.2.1 (LatticeSpanMembership.mem_Λp_iff.mp μ.2).2
        (LatticeSpanMembership.mem_Λp_iff.mp ν.2).2
    have h3 : (ψ ν : ℝ) = ((EFf Y.ξ0 Y.Gm μ ν : ℚ) : ℝ) := by exact_mod_cast h1
    rw [hψ, inner_Bmap_right, h2] at h3
    rw [inner_add_left]
    linarith
  set w := Bmap z ξ y + Bmap z ξ (phi z ξ hξ μ) with hw
  have hw0 : w = 0 := by
    have van : Submodule.span ℝ (Lat z ξ hξ : Set _) ≤ LinearMap.ker (innerSL ℝ w).toLinearMap := by
      apply Submodule.span_le.mpr
      rintro u hu
      obtain ⟨ν,rfl⟩ := (mem_Lat z ξ hξ).mp hu
      exact hEF ν
    exact inner_self_eq_zero.mp (van (x := w) (by rw [span_Lat z ξ hD3 hξ]; exact Submodule.mem_top))
  refine (mem_Lat z ξ hξ).mpr ⟨-μ, ?_⟩
  rw [map_neg]
  exact (eq_neg_of_add_eq_zero_left ((Bmap_injective z ξ) (by simpa [map_add, hw] using hw0))).symm

section lattice

variable (ep0 : ℝ) (hns : ∀ x ∈ Y.L', herm Y.Gm x ξ = 0 → (∀ e : E, x ≠ e • ξ) →
      ∃ τ : Y.Ψ, ep0 ≤ Y.maj z τ (Y.ucomp z ξ (Y.embV x) τ))

include hns in
theorem min_norm (a : VT (X := Y.toData) z ξ) (ha : a ∈ Lat z ξ hξ) (ha0 : a ≠ 0) :
    Real.sqrt ep0 / Y.NA ≤ ‖a‖ := by
  obtain ⟨μ, rfl⟩ := (mem_Lat z ξ hξ).mp ha
  have hμ := LatticeSpanMembership.mem_Λp_iff.mp μ.2
  have hNA : (Y.NA : E) ≠ 0 := by exact_mod_cast Y.NA_pos.ne'
  have hNAr : (0 : ℝ) < Y.NA := by exact_mod_cast Y.NA_pos
  obtain ⟨τ, hτ⟩ := hns ((Y.NA : E) • (μ : Fin r → E)) (Y.NA_sub _ hμ.1)
    (by rw [HermitianTraceFormVanishing.herm_smul_left, hμ.2, mul_zero])
    (by
      intro e he
      apply ha0
      have hμe : (μ : Fin r → E) = ((Y.NA : E)⁻¹ * e) • ξ := by
        rw [mul_smul, ← he, smul_smul, inv_mul_cancel₀ hNA, one_smul]
      exact VT.ext (by rw [phi_val, hμe, ucomp_line z ξ hξ]; rfl))
  have hemb : Y.embV ((Y.NA : E) • (μ : Fin r → E)) = (Y.NA : ℝ) • Y.embV μ := by
    funext τ' b
    simp [Data.embV, Data.emb]
  rw [hemb, ucomp_smul, Pi.smul_apply, ← Complex.coe_smul, UnipotentCoefficientShift.maj_smul hz.out] at hτ
  have h2 := maj_le_norm_sq z ξ (phi z ξ hξ μ) τ
  rw [phi_val] at h2
  have h3 : ep0 ≤ (Y.NA * ‖phi z ξ hξ μ‖) ^ 2 := by
    rw [mul_pow]
    exact le_trans hτ (mul_le_mul_of_nonneg_left h2 (by positivity))
  have h4 := Real.sqrt_le_sqrt h3
  rw [Real.sqrt_sq (by positivity)] at h4
  rw [div_le_iff₀ hNAr]
  linarith

include hns in
theorem discrete_Lat (hep : 0 < ep0) : DiscreteTopology (Lat z ξ hξ) := by
  apply discreteTopology_of_isOpen_singleton_zero
  refine Metric.isOpen_singleton_iff.mpr ⟨Real.sqrt ep0 / Y.NA,
    div_pos (Real.sqrt_pos.mpr hep) (by exact_mod_cast Y.NA_pos), ?_⟩
  intro a ha
  have hdist : dist a.val 0 < Real.sqrt ep0 / Y.NA := ha
  by_contra hn
  exact (not_lt_of_ge (min_norm z hξ ep0 hns a.val a.property (fun h => hn (Subtype.ext h))))
    (by simpa only [dist_zero_right] using hdist)

include hns in
theorem short_basis (hD3 : IntegerApproximationCount (E := E)) (hep : 0 < ep0) :
    ∃ y : Fin (finrank ℝ (VT (X := Y.toData) z ξ)) → VT (X := Y.toData) z ξ,
      LinearIndependent ℝ y ∧ (∀ i, y i ∈ Lat z ξ hξ) ∧
      ∀ i, ‖y i‖ ≤ (finrank ℝ (VT (X := Y.toData) z ξ) : ℝ) ^ 2 /
        (Y.k0 * Real.sqrt ep0 / Y.NA) := by
  classical
  have := discrete_Lat z hξ ep0 hns hep
  have : IsZLattice ℝ (Lat z ξ hξ) := ⟨span_Lat z ξ hD3 hξ⟩
  have := ZLattice.module_free ℝ (Lat z ξ hξ)
  have := ZLattice.module_finite ℝ (Lat z ξ hξ)
  set n := finrank ℝ (VT (X := Y.toData) z ξ) with hn
  let bZ := Module.Free.chooseBasis ℤ (Lat z ξ hξ)
  let bR := bZ.ofZLatticeBasis ℝ (Lat z ξ hξ)
  have hspanR : Submodule.span ℤ (Set.range bR) = Lat z ξ hξ := bZ.ofZLatticeBasis_span ℝ _
  let b' := bR.map (Bequiv z ξ)
  have hb' (j) : b' j = Bmap z ξ (bR j) := rfl
  set lam := Y.k0 * Real.sqrt ep0 / Y.NA with hlam
  have hlam0 : 0 < lam := by
    have h1 := Y.minWeight_pos
    have h2 : (0 : ℝ) < Y.NA := by exact_mod_cast Y.NA_pos
    have h3 := Real.sqrt_pos.mpr hep
    positivity
  let f := (Bmap z ξ).restrictScalars ℤ
  have hfr : f '' Set.range bR = Set.range b' := by rw [← Set.range_comp]; rfl
  have hmin : ∀ x ∈ Submodule.span ℤ (Set.range b'), x ≠ 0 → lam ≤ ‖x‖ := by
    intro x hx hx0
    rw [← hfr, Submodule.span_image, hspanR] at hx
    obtain ⟨a, ha, rfl⟩ := hx
    have ha0 : a ≠ 0 := by
      rintro rfl
      exact hx0 (map_zero f)
    have hfa : ‖f a‖ = Y.k0 * ‖a‖ := by
      exact norm_Bmap z ξ a
    rw [hfa, hlam, mul_div_assoc]
    exact mul_le_mul_of_nonneg_left (min_norm z hξ ep0 hns a ha ha0) Y.minWeight_pos.le
  obtain ⟨y, hli, hint, hnorm⟩ := BabaiCovering.dual_short b' lam hlam0 hmin
  refine ⟨y, hli, ?_, hnorm⟩
  intro i
  apply mem_Lat_of_int z hξ hD3
  intro a ha
  rw [← hspanR] at ha
  obtain ⟨c, rfl⟩ := (Submodule.mem_span_range_iff_exists_fun ℤ).mp ha
  choose m hm using hint i
  refine ⟨∑ j, c j * m j, ?_⟩
  simp only [map_sum, map_zsmul, inner_sum, ← Int.cast_smul_eq_zsmul ℝ, map_smul, real_inner_smul_right,
    ← hb', hm, Int.cast_sum, Int.cast_mul]


include hns in

theorem covering (hD3 : IntegerApproximationCount (E := E)) (hep : 0 < ep0) (d : VT (X := Y.toData) z ξ) :
    ∃ μ : Y.Λp ξ, ‖d - phi z ξ hξ μ‖ ≤ (finrank ℝ (VT (X := Y.toData) z ξ) : ℝ) ^ 3 * Y.NA /
      (2 * Y.k0 * Real.sqrt ep0) := by
  classical
  let n := finrank ℝ (VT (X := Y.toData) z ξ)
  let lam := Y.k0 * Real.sqrt ep0 / Y.NA
  have hk := Y.minWeight_pos
  have hN : (0 : ℝ) < Y.NA := by exact_mod_cast Y.NA_pos
  have hs := Real.sqrt_pos.mpr hep
  have hlam : 0 < lam := div_pos (mul_pos hk hs) hN
  obtain ⟨y, hli, hy, hlen⟩ := short_basis z hξ ep0 hns hD3 hep
  have hspan := hli.span_eq_top_of_card_eq_finrank' (by simp)
  obtain ⟨x, hx, hdist⟩ := BabaiCovering.babai n y d (hspan ▸ Submodule.mem_top)
  obtain ⟨μ, hμ⟩ := (mem_Lat z ξ hξ).mp ((Submodule.span_le.mpr (by rintro _ ⟨j, rfl⟩; exact hy j)) hx)
  refine ⟨μ, ?_⟩
  rw [hμ]
  have hb : ‖d - x‖ ^ 2 ≤ 1 / 4 * ((n : ℝ) * ((n : ℝ)^2 / lam)^2) := hdist.trans (by
    calc _ ≤ 1 / 4 * ∑ _i : Fin n, ((n : ℝ)^2 / lam)^2 := by
           gcongr with i
           exact hlen i
       _ = _ := by simp)
  have hn : (n : ℝ) ≤ (n : ℝ)^2 := by rw [sq]; exact_mod_cast Nat.le_mul_self n
  have hnn : 0 ≤ (n : ℝ) := Nat.cast_nonneg n
  have hbound : ‖d - x‖ ≤ (n : ℝ) / 2 * ((n : ℝ)^2 / lam) := by
    apply (sq_le_sq₀ (norm_nonneg _) (by positivity)).mp
    nlinarith only [hb, mul_le_mul_of_nonneg_right hn (sq_nonneg ((n : ℝ)^2 / lam))]
  apply hbound.trans_eq
  change _ = (n : ℝ)^3 * Y.NA / (2 * Y.k0 * Real.sqrt ep0)
  dsimp [lam]
  field_simp
  <;> ring


end lattice

end DiscreteLatticeMinimum

end ReciprocityTheory.ChartRestriction.G.FD
