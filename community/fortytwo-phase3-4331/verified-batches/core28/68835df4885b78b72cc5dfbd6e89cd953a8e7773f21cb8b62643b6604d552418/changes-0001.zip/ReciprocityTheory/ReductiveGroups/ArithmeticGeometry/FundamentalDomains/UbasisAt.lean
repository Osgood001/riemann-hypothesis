import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.HCSumRight

namespace ReciprocityTheory.ChartRestriction.G.FD.OrthonormalPerpBasis

open NumberField Complex Matrix
open scoped ComplexConjugate ComplexOrder

noncomputable section

variable {E : Type} [Field E] [NumberField E] [NumberField.IsCMField E]

variable {r : ℕ} (X : Data E r)

private theorem sum_castLE_lemma {M : Type*} [AddCommMonoid M] (n p : ℕ) (hp : p ≤ n)
    (f : Fin n → M) :
    ∑ i : Fin p, f (Fin.castLE hp i) = ∑ a : Fin n, if (a : ℕ) < p then f a else 0 := by
  obtain ⟨q, rfl⟩ := Nat.exists_eq_add_of_le hp
  rw [Fin.sum_univ_add]
  simp
  rfl

theorem ortho_majorant_coords {x : Frame X.Ψ r} (ho : X.IsOrtho x) (τ : X.Ψ) (c : Fin r → ℂ) :
    X.maj x τ (∑ a, c a • col (mat x τ) a) = (∑ a, c a * conj (c a)).re := by
  have gp : X.gramPos x τ = 1 := by
    ext a b
    simp [Data.gramPos, ho τ, Matrix.diagonal_apply, Matrix.one_apply, sgn, Fin.ext_iff]
  have hp : X.posPart x τ (∑ a, c a • col (mat x τ) a) =
      (∑ a : Fin r, if (a : ℕ) < X.p0 then c a * conj (c a) else 0).re := by
    unfold Data.posPart
    rw [gp, inv_one, ← sum_castLE_lemma r X.p0 X.p0_le (fun a => c a * conj (c a))]
    simp only [comb_col X ho τ, Matrix.one_apply, mul_ite, ite_mul, mul_one, mul_zero, zero_mul,
      Finset.sum_ite_eq, Finset.mem_univ, if_true]
    congr 1
    exact Finset.sum_congr rfl fun a _ => by simp [sgn]
  rw [Data.maj, hp, comb_comb X ho τ]
  simp only [Complex.re_sum, Finset.mul_sum, ← Finset.sum_sub_distrib]
  refine Finset.sum_congr rfl fun a _ => ?_
  by_cases h : (a : ℕ) < X.p0 <;> simp [h, sgn] <;> ring

private theorem sgn_eigen_perp_span_spec (n p : ℕ) (hp : p ≤ n) (d : Fin n → ℂ) (hd : d ≠ 0)
    (hiso : ∑ a, d a * conj (d a) * ((sgn p (a : ℕ) : ℝ) : ℂ) = 0) :
    ∃ F : Fin (n - 2) → Fin n → ℂ,
      (∀ k l, ∑ a, F k a * conj (F l a) = if k = l then 1 else 0) ∧
      (∀ (k : Fin (n - 2)) (a : Fin n),
        ((sgn p (a : ℕ) : ℝ) : ℂ) * F k a = (if (k : ℕ) < p - 1 then 1 else -1) * F k a) ∧
      (∀ k, ∑ a, F k a * conj (d a) = 0) ∧
      (∀ c : Fin n → ℂ, ∑ a, c a * conj (d a) = 0 →
        ∑ a, c a * conj (d a) * ((sgn p (a : ℕ) : ℝ) : ℂ) = 0 →
        c ∈ Submodule.span ℂ (Set.range F)) := by
  obtain ⟨q, rfl⟩ := Nat.exists_eq_add_of_le hp
  have sgL : ∀ i : Fin p, ((sgn p ((Fin.castAdd q i : Fin (p + q)) : ℕ) : ℝ) : ℂ) = 1 := fun i => by
    simp [sgn, i.isLt]
  have sgR : ∀ j : Fin q, ((sgn p ((Fin.natAdd p j : Fin (p + q)) : ℕ) : ℝ) : ℂ) = -1 := fun j => by
    simp [sgn]
  let u (i : Fin p) := d (Fin.castAdd q i)
  let v (j : Fin q) := d (Fin.natAdd p j)
  have balance : u ⬝ᵥ star u = v ⬝ᵥ star v := by
    rw [Fin.sum_univ_add] at hiso
    simp only [sgL, sgR, mul_one, mul_neg_one, Finset.sum_neg_distrib] at hiso
    exact eq_of_sub_eq_zero (by simpa only [sub_eq_add_neg, dotProduct, u, v, Pi.star_apply, Complex.star_def] using hiso)
  have hn : u ⬝ᵥ star u ≠ 0 := by
    intro h
    have hL := dotProduct_self_star_eq_zero.mp h
    have hR := dotProduct_self_star_eq_zero.mp (balance.symm.trans h)
    apply hd
    exact funext (Fin.addCases (fun i => congrFun hL i) (fun j => congrFun hR j))
  have hαne : u ≠ 0 := fun h => hn (by rw [h]; simp)
  have hβne : v ≠ 0 := fun h => hn (by rw [balance, h]; simp)
  have positive {m : ℕ} (w : Fin m → ℂ) (h : w ≠ 0) : 1 ≤ m := by
    cases m with
    | zero => exact (h (Subsingleton.elim _ _)).elim
    | succ m => omega
  have hp1 := positive _ hαne
  have hq1 := positive _ hβne
  obtain ⟨gp, gpO, gpA, gpS⟩ := onb_perp p hp1 _ hαne
  obtain ⟨gq, gqO, gqA, gqS⟩ := onb_perp q hq1 _ hβne
  let F : Fin (p + q - 2) → Fin (p + q) → ℂ := fun k a =>
    if hk : (k : ℕ) < p - 1 then
      Fin.addCases (motive := fun _ => ℂ) (fun i => gp ⟨k, hk⟩ i) (fun _ => 0) a
    else
      Fin.addCases (motive := fun _ => ℂ) (fun _ => 0)
        (fun j => gq ⟨k - (p - 1), by have := k.isLt; omega⟩ j) a
  have FL : ∀ k i, F k (Fin.castAdd q i) = if hk : (k : ℕ) < p - 1 then gp ⟨k, hk⟩ i else 0 := by
    intro k i
    simp only [F]
    split_ifs <;> simp
  have FR : ∀ k j, F k (Fin.natAdd p j) =
      if hk : (k : ℕ) < p - 1 then 0 else gq ⟨k - (p - 1), by have := k.isLt; omega⟩ j := by
    intro k j
    simp only [F]
    split_ifs <;> simp
  refine ⟨F, ?_, ?_, ?_, ?_⟩
  · intro k l
    rw [Fin.sum_univ_add]
    simp only [FL, FR]
    by_cases hk : (k : ℕ) < p - 1 <;> by_cases hl : (l : ℕ) < p - 1
    · simp [hk, hl, gpO, Fin.ext_iff]
    · have hne : k ≠ l := fun eq => hl (eq ▸ hk)
      simp [hk, hl, hne]
    · have hne : k ≠ l := fun eq => hk (eq ▸ hl)
      simp [hk, hl, hne]
    · have inj : (k : ℕ) - (p - 1) = (l : ℕ) - (p - 1) ↔ (k : ℕ) = l := by omega
      simp [hk, hl, gqO, Fin.ext_iff, inj]
  · intro k a
    induction a using Fin.addCases with
    | left i =>
      rw [sgL i, FL]
      by_cases hk : (k : ℕ) < p - 1 <;> simp [hk]
    | right j =>
      rw [sgR j, FR]
      by_cases hk : (k : ℕ) < p - 1 <;> simp [hk]
  · intro k
    rw [Fin.sum_univ_add]
    simp only [FL, FR]
    by_cases hk : (k : ℕ) < p - 1
    · simp only [dif_pos hk, zero_mul, Finset.sum_const_zero, add_zero]
      exact gpA ⟨k, hk⟩
    · simp only [dif_neg hk, zero_mul, Finset.sum_const_zero, zero_add]
      exact gqA _
  · intro c h1 h2
    rw [Fin.sum_univ_add] at h1 h2
    simp only [sgL, sgR, mul_one, mul_neg_one, Finset.sum_neg_distrib] at h2
    have hL : ∑ i : Fin p, c (Fin.castAdd q i) * conj (d (Fin.castAdd q i)) = 0 := by
      linear_combination (h1 + h2) / 2
    have hR : ∑ j : Fin q, c (Fin.natAdd p j) * conj (d (Fin.natAdd p j)) = 0 := by
      linear_combination (h1 - h2) / 2
    obtain ⟨μ1, hμ1⟩ := (Submodule.mem_span_range_iff_exists_fun ℂ).mp
      (gpS (fun i => c (Fin.castAdd q i)) hL)
    obtain ⟨μ2, hμ2⟩ := (Submodule.mem_span_range_iff_exists_fun ℂ).mp
      (gqS (fun j => c (Fin.natAdd p j)) hR)
    let μ (k : Fin (p + q - 2)) := if hk : (k : ℕ) < p - 1 then μ1 ⟨k, hk⟩
        else μ2 ⟨k - (p - 1), by have := k.isLt; omega⟩
    have dim : (p - 1) + (q - 1) = p + q - 2 := by omega
    let L (i : Fin (p - 1)) : Fin (p + q - 2) := Fin.cast dim (Fin.castAdd (q - 1) i)
    let R (j : Fin (q - 1)) : Fin (p + q - 2) := Fin.cast dim (Fin.natAdd (p - 1) j)
    have split (g : Fin (p + q - 2) → ℂ) : ∑ k, g k = ∑ i, g (L i) + ∑ j, g (R j) :=
      ((finCongr dim).sum_comp g).symm.trans (Fin.sum_univ_add _)
    have hL' (i : Fin (p - 1)) : (L i : ℕ) < p - 1 := i.isLt
    have hR' (j : Fin (q - 1)) : ¬(R j : ℕ) < p - 1 := by simp [R]
    have ml (i : Fin (p - 1)) : μ (L i) = μ1 i := by simp [μ, L]
    have mr (j : Fin (q - 1)) : μ (R j) = μ2 j := by simp [μ, R]
    refine (Submodule.mem_span_range_iff_exists_fun ℂ).mpr ⟨μ, ?_⟩
    funext a
    simp only [Finset.sum_apply, Pi.smul_apply, smul_eq_mul]
    rw [split]
    induction a using Fin.addCases with
    | left i =>
      simp only [FL, dif_pos (hL' _), dif_neg (hR' _), ml, mul_zero, Finset.sum_const_zero, add_zero]
      simpa [L, smul_eq_mul] using congrFun hμ1 i
    | right j =>
      simp only [FR, dif_pos (hL' _), dif_neg (hR' _), mr, mul_zero, Finset.sum_const_zero, zero_add]
      simpa [R, smul_eq_mul] using congrFun hμ2 j


theorem ubasis_at (ξ : Fin r → E) (z0 x0 : Frame X.Ψ r) (hξ0 : ξ ≠ 0) (hiso : herm X.Gm ξ ξ = 0)
    (hz : z0 ∈ X.dom) (hx0 : x0 ∈ X.dom) (ho : X.IsOrtho x0) (hflag : X.SameFlag z0 x0) (τ : X.Ψ) :
    ∃ fτ : Fin (r - 2) → Fin r → ℂ,
      (∀ k, hermC τ.1 X.Gm (fτ k) (Data.emb τ.1 ξ) = 0 ∧
        hermC τ.1 X.Gm (I • ((2 : ℂ) • X.ppos z0 τ (fτ k) - fτ k)) (Data.emb τ.1 ξ) = 0) ∧
      (∀ k, I • ((2 : ℂ) • X.ppos z0 τ (fτ k) - fτ k) = (if (k : ℕ) < X.p0 - 1 then I else -I) • fτ k) ∧
      (∀ k l, hermC τ.1 X.Gm (fτ k) (fτ l) =
        if k = l then (if (k : ℕ) < X.p0 - 1 then 1 else -1) else 0) ∧
      (∀ c : Fin (r - 2) → ℂ, X.maj z0 τ (∑ k, c k • fτ k) = ∑ k, ‖c k‖ ^ 2) ∧
      (∀ v : Fin r → ℂ, hermC τ.1 X.Gm v (Data.emb τ.1 ξ) = 0 →
        hermC τ.1 X.Gm (I • ((2 : ℂ) • X.ppos z0 τ v - v)) (Data.emb τ.1 ξ) = 0 →
        v ∈ Submodule.span ℂ (Set.range fτ)) := by
  have hsg : ∀ a : Fin r, ((sgn X.p0 (a : ℕ) : ℝ) : ℂ) * ((sgn X.p0 (a : ℕ) : ℝ) : ℂ) = 1 := fun a => sgn_mul_self X a
  obtain ⟨d, hexp⟩ : ∃ d : Fin r → ℂ, Data.emb τ.1 ξ = ∑ a : Fin r, d a • col (mat x0 τ) a :=
    ⟨_, expand X hx0 ho τ (Data.emb τ.1 ξ)⟩
  have hw0 : hermC τ.1 X.Gm (Data.emb τ.1 ξ) (Data.emb τ.1 ξ) = 0 := by
    rw [hermC_emb, hiso, map_zero]
  have hd0 : d ≠ 0 := by
    rintro rfl
    exact emb_ne_zero τ.1 hξ0 (by simpa using hexp)
  have hisod : ∑ a : Fin r, d a * conj (d a) * ((sgn X.p0 (a : ℕ) : ℝ) : ℂ) = 0 := by
    rw [← comb_comb X ho τ d d, ← hexp, hw0]
  obtain ⟨F, hO, hS, hA, hSp⟩ := sgn_eigen_perp_span_spec r X.p0 X.p0_le d hd0 hisod
  have hH : ∀ c : Fin r → ℂ, hermC τ.1 X.Gm (∑ a : Fin r, c a • col (mat x0 τ) a) (Data.emb τ.1 ξ) =
      ∑ a : Fin r, c a * conj (d a) * ((sgn X.p0 (a : ℕ) : ℝ) : ℂ) := by
    intro c
    rw [hexp]
    exact comb_comb X ho τ c d
  have hP : ∀ c : Fin r → ℂ, X.ppos z0 τ (∑ a : Fin r, c a • col (mat x0 τ) a) =
      ∑ a : Fin r, (if (a : ℕ) < X.p0 then c a else 0) • col (mat x0 τ) a := by
    intro c
    rw [FrameDegreeData.ppos_sameFlag X hz hx0 hflag τ, ppos_ortho X hx0 ho τ]
    simp only [comb_col X ho τ]
    refine (sum_castLE_lemma r X.p0 X.p0_le
      (fun (a : Fin r) => (c a * ((sgn X.p0 (a : ℕ) : ℝ) : ℂ)) • col (mat x0 τ) a)).trans ?_
    refine Finset.sum_congr rfl fun a _ => ?_
    by_cases h : (a : ℕ) < X.p0 <;> simp [h, sgn]
  have hJ : ∀ c : Fin r → ℂ, I • ((2 : ℂ) • X.ppos z0 τ (∑ a : Fin r, c a • col (mat x0 τ) a) -
      ∑ a : Fin r, c a • col (mat x0 τ) a) =
      ∑ a : Fin r, (I * ((sgn X.p0 (a : ℕ) : ℝ) : ℂ) * c a) • col (mat x0 τ) a := by
    intro c
    rw [hP, Finset.smul_sum, ← Finset.sum_sub_distrib, Finset.smul_sum]
    refine Finset.sum_congr rfl fun a _ => ?_
    rw [smul_smul, ← sub_smul, smul_smul]
    congr 1
    by_cases h : (a : ℕ) < X.p0 <;> simp [h, sgn] <;> ring
  have hmaj : ∀ C : Fin r → ℂ, X.maj z0 τ (∑ a : Fin r, C a • col (mat x0 τ) a) =
      (∑ a : Fin r, C a * conj (C a)).re := by
    intro C
    rw [← FlowMajorantFlags.maj_flag X hz hx0 hflag, ortho_majorant_coords X ho]
  have hnorm : ∀ c : Fin (r - 2) → ℂ,
      ∑ a : Fin r, (∑ k, c k * F k a) * conj (∑ k, c k * F k a) = ((∑ k, ‖c k‖ ^ 2 : ℝ) : ℂ) := by
    intro c
    let G (k : Fin (r - 2)) : EuclideanSpace ℂ (Fin r) := WithLp.toLp 2 (F k)
    have hG : Orthonormal ℂ G := orthonormal_iff_ite.mpr fun i j => by
      rw [EuclideanSpace.inner_eq_star_dotProduct]
      simpa [G, dotProduct, eq_comm] using hO j i
    have hin := hG.inner_sum c c Finset.univ
    rw [EuclideanSpace.inner_eq_star_dotProduct] at hin
    simpa [G, dotProduct, Complex.mul_conj, Complex.normSq_eq_norm_sq,
      Finset.sum_apply, mul_comm] using hin
  have hmix : ∀ c : Fin (r - 2) → ℂ, ∑ k, c k • ∑ a : Fin r, F k a • col (mat x0 τ) a =
      ∑ a : Fin r, (∑ k, c k * F k a) • col (mat x0 τ) a := by
    intro c
    simp [Finset.smul_sum, smul_smul]
    rw [Finset.sum_comm]
    simp [Finset.sum_smul]
  have pair (k : Fin (r - 2)) (v : Fin r → ℂ) :
      ∑ a : Fin r, F k a * conj (v a) * ((sgn X.p0 (a : ℕ) : ℝ) : ℂ) =
      (if (k : ℕ) < X.p0 - 1 then 1 else -1) * ∑ a : Fin r, F k a * conj (v a) := by
    rw [Finset.mul_sum]
    exact Finset.sum_congr rfl fun a _ => by linear_combination conj (v a) * hS k a
  have twice (v : Fin r → ℂ) :
      ∑ a : Fin r, I * ((sgn X.p0 (a : ℕ) : ℝ) : ℂ) * v a * conj (d a) * ((sgn X.p0 (a : ℕ) : ℝ) : ℂ) =
      I * ∑ a : Fin r, v a * conj (d a) := by
    rw [Finset.mul_sum]
    exact Finset.sum_congr rfl fun a _ => by linear_combination (I * v a * conj (d a)) * hsg a
  refine ⟨fun k => ∑ a : Fin r, F k a • col (mat x0 τ) a, ?_, ?_, ?_, ?_, ?_⟩
  · intro k
    refine ⟨?_, ?_⟩
    · rw [hH, pair, hA, mul_zero]
    · rw [hJ (F k), hH, twice, hA, mul_zero]
  · intro k
    rw [hJ (F k), Finset.smul_sum]
    refine Finset.sum_congr rfl fun a _ => ?_
    rw [smul_smul]
    congr 1
    have hSk := hS k a
    by_cases hk : (k : ℕ) < X.p0 - 1
    · rw [if_pos hk] at hSk ⊢
      linear_combination I * hSk
    · rw [if_neg hk] at hSk ⊢
      linear_combination I * hSk
  · intro k l
    rw [comb_comb X ho τ]
    rw [pair, hO]
    split_ifs <;> simp
  · intro c
    rw [hmix, hmaj, hnorm, Complex.ofReal_re]
  · intro v h1 h2
    obtain ⟨C, rfl⟩ : ∃ C : Fin r → ℂ, v = ∑ a : Fin r, C a • col (mat x0 τ) a :=
      ⟨_, expand X hx0 ho τ v⟩
    rw [hH] at h1
    rw [hJ C, hH] at h2
    have h2' : ∑ a : Fin r, C a * conj (d a) = 0 := by
      rw [twice] at h2
      exact (mul_eq_zero.mp h2).resolve_left Complex.I_ne_zero
    obtain ⟨μ, hμ⟩ := (Submodule.mem_span_range_iff_exists_fun ℂ).mp (hSp C h2' h1)
    refine (Submodule.mem_span_range_iff_exists_fun ℂ).mpr ⟨μ, ?_⟩
    rw [hmix, ← hμ]
    simp [Finset.sum_apply]

end

end ReciprocityTheory.ChartRestriction.G.FD.OrthonormalPerpBasis
