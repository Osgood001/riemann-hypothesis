import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.IsotropicOutsideLine
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.SpanColsMul

namespace ReciprocityTheory.ChartRestriction.G.FD

open Matrix

variable {E : Type} [Field E] [NumberField E] [NumberField.IsCMField E]

theorem unipotent_vector_group : UnipotentVectorGroup (E := E) := by
  intro r X u hiso
  refine ⟨X.Zb_Zb u hiso.1, fun b hb => ?_⟩
  have hfix (τ : X.Ψ) (i : Fin 2) :
      X.zmat u b τ *ᵥ Data.emb τ.1 (u i) = Data.emb τ.1 (u i) := by
    rw [X.zmat_eq, Matrix.add_mulVec, Matrix.one_mulVec, ← Matrix.mulVec_mulVec]
    have hz : X.Cm u b τ *ᵥ Data.emb τ.1 (u i) = 0 := by
      funext j
      simp [X.Cm_mulVec, hermC_emb, hiso.1]
    rw [hz, Matrix.mulVec_zero, add_zero]
  have hmaj (x : Frame X.Ψ r) (τ : X.Ψ) :
      X.maj (X.Zb u b x) τ (Data.emb τ.1 (u 0)) = X.maj x τ (Data.emb τ.1 (u 0)) := by
    have hv0 (w) : hermC τ.1 X.Gm (Data.emb τ.1 (u 0)) (X.zmat u b τ *ᵥ w) =
        hermC τ.1 X.Gm (Data.emb τ.1 (u 0)) w := by
      simpa only [hfix] using X.zmat_unitary u hiso.1 b hb τ (Data.emb τ.1 (u 0)) w
    have hg : gram τ.1 X.Gm (X.zmat u b τ * mat x τ) = gram τ.1 X.Gm (mat x τ) :=
      X.gram_Zb u hiso.1 b hb x τ
    simp [Data.maj, Data.posPart, Data.gramPos, hg, X.mat_Zb, Data.col_mul, hv0]

  refine ⟨X.zmat_unitary u hiso.1 b hb, hfix, X.zmat_det u hiso.1 b,
    fun _ hx => X.Zb_dom u hiso.1 b hb hx, ?_, fun la x _ => X.nfac_Zb u hiso.1 b hb la x,
    fun x τ _ => hmaj x τ, ?_, ?_, ?_⟩
  · intro x x' h τ
    have key (y : Frame X.Ψ r) :
        Set.range (fun a : Fin X.p0 => col (mat (X.Zb u b y) τ) (Fin.castLE X.p0_le a)) =
          (Matrix.mulVecLin (X.zmat u b τ)) ''
            Set.range (fun a : Fin X.p0 => col (mat y τ) (Fin.castLE X.p0_le a)) := by
      rw [← Set.range_comp]
      congr 1
    rw [key x, key x', Submodule.span_image, Submodule.span_image, h τ]
  · intro x hx
    exact ⟨X.Zb_dom u hiso.1 b hb hx.1, fun τ => by rw [hmaj]; exact hx.2 τ⟩
  · intro a s x
    rw [X.flowV_uvec, X.flowV_uvec, X.Zb_Zb u hiso.1, X.Zb_Zb u hiso.1, add_comm]
  · intro a s x
    exact X.flowV_uvec u a _ x

end ReciprocityTheory.ChartRestriction.G.FD
