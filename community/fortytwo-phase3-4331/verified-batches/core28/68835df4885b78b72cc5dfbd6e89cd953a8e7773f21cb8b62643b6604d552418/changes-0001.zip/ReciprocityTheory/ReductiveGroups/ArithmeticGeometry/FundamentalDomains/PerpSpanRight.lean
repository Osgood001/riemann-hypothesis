import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.ExistsUnitaryBasisSameFlag
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.LminorSubmatrixCastSucc
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.UMatUpper

namespace ReciprocityTheory.ChartRestriction.G.FD.GramSchmidtSelfImaginary

open NumberField Complex Matrix ReciprocityTheory.ChartRestriction.G.FD ReciprocityTheory.ChartRestriction.G.FD.FrameDegreeData
open scoped ComplexConjugate

noncomputable section

variable {E : Type} [Field E] [NumberField E] [NumberField.IsCMField E] {r : ℕ}
  (τ : E →+* ℂ) (G : Matrix (Fin r) (Fin r) E)

def hL (v : Fin r → ℂ) : (Fin r → ℂ) →ₗ[ℂ] ℂ := GramDeterminantReal.hL τ G v

theorem perp_span {s : Set (Fin r → ℂ)} {v : Fin r → ℂ} (h : ∀ y ∈ s, hermC τ G y v = 0) :
    ∀ y ∈ Submodule.span ℂ s, hermC τ G y v = 0 := by
  exact fun y hy => (Submodule.span_le (p := LinearMap.ker (hL τ G v))).mpr h hy

theorem perp_span_right (hG : ∀ a b, cc (G a b) = G b a) {s : Set (Fin r → ℂ)} {v : Fin r → ℂ}
    (h : ∀ y ∈ s, hermC τ G v y = 0) : ∀ y ∈ Submodule.span ℂ s, hermC τ G v y = 0 := by
  intro y hy
  induction hy using Submodule.span_induction with
  | mem z hz => exact h z hz
  | zero => simp [hermC]
  | add x y _ _ hx hy => simp [hermC_add_right, hx, hy]
  | smul c x _ hx => simp [hermC_smul_right, hx]

theorem coef_of_mem {n : ℕ} (Y : Fin n → Fin r → ℂ) (S : Set (Fin n)) {v : Fin r → ℂ}
    (hv : v ∈ Submodule.span ℂ (Y '' S)) :
    ∃ w : Fin n → ℂ, (∀ j, j ∉ S → w j = 0) ∧ v = ∑ j, w j • Y j := by
  classical
  obtain ⟨c, hc⟩ := (Submodule.mem_span_image_finset_iff_exists_fun' ℂ (s := S.toFinset)).mp
    (by simpa using hv)
  refine ⟨S.indicator c, fun j hj => Set.indicator_of_notMem hj _, ?_⟩
  rw [← hc]
  simp only [Set.indicator, ite_smul, zero_smul, ← Finset.sum_filter]
  congr 1
  ext i
  simp


theorem sum_mem_of {n : ℕ} (Y : Fin n → Fin r → ℂ) (S : Set (Fin n)) (w : Fin n → ℂ)
    (hw : ∀ j, j ∉ S → w j = 0) : ∑ j, w j • Y j ∈ Submodule.span ℂ (Y '' S) := by
  refine Submodule.sum_mem _ (fun j _ => ?_)
  by_cases hj : j ∈ S
  · exact Submodule.smul_mem _ _ (Submodule.subset_span ⟨j, hj, rfl⟩)
  · rw [hw j hj, zero_smul]
    exact Submodule.zero_mem _

variable (hG : ∀ a b, cc (G a b) = G b a)
include hG

private theorem block_basis {n : ℕ} (Y : Fin n → Fin r → ℂ) (hind : LinearIndependent ℂ Y)
    (A : Set (Fin n)) (e : ℝ) (he : e = 1 ∨ e = -1)
    (hpos : ∀ v ∈ Submodule.span ℂ (Y '' A), v ≠ 0 → 0 < e * (hermC τ G v v).re) :
    ∃ g : A → Fin r → ℂ,
      (∀ a, g a ∈ Submodule.span ℂ (Y '' A)) ∧
      (∀ a b, hermC τ G (g a) (g b) = if a = b then (e : ℂ) else 0) ∧
      Submodule.span ℂ (Y '' A) ≤ Submodule.span ℂ (Set.range g) := by
  classical
  let V := Submodule.span ℂ (Y '' A)
  have positive (u : V) (hu : u ≠ 0) := hpos u u.property (fun h => hu (Subtype.ext h))
  let form : InnerProductSpace.Core ℂ V := {
    inner := fun u v => (e : ℂ) * hermC τ G v u
    conj_inner_symm := fun u v => by simp only [map_mul, Complex.conj_ofReal, hermC_conj τ hG]
    re_inner_nonneg := fun u => by
      change 0 ≤ ((e : ℂ) * hermC τ G u u).re
      by_cases h : u = 0
      · subst u
        simp [hermC_zero_left]
      · simpa using (positive u h).le
    add_left := fun u v w => by
      change (e : ℂ) * hermC τ G w ((u : Fin r → ℂ) + v) = _
      rw [hermC_add_right, mul_add]
    smul_left := fun u v c => by
      change (e : ℂ) * hermC τ G v (c • (u : Fin r → ℂ)) = _
      rw [hermC_smul_right]
      ring
    definite := fun u hu => by
      by_contra h
      have hreal := congrArg Complex.re hu
      simpa [(positive u h).ne'] using hreal }
  letI : NormedAddCommGroup V := @InnerProductSpace.Core.toNormedAddCommGroup ℂ V _ _ _ form
  letI : SeminormedAddCommGroup V := @InnerProductSpace.Core.toSeminormedAddCommGroup ℂ V _ _ _ form.toCore
  letI : InnerProductSpace ℂ V := InnerProductSpace.ofCore form.toCore
  have dim : Module.finrank ℂ V = Fintype.card A := by
    have hi := hind.comp (Subtype.val : A → Fin n) Subtype.val_injective
    change Module.finrank ℂ ↥(Submodule.span ℂ (Y '' A)) = _
    rw [Set.image_eq_range]
    exact finrank_span_eq_card hi
  let B : OrthonormalBasis A ℂ V := (stdOrthonormalBasis ℂ V).reindex (Fintype.equivFinOfCardEq dim.symm).symm
  refine ⟨fun a => (B a).val, fun a => (B a).property, ?_, ?_⟩
  · intro a b
    have H := B.inner_eq_ite b a
    change (e : ℂ) * hermC τ G (B a) (B b) = _ at H
    rcases he with rfl | rfl <;> by_cases h : a = b <;> simp_all [eq_comm]
  · intro v hv
    let u : V := ⟨v, hv⟩
    have h := congrArg V.subtype (B.sum_repr u)
    simp [map_sum, map_smul] at h
    rw [show v = ∑ a, B.repr u a • (B a).val from h.symm]
    exact Submodule.sum_mem _ fun a _ => Submodule.smul_mem _ _ (Submodule.subset_span ⟨a, rfl⟩)

theorem gs_exists {n : ℕ} (p : ℕ) (Y : Fin n → Fin r → ℂ) (hind : LinearIndependent ℂ Y)
    (horth : ∀ j k : Fin n, (j : ℕ) < p → p ≤ (k : ℕ) → hermC τ G (Y j) (Y k) = 0)
    (hpos : ∀ w : Fin n → ℂ, (∀ j : Fin n, p ≤ (j : ℕ) → w j = 0) → w ≠ 0 →
      0 < (hermC τ G (∑ j, w j • Y j) (∑ j, w j • Y j)).re)
    (hneg : ∀ w : Fin n → ℂ, (∀ j : Fin n, (j : ℕ) < p → w j = 0) → w ≠ 0 →
      (hermC τ G (∑ j, w j • Y j) (∑ j, w j • Y j)).re < 0) :
    ∃ g : Fin n → Fin r → ℂ,
      (∀ c a : Fin n, hermC τ G (g c) (g a) =
        if c = a then (if (c : ℕ) < p then 1 else -1) else 0) ∧
      (∀ c : Fin n, (c : ℕ) < p → g c ∈ Submodule.span ℂ (Y '' {j | (j : ℕ) < p})) ∧
      (∀ c : Fin n, g c ∈ Submodule.span ℂ (Set.range Y)) ∧
      (∀ j : Fin n, ∃ β : Fin n → ℂ, (∀ c : Fin n, ¬((c : ℕ) < p ↔ (j : ℕ) < p) → β c = 0) ∧
        Y j = ∑ c, β c • g c) := by
  classical
  let A : Set (Fin n) := {j | (j : ℕ) < p}
  have signed (S : Set (Fin n)) (e : ℝ)
      (h : ∀ w : Fin n → ℂ, (∀ j, j ∉ S → w j = 0) → w ≠ 0 →
        0 < e * (hermC τ G (∑ i, w i • Y i) (∑ i, w i • Y i)).re) :
      ∀ v ∈ Submodule.span ℂ (Y '' S), v ≠ 0 → 0 < e * (hermC τ G v v).re := by
    intro v hv hne
    obtain ⟨w, hw, rfl⟩ := coef_of_mem Y S hv
    exact h w hw (fun hz => hne (by simp [hz]))
  obtain ⟨P, hP, oP, sP⟩ := block_basis τ G hG Y hind A 1 (Or.inl rfl) (signed _ _ (by
    intro w hw hn
    simpa using hpos w (fun j hj => hw j (not_lt.mpr hj)) hn))
  obtain ⟨N, hN, oN, sN⟩ := block_basis τ G hG Y hind Aᶜ (-1) (Or.inr rfl) (signed _ _ (by
    intro w hw hn
    simpa using hneg w (fun j hj => hw j (by simpa [A] using hj)) hn))
  have orth (i : A) (j : ↥(Aᶜ)) : hermC τ G (P i) (N j) = 0 := by
    refine perp_span τ G ?_ _ (hP i)
    rintro _ ⟨k,hk,rfl⟩
    refine perp_span_right τ G hG ?_ _ (hN j)
    rintro _ ⟨l,hl,rfl⟩
    exact horth k l hk (not_lt.mp hl)
  let g (j : Fin n) := if h : j ∈ A then P ⟨j,h⟩ else N ⟨j,h⟩
  refine ⟨g, ?_, ?_, ?_, ?_⟩
  · intro c a
    by_cases hc : c ∈ A <;> by_cases ha : a ∈ A
    · simpa [g, hc, ha, show (c : ℕ) < p from hc, Subtype.ext_iff] using oP ⟨c,hc⟩ ⟨a,ha⟩
    · simpa [g, hc, ha, show c ≠ a from fun e => ha (e ▸ hc)] using orth ⟨c,hc⟩ ⟨a,ha⟩
    · have h := hermC_conj τ hG (P ⟨a,ha⟩) (N ⟨c,hc⟩)
      rw [orth, map_zero] at h
      simpa [g, hc, ha, show c ≠ a from fun e => hc (e ▸ ha)] using h.symm
    · simpa [g, hc, ha, show ¬ (c : ℕ) < p from hc, Subtype.ext_iff] using oN ⟨c,hc⟩ ⟨a,ha⟩
  · intro c hc
    simpa only [g, dif_pos (show c ∈ A from hc)] using hP ⟨c,hc⟩
  · intro c
    by_cases hc : c ∈ A
    · exact Submodule.span_mono (Set.image_subset_range _ _) (by simpa [g,hc] using hP ⟨c,hc⟩)
    · exact Submodule.span_mono (Set.image_subset_range _ _) (by simpa [g,hc] using hN ⟨c,hc⟩)
  · intro j
    let S : Set (Fin n) := {c | (c ∈ A ↔ j ∈ A)}
    apply coef_of_mem g S
    by_cases hj : j ∈ A
    · refine Submodule.span_mono ?_ (sP (Submodule.subset_span ⟨j,hj,rfl⟩))
      rintro _ ⟨a,rfl⟩
      exact ⟨a, iff_of_true a.property hj, by simp [g,a.property]⟩
    · refine Submodule.span_mono ?_ (sN (Submodule.subset_span ⟨j,hj,rfl⟩))
      rintro _ ⟨a,rfl⟩
      exact ⟨a, iff_of_false a.property hj, by simp [g,show (a : Fin n) ∉ A from a.property]⟩

end

end ReciprocityTheory.ChartRestriction.G.FD.GramSchmidtSelfImaginary
