import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.HermCOrthonormalCoordinates

namespace ReciprocityTheory.ChartRestriction.G.FD.OrthonormalChartBounds

open NumberField Complex Matrix ReciprocityTheory.ChartRestriction.G.FD
open scoped ComplexConjugate

noncomputable section

private lemma graph_energy {u v t k : ℝ} (hu : 0 ≤ u) (hv : 0 ≤ v) (hk : 0 ≤ k) (hk1 : k < 1)
    (h : v ≤ k * u) (ht : |t| ≤ u * v) :
    (1-k)/(1+k) * (u^2 + v^2 + 2*t) ≤ u^2 - v^2 ∧
    u^2 - v^2 ≤ (1+k)/(1-k) * (u^2 + v^2 + 2*t) := by
  have hvu : v ≤ u := h.trans (mul_le_of_le_one_left hu hk1.le)
  have A := mul_nonneg (add_nonneg hu hv) (sub_nonneg.mpr h)
  have B := mul_nonneg (sub_nonneg.mpr hvu) (sub_nonneg.mpr h)
  obtain ⟨lo,hi⟩ := abs_le.mp ht
  constructor
  · rw [div_mul_eq_mul_div, div_le_iff₀ (by linarith)]
    nlinarith [mul_nonneg (sub_nonneg.mpr hk1.le) (sub_nonneg.mpr hi)]
  · rw [div_mul_eq_mul_div, le_div_iff₀ (by linarith)]
    nlinarith [mul_nonneg (by linarith : 0 ≤ 1+k) (sub_nonneg.mpr lo)]

private lemma real_pair_bound (a b c d : ℝ) :
    a*c + b*d ≤ Real.sqrt ((a^2+b^2)*(c^2+d^2)) :=
  Real.le_sqrt_of_sq_le (by nlinarith [sq_nonneg (a*d-b*c)])

variable {E : Type} [Field E] [NumberField E] [IsCMField E] {r : ℕ} (X : Data E r)

lemma mj_xZ_zero (x : Frame X.Ψ r) : X.xZ x 0 = x := by
  funext τ
  have h1 : X.lowBlock 0 τ = 1 := by
    ext a b
    simp [Data.lowBlock, Matrix.one_apply]
  show (mat x τ * X.lowBlock 0 τ : Matrix (Fin r) (Fin r) ℂ) = x τ
  rw [h1, Matrix.mul_one]
  rfl

private lemma nsq_add_fundamental_domains {n : ℕ} (p q : Fin n → ℂ) :
    nsq (p + q) = nsq p + 2 * (mjip p q).re + nsq q := by
  rw [show p + q = p - ((-1 : ℝ) : ℂ) • q by simp, mjnsq_sub_smul]
  ring

private lemma re_mjip_comm {n : ℕ} (p q : Fin n → ℂ) : (mjip q p).re = (mjip p q).re := by
  simp only [mjip, Complex.re_sum]
  refine Finset.sum_congr rfl fun i _ => ?_
  simp [Complex.mul_re]
  ring

private lemma mjip_sub_left {n : ℕ} (p q δ : Fin n → ℂ) :
    mjip (p - q) δ = mjip p δ - mjip q δ := by
  simp [mjip, sub_mul, Finset.sum_sub_distrib]

set_option maxHeartbeats 800000 in

theorem mj_bounds {x : Frame X.Ψ r} (hx : x ∈ X.dom) (ho : X.IsOrtho x) {ρ : ℝ} (hρ0 : 0 < ρ)
    (hρ : ρ ≤ 1 / 10) {Z : X.Coord} (hZ : X.zN Z ≤ ρ) (hy : X.xZ x Z ∈ X.dom) (τ : X.Ψ)
    (v : Fin r → ℂ) :
    (1 - ρ) / (1 + ρ) * X.maj x τ v ≤ X.maj (X.xZ x Z) τ v ∧
      X.maj (X.xZ x Z) τ v ≤ (1 + ρ) / (1 - ρ) * X.maj x τ v := by
  obtain ⟨w, rfl⟩ : ∃ w, v = mat x τ *ᵥ w := ⟨(mat x τ)⁻¹ *ᵥ v, by
    rw [Matrix.mulVec_mulVec, Matrix.mul_nonsing_inv _
      (isUnit_iff_ne_zero.mpr ((X.mem_dom_iff x).1 hx τ).1), Matrix.one_mulVec]⟩
  have hx0 : X.xZ x 0 ∈ X.dom := by rw [mj_xZ_zero]; exact hx
  obtain ⟨γ0, h0maj, h0id⟩ := mj_coord X ho 0 hx0 τ w
  rw [mj_xZ_zero] at h0maj
  have hZ0 : Matrix.of ((0 : X.Coord) τ) = 0 := by ext; rfl
  have hγ0 : γ0 = mjpa X w := by
    funext d
    have := h0id (Pi.single d 1)
    simp only [hZ0, Matrix.zero_mulVec, mjip_zero_right, sub_zero, mjip_single] at this
    exact this.symm
  have hmx : X.maj x τ (mat x τ *ᵥ w) = nsq (mjpa X w) + nsq (mjpb X w) := by
    rw [h0maj, hZ0, Matrix.zero_mulVec, nsq_zero', hγ0]
    ring
  obtain ⟨γ, hmaj, hid⟩ := mj_coord X ho Z hy τ w
  rw [hmx, hmaj]
  have hk0 : 0 ≤ Data.opN (Matrix.of (Z τ)) := opN_nonneg _
  have hkρ : Data.opN (Matrix.of (Z τ)) ≤ ρ := (opN_le_zN X Z τ).trans hZ
  have hs2 : nsq (Matrix.of (Z τ) *ᵥ γ) ≤ Data.opN (Matrix.of (Z τ)) ^ 2 * nsq γ :=
    nsq_mulVec_le_opN _ _
  have hdid : ∀ δ, mjip (mjpa X w - γ) δ =
      mjip (mjpb X w - Matrix.of (Z τ) *ᵥ γ) (Matrix.of (Z τ) *ᵥ δ) := by
    intro δ
    rw [mjip_sub_left, mjip_sub_left]
    linear_combination hid δ
  set Zm := Matrix.of (Z τ) with hZm
  set k := Data.opN Zm with hkdef
  set d := mjpa X w - γ with hd
  set t := mjpb X w - Zm *ᵥ γ with ht
  have hdd : nsq d ≤ k ^ 2 * nsq t := by
    have h : (mjip t (Zm *ᵥ d)).re = nsq d := by rw [← hdid, mjip_self, Complex.ofReal_re]
    have H := (Complex.re_le_norm _).trans (mjip_norm_le t (Zm *ᵥ d))
    rw [h] at H
    have H₂ := pow_le_pow_left₀ (nsq_nonneg d) H 2
    rw [mul_pow, Real.sq_sqrt (nsq_nonneg _), Real.sq_sqrt (nsq_nonneg _)] at H₂
    have H₃ := mul_le_mul_of_nonneg_left (nsq_mulVec_le_opN Zm d) (nsq_nonneg t)
    rcases eq_or_lt_of_le (nsq_nonneg d) with hd0 | hd0
    · rw [← hd0]; exact mul_nonneg (sq_nonneg _) (nsq_nonneg _)
    · apply le_of_mul_le_mul_right (b := nsq d) _ hd0
      change nsq d * nsq d ≤ (Data.opN Zm ^ 2 * nsq t) * nsq d
      nlinarith
  have hAe : nsq (mjpa X w) = nsq γ + 2 * (mjip γ d).re + nsq d := by
    rw [show mjpa X w = γ + d by rw [hd]; abel, nsq_add_fundamental_domains]
  have hBe : nsq (mjpb X w) = nsq (Zm *ᵥ γ) + 2 * (mjip (Zm *ᵥ γ) t).re + nsq t := by
    rw [show mjpb X w = Zm *ᵥ γ + t by rw [ht]; abel, nsq_add_fundamental_domains]
  have hcross : (mjip γ d).re = (mjip (Zm *ᵥ γ) t).re := by
    rw [re_mjip_comm d γ, hdid γ, re_mjip_comm (Zm *ᵥ γ) t]
  let U := nsq γ + nsq t
  let V := nsq d + nsq (Zm *ᵥ γ)
  let C := (mjip γ d).re + (mjip (Zm *ᵥ γ) t).re
  have hU : 0 ≤ U := add_nonneg (nsq_nonneg _) (nsq_nonneg _)
  have hV : 0 ≤ V := add_nonneg (nsq_nonneg _) (nsq_nonneg _)
  have hVr : Real.sqrt V ≤ ρ * Real.sqrt U := by
    rw [← Real.sqrt_sq hρ0.le, ← Real.sqrt_mul (sq_nonneg _)]
    apply Real.sqrt_le_sqrt
    calc V ≤ k^2 * U := by dsimp [V,U]; nlinarith [hdd,hs2]
         _ ≤ ρ^2 * U := mul_le_mul_of_nonneg_right (pow_le_pow_left₀ hk0 hkρ 2) hU
  have hC : |C| ≤ Real.sqrt U * Real.sqrt V := by
    have hpair := real_pair_bound (Real.sqrt (nsq γ)) (Real.sqrt (nsq t))
      (Real.sqrt (nsq d)) (Real.sqrt (nsq (Zm *ᵥ γ)))
    simp only [Real.sq_sqrt (nsq_nonneg _)] at hpair
    calc |C| ≤ |(mjip γ d).re| + |(mjip (Zm *ᵥ γ) t).re| := abs_add_le _ _
         _ ≤ _ := add_le_add ((Complex.abs_re_le_norm _).trans (mjip_norm_le γ d))
           ((Complex.abs_re_le_norm _).trans (mjip_norm_le (Zm *ᵥ γ) t))
         _ ≤ _ := by rw [← Real.sqrt_mul hU]; simpa [U,V,mul_comm] using hpair
  have hAB : nsq (mjpa X w) + nsq (mjpb X w) = U + V + 2*C := by
    rw [hAe,hBe]; dsimp [U,V,C]; ring
  have hdiff : 2*(nsq γ - nsq (Zm *ᵥ γ)) - (nsq (mjpa X w) - nsq (mjpb X w)) = U - V := by
    rw [hAe,hBe,hcross]; dsimp [U,V]; ring
  rw [hAB,hdiff]
  simpa only [Real.sq_sqrt hU, Real.sq_sqrt hV] using
    graph_energy (Real.sqrt_nonneg U) (Real.sqrt_nonneg V) hρ0.le (by linarith : ρ < 1) hVr hC


end

end ReciprocityTheory.ChartRestriction.G.FD.OrthonormalChartBounds
