import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.LowBlock

namespace ReciprocityTheory.ChartRestriction.G.FD.OrthonormalChartBounds

open NumberField Complex Matrix ReciprocityTheory.ChartRestriction.G.FD
open scoped ComplexConjugate ComplexOrder

noncomputable section

lemma dot_self {n : ℕ} (y : Fin n → ℂ) : star y ⬝ᵥ y = ((nsq y : ℝ) : ℂ) := by
  simp [nsq, dotProduct, Pi.star_apply]
  push_cast
  refine Finset.sum_congr rfl fun i _ => ?_
  exact Complex.conj_mul' (y i)

lemma quad_AtA {n q : ℕ} (A : Matrix (Fin q) (Fin n) ℂ) (y : Fin n → ℂ) :
    star y ⬝ᵥ ((Aᵀ * A.map (starRingEnd ℂ)) *ᵥ y) = ((nsq (A.map (starRingEnd ℂ) *ᵥ y) : ℝ) : ℂ) := by
  have h : A *ᵥ star y = star (A.map (starRingEnd ℂ) *ᵥ y) := by
    funext i
    simp [Matrix.mulVec, dotProduct, star_sum, mul_comm]
  rw [← Matrix.mulVec_mulVec, Matrix.dotProduct_mulVec, Matrix.vecMul_transpose, h, dot_self]

lemma posDef_of_bound {n q k : ℕ} (A : Matrix (Fin q) (Fin n) ℂ) (B : Matrix (Fin k) (Fin n) ℂ) {s : ℝ}
    (hs : s < 1) (hA : ∀ y, nsq (A.map (starRingEnd ℂ) *ᵥ y) ≤ s ^ 2 * nsq y) (hs0 : 0 ≤ s) :
    (1 - Aᵀ * A.map (starRingEnd ℂ) + Bᵀ * B.map (starRingEnd ℂ)).PosDef := by
  have gram {d : ℕ} (C : Matrix (Fin d) (Fin n) ℂ) :
      (Cᵀ * C.map (starRingEnd ℂ)).PosSemidef := Matrix.posSemidef_self_mul_conjTranspose Cᵀ
  apply Matrix.PosDef.add_posSemidef _ (gram B)
  refine Matrix.PosDef.of_dotProduct_mulVec_pos (Matrix.isHermitian_one.sub (gram A).isHermitian) fun x hx => ?_
  rw [Matrix.sub_mulVec, Matrix.one_mulVec, dotProduct_sub, dot_self, quad_AtA]
  have hx' := dotProduct_star_self_pos_iff.mpr hx
  rw [dot_self] at hx'
  have hn : 0 < nsq x := by exact_mod_cast hx'
  have small : s ^ 2 < 1 := by nlinarith
  have strict : 0 < nsq x - nsq (A.map (starRingEnd ℂ) *ᵥ x) := by
    nlinarith [hA x, mul_lt_mul_of_pos_right small hn]
  exact_mod_cast strict

end

end ReciprocityTheory.ChartRestriction.G.FD.OrthonormalChartBounds
