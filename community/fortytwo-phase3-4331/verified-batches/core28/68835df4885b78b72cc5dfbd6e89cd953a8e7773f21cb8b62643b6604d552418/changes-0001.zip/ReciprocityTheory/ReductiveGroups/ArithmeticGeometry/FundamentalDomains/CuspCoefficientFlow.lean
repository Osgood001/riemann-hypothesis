import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.FourierCoefficientDomain
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.FlowCoefficientBounds

namespace ReciprocityTheory.ChartRestriction.G.FD.CuspCoefficientFlow

open NumberField Complex ReciprocityTheory.ChartRestriction.G.FD MeasureTheory Metric Set Filter
open scoped ComplexConjugate Topology

noncomputable section

section Param

variable {F : Type*} [NormedAddCommGroup F] [NormedSpace ℂ F] [FiniteDimensional ℂ F]
  [MeasurableSpace F] [BorelSpace F] {ι : Type} [Fintype ι]

theorem diffOn_param_bdd {K : Set (ι → ℝ)} (hKv : volume K < ⊤)
    (A : (ι → ℝ) → F →L[ℂ] F) (hA : Continuous A) {U : Set F} (hU : IsOpen U)
    (hAU : ∀ t, ∀ x ∈ U, A t x ∈ U) (G : F → ℂ) (hG : DifferentiableOn ℂ G U)
    (e : (ι → ℝ) → ℂ) (he : Continuous e) (he1 : ∀ t, ‖e t‖ ≤ 1)
    (hbd : ∀ x0 ∈ U, ∃ ρ > 0, ∃ C, closedBall x0 ρ ⊆ U ∧
      ∀ t, ∀ z ∈ closedBall x0 ρ, ‖G (A t z)‖ ≤ C) :
    DifferentiableOn ℂ (fun x => ∫ t in K, G (A t x) * e t) U := by
  letI : IsFiniteMeasure (volume.restrict K) := isFiniteMeasure_restrict.mpr hKv.ne
  apply FourierCoefficientDomain.diffOn_finite_integral (volume.restrict K) A hA hU
    (Eventually.of_forall fun t => fun _ hz => hAU t _ hz) G hG e he
  · intro x hx
    exact ((hG.continuousOn.comp_continuous (hA.clm_apply continuous_const)
      (fun t => hAU t x hx)).mul he).aestronglyMeasurable
  · intro x hx
    obtain ⟨ρ, hρ, C, hsub, hC⟩ := hbd x hx
    refine ⟨ρ, hρ, C, hsub, Eventually.of_forall fun t z hz => ?_⟩
    rw [norm_mul]
    exact (mul_le_mul_of_nonneg_left (he1 t) (norm_nonneg _)).trans (by simpa using hC t z hz)


end Param

section Frame

variable {E : Type} [Field E] [NumberField E] [IsCMField E] {r : ℕ} (X : Data E r)

def flowL (ξ : Fin r → E) (s : X.Ψ → ℝ) : Frame X.Ψ r →L[ℂ] Frame X.Ψ r :=
  (LinearMap.pi fun τ => (LinearMap.mulLeft ℂ (X.flowMat ξ τ (s τ : ℂ))).comp (LinearMap.proj τ)).toContinuousLinearMap

lemma flowL_apply (ξ : Fin r → E) (s : X.Ψ → ℝ) (x : Frame X.Ψ r) :
    flowL X ξ s x = X.flow ξ (fun τ => (s τ : ℂ)) x := rfl

lemma cont_flowL (ξ : Fin r → E) : Continuous fun s => flowL X ξ s := by
  apply continuous_clm_apply.mpr
  intro x
  simp [flowL_apply]
  unfold Data.flow
  refine continuous_pi fun τ => continuous_pi fun a => continuous_pi fun b => ?_
  simp [Matrix.mul_apply, Data.flowMat]
  fun_prop

lemma cont_dmin (τ : X.Ψ) (i : Fin (r + 1)) :
    Continuous fun x : Frame X.Ψ r => dmin X.Gm x τ i := by
  unfold dmin lminor
  apply Continuous.matrix_det
  apply Continuous.matrix_submatrix
  refine continuous_pi fun a => continuous_pi fun b => ?_
  simp [gram, hermC, col, mat]
  fun_prop

lemma continuousAt_nfac (la : Wt X.Ψ r) {x0 : Frame X.Ψ r} (hx0 : x0 ∈ X.dom) :
    ContinuousAt (X.nfac la) x0 := by
  have h : ∀ (τ : X.Ψ) (i : Fin r), ContinuousAt (fun x : Frame X.Ψ r =>
      ‖dmin X.Gm x τ i.succ / dmin X.Gm x τ i.castSucc‖ ^ (-(la τ i : ℝ) / 2)) x0 := by
    intro τ i
    have hd1 := (cont_dmin X τ i.succ).continuousAt (x := x0)
    have hd2 := (cont_dmin X τ i.castSucc).continuousAt (x := x0)
    have hne1 := FlowCoefficientBounds.dmin_ne X hx0 τ i.succ
    have hne2 := FlowCoefficientBounds.dmin_ne X hx0 τ i.castSucc
    exact (hd1.div hd2 hne2).norm.rpow_const (Or.inl (norm_ne_zero_iff.mpr (div_ne_zero hne1 hne2)))
  unfold Data.nfac
  exact tendsto_finset_prod _ fun τ _ => tendsto_finset_prod _ fun i _ => h τ i

lemma fj_hbd (la : Wt X.Ψ r) (P : Frame X.Ψ r → ℂ) (hP : X.IsBddSec la P) {ξ : Fin r → E}
    (hξ : X.IsIso ξ) : ∀ x0 ∈ X.dom, ∃ ρ > 0, ∃ C, closedBall x0 ρ ⊆ X.dom ∧
      ∀ t : X.Ψ → ℝ, ∀ z ∈ closedBall x0 ρ, ‖P (flowL X ξ t z)‖ ≤ C := by
  intro x0 hx0
  obtain ⟨-, C, hC⟩ := hP
  have hpos := FlowCoefficientBounds.nfac_pos X hx0 la
  have hcont := continuousAt_nfac X la hx0
  have hev : ∀ᶠ z in 𝓝 x0, X.nfac la x0 / 2 < X.nfac la z ∧ z ∈ X.dom :=
    (hcont.eventually (lt_mem_nhds (by linarith : X.nfac la x0 / 2 < X.nfac la x0))).and
      ((FourierCoefficientDomain.isOpen_dom X).mem_nhds hx0)
  obtain ⟨ρ, hρ, hball⟩ := Metric.mem_nhds_iff.mp hev
  refine ⟨ρ / 2, by positivity, 2 * C / X.nfac la x0, ?_, ?_⟩
  · intro z hz
    exact (hball (Metric.closedBall_subset_ball (by linarith) hz)).2
  · intro t z hz
    have hz' := hball (Metric.closedBall_subset_ball (by linarith) hz)
    obtain ⟨hfd, hfn⟩ := FlowCoefficientBounds.flow_real X hξ hz'.2 t la
    have h1 := hC _ hfd
    rw [flowL_apply]
    have h2 : X.pnorm la P (X.flow ξ (fun τ => (t τ : ℂ)) z) =
        ‖P (X.flow ξ (fun τ => (t τ : ℂ)) z)‖ * X.nfac la z := by
      rw [← hfn]
      rfl
    rw [h2] at h1
    have h3 : ‖P (X.flow ξ (fun τ => (t τ : ℂ)) z)‖ * (X.nfac la x0 / 2) ≤
        ‖P (X.flow ξ (fun τ => (t τ : ℂ)) z)‖ * X.nfac la z :=
      mul_le_mul_of_nonneg_left hz'.1.le (norm_nonneg _)
    rw [le_div_iff₀ hpos]
    linarith

theorem fj_diffOn (la : Wt X.Ψ r) (P : Frame X.Ψ r → ℂ) (hP : X.IsBddSec la P) {ξ : Fin r → E}
    (hξ : X.IsIso ξ) (ν : X.Ψ → ℝ) : DifferentiableOn ℂ (X.fj la ξ ν P) X.dom := by
  unfold Data.fj
  split_ifs with h1 h2
  · apply DifferentiableOn.const_mul
    have he1 : ∀ s : X.Ψ → ℝ, ‖cexp (-(4 * (Real.pi : ℂ) * I) * ∑ τ, (ν τ : ℂ) * (s τ : ℂ))‖ ≤ 1 := by
      intro s
      have hre : -(4 * (Real.pi : ℂ) * I) * ∑ τ, (ν τ : ℂ) * (s τ : ℂ) =
          ((-(4 * Real.pi * ∑ τ, ν τ * s τ) : ℝ) : ℂ) * I := by
        push_cast
        ring
      rw [hre, Complex.norm_exp_ofReal_mul_I]
    have hec : Continuous fun s : X.Ψ → ℝ => cexp (-(4 * (Real.pi : ℂ) * I) * ∑ τ, (ν τ : ℂ) * (s τ : ℂ)) := by
      fun_prop
    exact diffOn_param_bdd h2.choose_spec.2.2.2 (flowL X ξ) (cont_flowL X ξ) (FourierCoefficientDomain.isOpen_dom X)
      (fun t x hx => (FlowCoefficientBounds.flow_real X hξ hx t la).1) P hP.1.1 _ hec he1 (fj_hbd X la P hP hξ)
  · exact differentiableOn_const 0
  · exact differentiableOn_const 0

end Frame

end

end ReciprocityTheory.ChartRestriction.G.FD.CuspCoefficientFlow
