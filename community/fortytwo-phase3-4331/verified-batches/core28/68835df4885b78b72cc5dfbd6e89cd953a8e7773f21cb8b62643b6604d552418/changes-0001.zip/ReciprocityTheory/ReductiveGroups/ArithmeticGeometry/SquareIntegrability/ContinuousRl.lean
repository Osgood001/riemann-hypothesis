import Mathlib

open MeasureTheory Set Complex

noncomputable section

namespace ReciprocityTheory.ChartRestriction.G.I2.DimB

variable {k : ℕ}

local instance : MeasureSpace UnitAddCircle := ⟨AddCircle.haarAddCircle⟩

local instance : Measure.IsAddHaarMeasure (volume : Measure UnitAddCircle) :=
  inferInstanceAs (Measure.IsAddHaarMeasure AddCircle.haarAddCircle)

local instance : IsProbabilityMeasure (volume : Measure UnitAddCircle) :=
  inferInstanceAs (IsProbabilityMeasure AddCircle.haarAddCircle)



def ubox (k : ℕ) : Set (Fin k → ℝ) :=
  {x | ∀ i, x i ∈ Ioc ((0 : Fin k → ℝ) i) ((0 : Fin k → ℝ) i + 1)}

def tproj (t : Fin k → ℝ) : UnitAddTorus (Fin k) := fun i => (t i : UnitAddCircle)

theorem tproj_oqm : IsOpenQuotientMap (tproj (k := k)) :=
  IsOpenQuotientMap.piMap (fun _ => QuotientAddGroup.isOpenQuotientMap_mk)


theorem tproj_eq {s t : Fin k → ℝ} (h : tproj s = tproj t) :
    ∃ n : Fin k → ℤ, t = s + fun i => (n i : ℝ) := by
  have hi : ∀ i, ∃ m : ℤ, t i = s i + m := by
    intro i
    have h1 : ((s i : ℝ) : UnitAddCircle) = (t i : UnitAddCircle) := congrFun h i
    have h2 : (((t i - s i : ℝ)) : UnitAddCircle) = 0 := by
      rw [AddCircle.coe_sub, h1, sub_self]
    obtain ⟨m, hm⟩ := (AddCircle.coe_eq_zero_iff (p := (1 : ℝ))).1 h2
    refine ⟨m, ?_⟩
    simp [zsmul_eq_mul] at hm
    linarith
  choose n hn using hi
  exact ⟨n, funext fun i => by simp [hn i]⟩

theorem descend (φ : (Fin k → ℝ) → ℂ) (hφ : Continuous φ)
    (hp : ∀ (n : Fin k → ℤ) t, φ (t + fun i => (n i : ℝ)) = φ t) :
    ∃ D : C(UnitAddTorus (Fin k), ℂ), ∀ t, D (tproj t) = φ t := by
  let D0 : UnitAddTorus (Fin k) → ℂ := fun θ => φ (Function.surjInv tproj_oqm.surjective θ)
  have hD : ∀ t, D0 (tproj t) = φ t := by
    intro t
    obtain ⟨n, hn⟩ := tproj_eq (Function.surjInv_eq tproj_oqm.surjective (tproj t))
    have e := hp n (Function.surjInv tproj_oqm.surjective (tproj t))
    rw [← hn] at e
    exact e.symm
  refine ⟨⟨D0, ?_⟩, hD⟩
  rw [tproj_oqm.isQuotientMap.continuous_iff]
  have : D0 ∘ tproj = φ := funext hD
  rw [this]; exact hφ


theorem mF_tproj (m : Fin k → ℤ) (x : Fin k → ℝ) :
    UnitAddTorus.mFourier m (tproj x) = cexp (2 * Real.pi * I * ∑ l, (m l : ℂ) * (x l : ℂ)) := by
  simp only [UnitAddTorus.mFourier, ContinuousMap.coe_mk, tproj, fourier_coe_apply]
  rw [← Complex.exp_sum, Finset.mul_sum]
  congr 1
  refine Finset.sum_congr rfl fun i _ => ?_
  simp; ring

end ReciprocityTheory.ChartRestriction.G.I2.DimB
