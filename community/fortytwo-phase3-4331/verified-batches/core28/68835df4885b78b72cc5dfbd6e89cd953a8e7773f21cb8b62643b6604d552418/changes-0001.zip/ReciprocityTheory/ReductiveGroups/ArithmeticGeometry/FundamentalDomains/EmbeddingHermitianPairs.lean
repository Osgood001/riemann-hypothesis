import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.ModerateCoefficientPositivity

namespace ReciprocityTheory.ChartRestriction.G.FD.EmbeddingHermitianPairs

open NumberField Complex Matrix ReciprocityTheory.ChartRestriction.G.FD
open scoped ComplexConjugate

variable {E : Type} [Field E] [NumberField E] [IsCMField E] {r : ℕ}

lemma emb_cc' (τ : E →+* ℂ) (x : E) : τ (cc x) = conj (τ x) := NumberField.IsCMField.complexEmbedding_complexConj E τ x

section herm

variable (τ : E →+* ℂ) (G : Matrix (Fin r) (Fin r) E)






lemma hermC_emb (x y : Fin r → E) :
    hermC τ G (fun a => τ (x a)) (fun a => τ (y a)) = τ (herm G x y) := by
  simp [hermC, herm, map_sum, emb_cc']

end herm

section flowAlg

variable (X : Data E r)

def covector (τ : X.Ψ) (e : Fin r → ℂ) (b : Fin r) : ℂ :=
  ∑ k, τ.1 (X.Gm b k) * conj (e k)

lemma covector_apply (τ : X.Ψ) (e v : Fin r → ℂ) :
    covector X τ e ⬝ᵥ v = hermC τ.1 X.Gm v e := by
  simp only [dotProduct, covector, hermC, Finset.sum_mul, Finset.mul_sum]
  exact Finset.sum_congr rfl fun a _ => Finset.sum_congr rfl fun b _ => by ring

lemma complex_flow_eq (τ : X.Ψ) (e : Fin r → ℂ) (s : ℂ) :
    X.flowMatV e τ s = 1 + (-(I * X.c τ * s)) • vecMulVec e (covector X τ e) := by
  ext a b
  simp [Data.flowMatV, Matrix.one_apply, vecMulVec_apply, covector]
  <;> ring

lemma complex_flow_apply (τ : X.Ψ) (e v : Fin r → ℂ) (s : ℂ) :
    (X.flowMatV e τ s) *ᵥ v = v + (-(I * X.c τ * s) * hermC τ.1 X.Gm v e) • e := by
  rw [complex_flow_eq, Matrix.add_mulVec, Matrix.one_mulVec, Matrix.smul_mulVec,
      Matrix.vecMulVec_mulVec, covector_apply]
  congr 1
  ext a
  change _ * (e a * hermC τ.1 X.Gm v e) = (_ * _) * e a
  ring

lemma complex_flow_det (τ : X.Ψ) (e : Fin r → ℂ) (s : ℂ) (h : hermC τ.1 X.Gm e e = 0) :
    (X.flowMatV e τ s).det = 1 := by
  rw [complex_flow_eq, Matrix.vecMulVec_eq Unit, ← Matrix.smul_mul, ← Matrix.replicateCol_smul,
    Matrix.det_one_add_replicateCol_mul_replicateRow, dotProduct_smul, covector_apply,
    h, smul_zero, add_zero]

def wv (ξ : Fin r → E) (τ : X.Ψ) : Fin r → ℂ := fun b => ∑ k, τ.1 (X.Gm b k) * conj (τ.1 (ξ k))

lemma wv_dot (ξ : Fin r → E) (τ : X.Ψ) (v : Fin r → ℂ) :
    wv X ξ τ ⬝ᵥ v = hermC τ.1 X.Gm v (Data.emb τ.1 ξ) := by
  exact covector_apply X τ _ _

lemma wv_dot_self {ξ : Fin r → E} (hξ : herm X.Gm ξ ξ = 0) (τ : X.Ψ) :
    wv X ξ τ ⬝ᵥ Data.emb τ.1 ξ = 0 := by
  rw [wv_dot]
  exact (hermC_emb τ.1 X.Gm ξ ξ).trans (by rw [hξ, map_zero])

lemma flowMat_eq (ξ : Fin r → E) (τ : X.Ψ) (s : ℂ) :
    X.flowMat ξ τ s = 1 + (-(I * X.c τ * s)) • vecMulVec (Data.emb τ.1 ξ) (wv X ξ τ) := by
  exact complex_flow_eq X τ _ _

lemma nil_sq {ξ : Fin r → E} (hξ : herm X.Gm ξ ξ = 0) (τ : X.Ψ) :
    vecMulVec (Data.emb τ.1 ξ) (wv X ξ τ) * vecMulVec (Data.emb τ.1 ξ) (wv X ξ τ) = 0 := by
  rw [Matrix.vecMulVec_mul_vecMulVec, wv_dot_self X hξ, zero_smul, Matrix.vecMulVec_zero]

lemma flowMat_mul {ξ : Fin r → E} (hξ : herm X.Gm ξ ξ = 0) (τ : X.Ψ) (s s' : ℂ) :
    X.flowMat ξ τ s * X.flowMat ξ τ s' = X.flowMat ξ τ (s + s') := by
  rw [flowMat_eq, flowMat_eq, flowMat_eq]
  rw [add_mul, one_mul, mul_add, mul_one, Matrix.smul_mul, Matrix.mul_smul, nil_sq X hξ,
    smul_zero, smul_zero, add_zero, add_assoc, ← add_smul]
  congr 2
  ring

lemma flowMat_zero (ξ : Fin r → E) (τ : X.Ψ) : X.flowMat ξ τ 0 = 1 := by
  ext a b
  simp [Data.flowMat, Matrix.one_apply]

lemma det_flowMat {ξ : Fin r → E} (hξ : herm X.Gm ξ ξ = 0) (τ : X.Ψ) (s : ℂ) :
    (X.flowMat ξ τ s).det = 1 := by
  exact complex_flow_det X τ _ _ ((hermC_emb τ.1 X.Gm ξ ξ).trans (by rw [hξ, map_zero]))

lemma flow_flow {ξ : Fin r → E} (hξ : herm X.Gm ξ ξ = 0) (s s' : X.Ψ → ℂ) (x : Frame X.Ψ r) :
    X.flow ξ s (X.flow ξ s' x) = X.flow ξ (s + s') x := by
  funext τ
  show (X.flowMat ξ τ (s τ) * (X.flowMat ξ τ (s' τ) * mat x τ) : Matrix (Fin r) (Fin r) ℂ) =
    X.flowMat ξ τ ((s + s') τ) * mat x τ
  rw [← Matrix.mul_assoc, flowMat_mul X hξ, Pi.add_apply]

lemma flow_zero (ξ : Fin r → E) (x : Frame X.Ψ r) : X.flow ξ 0 x = x := by
  funext τ
  show (X.flowMat ξ τ ((0 : X.Ψ → ℂ) τ) * mat x τ : Matrix (Fin r) (Fin r) ℂ) = x τ
  rw [Pi.zero_apply, flowMat_zero, Matrix.one_mul]
  rfl

lemma flowMat_mulVec (ξ : Fin r → E) (τ : X.Ψ) (s : ℂ) (v : Fin r → ℂ) :
    X.flowMat ξ τ s *ᵥ v = v + ((-(I * X.c τ * s)) * hermC τ.1 X.Gm v (Data.emb τ.1 ξ)) •
      Data.emb τ.1 ξ := by
  exact complex_flow_apply X τ _ _ _

end flowAlg

end ReciprocityTheory.ChartRestriction.G.FD.EmbeddingHermitianPairs
