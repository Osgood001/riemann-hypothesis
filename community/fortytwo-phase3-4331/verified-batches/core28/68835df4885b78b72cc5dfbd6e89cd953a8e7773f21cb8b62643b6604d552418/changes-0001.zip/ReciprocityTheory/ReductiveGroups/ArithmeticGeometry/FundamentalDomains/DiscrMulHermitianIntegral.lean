import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.MmatMulVec
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.HermitianTraceFormVanishing

namespace ReciprocityTheory.ChartRestriction.G.FD

open NumberField Complex Module Matrix
open scoped ComplexConjugate

variable {E : Type} [Field E] [NumberField E] [IsCMField E]

theorem smul_mem_of_int {r : ℕ} (L : Submodule (𝓞 E) (Fin r → E)) {c : E} (hc : IsIntegral ℤ c)
    {v : Fin r → E} (hv : v ∈ L) : c • v ∈ L := by
  exact L.smul_mem (⟨c, hc⟩ : 𝓞 E) hv

namespace DataX

variable {r : ℕ} (X : DataX E r)

theorem discr_mul_hermitian_integral {v w : Fin r → E} (hv : v ∈ X.Λ) (hw : w ∈ X.Λ) :
    IsIntegral ℤ (((NumberField.discr E).natAbs : E) * (X.ξ0 * herm X.Gm v w)) := by
  have h := d4l2_dual_int' (-(X.ξ0 * herm X.Gm v w)) (fun γ => by
    obtain ⟨k, hk⟩ := X.EF_int ((γ : E) • v) (smul_mem_of_int X.Λ (RingOfIntegers.isIntegral_coe γ) hv) w hw
    refine ⟨k, ?_⟩
    rw [← hk]
    unfold EFf
    rw [HermitianTraceFormVanishing.herm_smul_left]
    congr 1; ring)
  simpa only [mul_neg, neg_neg] using h.neg

theorem Mmat_cong (u : Fin 2 → Fin r → E) (hmem : ∀ i, u i ∈ X.Λ) (β : Matrix (Fin 2) (Fin 2) E)
    (hβ : ∀ i k, ∃ γ : E, IsIntegral ℤ γ ∧ β i k = ((X.g * dEnat E : ℕ) : E) / 2 * γ) :
    ∀ v ∈ X.Λ, ∃ y ∈ X.Λ, X.Mmat u β *ᵥ v - v = (X.g : E) • y := by
  intro v hv
  choose γ hγi hγ using hβ
  set d := (NumberField.discr E).natAbs with hd
  have hint : ∀ k, IsIntegral ℤ ((d : E) * (X.ξ0 * herm X.Gm v (u k))) :=
    fun k => X.discr_mul_hermitian_integral hv (hmem k)
  have hc : ∀ i k, IsIntegral ℤ (X.κ0 / 2 * d * γ i k * herm X.Gm v (u k)) := by
    intro i k
    have both := (hγi i k).mul (hint k)
    rcases X.κ0_xi with e | e
    · convert both using 1 <;> first | rfl | (rw [e]; ring)
    · convert both.neg using 1 <;> first | rfl | (rw [e]; ring)
  set c : Fin 2 → E := fun i => ∑ k, X.κ0 / 2 * d * γ i k * herm X.Gm v (u k) with hcdef
  have hci : ∀ i, IsIntegral ℤ (c i) := fun i => by
    simp only [hcdef, Fin.sum_univ_two]; exact (hc i 0).add (hc i 1)
  refine ⟨∑ i, c i • u i, Submodule.sum_mem _ fun i _ => smul_mem_of_int X.Λ (hci i) (hmem i), ?_⟩
  rw [X.Mmat_mulVec, add_sub_cancel_left, Finset.smul_sum]
  refine Finset.sum_congr rfl fun i _ => ?_
  rw [smul_smul]
  congr 1
  simp only [hcdef, Finset.mul_sum]
  refine Finset.sum_congr rfl fun k _ => ?_
  rw [hγ i k, hd]
  unfold dEnat
  push_cast
  ring

theorem g_smul_mem {y : Fin r → E} (hy : y ∈ X.Λ) : (X.g : E) • y ∈ X.Λ := by
  rw [Nat.cast_smul_eq_nsmul]
  exact nsmul_mem hy _

theorem exists_gamma (u : Fin 2 → Fin r → E) (hu : IsIsoPair X.Gm u) (hmem : ∀ i, u i ∈ X.Λ)
    (b : X.Ψ → Fin 2 → Fin 2 → ℂ) (hb : b ∈ X.LZ X.g) :
    ∃ γ ∈ X.Γ, (∀ v ∈ X.Λ, ∃ y ∈ X.Λ,
        Matrix.mulVec (γ : Matrix (Fin r) (Fin r) E) v - v = (X.g : E) • y) ∧
      ∀ τ, (γ : Matrix (Fin r) (Fin r) E).map τ.1 = X.zmat u b τ := by
  obtain ⟨β, hβh, hβi, rfl⟩ := hb
  have hiso := hu.1
  have hγc : ∀ v ∈ X.Λ, ∃ y ∈ X.Λ, X.Mmat u β *ᵥ v - v = (X.g : E) • y :=
    X.Mmat_cong u hmem β hβi
  have hγc' : ∀ v ∈ X.Λ, ∃ y ∈ X.Λ, X.Mmat u (-β) *ᵥ v - v = (X.g : E) • y :=
    X.Mmat_cong u hmem (-β) (fun i k => by
      obtain ⟨γ', h1, h2⟩ := hβi i k
      exact ⟨-γ', h1.neg, by simp [h2]⟩)
  have stable (M : Matrix (Fin r) (Fin r) E)
      (hc : ∀ v ∈ X.Λ, ∃ y ∈ X.Λ, M *ᵥ v - v = (X.g : E) • y)
      (v) (hv : v ∈ X.Λ) : M *ᵥ v ∈ X.Λ := by
    obtain ⟨y,hy,he⟩ := hc v hv
    rw [← sub_add_cancel (M *ᵥ v) v, he]
    exact X.Λ.add_mem (X.g_smul_mem hy) hv
  have hstab : IsUStab X.Gm X.Λ (X.gam u hiso β) := by
    refine ⟨fun x y => X.herm_Mmat u hiso β hβh x y, fun x => ⟨stable _ hγc x, fun hx => ?_⟩⟩
    change X.Mmat u β *ᵥ x ∈ X.Λ at hx
    have h := stable _ hγc' _ hx
    simpa only [Matrix.mulVec_mulVec, X.Mmat_mul u hiso, neg_add_cancel, Data.Mmat_zero,
      Matrix.one_mulVec] using h
  exact ⟨X.gam u hiso β, X.cong _ hstab hγc, hγc, fun τ => X.Mmat_map u β τ⟩

theorem LZ_periodic (u : Fin 2 → Fin r → E) (hu : IsIsoPair X.Gm u) (hmem : ∀ i, u i ∈ X.Λ)
    (la : Wt X.Ψ r) (P : Frame X.Ψ r → ℂ) (hP : X.IsSec la P)
    (hχ : ∀ γ ∈ X.Γ, (∀ v ∈ X.Λ, ∃ y ∈ X.Λ,
        Matrix.mulVec (γ : Matrix (Fin r) (Fin r) E) v - v = (X.g : E) • y) → X.χ la γ = 1)
    (b : X.Ψ → Fin 2 → Fin 2 → ℂ) (hb : b ∈ X.LZ X.g) (x : Frame X.Ψ r) (hx : x ∈ X.dom) :
    P (X.Zb u b x) = P x := by
  obtain ⟨γ, hγΓ, hγc, hmap⟩ := X.exists_gamma u hu hmem b hb
  have e1 : X.Zb u b x = lact γ x := funext fun τ => by
    show X.zmat u b τ * mat x τ = (γ : Matrix (Fin r) (Fin r) E).map τ.1 * mat x τ
    rw [hmap]
  rw [e1, hP.2.2 γ hγΓ x hx, hχ γ hγΓ hγc, one_mul]

noncomputable def c0E : E := ((X.g * dEnat E : ℕ) : E) / 2

theorem cc_c0E : cc X.c0E = X.c0E := by
  unfold c0E cc
  rw [map_div₀, map_natCast, map_ofNat]

theorem tau_c0E (τ : E →+* ℂ) : τ X.c0E = ((((X.g * dEnat E : ℕ) : ℝ) / 2 : ℝ) : ℂ) := by
  unfold c0E
  rw [map_div₀, map_natCast, map_ofNat]
  push_cast
  try ring

theorem mem_LZ_of (w : Fin 2 → Fin 2 → E) (hwi : ∀ i k, IsIntegral ℤ (w i k))
    (hwh : ∀ i k, cc (w i k) = w k i) :
    X.embH (Matrix.of fun i k => X.c0E * w i k) ∈ X.LZ X.g := by
  refine ⟨Matrix.of fun i k => X.c0E * w i k, fun i k => ?_, fun i k => ⟨w i k, hwi i k, rfl⟩, rfl⟩
  show cc (X.c0E * w i k) = X.c0E * w k i
  rw [show cc (X.c0E * w i k) = cc X.c0E * cc (w i k) from map_mul (IsCMField.complexConj E) _ _, X.cc_c0E, hwh i k]

theorem pairR_of (χ : X.Ψ → Fin 2 → Fin 2 → ℂ) (w : Fin 2 → Fin 2 → E) :
    X.pairR χ (X.embH (Matrix.of fun i k => X.c0E * w i k)) =
      (((X.g * dEnat E : ℕ) : ℝ) / 2) *
        (∑ τ : X.Ψ, ∑ i, ∑ k, χ τ i k * τ.1 (w i k)).re := by
  unfold Data.pairR Data.embH
  simp only [Matrix.of_apply, map_mul, tau_c0E]
  rw [← Complex.re_ofReal_mul]
  simp only [Finset.mul_sum, mul_left_comm]

theorem freq_entry (χ : X.Ψ → Fin 2 → Fin 2 → ℂ) (hf : X.IsFreqZ X.g χ) (z : X.Ψ → ℂ)
    (w : 𝓞 E → Fin 2 → Fin 2 → E) (hwi : ∀ γ i k, IsIntegral ℤ (w γ i k))
    (hwh : ∀ γ i k, cc (w γ i k) = w γ k i)
    (hterm : ∀ γ : 𝓞 E, (∑ τ : X.Ψ, ∑ i, ∑ k, χ τ i k * τ.1 (w γ i k)).re =
      2 * (∑ τ : X.Ψ, z τ * τ.1 (γ : E)).re) :
    ∃ ω : E, (∀ τ : X.Ψ, z τ = τ.1 ω) ∧
      IsIntegral ℤ (((X.g * (NumberField.discr E).natAbs ^ 2 : ℕ) : E) * ω) := by
  refine X.exists_emb_int z X.g X.g_pos fun γ => ?_
  obtain ⟨k, hk⟩ := hf _ (X.mem_LZ_of (w γ) (hwi γ) (hwh γ))
  rw [X.pairR_of, hterm γ] at hk
  refine ⟨k, ?_⟩
  rw [← hk]
  unfold dEnat
  push_cast
  ring

theorem freq_to_beta (χ : X.Ψ → Fin 2 → Fin 2 → ℂ) (hχ : IsHermFam χ) (hf : X.IsFreqZ X.g χ) :
    ∃ β : Matrix (Fin 2) (Fin 2) E, (∀ i k, cc (β i k) = β k i) ∧ χ = X.embH β ∧
      ∀ i k, IsIntegral ℤ (((X.g * dEnat E ^ 2 : ℕ) : E) * β i k) := by
  classical
  have single_sum (C : Fin 2 → Fin 2 → ℂ) (a b : Fin 2) (z : ℂ) :
      ∑ i, ∑ k, C i k * (if i = a ∧ k = b then z else 0) = C a b * z := by
    rw [Finset.sum_eq_single a, Finset.sum_eq_single b]
    · simp
    · intro i _ hi; simp [hi]
    · simp
    · intro i _ hi; simp [hi]
    · simp
  have dual_sum (C : Fin 2 → Fin 2 → ℂ) (a b : Fin 2) (z : ℂ) :
      ∑ i, ∑ k, C i k * (if k = a ∧ i = b then z else 0) = C b a * z := by
    rw [Finset.sum_comm]
    exact single_sum (fun i k => C k i) a b z
  have entry (a b : Fin 2) : ∃ ω : E, (∀ τ : X.Ψ, χ τ a b = τ.1 ω) ∧
      IsIntegral ℤ (((X.g * (NumberField.discr E).natAbs ^ 2 : ℕ) : E) * ω) := by
    apply X.freq_entry χ hf (fun τ => χ τ a b)
      (fun γ i k => (if i = a ∧ k = b then (γ : E) else 0) +
                    cc (if k = a ∧ i = b then (γ : E) else 0))
    · intro γ i k
      apply IsIntegral.add
      · split_ifs
        · exact γ.isIntegral_coe
        · exact isIntegral_zero
      · apply isIntegral_cc
        split_ifs
        · exact γ.isIntegral_coe
        · exact isIntegral_zero
    · intro γ i k
      simp [cc, map_add, IsCMField.complexConj_apply_apply, add_comm]
    · intro γ
      rw [Complex.re_sum, Complex.re_sum, Finset.mul_sum]
      refine Finset.sum_congr rfl fun τ _ => ?_
      simp only [map_add, emb_cc, apply_ite τ.1, apply_ite conj, map_zero, mul_add,
        Finset.sum_add_distrib, single_sum, dual_sum, hχ τ a b]
      simp [Complex.mul_re]
      ring
  choose β hβ hi using entry
  obtain ⟨τ⟩ := X.nonempty_Psi
  refine ⟨Matrix.of β, fun i k => τ.1.injective ?_, funext fun t => funext fun i =>
    funext fun k => hβ i k t, hi⟩
  change τ.1 (cc (β i k)) = τ.1 (β k i)
  rw [emb_cc, ← hβ, ← hβ, ← hχ τ i k]

end DataX

end ReciprocityTheory.ChartRestriction.G.FD
