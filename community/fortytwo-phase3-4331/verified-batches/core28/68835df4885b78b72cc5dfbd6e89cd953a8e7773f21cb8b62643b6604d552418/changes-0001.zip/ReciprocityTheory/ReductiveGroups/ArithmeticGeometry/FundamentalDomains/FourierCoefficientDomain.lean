import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.FourierCoefficientMatrices

namespace ReciprocityTheory.ChartRestriction.G.FD.FourierCoefficientDomain

open NumberField Complex ReciprocityTheory.ChartRestriction.G.FD MeasureTheory Metric Set Filter
open scoped ComplexConjugate Topology

noncomputable section

section Cauchy

variable {F : Type*} [NormedAddCommGroup F] [NormedSpace ℂ F]

lemma norm_fderiv_le {U : Set F} (hU : IsOpen U) {G : F → ℂ} (hG : DifferentiableOn ℂ G U)
    {y : F} {R C : ℝ} (hR : 0 < R) (hball : closedBall y R ⊆ U)
    (hC : ∀ z ∈ closedBall y R, ‖G z‖ ≤ C) : ‖fderiv ℂ G y‖ ≤ C / R := by
  have hy := Metric.mem_closedBall_self hR.le (x := y)
  refine ContinuousLinearMap.opNorm_le_of_unit_norm (div_nonneg ((norm_nonneg _).trans (hC _ hy)) hR.le) ?_
  intro v hv
  let l (t : ℂ) := y + t • v
  have hl (t : ℂ) : HasDerivAt l v t := by simpa [l] using ((hasDerivAt_id t).smul_const v).const_add y
  have hm (t : ℂ) (ht : t ∈ closedBall 0 R) : l t ∈ closedBall y R := by
    simpa [l, Metric.mem_closedBall, dist_eq_norm, norm_smul, hv] using ht
  have hd : DifferentiableOn ℂ (G ∘ l) (closedBall 0 R) := fun t ht =>
    ((hG.differentiableAt (hU.mem_nhds (hball (hm t ht)))).comp t (hl t).differentiableAt).differentiableWithinAt
  have hg : HasDerivAt (G ∘ l) (fderiv ℂ G y v) 0 :=
    (hG.differentiableAt (hU.mem_nhds (hball hy))).hasFDerivAt.comp_hasDerivAt_of_eq 0 (hl 0) (by simp [l])
  rw [← hg.deriv]
  apply Complex.norm_deriv_le_of_forall_mem_sphere_norm_le hR
  · apply DifferentiableOn.diffContOnCl
    rwa [closure_ball (0 : ℂ) hR.ne']
  · exact fun t ht => hC _ (hm t (Metric.sphere_subset_closedBall ht))

end Cauchy

section Param

variable {F : Type*} [NormedAddCommGroup F] [NormedSpace ℂ F] [FiniteDimensional ℂ F]
  [MeasurableSpace F] [BorelSpace F] {n : ℕ}

theorem diffOn_finite_integral {ι : Type} [Fintype ι] (μ : Measure (ι → ℝ)) [IsFiniteMeasure μ]
    (A : (ι → ℝ) → F →L[ℂ] F) (hA : Continuous A) {U : Set F} (hU : IsOpen U)
    (hAU : ∀ᵐ t ∂μ, MapsTo (A t) U U) (G : F → ℂ) (hG : DifferentiableOn ℂ G U)
    (e : (ι → ℝ) → ℂ) (he : Continuous e)
    (hm : ∀ x ∈ U, AEStronglyMeasurable (fun t => G (A t x) * e t) μ)
    (hb : ∀ x ∈ U, ∃ ρ > 0, ∃ C, closedBall x ρ ⊆ U ∧
      ∀ᵐ t ∂μ, ∀ z ∈ closedBall x ρ, ‖G (A t z) * e t‖ ≤ C) :
    DifferentiableOn ℂ (fun x => ∫ t, G (A t x) * e t ∂μ) U := by
  intro x hx
  obtain ⟨ρ, hρ, C, hsub, hC⟩ := hb x hx
  let D (z : F) (t : ι → ℝ) := e t • (fderiv ℂ G (A t z)).comp (A t)
  have hd (t) (ht : MapsTo (A t) U U) {z} (hz : z ∈ U) :
      HasFDerivAt (fun y => G (A t y) * e t) (D z t) z :=
    (((hG.differentiableAt (hU.mem_nhds (ht hz))).hasFDerivAt).comp z (A t).hasFDerivAt).mul_const _
  have hnear {z} (hz : z ∈ ball x (ρ / 2)) : closedBall z (ρ / 2) ⊆ closedBall x ρ := by
    intro y hy
    exact mem_closedBall.mpr (by linarith [dist_triangle y z x, mem_closedBall.mp hy, mem_ball.mp hz])
  have hu {z} (hz : z ∈ ball x (ρ / 2)) : z ∈ U :=
    hsub (hnear hz (mem_closedBall_self (half_pos hρ).le))
  have m1 := (measurable_fderiv ℂ G).comp (hA.clm_apply (continuous_const (y := x))).measurable
  have m2 : Measurable fun t => (fderiv ℂ G (A t x)).comp (A t) :=
    isBoundedBilinearMap_comp.continuous.measurable.comp (m1.prodMk hA.measurable)
  have key := hasFDerivAt_integral_of_dominated_of_fderiv_le (μ := μ)
    (F := fun z t => G (A t z) * e t) (F' := D) (bound := fun _ => C / (ρ / 2))
    (ball_mem_nhds x (half_pos hρ))
    (eventually_of_mem (hU.mem_nhds hx) (fun z hz => hm z hz))
    ((integrable_const C).mono' (hm x hx)
      (hC.mono fun t ht => ht x (mem_closedBall_self hρ.le)))
    (he.measurable.smul m2).aestronglyMeasurable
    (by
      filter_upwards [hAU, hC] with t ht hc z hz
      rw [← (hd t ht (hu hz)).fderiv]
      exact norm_fderiv_le hU (fun y hy => (hd t ht hy).differentiableAt.differentiableWithinAt)
        (half_pos hρ) ((hnear hz).trans hsub) (fun y hy => hc y (hnear hz hy)))
    (integrable_const _)
    (hAU.mono fun t ht z hz => hd t ht (hu hz))
  exact key.differentiableAt.differentiableWithinAt

theorem diffOn_param {K : Set (Fin n → ℝ)} (hK : IsCompact K) (hKm : MeasurableSet K)
    (A : (Fin n → ℝ) → F →L[ℂ] F) (hA : Continuous A) {U : Set F} (hU : IsOpen U)
    (hAU : ∀ t ∈ K, ∀ x ∈ U, A t x ∈ U) (G : F → ℂ) (hG : DifferentiableOn ℂ G U)
    (e : (Fin n → ℝ) → ℂ) (he : Continuous e) :
    DifferentiableOn ℂ (fun x => ∫ t in K, G (A t x) * e t) U := by
  letI : IsFiniteMeasure (volume.restrict K) := isFiniteMeasure_restrict.mpr hK.measure_lt_top.ne
  apply diffOn_finite_integral (volume.restrict K) A hA hU
    ((ae_restrict_iff' hKm).2 (Eventually.of_forall fun t ht => fun _ hz => hAU t ht _ hz)) G hG e he
  · intro x hx
    exact ((hG.continuousOn.comp (hA.clm_apply continuous_const).continuousOn
      (fun t ht => hAU t ht x hx)).mul he.continuousOn).aestronglyMeasurable hKm
  · intro x hx
    obtain ⟨ρ, hρ, hsub⟩ := Metric.nhds_basis_closedBall.mem_iff.mp (hU.mem_nhds hx)
    let S := K ×ˢ closedBall x ρ
    have hc : ContinuousOn (fun p : (Fin n → ℝ) × F => G (A p.1 p.2) * e p.1) S :=
      (hG.continuousOn.comp ((hA.comp continuous_fst).clm_apply continuous_snd).continuousOn
        (fun p hp => hAU p.1 hp.1 p.2 (hsub hp.2))).mul (he.comp continuous_fst).continuousOn
    obtain ⟨C, hC⟩ := (hK.prod (isCompact_closedBall x ρ)).exists_bound_of_continuousOn hc
    exact ⟨ρ, hρ, C, hsub, (ae_restrict_iff' hKm).2
      (Eventually.of_forall fun t ht z hz => hC (t, z) ⟨ht, hz⟩)⟩


end Param

section Dom

variable {E : Type} [Field E] [NumberField E] [IsCMField E] {r : ℕ} (X : Data E r)
  (u : Fin 2 → Fin r → E)

lemma cont_gram (τ : X.Ψ) : Continuous fun x : Frame X.Ψ r => gram τ.1 X.Gm (mat x τ) := by
  refine continuous_pi fun a => continuous_pi fun b => ?_
  simp [gram, hermC, col, mat]
  fun_prop

lemma isOpen_dom : IsOpen X.dom := by
  have h : X.dom = ⋂ τ : X.Ψ, ({x : Frame X.Ψ r | (mat x τ).det ≠ 0} ∩
      ⋂ i : Fin (r + 1), {x | 0 < psgn X.p0 i * (dmin X.Gm x τ i).re}) := by
    ext x; simp [Data.dom, GG]
  rw [h]
  refine isOpen_iInter_of_finite fun τ => IsOpen.inter ?_ (isOpen_iInter_of_finite fun i => ?_)
  · exact isOpen_ne_fun (show Continuous fun x : Frame X.Ψ r => mat x τ from continuous_apply τ).matrix_det
      continuous_const
  · exact isOpen_lt continuous_const (continuous_const.mul (Complex.continuous_re.comp
      ((cont_gram X τ).matrix_submatrix _ _).matrix_det))

def ZbL (b : X.Ψ → Fin 2 → Fin 2 → ℂ) : Frame X.Ψ r →L[ℂ] Frame X.Ψ r :=
  (LinearMap.pi fun τ => (LinearMap.mulLeft ℂ (X.zmat u b τ)).comp (LinearMap.proj τ)).toContinuousLinearMap

lemma cont_Zb {n : ℕ} {B : (Fin n → ℝ) → X.Ψ → Fin 2 → Fin 2 → ℂ}
    (hB : Continuous B) (y : Frame X.Ψ r) : Continuous fun t => X.Zb u (B t) y := by
  have hB' : ∀ τ i k, Continuous fun t => B t τ i k := fun τ i k => by fun_prop
  refine continuous_pi fun τ => continuous_pi fun a => continuous_pi fun c => ?_
  simp [Data.Zb, Data.zmat, Matrix.mul_apply, mat]
  fun_prop

lemma cont_ZbL {n : ℕ} {B : (Fin n → ℝ) → X.Ψ → Fin 2 → Fin 2 → ℂ}
    (hB : Continuous B) : Continuous fun t => ZbL X u (B t) :=
  continuous_clm_apply.2 fun y => cont_Zb X u hB y

end Dom

end

end ReciprocityTheory.ChartRestriction.G.FD.FourierCoefficientDomain
