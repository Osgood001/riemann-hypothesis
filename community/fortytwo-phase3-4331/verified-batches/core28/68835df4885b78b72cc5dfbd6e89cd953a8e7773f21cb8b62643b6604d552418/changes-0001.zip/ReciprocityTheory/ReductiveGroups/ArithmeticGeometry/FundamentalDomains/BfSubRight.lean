import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.SignTypeCancelIdentity

namespace ReciprocityTheory.ChartRestriction.G.FD.OrthonormalChartBounds

open NumberField Complex Matrix ReciprocityTheory.ChartRestriction.G.FD ReciprocityTheory.ChartRestriction.G.FD.FrameDegreeData
open scoped ComplexConjugate

noncomputable section

variable {E : Type} [Field E] [NumberField E] [IsCMField E] {r : ℕ} (X : Data E r)

def Bf (Z : X.Coord) (τ : X.Ψ) (v w : Fin r → ℂ) : ℂ := ∑ a, ∑ b, v a * Gp X Z τ a b * conj (w b)

def Nv (Z : X.Coord) (τ : X.Ψ) (v : Fin r → ℂ) (m : Fin (r - X.p0)) : ℂ :=
  v (nI X m) + ∑ c, Z τ m c * v (Fin.castLE X.p0_le c)

def Pv (v : Fin r → ℂ) (a : Fin X.p0) : ℂ := v (Fin.castLE X.p0_le a)

private lemma prefix_sum {n k : ℕ} (h : k ≤ n) (f : Fin n → ℂ)
    (hf : ∀ j : Fin n, k ≤ j.val → f j = 0) :
    ∑ j, f j = ∑ i : Fin k, f (Fin.castLE h i) := by
  let e := finCongr (Nat.add_sub_cancel' h)
  rw [← Fintype.sum_equiv e (fun i => f (e i)) f (fun _ => rfl), Fin.sum_univ_add]
  have hz (i : Fin (n-k)) : f (e (Fin.natAdd k i)) = 0 := hf _ (by simp [e])
  simp [hz]
  rfl

lemma Lv_p (Z : X.Coord) (τ : X.Ψ) (v : Fin r → ℂ) (a : Fin X.p0) :
    ∑ j, X.lowBlock Z τ (Fin.castLE X.p0_le a) j * v j = v (Fin.castLE X.p0_le a) := by
  rw [sum_split X]
  simp [L_pp X, L_pn X, ite_mul]

lemma Lv_n (Z : X.Coord) (τ : X.Ψ) (v : Fin r → ℂ) (m : Fin (r - X.p0)) :
    ∑ j, X.lowBlock Z τ (nI X m) j * v j = Nv X Z τ v m := by
  rw [sum_split X]
  simp only [L_np X, L_nn X, ite_mul, one_mul, zero_mul, Finset.sum_ite_eq, Finset.mem_univ, if_true, Nv]
  exact add_comm _ _

lemma Bf_coord (Z : X.Coord) (τ : X.Ψ) (v w : Fin r → ℂ) :
    Bf X Z τ v w = ∑ a, Pv X v a * conj (Pv X w a) - ∑ m, Nv X Z τ v m * conj (Nv X Z τ w m) := by
  have h1 : Bf X Z τ v w = ∑ c : Fin r, ((sgn X.p0 (c : ℕ) : ℝ) : ℂ) * (∑ a, X.lowBlock Z τ c a * v a) *
      conj (∑ b, X.lowBlock Z τ c b * w b) := by
    have eval : Bf X Z τ v w = v ⬝ᵥ ((Gp X Z τ) *ᵥ fun j => conj (w j)) := by
      simp only [Bf, Matrix.mulVec, dotProduct, Finset.mul_sum, mul_assoc]
    rw [eval, Gp, ← Matrix.mulVec_mulVec, ← Matrix.mulVec_mulVec,
      Matrix.dotProduct_mulVec, Matrix.vecMul_transpose]
    unfold dotProduct
    refine Finset.sum_congr rfl fun c _ => ?_
    rw [Matrix.mulVec_diagonal]
    simp only [Matrix.mulVec, dotProduct, map_sum, map_mul, Matrix.map_apply]
    ring
  rw [h1, sum_split X]
  rw [sub_eq_add_neg, ← Finset.sum_neg_distrib]
  congr 1
  · refine Finset.sum_congr rfl fun a _ => ?_
    rw [Lv_p X, Lv_p X]
    simp [sgn, Pv]
  · refine Finset.sum_congr rfl fun m _ => ?_
    rw [Lv_n X, Lv_n X]
    simp [sgn, nI]

lemma Bf_sub_left (Z : X.Coord) (τ : X.Ψ) (v t w : Fin r → ℂ) :
    Bf X Z τ (v - t) w = Bf X Z τ v w - Bf X Z τ t w := by
  simp [Bf, sub_mul, Finset.sum_sub_distrib]

lemma Bf_sub_right (Z : X.Coord) (τ : X.Ψ) (v t w : Fin r → ℂ) :
    Bf X Z τ w (v - t) = Bf X Z τ w v - Bf X Z τ w t := by
  simp [Bf, mul_sub, Finset.sum_sub_distrib]

lemma Bf_conj (Z : X.Coord) (τ : X.Ψ) (v w : Fin r → ℂ) : Bf X Z τ w v = conj (Bf X Z τ v w) := by
  rw [Bf_coord X, Bf_coord X]
  simp [map_sum, starRingEnd_self_apply]
  congr 1 <;> exact Finset.sum_congr rfl fun _ _ => mul_comm _ _

private lemma sum_eq_add_sum_castLE_of_vanish_above {n : ℕ} (k : Fin n) (f : Fin n → ℂ) (hf : ∀ j : Fin n, k < j → f j = 0) :
    ∑ j, f j = f k + ∑ c : Fin k, f (Fin.castLE k.isLt.le c) := by
  rw [prefix_sum k.isLt f (fun j hj => hf j (by omega)), Fin.sum_univ_castSucc, add_comm]
  rfl

lemma Bf_gv_zero (Z : X.Coord) (τ : X.Ψ) (hdet : ∀ c : Fin r, (blk (Gp X Z τ) c).det ≠ 0) (k : Fin r)
    (t : Fin r → ℂ) (ht : ∀ b, k ≤ b → t b = 0) :
    Bf X Z τ (fun a => uMat (Gp X Z τ) a k) t = 0 := by
  have hB : IsUnit (blk (Gp X Z τ) k).det := isUnit_iff_ne_zero.mpr (hdet k)
  have hw : Matrix.vecMul (Matrix.vecMul (rowc (Gp X Z τ) k) (blk (Gp X Z τ) k)⁻¹)
      (blk (Gp X Z τ) k) = rowc (Gp X Z τ) k := by
    rw [Matrix.vecMul_vecMul, Matrix.nonsing_inv_mul _ hB, Matrix.vecMul_one]
  show ∑ a, ∑ b, uMat (Gp X Z τ) a k * Gp X Z τ a b * conj (t b) = 0
  rw [Finset.sum_comm]
  apply Finset.sum_eq_zero
  intro b _
  by_cases hb : k ≤ b
  · simp [ht b hb]
  · push_neg at hb
    rw [← Finset.sum_mul]
    have hcol : ∑ c : Fin k, (Matrix.vecMul (rowc (Gp X Z τ) k) (blk (Gp X Z τ) k)⁻¹) c *
        Gp X Z τ (Fin.castLE k.isLt.le c) b = Gp X Z τ k b := congrFun hw ⟨(b : ℕ), hb⟩
    have hu : ∀ c : Fin k, uMat (Gp X Z τ) (Fin.castLE k.isLt.le c) k =
        -(Matrix.vecMul (rowc (Gp X Z τ) k) (blk (Gp X Z τ) k)⁻¹) c := by
      intro c
      have hne : Fin.castLE k.isLt.le c ≠ k := by
        intro h
        have h1 := congrArg Fin.val h
        have h2 := c.isLt
        simp [Fin.coe_castLE] at h1
        omega
      have hlt : Fin.castLE k.isLt.le c < k := Fin.lt_iff_val_lt_val.mpr (by simp)
      simp only [uMat, Matrix.of_apply, if_neg hne, dif_pos hlt]
      try rfl
    have hsum : ∑ a, uMat (Gp X Z τ) a k * Gp X Z τ a b = 0 := by
      rw [sum_eq_add_sum_castLE_of_vanish_above k]
      · rw [show uMat (Gp X Z τ) k k = 1 by simp [uMat]]
        simp [hu, neg_mul, Finset.sum_neg_distrib]
        rw [hcol]
        ring
      · intro j hj
        simp only [uMat, Matrix.of_apply, if_neg (ne_of_gt hj), dif_neg (not_lt.mpr hj.le), zero_mul]
    rw [hsum, zero_mul]

lemma Bf_self_re (Z : X.Coord) (τ : X.Ψ) (v : Fin r → ℂ) :
    (Bf X Z τ v v).re = nsq (Pv X v) - nsq (Nv X Z τ v) := by
  rw [Bf_coord X]
  simp only [Complex.sub_re, Complex.re_sum, nsq]
  congr 1 <;> refine Finset.sum_congr rfl fun a _ => ?_ <;>
    rw [Complex.mul_conj, Complex.ofReal_re, Complex.normSq_eq_norm_sq]

lemma Bf_pos_ge (Z : X.Coord) (τ : X.Ψ) (v : Fin r → ℂ) (hv : ∀ m, v (nI X m) = 0) :
    (1 - X.zN Z ^ 2) * nsq (Pv X v) ≤ (Bf X Z τ v v).re := by
  rw [Bf_self_re X]
  have hN : Nv X Z τ v = (Matrix.of (Z τ)).mulVec (Pv X v) := by
    funext m
    simp only [Nv, hv m, zero_add]
    rfl
  have h1 := nsq_mulVec_le_opN (Matrix.of (Z τ)) (Pv X v)
  have h2 := opN_le_zN X Z τ
  have h3 := opN_nonneg (Matrix.of (Z τ))
  have h4 := nsq_nonneg (Pv X v)
  rw [← hN] at h1
  have h5 : Data.opN (Matrix.of (Z τ)) ^ 2 ≤ X.zN Z ^ 2 := by nlinarith
  nlinarith [mul_le_mul_of_nonneg_right h5 h4]

end

end ReciprocityTheory.ChartRestriction.G.FD.OrthonormalChartBounds
