import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.UnitaryComplementMoveOfIsotropic
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.FourierCoefficientLattice
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.FourierCubeVolume

namespace ReciprocityTheory.ChartRestriction.G.FD.FourierCubeIntegral

open NumberField Complex ReciprocityTheory.ChartRestriction.G.FD ReciprocityTheory.ChartRestriction.G.FD.FourierCoefficientMatrices ReciprocityTheory.ChartRestriction.G.FD.FourierCubeVolume
  MeasureTheory Set Filter

noncomputable section

lemma cube_int_shift {N : ℕ} (φ : (Fin N → ℝ) → ℂ) (hφ : Continuous φ)
    (hp : ∀ (n : Fin N → ℤ) t, φ (t + fun i => (n i : ℝ)) = φ t) (s : Fin N → ℝ) :
    ∫ t in cube N, φ (t + s) = ∫ t in cube N, φ t := by
  letI : MeasureSpace UnitAddCircle := ⟨AddCircle.haarAddCircle⟩
  letI : Measure.IsAddHaarMeasure (volume : Measure UnitAddCircle) :=
    inferInstanceAs (Measure.IsAddHaarMeasure AddCircle.haarAddCircle)
  letI : IsProbabilityMeasure (volume : Measure UnitAddCircle) :=
    inferInstanceAs (IsProbabilityMeasure AddCircle.haarAddCircle)
  obtain ⟨D, hD⟩ := I2.DimB.descend φ hφ hp
  have torus (F : UnitAddTorus (Fin N) → ℂ) :
      ∫ t in cube N, F (I2.DimB.tproj t) = ∫ θ, F θ := by
    exact (setIntegral_congr_set (f := fun t => F (I2.DimB.tproj t)) (ubox_ae N).symm).trans
      (UnitAddTorus.integral_preimage F (0 : Fin N → ℝ)).symm
  have hadd (t : Fin N → ℝ) : I2.DimB.tproj (t + s) = I2.DimB.tproj t + I2.DimB.tproj s := by
    funext i
    simp [I2.DimB.tproj]
  simp_rw [← hD, hadd]
  exact (torus (fun θ => D (θ + I2.DimB.tproj s))).trans
    ((integral_add_right_eq_self (μ := volume) (fun θ => D θ) (I2.DimB.tproj s)).trans (torus D).symm)

variable {E : Type} [Field E] [NumberField E] [IsCMField E] {r : ℕ} {X : Data E r}
  {u : Fin 2 → Fin r → E} {g : ℕ} {ω : Fin (4 * Fintype.card X.Ψ) → X.Ψ → Fin 2 → Fin 2 → ℂ}
  {G : Frame X.Ψ r → ℂ}

theorem Ich_Zb (hω : X.IsLZBasis g ω)
    (hadd : ∀ b b' x, X.Zb u b (X.Zb u b' x) = X.Zb u (b + b') x)
    (hdomH : ∀ b, IsHermFam b → ∀ x ∈ X.dom, X.Zb u b x ∈ X.dom)
    (hG : DifferentiableOn ℂ G X.dom) (hper : ∀ b ∈ X.LZ g, ∀ x ∈ X.dom, G (X.Zb u b x) = G x)
    {χ : X.Ψ → Fin 2 → Fin 2 → ℂ} (hfreq : ∀ j, ∃ k : ℤ, 2 * X.pairR χ (ω j) = k)
    {b : X.Ψ → Fin 2 → Fin 2 → ℂ} (hb : IsHermFam b) {x : Frame X.Ψ r} (hx : x ∈ X.dom) :
    Ich X u ω G χ (X.Zb u b x) = cexp (4 * Real.pi * I * X.pairR χ b) * Ich X u ω G χ x := by
  obtain ⟨s, hs⟩ := herm_eq_sum ω (herm_ω hω) hω.2.2 rfl hb
  change b = Bv ω s at hs
  subst b
  choose k hk using hfreq
  have hshift := cube_int_shift (fun t => G (X.Zb u (Bv ω t) x) * ech ω χ t)
    ((psi_cont hω hdomH hG hx).mul (ech_cont ω χ)) (fun n t => by
      rw [psi_per hω hadd hdomH hper hx n t, ech_add, ech_int (ω := ω) χ hk n, mul_one]) s
  have hinv : ech ω χ s * cexp (4 * Real.pi * I * X.pairR χ (Bv ω s)) = 1 := by
    show cexp (-(4 * Real.pi * I) * (X.pairR χ (Bv ω s) : ℂ)) *
      cexp (4 * Real.pi * I * X.pairR χ (Bv ω s)) = 1
    rw [← Complex.exp_add]
    ring_nf
    exact Complex.exp_zero
  have hpt : ∀ t, G (X.Zb u (Bv ω t) (X.Zb u (Bv ω s) x)) * ech ω χ t =
      (G (X.Zb u (Bv ω (t + s)) x) * ech ω χ (t + s)) *
        cexp (4 * Real.pi * I * X.pairR χ (Bv ω s)) := by
    intro t
    rw [hadd, ← Bv_add, ech_add, mul_assoc, mul_assoc, hinv, mul_one]
  show ∫ t in cube (4 * Fintype.card X.Ψ), G (X.Zb u (Bv ω t) (X.Zb u (Bv ω s) x)) * ech ω χ t =
    cexp (4 * Real.pi * I * X.pairR χ (Bv ω s)) *
      ∫ t in cube (4 * Fintype.card X.Ψ), G (X.Zb u (Bv ω t) x) * ech ω χ t
  simp_rw [hpt]
  rw [integral_mul_const, hshift, mul_comm]

theorem Ich_bound_fixed (χ : X.Ψ → Fin 2 → Fin 2 → ℂ) (x : Frame X.Ψ r)
    {K M : ℝ} (hK : 0 ≤ K) (hb : ∀ t, ‖G (X.Zb u (Bv ω t) x)‖ * K ≤ M) :
    ‖Ich X u ω G χ x‖ * K ≤ M := by
  let F := fun t => G (X.Zb u (Bv ω t) x) * ech ω χ t
  have hv : volume (cube (4 * Fintype.card X.Ψ)) = 1 := by
    change volume (Set.univ.pi fun _ : Fin (4 * Fintype.card X.Ψ) => Set.Icc (0 : ℝ) 1) = 1
    rw [volume_pi, Measure.pi_pi]
    simp
  have hcomplex : ‖(K : ℂ)‖ = K := by simp [abs_of_nonneg hK]
  have he (t) : ‖ech ω χ t‖ = 1 := by simp [ech, Complex.norm_exp]
  have hbound := norm_setIntegral_le_of_norm_le_const (f := fun t => F t * (K : ℂ))
    (by rw [hv]; simp) (fun t _ => by
      simpa only [F, norm_mul, hcomplex, he, mul_one] using hb t)
  rw [integral_mul_const, norm_mul, hcomplex, Measure.real, hv, ENNReal.toReal_one, mul_one] at hbound
  exact hbound

theorem Ich_bound (hω : X.IsLZBasis g ω)
    (hunit : ∀ b, IsHermFam b → X.IsUnitaryC (X.zmat u b)) (la : Wt X.Ψ r)
    (χ : X.Ψ → Fin 2 → Fin 2 → ℂ) (x : Frame X.Ψ r) {M : ℝ}
    (hM : ∀ b, IsHermFam b → X.pnorm la G (X.Zb u b x) ≤ M) :
    ‖Ich X u ω G χ x‖ * fac X la x ≤ M := by
  have hBv := Bv_herm ω (herm_ω hω)
  have hfac : ∀ b, IsHermFam b → fac X la (X.Zb u b x) = fac X la x := by
    intro b hb
    have hd (τ i) : dmin X.Gm (X.Zb u b x) τ i = dmin X.Gm x τ i := by
      unfold dmin
      rw [FourierCoefficientMatrices.mat_Zb, X.gram_unitary x τ _ (hunit b hb τ)]
    simp [fac, hd]
  apply Ich_bound_fixed χ x (fac_nonneg X la x)
  intro t
  simpa only [FourierCoefficientMatrices.pnorm_eq, hfac _ (hBv t)] using hM _ (hBv t)

theorem Ich_coeff {χ : X.Ψ → Fin 2 → Fin 2 → ℂ} {m : Fin (4 * Fintype.card X.Ψ) → ℤ}
    (hm : ∀ j, 2 * X.pairR χ (ω j) = m j) {x : Frame X.Ψ r}
    (D : C(UnitAddTorus (Fin (4 * Fintype.card X.Ψ)), ℂ))
    (hD : ∀ t, D (I2.DimB.tproj t) = G (X.Zb u (Bv ω t) x)) :
    Ich X u ω G χ x = UnitAddTorus.mFourierCoeff D m := by
  have hp : ∀ j, pr χ (ω j) = (m j : ℝ) / 2 := fun j => by
    have := hm j
    change 2 * pr χ (ω j) = _ at this
    linarith
  rw [UnitAddTorus.mFourierCoeff_eq_integral _ m 0]
  unfold Ich
  rw [← setIntegral_congr_set (ubox_ae _)]
  have e : ∀ t : Fin (4 * Fintype.card X.Ψ) → ℝ, G (X.Zb u (Bv ω t) x) * ech ω χ t =
      UnitAddTorus.mFourier (-m) (fun i => (t i : UnitAddCircle)) •
        D (fun i => (t i : UnitAddCircle)) := by
    intro t
    rw [show (fun i => (t i : UnitAddCircle)) = I2.DimB.tproj t from rfl, hD, I2.DimB.mF_tproj,
      smul_eq_mul, mul_comm]
    congr 1
    simp [ech, pair_Bv, hp]
    congr 1
    push_cast
    simp [Pi.neg_apply, Int.cast_neg]
    rw [Finset.mul_sum, Finset.mul_sum]
    refine Finset.sum_congr rfl fun j _ => ?_
    ring
  simp_rw [e]
  rfl

end

end ReciprocityTheory.ChartRestriction.G.FD.FourierCubeIntegral
