import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.PositiveSpanMatrices
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.HermCOrthonormalCoordinates
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.FundamentalDomainExtension.UnipotentMoves.KatoClassHeckeEulerFactorRelation
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.LowBlock
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.LminorSubmatrixCastSucc

namespace UnipMove.GraphH

open ReciprocityTheory.ChartRestriction.G.FD ReciprocityTheory.ChartRestriction.G.FD.OrthonormalChartBounds NumberField Complex
open scoped ComplexConjugate Matrix

noncomputable section

def en {n : ℕ} (v : Fin n → ℂ) : ℝ := ‖(WithLp.toLp 2 v : EuclideanSpace ℂ (Fin n))‖

lemma en_nonneg {n : ℕ} (v : Fin n → ℂ) : 0 ≤ en v := norm_nonneg _

lemma en_eq_sqrt {n : ℕ} (v : Fin n → ℂ) : en v = Real.sqrt (nsq v) := by
  unfold en nsq
  simp [EuclideanSpace.norm_eq]

lemma en_sq {n : ℕ} (v : Fin n → ℂ) : en v ^ 2 = nsq v := by
  rw [en_eq_sqrt, Real.sq_sqrt (OrthonormalChartBounds.nsq_nonneg v)]

lemma en_add_le {n : ℕ} (u v : Fin n → ℂ) : en (u + v) ≤ en u + en v := norm_add_le (WithLp.toLp 2 u) (WithLp.toLp 2 v)

lemma en_sub_le {n : ℕ} (u v : Fin n → ℂ) : en (u - v) ≤ en u + en v := norm_sub_le (WithLp.toLp 2 u) (WithLp.toLp 2 v)

lemma eq_zero_of_en {n : ℕ} (d : Fin n → ℂ) (h : en d = 0) : d = 0 :=
  congrArg WithLp.ofLp (norm_eq_zero.mp h)

lemma en_pos {n : ℕ} {v : Fin n → ℂ} (hv : v ≠ 0) : 0 < en v := by
  exact lt_of_le_of_ne (en_nonneg v) (fun h => hv (eq_zero_of_en v h.symm))

lemma en_le_of_nsq {m n : ℕ} (u : Fin m → ℂ) (v : Fin n → ℂ) {c : ℝ} (hc : 0 ≤ c)
    (h : nsq u ≤ c ^ 2 * nsq v) : en u ≤ c * en v := by
  rw [en_eq_sqrt, en_eq_sqrt]
  calc Real.sqrt (nsq u) ≤ Real.sqrt (c ^ 2 * nsq v) := Real.sqrt_le_sqrt h
    _ = c * Real.sqrt (nsq v) := by rw [Real.sqrt_mul (sq_nonneg c), Real.sqrt_sq hc]

lemma opN_le {m n : ℕ} (A : Matrix (Fin m) (Fin n) ℂ) {c : ℝ} (hc : 0 ≤ c)
    (h : ∀ v, en (A *ᵥ v) ≤ c * en v) : Data.opN A ≤ c := by
  apply Real.sSup_le _ hc
  rintro t ⟨v, hv, rfl⟩
  simpa only [en_eq_sqrt, nsq] using (div_le_iff₀ (en_pos hv)).2 (h v)

section Blocks

variable {E : Type} [Field E] [NumberField E] [IsCMField E] {r : ℕ} (X : Data E r)

def top (w : Fin r → ℂ) : Fin X.p0 → ℂ := fun a => w (Fin.castLE X.p0_le a)

def bot (w : Fin r → ℂ) : Fin (r - X.p0) → ℂ := fun m => w (nI X m)

def ext (d : Fin X.p0 → ℂ) : Fin r → ℂ := fun i => if h : (i : ℕ) < X.p0 then d ⟨i, h⟩ else 0

def blkA (K : Matrix (Fin r) (Fin r) ℂ) : Matrix (Fin X.p0) (Fin X.p0) ℂ :=
  Matrix.of fun a b => K (Fin.castLE X.p0_le a) (Fin.castLE X.p0_le b)

def blkB (K : Matrix (Fin r) (Fin r) ℂ) : Matrix (Fin (r - X.p0)) (Fin X.p0) ℂ :=
  Matrix.of fun m b => K (nI X m) (Fin.castLE X.p0_le b)

lemma nsq_split (w : Fin r → ℂ) : nsq w = nsq (top X w) + nsq (bot X w) := by
  unfold nsq
  exact PositiveSpanMatrices.sum_split X.p0_le (fun j => ‖w j‖ ^ 2)

lemma en_top_le (w : Fin r → ℂ) : en (top X w) ≤ en w := by
  rw [en_eq_sqrt, en_eq_sqrt, nsq_split X w]
  exact Real.sqrt_le_sqrt (le_add_of_nonneg_right (OrthonormalChartBounds.nsq_nonneg (bot X w)))

lemma en_bot_le (w : Fin r → ℂ) : en (bot X w) ≤ en w := by
  rw [en_eq_sqrt, en_eq_sqrt, nsq_split X w]
  exact Real.sqrt_le_sqrt (le_add_of_nonneg_left (OrthonormalChartBounds.nsq_nonneg (top X w)))

lemma sum_mul_ext (f : Fin r → ℂ) (d : Fin X.p0 → ℂ) :
    ∑ j, f j * ext X d j = ∑ b, f (Fin.castLE X.p0_le b) * d b  := by
  rw [PositiveSpanMatrices.sum_split X.p0_le]
  simp [ext, PositiveSpanMatrices.kap]

lemma top_mulVec_ext (K : Matrix (Fin r) (Fin r) ℂ) (d : Fin X.p0 → ℂ) :
    top X (K *ᵥ ext X d) = blkA X K *ᵥ d := by
  funext a
  exact sum_mul_ext X (fun j => K (Fin.castLE X.p0_le a) j) d

lemma bot_mulVec_ext (K : Matrix (Fin r) (Fin r) ℂ) (d : Fin X.p0 → ℂ) :
    bot X (K *ᵥ ext X d) = blkB X K *ᵥ d := by
  funext m
  exact sum_mul_ext X (fun j => K (nI X m) j) d

lemma blkA_low (Z : X.Coord) (τ : X.Ψ) : blkA X (X.lowBlock Z τ) = 1 := by
  ext a b
  have ha := a.isLt
  have hb := b.isLt
  simp only [blkA, Data.lowBlock, Matrix.of_apply, Matrix.one_apply, Fin.ext_iff, Fin.coe_castLE]
  split_ifs <;> first | omega | rfl | simp

lemma blkB_low (Z : X.Coord) (τ : X.Ψ) : blkB X (X.lowBlock Z τ) = Matrix.of (Z τ) := by
  ext m b
  have hb := b.isLt
  have hne : X.p0 + (m : ℕ) ≠ (b : ℕ) := by omega
  simp [blkB, Data.lowBlock, nI, Fin.ext_iff, hne, hb]

end Blocks

section Frames

variable {E : Type} [Field E] [NumberField E] [IsCMField E] {r : ℕ} (X : Data E r)

lemma fin_split (i : Fin r) :
    (∃ a : Fin X.p0, i = Fin.castLE X.p0_le a) ∨ ∃ m : Fin (r - X.p0), i = nI X m := PositiveSpanMatrices.fin_cases_split X.p0_le i

lemma span_cols_eq {p : ℕ} (u w : Fin p → Fin r → ℂ) (A : Matrix (Fin p) (Fin p) ℂ)
    (hA : IsUnit A.det) (h : ∀ a, u a = ∑ b, A b a • w b) :
    Submodule.span ℂ (Set.range u) = Submodule.span ℂ (Set.range w) := PositiveSpanMatrices.span_eq_of_mat w u A hA.ne_zero h

lemma maj_ortho {x : Frame X.Ψ r} (ho : X.IsOrtho x) (τ : X.Ψ) (c : Fin r → ℂ) :
    X.maj x τ (mat x τ *ᵥ c) = nsq c := by
  have hlin : mat x τ *ᵥ c = ∑ j, c j • col (mat x τ) j := by
    rw [Matrix.mulVec_eq_sum]; simp [op_smul_eq_smul]; rfl
  rw [hlin, OrthonormalPerpBasis.ortho_majorant_coords X ho, Complex.re_sum]
  unfold nsq
  exact Finset.sum_congr rfl fun j _ => by simp [Complex.mul_conj, Complex.normSq_eq_norm_sq, ← Complex.ofReal_pow]


private lemma en_mulVec_le_opN_mul_en {m n : ℕ} (W : Matrix (Fin m) (Fin n) ℂ) (v : Fin n → ℂ) :
    en (W *ᵥ v) ≤ Data.opN W * en v :=
  en_le_of_nsq _ _ (opN_nonneg W) (nsq_mulVec_le_opN W v)

lemma graph_tau {x0 : Frame X.Ψ r} (hx0 : x0 ∈ X.dom) (ho : X.IsOrtho x0) (τ : X.Ψ)
    (nτ : Matrix (Fin r) (Fin r) ℂ) (Z1 : X.Coord) {η z : ℝ} (hη : 0 ≤ η) (hz : 0 ≤ z)
    (hZ1 : X.zN Z1 ≤ z) (hs : η * (1 + z) < 1)
    (hn : ∀ v, X.maj x0 τ ((nτ - 1) *ᵥ v) ≤ η ^ 2 * X.maj x0 τ v) :
    ∃ W : Matrix (Fin (r - X.p0)) (Fin X.p0) ℂ,
      Data.opN W ≤ (z + η * (1 + z)) / (1 - η * (1 + z)) ∧
      ∀ Z : X.Coord, Matrix.of (Z τ) = W →
        Submodule.span ℂ (Set.range fun a : Fin X.p0 =>
            col (nτ * (mat x0 τ * X.lowBlock Z1 τ)) (Fin.castLE X.p0_le a)) =
          Submodule.span ℂ (Set.range fun a : Fin X.p0 =>
            col (mat x0 τ * X.lowBlock Z τ) (Fin.castLE X.p0_le a)) := by
  have hMu : IsUnit (mat x0 τ).det := isUnit_iff_ne_zero.mpr (hx0 τ).1
  have hMMi : mat x0 τ * (mat x0 τ)⁻¹ = 1 := Matrix.mul_nonsing_inv _ hMu
  set N' := (mat x0 τ)⁻¹ * nτ * mat x0 τ with hN'
  have hMN : mat x0 τ * N' = nτ * mat x0 τ := by
    rw [hN', ← mul_assoc, ← mul_assoc, hMMi, one_mul]
  have hN1 : ∀ c, en ((N' - 1) *ᵥ c) ≤ η * en c := by
    intro c
    apply en_le_of_nsq _ _ hη
    have hMN1 : mat x0 τ * (N' - 1) = (nτ - 1) * mat x0 τ := by
      rw [mul_sub, mul_one, hMN, sub_mul, one_mul]
    rw [← maj_ortho X ho τ ((N' - 1) *ᵥ c), ← maj_ortho X ho τ c, Matrix.mulVec_mulVec, hMN1,
      ← Matrix.mulVec_mulVec]
    exact hn (mat x0 τ *ᵥ c)
  have hZτ : Data.opN (Matrix.of (Z1 τ)) ≤ z := (opN_le_zN X Z1 τ).trans hZ1
  have hsplit : ∀ w : Fin r → ℂ, en w ≤ en (top X w) + en (bot X w) := by
    intro w
    have squares := nsq_split X w
    rw [← en_sq, ← en_sq, ← en_sq] at squares
    nlinarith [en_nonneg w, en_nonneg (top X w), en_nonneg (bot X w),
      mul_nonneg (en_nonneg (top X w)) (en_nonneg (bot X w))]
  set K : Matrix (Fin r) (Fin r) ℂ := N' * X.lowBlock Z1 τ with hK
  have hyt : ∀ d, top X (X.lowBlock Z1 τ *ᵥ ext X d) = d := fun d => by
    rw [top_mulVec_ext, blkA_low, Matrix.one_mulVec]
  have hyb : ∀ d, bot X (X.lowBlock Z1 τ *ᵥ ext X d) = Matrix.of (Z1 τ) *ᵥ d := fun d => by
    rw [bot_mulVec_ext, blkB_low]
  have hzblock (d) : en (Matrix.of (Z1 τ) *ᵥ d) ≤ z * en d :=
    (en_mulVec_le_opN_mul_en _ _).trans (mul_le_mul_of_nonneg_right hZτ (en_nonneg d))
  let base (d) := X.lowBlock Z1 τ *ᵥ ext X d
  let error (d) := (N' - 1) *ᵥ base d
  have hed (d) : en (error d) ≤ η * (1 + z) * en d := by
    have h := hsplit (base d)
    change en (base d) ≤ en (top X (X.lowBlock Z1 τ *ᵥ ext X d)) + en (bot X (X.lowBlock Z1 τ *ᵥ ext X d)) at h
    rw [hyt, hyb] at h
    have b : en (base d) ≤ (1 + z) * en d := by linarith [hzblock d]
    simpa [mul_assoc] using (hN1 (base d)).trans (mul_le_mul_of_nonneg_left b hη)
  have hKd (d) : K *ᵥ ext X d = base d + error d := by
    simp only [hK, base, error, ← Matrix.mulVec_mulVec, Matrix.sub_mulVec, Matrix.one_mulVec]
    abel
  have hAe (d) : blkA X K *ᵥ d = d + top X (error d) := by
    rw [← top_mulVec_ext, hKd]
    change top X (X.lowBlock Z1 τ *ᵥ ext X d) + _ = _
    rw [hyt]
    rfl
  have hBe (d) : blkB X K *ᵥ d = Matrix.of (Z1 τ) *ᵥ d + bot X (error d) := by
    rw [← bot_mulVec_ext, hKd]
    change bot X (X.lowBlock Z1 τ *ᵥ ext X d) + _ = _
    rw [hyb]
    rfl
  have hs0 : 0 ≤ η * (1 + z) := mul_nonneg hη (by linarith)
  have hAl (d) : (1 - η * (1 + z)) * en d ≤ en (blkA X K *ᵥ d) := by
    have h := en_sub_le (blkA X K *ᵥ d) (top X (error d))
    rw [hAe, add_sub_cancel_right] at h
    rw [hAe]
    nlinarith [(en_top_le X (error d)).trans (hed d)]
  have hBu (d) : en (blkB X K *ᵥ d) ≤ (z + η * (1 + z)) * en d := by
    rw [hBe]
    exact (en_add_le _ _).trans (by nlinarith [hzblock d, (en_bot_le X (error d)).trans (hed d)])
  have h1s : 0 < 1 - η * (1 + z) := by linarith
  have hAu : IsUnit (blkA X K).det := isUnit_iff_ne_zero.mpr fun h0 => by
    obtain ⟨d, hd, hAd⟩ := Matrix.exists_mulVec_eq_zero_iff.mpr h0
    have h1 := hAl d
    rw [hAd] at h1
    have hzv : en (0 : Fin X.p0 → ℂ) = 0 := by simp [en_eq_sqrt, nsq]
    nlinarith [mul_pos h1s (en_pos hd)]
  refine ⟨blkB X K * (blkA X K)⁻¹, ?_, fun Z hZW => ?_⟩
  · apply opN_le _ (div_nonneg (by linarith) h1s.le)
    intro v
    have hAd : blkA X K *ᵥ ((blkA X K)⁻¹ *ᵥ v) = v := by
      rw [Matrix.mulVec_mulVec, Matrix.mul_nonsing_inv _ hAu, Matrix.one_mulVec]
    rw [← Matrix.mulVec_mulVec]
    have hB := hBu ((blkA X K)⁻¹ *ᵥ v)
    have hA := hAl ((blkA X K)⁻¹ *ᵥ v)
    rw [hAd] at hA
    rw [div_mul_eq_mul_div, le_div_iff₀ h1s]
    have hzs : 0 ≤ z + η * (1 + z) := by linarith
    nlinarith [mul_le_mul_of_nonneg_left hA hzs, mul_le_mul_of_nonneg_left hB h1s.le]
  · have hMK : nτ * (mat x0 τ * X.lowBlock Z1 τ) = mat x0 τ * K := by
      rw [hK, ← mul_assoc (mat x0 τ), hMN, mul_assoc]
    have hcol : ∀ (i : Fin r) (a : Fin X.p0), K i (Fin.castLE X.p0_le a) =
        ∑ b, X.lowBlock Z τ i (Fin.castLE X.p0_le b) * blkA X K b a := by
      intro i a
      rcases fin_split X i with ⟨i', rfl⟩ | ⟨m, rfl⟩
      · have h1 : (blkA X (X.lowBlock Z τ) * blkA X K) i' a = blkA X K i' a := by
          rw [blkA_low, Matrix.one_mul]
        rw [Matrix.mul_apply] at h1
        exact h1.symm
      · have h2 : (blkB X (X.lowBlock Z τ) * blkA X K) m a = blkB X K m a := by
          rw [blkB_low, hZW, Matrix.mul_assoc, Matrix.nonsing_inv_mul _ hAu, Matrix.mul_one]
        rw [Matrix.mul_apply] at h2
        exact h2.symm
    refine span_cols_eq _ _ (blkA X K) hAu (fun a => ?_)
    have hc : col K (Fin.castLE X.p0_le a) =
        ∑ b, blkA X K b a • col (X.lowBlock Z τ) (Fin.castLE X.p0_le b) := by
      funext i
      simpa [Finset.sum_apply, col, mul_comm] using hcol i a
    rw [hMK, Data.col_mul, hc, Matrix.mulVec_sum]
    simp [Data.col_mul, Matrix.mulVec_smul]

end Frames

end

end UnipMove.GraphH

namespace UnipMove

open ReciprocityTheory.ChartRestriction.G.FD NumberField

theorem sGraph {E : Type} [Field E] [NumberField E] [IsCMField E] : SGraph E := by
  unfold SGraph
  intro r X x0 hx0 ho n Z1 η z hη hz hZ1 hs hn
  have hg := fun τ => GraphH.graph_tau X hx0 ho τ (n τ) Z1 hη hz hZ1 hs (hn τ)
  choose W hW1 hW2 using hg
  refine ⟨(fun τ => W τ : X.Coord), ?_, ?_⟩
  · intro τ
    exact hW2 τ (fun τ => W τ) rfl
  · unfold Data.zN
    apply Real.iSup_le
    · intro τ
      exact hW1 τ
    · have h1 : 0 ≤ η * (1 + z) := mul_nonneg hη (by linarith)
      apply div_nonneg
      · linarith
      · linarith

end UnipMove
