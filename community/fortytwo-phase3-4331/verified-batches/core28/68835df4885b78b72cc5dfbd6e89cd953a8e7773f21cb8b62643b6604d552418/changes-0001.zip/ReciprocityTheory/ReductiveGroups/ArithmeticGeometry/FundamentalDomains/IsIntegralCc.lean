import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.Signature

namespace ReciprocityTheory.ChartRestriction.G.FD

open NumberField Complex
open scoped ComplexConjugate

variable {E : Type} [Field E] [NumberField E] [IsCMField E]

lemma cc_cc (x : E) : cc (cc x) = x := by
  simp [cc]




lemma cc_zero : cc (0 : E) = 0 := by
  simp [cc]

lemma emb_cc (τ : E →+* ℂ) (x : E) : τ (cc x) = conj (τ x) := by
  rw [cc]
  exact IsCMField.complexEmbedding_complexConj E τ x


lemma isIntegral_cc {x : E} (hx : IsIntegral ℤ x) : IsIntegral ℤ (cc x) := by
  have := hx.map (IsCMField.complexConj E).toAlgHom.toRatAlgHom
  exact this

end ReciprocityTheory.ChartRestriction.G.FD
