import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.MajPos

namespace ReciprocityTheory.ChartRestriction.G.FD

open NumberField Complex
open scoped ComplexConjugate Matrix

variable {E : Type} [Field E] [NumberField E] [IsCMField E]

noncomputable section

section herm

variable {r : ℕ} (τ : E →+* ℂ) (G : Matrix (Fin r) (Fin r) E)

alias hC_sub_right := _root_.ReciprocityTheory.ChartRestriction.G.FD.hermC_sub_right

alias hC_zero_left := _root_.ReciprocityTheory.ChartRestriction.G.FD.hermC_zero_left

def hL (y : Fin r → ℂ) : (Fin r → ℂ) →ₗ[ℂ] ℂ := GramDeterminantReal.hL τ G y

def rz (φ : (Fin r → ℂ) →ₗ[ℂ] ℂ) : Fin r → ℂ :=
  fun b => conj (((G.map τ)⁻¹).mulVec (fun a => φ (fun j => if a = j then 1 else 0)) b)

lemma rz_spec (hG : (G.map τ).det ≠ 0) (φ : (Fin r → ℂ) →ₗ[ℂ] ℂ) (v : Fin r → ℂ) :
    hermC τ G v (rz τ G φ) = φ v := by
  let M := G.map τ
  let y (a : Fin r) := φ (fun j => if a = j then 1 else 0)
  have hy : M *ᵥ (M⁻¹ *ᵥ y) = y := by
    rw [Matrix.mulVec_mulVec, Matrix.mul_nonsing_inv _ (isUnit_iff_ne_zero.mpr hG), Matrix.one_mulVec]
  simp only [hermC, rz, Complex.conj_conj, mul_assoc, ← Finset.mul_sum]
  change ∑ a, v a * (M *ᵥ (M⁻¹ *ᵥ y)) a = φ v
  rw [hy, LinearMap.pi_apply_eq_sum_univ φ v]
  rfl

lemma map_det_ne (hG : G.det ≠ 0) : (G.map τ).det ≠ 0 := by
  rw [← RingHom.mapMatrix_apply, ← RingHom.map_det]
  exact (map_ne_zero τ).mpr hG

end herm

namespace Data

variable {r : ℕ} (X : Data E r)


private lemma hermC_Gm_eq_conj_swap (τ : X.Ψ) (u w : Fin r → ℂ) :
    hermC τ.1 X.Gm u w = conj (hermC τ.1 X.Gm w u) := (hermC_conj τ.1 X.Gm_herm w u).symm


def Jp (x : Frame X.Ψ r) (τ : X.Ψ) (v : Fin r → ℂ) : Fin r → ℂ := (2 : ℂ) • X.ppos x τ v - v

lemma Jp_add (x : Frame X.Ψ r) (τ : X.Ψ) (u v : Fin r → ℂ) :
    X.Jp x τ (u + v) = X.Jp x τ u + X.Jp x τ v := X.jp_add x τ u v

lemma Jp_smul (x : Frame X.Ψ r) (τ : X.Ψ) (c : ℂ) (v : Fin r → ℂ) :
    X.Jp x τ (c • v) = c • X.Jp x τ v := X.jp_smul x τ c v

lemma Jp_Jp {x : Frame X.Ψ r} (hx : x ∈ X.dom) (τ : X.Ψ) (v : Fin r → ℂ) :
    X.Jp x τ (X.Jp x τ v) = v := X.jp_jp hx τ v

lemma Jp_adj {x : Frame X.Ψ r} (hx : x ∈ X.dom) (τ : X.Ψ) (u w : Fin r → ℂ) :
    hermC τ.1 X.Gm (X.Jp x τ u) w = hermC τ.1 X.Gm u (X.Jp x τ w) := X.hermC_jp_left hx τ u w

section perTau

variable (x : Frame X.Ψ r) (τ : X.Ψ) (e : Fin r → ℂ) (δ : (Fin r → ℂ) →ₗ[ℂ] ℂ)

def d2q : ℂ := X.Hf x τ e e

def d2b : (Fin r → ℂ) →ₗ[ℂ] ℂ := (X.d2q x τ e)⁻¹ • hL τ.1 X.Gm e

def d2a : (Fin r → ℂ) →ₗ[ℂ] ℂ := (X.d2q x τ e)⁻¹ • hL τ.1 X.Gm (X.Jp x τ e)

def d2pi : (Fin r → ℂ) →ₗ[ℂ] (Fin r → ℂ) :=
  LinearMap.id - (X.d2a x τ e).smulRight e - (X.d2b x τ e).smulRight (X.Jp x τ e)

def d2z : Fin r → ℂ := rz τ.1 X.Gm ((X.d2q x τ e) • (δ ∘ₗ X.d2pi x τ e))

def d2nL : (Fin r → ℂ) →ₗ[ℂ] (Fin r → ℂ) :=
  LinearMap.id + (δ ∘ₗ X.d2pi x τ e - (δ (X.d2z x τ e δ) / 2) • X.d2b x τ e).smulRight e -
    (X.d2b x τ e).smulRight (X.d2z x τ e δ)

def d2n : Matrix (Fin r) (Fin r) ℂ := LinearMap.toMatrix' (X.d2nL x τ e δ)

lemma hyperbolic_coeff_b_apply (v : Fin r → ℂ) :
    X.d2b x τ e v = (X.d2q x τ e)⁻¹ * hermC τ.1 X.Gm v e := rfl

lemma hyperbolic_coeff_a_apply (v : Fin r → ℂ) :
    X.d2a x τ e v = (X.d2q x τ e)⁻¹ * hermC τ.1 X.Gm v (X.Jp x τ e) := rfl

lemma hyperbolic_projection_apply (v : Fin r → ℂ) :
    X.d2pi x τ e v = v - X.d2a x τ e v • e - X.d2b x τ e v • X.Jp x τ e := rfl

lemma unipotent_mulVec_formula (v : Fin r → ℂ) :
    Matrix.mulVec (X.d2n x τ e δ) v = v + (δ (X.d2pi x τ e v) -
      δ (X.d2z x τ e δ) / 2 * X.d2b x τ e v) • e - X.d2b x τ e v • X.d2z x τ e δ := by
  simp [d2n, LinearMap.toMatrix'_mulVec]
  rfl

variable {x τ e}

lemma hsym (u w : Fin r → ℂ) : hermC τ.1 X.Gm u w = conj (hermC τ.1 X.Gm w u) := by
  apply hermC_Gm_eq_conj_swap <;> assumption

lemma hermitian_pairing_Je_e : hermC τ.1 X.Gm (X.Jp x τ e) e = X.d2q x τ e := rfl

lemma hermitian_pairing_e_Je (hx : x ∈ X.dom) : hermC τ.1 X.Gm e (X.Jp x τ e) = X.d2q x τ e := (X.Jp_adj hx τ e e).symm.trans X.hermitian_pairing_Je_e

lemma hermitian_pairing_Je_Je_zero (hx : x ∈ X.dom) (he : hermC τ.1 X.Gm e e = 0) :
    hermC τ.1 X.Gm (X.Jp x τ e) (X.Jp x τ e) = 0 := by
  rw [X.Jp_adj hx τ e (X.Jp x τ e), X.Jp_Jp hx τ e, he]

variable (hx : x ∈ X.dom) (he : hermC τ.1 X.Gm e e = 0) (hq : X.d2q x τ e ≠ 0)
include hx he hq

lemma hyperbolic_projection_e : X.d2pi x τ e e = 0 := by
  rw [hyperbolic_projection_apply, hyperbolic_coeff_a_apply, hyperbolic_coeff_b_apply, X.hermitian_pairing_e_Je hx, he, inv_mul_cancel₀ hq]
  simp

lemma hyperbolic_projection_Je : X.d2pi x τ e (X.Jp x τ e) = 0 := by
  rw [hyperbolic_projection_apply, hyperbolic_coeff_a_apply, hyperbolic_coeff_b_apply, X.hermitian_pairing_Je_Je_zero hx he, X.hermitian_pairing_Je_e, inv_mul_cancel₀ hq]
  simp

lemma hyperbolic_projection_of_perp {u : Fin r → ℂ} (hu1 : hermC τ.1 X.Gm u e = 0)
    (hu2 : hermC τ.1 X.Gm u (X.Jp x τ e) = 0) : X.d2pi x τ e u = u := by
  rw [hyperbolic_projection_apply, hyperbolic_coeff_a_apply, hyperbolic_coeff_b_apply, hu1, hu2]
  simp

lemma hyperbolic_projection_perp_e (v : Fin r → ℂ) : hermC τ.1 X.Gm (X.d2pi x τ e v) e = 0 := by
  rw [hyperbolic_projection_apply, hermC_sub_left, hermC_sub_left, hC_smul_left, hC_smul_left, he, X.hermitian_pairing_Je_e,
    hyperbolic_coeff_b_apply, mul_zero, sub_zero, inv_mul_eq_div, div_mul_cancel₀ _ hq, sub_self]

lemma hyperbolic_projection_perp_Je (v : Fin r → ℂ) :
    hermC τ.1 X.Gm (X.d2pi x τ e v) (X.Jp x τ e) = 0 := by
  rw [hyperbolic_projection_apply, hermC_sub_left, hermC_sub_left, hC_smul_left, hC_smul_left, X.hermitian_pairing_e_Je hx,
    X.hermitian_pairing_Je_Je_zero hx he, hyperbolic_coeff_a_apply, mul_zero, sub_zero, inv_mul_eq_div, div_mul_cancel₀ _ hq, sub_self]

lemma unipotent_shift_spec (v : Fin r → ℂ) :
    hermC τ.1 X.Gm v (X.d2z x τ e δ) = X.d2q x τ e * δ (X.d2pi x τ e v) := by
  simp [d2z]
  rw [rz_spec _ _ (map_det_ne _ _ X.Gm_det)]
  simp [LinearMap.smul_apply, LinearMap.comp_apply]

lemma unipotent_shift_orthogonal_e : hermC τ.1 X.Gm (X.d2z x τ e δ) e = 0 := by
  rw [X.hsym, X.unipotent_shift_spec δ hx he hq, X.hyperbolic_projection_e hx he hq]
  simp

lemma unipotent_shift_orthogonal_Je : hermC τ.1 X.Gm (X.d2z x τ e δ) (X.Jp x τ e) = 0 := by
  rw [X.hsym, X.unipotent_shift_spec δ hx he hq, X.hyperbolic_projection_Je hx he hq]
  simp

lemma d2pi_d2z_eq_d2z : X.d2pi x τ e (X.d2z x τ e δ) = X.d2z x τ e δ := X.hyperbolic_projection_of_perp hx he hq (X.unipotent_shift_orthogonal_e δ hx he hq) (X.unipotent_shift_orthogonal_Je δ hx he hq)

lemma unipotent_shift_self_pairing : hermC τ.1 X.Gm (X.d2z x τ e δ) (X.d2z x τ e δ) =
    X.d2q x τ e * δ (X.d2z x τ e δ) := by
  rw [X.unipotent_shift_spec δ hx he hq, X.d2pi_d2z_eq_d2z δ hx he hq]

lemma unipotent_fixes_e : Matrix.mulVec (X.d2n x τ e δ) e = e := by
  rw [unipotent_mulVec_formula, X.hyperbolic_projection_e hx he hq, hyperbolic_coeff_b_apply, he]
  simp

lemma unipotent_on_orthogonal_e {u : Fin r → ℂ} (hu1 : hermC τ.1 X.Gm u e = 0) :
    Matrix.mulVec (X.d2n x τ e δ) u = u + δ (X.d2pi x τ e u) • e := by
  rw [unipotent_mulVec_formula, hyperbolic_coeff_b_apply, hu1]
  simp

lemma unipotent_on_hyperbolic_complement {u : Fin r → ℂ} (hu1 : hermC τ.1 X.Gm u e = 0)
    (hu2 : hermC τ.1 X.Gm u (X.Jp x τ e) = 0) :
    Matrix.mulVec (X.d2n x τ e δ) u = u + δ u • e := by
  rw [X.unipotent_on_orthogonal_e δ hx he hq hu1, X.hyperbolic_projection_of_perp hx he hq hu1 hu2]

lemma unipotent_transform_unitary (hqr : conj (X.d2q x τ e) = X.d2q x τ e) (u w : Fin r → ℂ) :
    hermC τ.1 X.Gm (Matrix.mulVec (X.d2n x τ e δ) u) (Matrix.mulVec (X.d2n x τ e δ) w) =
      hermC τ.1 X.Gm u w := by
  have hb : ∀ v, hermC τ.1 X.Gm v e = X.d2q x τ e * X.d2b x τ e v := by
    intro v
    rw [hyperbolic_coeff_b_apply, ← mul_assoc, mul_inv_cancel₀ hq, one_mul]
  have hz : ∀ v, hermC τ.1 X.Gm v (X.d2z x τ e δ) = X.d2q x τ e * δ (X.d2pi x τ e v) :=
    X.unipotent_shift_spec δ hx he hq
  have hze : hermC τ.1 X.Gm (X.d2z x τ e δ) e = 0 := X.unipotent_shift_orthogonal_e δ hx he hq
  have hez : hermC τ.1 X.Gm e (X.d2z x τ e δ) = 0 := by
    rw [X.hsym, hze, map_zero]
  have hew : ∀ v, hermC τ.1 X.Gm e v = X.d2q x τ e * conj (X.d2b x τ e v) := by
    intro v
    rw [X.hsym, hb, map_mul, hqr]
  have hzw : ∀ v, hermC τ.1 X.Gm (X.d2z x τ e δ) v =
      X.d2q x τ e * conj (δ (X.d2pi x τ e v)) := by
    intro v
    rw [X.hsym, hz, map_mul, hqr]
  have hzz := X.unipotent_shift_self_pairing δ hx he hq
  have hδ : conj (δ (X.d2z x τ e δ)) = δ (X.d2z x τ e δ) := by
    have h1 := X.hsym (τ := τ) (X.d2z x τ e δ) (X.d2z x τ e δ)
    rw [hzz, map_mul, hqr] at h1
    exact (mul_left_cancel₀ hq h1).symm
  rw [unipotent_mulVec_formula, unipotent_mulVec_formula]
  simp only [hC_add_left, hermC_sub_left, hC_smul_left, hermC_add_right, hC_sub_right,
    hermC_smul_right]
  simp only [he, hze, hez, hzz]
  simp only [hb, hz, hew, hzw]
  simp only [map_sub, map_mul, map_div₀, hδ, map_ofNat]
  ring

end perTau

end Data

end

end ReciprocityTheory.ChartRestriction.G.FD
