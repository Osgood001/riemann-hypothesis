import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.FourierCoefficientMatrices

namespace ReciprocityTheory.ChartRestriction.G.FD.FourierCoefficientLattice

open NumberField Complex ReciprocityTheory.ChartRestriction.G.FD ReciprocityTheory.ChartRestriction.G.FD.FourierCoefficientMatrices ReciprocityTheory.ChartRestriction.G.FD.EmbeddingHermitianPairs
open scoped ComplexConjugate

noncomputable section

section Slot

variable {ι : Type} [Fintype ι]

def intersection_update_fsHerm_neg_one (i0 k0 : Fin 2) : (ι → ℝ) →ₗ[ℝ] (ι → Fin 2 → Fin 2 → ℝ) :=
  LinearMap.pi fun τ => LinearMap.pi fun i => LinearMap.pi fun k =>
    if i = i0 ∧ k = k0 then LinearMap.proj τ else 0

lemma position_apply (i0 k0 : Fin 2) (p : ι → ℝ) (τ : ι) (i k : Fin 2) :
    intersection_update_fsHerm_neg_one i0 k0 p τ i k = if i = i0 ∧ k = k0 then p τ else 0 := by
  by_cases h : i = i0 ∧ k = k0 <;> simp [intersection_update_fsHerm_neg_one, h]

lemma sum_position (y : ι → Fin 2 → Fin 2 → ℝ) :
    y = ∑ i0, ∑ k0, intersection_update_fsHerm_neg_one i0 k0 (fun τ => y τ i0 k0) := by
  funext τ i k
  simp [Finset.sum_apply, Fin.sum_univ_two]
  fin_cases i <;> fin_cases k <;> simp [position_apply]


end Slot

variable {E : Type} [Field E] [NumberField E] [IsCMField E] {r : ℕ} (X : Data E r) (g : ℕ)

def cE : E := ((g * dEnat E : ℕ) : E) / 2

def cr : ℝ := ((g * dEnat E : ℕ) : ℝ) / 2

lemma emb_cE (τ : E →+* ℂ) : τ (cE (E := E) g) = (cr (E := E) g : ℂ) := by
  simp only [cE, cr, map_div₀, map_natCast, map_ofNat]
  try push_cast
  try ring

lemma cr_ge (hg : 0 < g) : (1 : ℝ) / 2 ≤ cr (E := E) g := by
  apply div_le_div_of_nonneg_right _ (by norm_num)
  exact_mod_cast Nat.mul_pos hg (Int.natAbs_pos.mpr (NumberField.discr_ne_zero E))

lemma cr_pos (hg : 0 < g) : 0 < cr (E := E) g :=
  lt_of_lt_of_le (by norm_num) (cr_ge (E := E) g hg)

lemma cc_cE : cc (cE (E := E) g) = cE g := by
  simp only [cc, cE, map_div₀, map_natCast, map_ofNat]

lemma embH_herm {β : Matrix (Fin 2) (Fin 2) E} (hβ : ∀ i k, cc (β i k) = β k i) :
    IsHermFam (X.embH β) := by
  intro τ i k
  show τ.1 (β k i) = conj (τ.1 (β i k))
  rw [← hβ i k]
  exact NumberField.IsCMField.complexEmbedding_complexConj E τ.1 (β i k)

lemma herm_of_LZ {b : X.Ψ → Fin 2 → Fin 2 → ℂ} (hb : b ∈ X.LZ g) : IsHermFam b := by
  obtain ⟨β, hβ, -, rfl⟩ := hb
  exact embH_herm X hβ

lemma mem_LZ_of (Γ : Matrix (Fin 2) (Fin 2) E) (hh : ∀ i k, cc (Γ i k) = Γ k i)
    (hi : ∀ i k, IsIntegral ℤ (Γ i k)) : X.embH (fun i k => cE g * Γ i k) ∈ X.LZ g := by
  refine ⟨fun i k => cE g * Γ i k, fun i k => ?_, fun i k => ⟨Γ i k, hi i k, rfl⟩, rfl⟩
  show cc (cE g * Γ i k) = cE g * Γ k i
  rw [show cc (cE g * Γ i k) = cc (cE g) * cc (Γ i k) from map_mul _ _ _, cc_cE, hh]

def LZsub : AddSubgroup (X.Ψ → Fin 2 → Fin 2 → ℂ) where
  carrier := X.LZ g
  add_mem' := by
    rintro _ _ ⟨β, hβ, hγ, rfl⟩ ⟨β', hβ', hγ', rfl⟩
    refine ⟨β + β', fun i k => ?_, fun i k => ?_, ?_⟩
    · show cc (β i k + β' i k) = β k i + β' k i
      rw [show cc (β i k + β' i k) = cc (β i k) + cc (β' i k) from map_add _ _ _, hβ, hβ']
    · obtain ⟨γ, hγi, e⟩ := hγ i k
      obtain ⟨γ', hγi', e'⟩ := hγ' i k
      exact ⟨γ + γ', hγi.add hγi', by simp only [Matrix.add_apply, e, e']; ring⟩
    · funext τ i k; simp [Data.embH]
  zero_mem' := ⟨0, fun i k => by simp [cc], fun i k => ⟨0, isIntegral_zero, by simp⟩,
    by funext τ i k; simp [Data.embH]⟩
  neg_mem' := by
    rintro _ ⟨β, hβ, hγ, rfl⟩
    refine ⟨-β, fun i k => ?_, fun i k => ?_, ?_⟩
    · show cc (-β i k) = -β k i
      rw [show cc (-β i k) = -cc (β i k) from map_neg _ _, hβ]
    · obtain ⟨γ, hγi, e⟩ := hγ i k
      exact ⟨-γ, hγi.neg, by simp only [Matrix.neg_apply, e]; ring⟩
    · funext τ i k; simp [Data.embH]

lemma LZ_sum {N : ℕ} {ω : Fin N → X.Ψ → Fin 2 → Fin 2 → ℂ} (hω : ∀ j, ω j ∈ X.LZ g)
    (n : Fin N → ℤ) : ∑ j, (n j : ℂ) • ω j ∈ X.LZ g := by
  simp only [Int.cast_smul_eq_zsmul]
  exact (LZsub X g).sum_mem fun j _ => (LZsub X g).zsmul_mem (hω j) (n j)

def Lc : Submodule ℤ (X.Ψ → Fin 2 → Fin 2 → ℝ) :=
  ((LZsub X g).map (kapL : (X.Ψ → Fin 2 → Fin 2 → ℂ) →ₗ[ℝ] _).toAddMonoidHom).toIntSubmodule

lemma mem_Lc {y : X.Ψ → Fin 2 → Fin 2 → ℝ} : y ∈ Lc X g ↔ ∃ b ∈ X.LZ g, kap b = y := by
  exact Iff.rfl

lemma finite_small (hg : 0 < g) : {y | y ∈ Lc X g ∧ ‖y‖ < 1}.Finite := by
  have hS := NumberField.Embeddings.finite_of_norm_le E ℂ 4
  have hpi : (Set.pi Set.univ fun _ : Fin 2 => Set.pi Set.univ fun _ : Fin 2 =>
      {x : E | IsIntegral ℤ x ∧ ∀ φ : E →+* ℂ, ‖φ x‖ ≤ 4}).Finite :=
    Set.Finite.pi fun _ => Set.Finite.pi fun _ => hS
  refine (hpi.image fun γ => kap (X.embH fun i k => cE g * γ i k)).subset ?_
  rintro y ⟨hy, hn⟩
  obtain ⟨b, ⟨β, hβ, hγ, rfl⟩, rfl⟩ := (mem_Lc X g).mp hy
  choose γ hγi hγe using hγ
  have hcr := cr_ge (E := E) g hg
  have hcr0 := cr_pos (E := E) g hg
  have hb : IsHermFam (X.embH β) := embH_herm X hβ
  have hk : ∀ (τ : X.Ψ) (i k : Fin 2), |kap (X.embH β) τ i k| < 1 := fun τ i k => by
    have h := (norm_le_pi_norm (kap (X.embH β) τ i) k).trans
      ((norm_le_pi_norm (kap (X.embH β) τ) i).trans (norm_le_pi_norm (kap (X.embH β)) τ))
    rw [Real.norm_eq_abs] at h
    linarith
  have hre : ∀ (τ : X.Ψ) (i k : Fin 2), |(τ.1 (β i k)).re| < 1 ∧ |(τ.1 (β i k)).im| < 1 := by
    intro τ
    intro i k
    change |(X.embH β τ i k).re| < 1 ∧ |(X.embH β τ i k).im| < 1
    rw [← th_kap hb]
    unfold th
    split_ifs <;> simp [Complex.mul_re, Complex.mul_im, hk]
  have hΨ : ∀ (τ : X.Ψ) (i k : Fin 2), ‖τ.1 (γ i k)‖ ≤ 4 := by
    intro τ i k
    have h2 : ‖τ.1 (β i k)‖ < 2 := by
      have hn1 := Complex.norm_le_abs_re_add_abs_im (τ.1 (β i k))
      have hr := hre τ i k
      linarith [hr.1, hr.2]
    change ‖τ.1 (β i k)‖ < 2 at h2
    have he : β i k = cE (E := E) g * γ i k := hγe i k
    rw [he, map_mul, emb_cE, norm_mul, Complex.norm_real, Real.norm_of_nonneg hcr0.le] at h2
    nlinarith [norm_nonneg (τ.1 (γ i k))]
  refine ⟨γ, ?_, ?_⟩
  · simp only [Set.mem_pi, Set.mem_univ, true_implies, forall_const, Set.mem_setOf_eq]
    intro i k
    refine ⟨hγi i k, fun φ => ?_⟩
    by_cases hφ : φ ∈ X.Ψ
    · exact hΨ ⟨φ, hφ⟩ i k
    · have hc : ComplexEmbedding.conjugate φ ∈ X.Ψ := by
        by_contra h
        exact hφ ((X.cmType φ).mpr h)
      have := hΨ ⟨_, hc⟩ i k
      simpa [NumberField.ComplexEmbedding.conjugate_coe_eq] using this
  · have hfun : (fun i k => cE (E := E) g * γ i k) = β := by
      funext i k
      exact (hγe i k).symm
    exact congrArg (fun β' => kap (X.embH β')) hfun

instance Lc_discrete [Fact (0 < g)] : DiscreteTopology (Lc X g) := by

  rw [discreteTopology_iff_isOpen_singleton_zero]
  apply isOpen_singleton_of_finite_mem_nhds (0 : Lc X g) (Metric.ball_mem_nhds _ zero_lt_one)
  apply ((finite_small X g Fact.out).preimage Subtype.val_injective.injOn).subset
  intro q hq
  exact ⟨q.2, by simpa [Metric.mem_ball] using hq⟩

lemma span_fixed_integral_real_parts : Submodule.span ℝ {p : X.Ψ → ℝ | ∃ a : E, cc a = a ∧ IsIntegral ℤ a ∧
    p = fun τ => (τ.1 a).re} = ⊤ := by
  apply top_unique
  rw [← RealEmbeddingCharacters.periods_span X (0 : Wt X.Ψ r)]
  refine Submodule.span_le.mpr ?_
  intro p hp
  obtain ⟨a, ha, hi, rfl⟩ := (RealEmbeddingCharacters.mem_periods_iff X (0 : Wt X.Ψ r) p).mp hp
  exact Submodule.smul_mem _ ((X.m * X.chiOrd (0 : Wt X.Ψ r) : ℕ) : ℝ)
    (Submodule.subset_span ⟨a, ha, hi, rfl⟩)

lemma span_gen (T : (X.Ψ → ℝ) →ₗ[ℝ] (X.Ψ → Fin 2 → Fin 2 → ℝ))
    (hT : ∀ a : E, cc a = a → IsIntegral ℤ a →
      T (fun τ => (τ.1 a).re) ∈ Submodule.span ℝ (Lc X g : Set (X.Ψ → Fin 2 → Fin 2 → ℝ)))
    (p : X.Ψ → ℝ) : T p ∈ Submodule.span ℝ (Lc X g : Set (X.Ψ → Fin 2 → Fin 2 → ℝ)) := by
  have hp : p ∈ Submodule.span ℝ {p : X.Ψ → ℝ | ∃ a : E, cc a = a ∧ IsIntegral ℤ a ∧
      p = fun τ => (τ.1 a).re} := by
    rw [span_fixed_integral_real_parts X]
    exact Submodule.mem_top
  have hle : Submodule.span ℝ {p : X.Ψ → ℝ | ∃ a : E, cc a = a ∧ IsIntegral ℤ a ∧
      p = fun τ => (τ.1 a).re} ≤
      (Submodule.span ℝ (Lc X g : Set (X.Ψ → Fin 2 → Fin 2 → ℝ))).comap T := by
    rw [Submodule.span_le]
    rintro _ ⟨a, ha, hi, rfl⟩
    exact hT a ha hi
  exact hle hp

end

end ReciprocityTheory.ChartRestriction.G.FD.FourierCoefficientLattice
