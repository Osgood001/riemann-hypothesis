import Mathlib
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SquareTriple
import Development.AbelianVarietyTheory.PublishedTheorems.TwistedTraceFormula.UnifModGrowthOfIsUnifModerate

open Formalism.BasicNotions Formalism.BasicNotions.TH Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.MainNotions.StandardLattice Formalism.L2.Theta Formalism.IndefR.Datum Formalism.IndefR.Links
open IsDedekindDomain NumberField MeasureTheory Matrix
open scoped TensorProduct
open GlobalTheory.FunObj GlobalTheory.ChiGrid GlobalTheory.SplitFlip GlobalTheory.SplitWeil GlobalTheory.StdFrames Formalism.L2.DIV

attribute [local instance] Formalism.BasicNotions.Host.cmStar GlobalTheory.LocalData.complRel GlobalTheory.LocalData.isLocalField borelKw borelSpaceKw

noncomputable section

namespace GlobalTheory.FunObj

theorem hasSignature_of_hasSig_conj {n r s : ℕ} {M : Matrix (Fin n) (Fin n) ℂ}
    (h : GlobalTheory.IndefiniteRowSideFullHecke.WeilTensorModels.HasSig (M.map (starRingEnd ℂ)) r s) : Formalism.UG.HasSignature M r s := by
  obtain ⟨hn, A, hA⟩ := h
  let e : Fin n ≃ Fin r ⊕ Fin s := (finCongr hn.symm).trans finSumFinEquiv.symm
  let P : Matrix (Fin r ⊕ Fin s) (Fin r ⊕ Fin s) ℂ := A.submatrix e.symm id
  have h2 := congrArg (fun X => X.map (starRingEnd ℂ)) hA
  simp only [Matrix.map_mul, Matrix.transpose_map, Matrix.map_map, Matrix.fromBlocks_map] at h2
  have hc : (starRingEnd ℂ) ∘ (starRingEnd ℂ) = id := funext fun z => Complex.conj_conj z
  have hc' : (starRingEnd ℂ) ∘ (star : ℂ → ℂ) = id := funext fun z => Complex.conj_conj z
  simp only [hc, hc', Matrix.map_id] at h2
  have key : (A.map (starRingEnd ℂ))ᵀ * M * A = Formalism.UG.Jpq r s := by
    rw [Formalism.UG.Jpq, h2]
    congr 1
    · ext a b; simp [Matrix.one_apply]
    · ext a b; simp
    · ext a b; simp
    · ext a b; simp [Matrix.one_apply]
  have key2 : Formalism.UG.cT (starRingEnd ℂ) P * Matrix.reindex e e M * P = Formalism.UG.Jpq r s := by
    rw [← key, Formalism.UG.cT, Matrix.reindex_apply]
    have hm : (A.submatrix e.symm id).map (starRingEnd ℂ) = (A.map (starRingEnd ℂ)).submatrix e.symm id := rfl
    simp only [P, hm, Matrix.transpose_submatrix]
    rw [Matrix.submatrix_mul_equiv, Matrix.submatrix_mul_equiv, Matrix.submatrix_id_id]
  have hinv : (Formalism.UG.Jpq r s * (Formalism.UG.cT (starRingEnd ℂ) P * Matrix.reindex e e M)) * P = 1 := by
    rw [Matrix.mul_assoc, key2, Formalism.UG.Jpq, Matrix.fromBlocks_multiply]
    simp
  exact ⟨e, ⟨P, _, mul_eq_one_comm.mp hinv, hinv⟩, key2⟩


end GlobalTheory.FunObj

end
