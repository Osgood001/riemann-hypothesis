import Mathlib
import Formalism.SharpRestriction.GlobalSchurBounds.GeneralLinearActions.GenusMassVolumes
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.T2SpaceNumberFieldInfiniteAdeles

noncomputable section

namespace GlobalTheory.SWQ

open scoped TensorProduct NNReal ENNReal
open NumberField IsDedekindDomain MeasureTheory Topology Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes GlobalTheory.GaugeEx

variable {F : Type} [Field F] [NumberField F] {N : ℕ}

def qd (R : Type) [CommRing R] [Algebra F R] (a : Fin N → F) (u : Fin N → R) : R :=
  ∑ l, algebraMap F R (a l) * u l ^ 2

def Bd (R : Type) [CommRing R] [Algebra F R] (a : Fin N → F) (u u' : Fin N → R) : R :=
  ∑ l, algebraMap F R (2 * a l) * u l * u' l

def rat (ξ : Fin N → F) : Fin N → AF F := fun l => algebraMap F (AF F) (ξ l)

def inf (u : Fin N → AF F) : Fin N → Ainf F := fun l => fstA F (u l)

def fin (u : Fin N → AF F) : Fin N → Af F := fun l => sndA F (u l)

def loc (v : HeightOneSpectrum (𝓞 F)) (u : Fin N → Af F) : Fin N → Fv F v := fun l => evalV F v (u l)

def re (x : Ainf F) (w : InfinitePlace F) : ℝ :=
  (InfinitePlace.Completion.extensionEmbedding w (x w)).re

def sz (u : Fin N → AF F) : ℝ := ∑ l, ∑ w : InfinitePlace F, |re (inf u l) w|

def hf (F : Type) [Field F] [NumberField F] : AF F := pairA F (algebraMap F (Ainf F) (1 / 2)) 1


def Decay (Φ : (Fin N → AF F) → ℂ) : Prop :=
  Continuous Φ ∧ (∃ K : Set (Fin N → Af F), IsCompact K ∧ ∀ u, fin u ∉ K → Φ u = 0) ∧
    ∀ k : ℕ, ∃ C : ℝ, ∀ u, ‖Φ u‖ * (1 + sz u) ^ k ≤ C

def IsCov1 (ν : Measure (AF F)) : Prop :=
  ν.IsAddHaarMeasure ∧ ∃ D : Set (AF F), MeasurableSet D ∧
    IsAddFundamentalDomain (algebraMap F (AF F)).range.toAddSubgroup D ν ∧ ν D = 1

def muV (N : ℕ) (ν : Measure (AF F)) : Measure (Fin N → AF F) := Measure.pi fun _ => ν

def IsLam (ψ : AddChar (AF F) ℂ) (lam : InfinitePlace F → ℝ) : Prop :=
  (∀ w, lam w ≠ 0) ∧ ∀ x : Ainf F,
    psiInf F ψ x = Complex.exp (2 * Real.pi * Complex.I * ((∑ w, lam w * re x w : ℝ) : ℂ))

def Ctx (ψ : AddChar (AF F) ℂ) (lam : InfinitePlace F → ℝ) (ν : Measure (AF F)) (a : Fin N → F) : Prop :=
  IsTotallyReal F ∧ IsCharAF F ψ ∧ IsLam ψ lam ∧ IsCov1 ν ∧ ∀ l, a l ≠ 0

variable (ψ : AddChar (AF F) ℂ) (lam : InfinitePlace F → ℝ) (ν : Measure (AF F)) (a : Fin N → F)



def Fo (Φ : (Fin N → AF F) → ℂ) : (Fin N → AF F) → ℂ :=
  fun u => ∫ s, Φ s * ψ (Bd (AF F) a s u) ∂(muV N ν)

def rho (x y : Fin N → AF F) (Φ : (Fin N → AF F) → ℂ) : (Fin N → AF F) → ℂ :=
  fun u => ψ (Bd (AF F) a u y + algebraMap F (AF F) (1 / 2) * Bd (AF F) a x y) * Φ (u + x)

def th (Φ : (Fin N → AF F) → ℂ) : ℂ := ∑' ξ : Fin N → F, Φ (rat ξ)










structure IsTheta (M : ℕ) (Θ : Measure (Fin N → AF F)) : Prop where
  ratl : Θ {u | ¬ ∃ β : F, qd (AF F) a u = algebraMap F (AF F) β} = 0
  small : ∀ Ω : Set (Fin N → AF F), IsCompact Ω → ∃ C : ℝ≥0, ∀ j : ℕ,
    Θ ((fun u => hf F ^ j • u) '' Ω) * 2 ^ (Fintype.card (InfinitePlace F) * M * j) ≤ C
  big : ∀ Ω : Set (Fin N → AF F), IsCompact Ω → ∃ C : ℝ≥0, ∀ j : ℕ,
    Θ {u | hf F ^ j • u ∈ Ω} ≤ C * 2 ^ (Fintype.card (InfinitePlace F) * N * j)
  four : ∀ Φ, Decay Φ → Decay (Fo ψ ν a Φ) →
    Fo ψ ν a Φ 0 + ∫ u, Fo ψ ν a Φ u ∂Θ = Φ 0 + ∫ u, Φ u ∂Θ
  dil : ∀ t : F, t ≠ 0 → Θ.map (fun u => algebraMap F (AF F) t • u) = Θ



def tens (Φi : (Fin N → Ainf F) → ℂ) (Φv : ∀ v : HeightOneSpectrum (𝓞 F), (Fin N → Fv F v) → ℂ) :
    (Fin N → AF F) → ℂ := fun u => Φi (inf u) * ∏ᶠ v, Φv v (loc v (fin u))



structure LocData where
  μi : Measure (Fin N → Ainf F)
  νi : Measure (Ainf F)
  μv : ∀ v : HeightOneSpectrum (𝓞 F), Measure (Fin N → Fv F v)
  νv : ∀ v : HeightOneSpectrum (𝓞 F), Measure (Fv F v)
  fi : Ainf F → Measure (Fin N → Ainf F)
  fv : ∀ v : HeightOneSpectrum (𝓞 F), Fv F v → Measure (Fin N → Fv F v)
  sdμi : SelfDual μi fun x y => psiInf F ψ (Bd (Ainf F) a x y)
  sdνi : SdR (Ainf F) (psiInf F ψ) νi
  sdμv : ∀ v, SelfDual (μv v) fun x y => psiV F ψ v (Bd (Fv F v) a x y)
  sdνv : ∀ v, SdR (Fv F v) (psiV F ψ v) (νv v)
  fibi : IsFibreFamily μi (qd (Ainf F) a) id Set.univ νi {c : Ainf F | ∀ w, c w ≠ 0} fi
  fibv : ∀ v, IsFibreFamily (μv v) (qd (Fv F v) a) id Set.univ (νv v) {c | c ≠ 0} (fv v)

variable {ψ a}


def Good (ψ : AddChar (AF F) ℂ) (a : Fin N → F) (v : HeightOneSpectrum (𝓞 F)) : Prop :=
  (∀ y : Fv F v, (∀ t ∈ v.adicCompletionIntegers F, psiV F ψ v (y * t) = 1) ↔
    y ∈ v.adicCompletionIntegers F) ∧
  ‖(2 : Fv F v)‖ = 1 ∧ ∀ l, ‖algebraMap F (Fv F v) (a l)‖ = 1

section Herm

variable {E : Type} [Field E] [Algebra F E] {M : ℕ}





end Herm

theorem decay_zero : Decay (fun _ : Fin N → AF F => (0 : ℂ)) :=
  ⟨continuous_const, ⟨∅, isCompact_empty, fun _ _ => rfl⟩, fun _ => ⟨0, fun _ => by simp⟩⟩

end GlobalTheory.SWQ
