import Mathlib
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsLagrModelOfIsLin
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HasCompactSupportFinprodSchwartzBruhatFiniteAdel
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsLocallyConstantFinprodSchwartzBruhatFiniteAdel
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsFactorPureTensorComponentAtPlace

noncomputable section

namespace GlobalTheory.BigNZ

section Generic

open Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes IsDedekindDomain NumberField MeasureTheory Filter Topology
open GlobalTheory.WeilM GlobalTheory.AdelicU GlobalTheory.IndefiniteRowSideFullHecke.WeilTensorModels
open scoped TensorProduct Classical

variable {F E : Type} [Field F] [NumberField F] [Field E] [NumberField E] [Algebra F E] {σ : E →ₐ[F] E}

section Pair

variable {n d : ℕ} {X : Spc F E n} {Y : Spc F E d} {M : Model σ X Y} {ψ : AddChar (AF F) ℂ}

def Fam (M : Model σ X Y) (φ : ∀ v : Pl F, (Fin n × Fin d → Fv F v) → ℂ) : Prop :=
  (∀ v, φ v ∈ SB (Fin n × Fin d → Fv F v)) ∧ ∀ᶠ v in cofinite, φ v = M.vac v

theorem IsFinPart.fam {T : Finset (Pl F)} {φ} (h : IsFinPart M T φ) : Fam M φ :=
  ⟨h.1, T.eventually_cofinite_notMem.mono h.2⟩

theorem Fam.update {φ} (h : Fam M φ) (v : Pl F) {φ₁} (h₁ : φ₁ ∈ SB (Fin n × Fin d → Fv F v)) :
    Fam M (Function.update φ v φ₁) := by
  refine ⟨fun u => ?_, (h.2.and (eventually_cofinite_ne v)).mono fun u hu => ?_⟩
  · by_cases e : u = v
    · subst e; rwa [Function.update_self]
    · rw [Function.update_of_ne e]; exact h.1 u
  · rw [Function.update_of_ne hu.2]; exact hu.1


theorem Fam.std (hM : M.IsGood ψ) {φ} (h : Fam M φ) :
    ∀ᶠ v in cofinite, φ v = Set.indicator {x | ∀ i, x i ∈ v.adicCompletionIntegers F} 1 :=
  (h.2.and hM.std).mono fun _ hv => hv.1.trans hv.2

def finPartFn (φ : ∀ v : Pl F, (Fin n × Fin d → Fv F v) → ℂ) (y : Fin n × Fin d → Af F) : ℂ :=
  ∏ᶠ v, φ v fun i => evalV F v (y i)

theorem pure_eq (f : SInf F (Fin n × Fin d)) (φ : ∀ v : Pl F, (Fin n × Fin d → Fv F v) → ℂ) :
    GlobalTheory.IndefiniteRowSideFullHecke.WeilTensorModels.pure f φ = pureA F f (finPartFn φ) := rfl

theorem Fam.sb (hM : M.IsGood ψ) {φ} (h : Fam M φ) : finPartFn φ ∈ SB (Fin n × Fin d → Af F) :=
  ⟨GlobalTheory.WeilM.isLocallyConstant_finprod_evalV φ h.1 (h.std hM),
    GlobalTheory.AdelicCoordSupport.hasCompactSupport_finprod φ h.1 (h.std hM)⟩

theorem Fam.mem (hM : M.IsGood ψ) {φ} (h : Fam M φ) (f : SInf F (Fin n × Fin d)) :
    GlobalTheory.IndefiniteRowSideFullHecke.WeilTensorModels.pure f φ ∈ schA F (Fin n × Fin d) :=
  Submodule.subset_span ⟨f, _, h.sb hM, pure_eq f φ⟩

theorem Fam.acts (hM : M.IsGood ψ) {φ} (h : Fam M φ) (f : SInf F (Fin n × Fin d)) {v : Pl F} {Op φ₂ φ₃}
    (h₂ : φ₂ ∈ SB (Fin n × Fin d → Fv F v)) (ha : Acts (evFin F v) Op φ₂ φ₃) :
    Op (GlobalTheory.IndefiniteRowSideFullHecke.WeilTensorModels.pure f (Function.update φ v φ₂)) = GlobalTheory.IndefiniteRowSideFullHecke.WeilTensorModels.pure f (Function.update φ v φ₃) := by
  obtain ⟨r, hr, e⟩ := GlobalTheory.PureFactor.exists_rest_factor v f φ (h.std hM)
  rw [← e, ← e]
  exact ha r ⟨hr, by rw [e]; exact (h.update v h₂).mem hM f⟩



end Pair

variable {a a' : ℕ} {B : Base F E} {G : Geo σ a a'} {X : Chars F E} {om : Rep σ G.V G.W} {om' : Rep σ G.V' G.W}
  {R : RealMaps F a a'} {Rf : FinMaps F a a'}










end Generic

end GlobalTheory.BigNZ

end
