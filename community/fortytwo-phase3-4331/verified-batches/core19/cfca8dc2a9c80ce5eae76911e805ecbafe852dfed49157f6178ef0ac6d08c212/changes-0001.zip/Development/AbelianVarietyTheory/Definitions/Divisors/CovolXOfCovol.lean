import Mathlib
import Development.AbelianVarietyTheory.Definitions.Divisors.TupleReadBaseTupleEqFamily
import Development.AbelianVarietyTheory.Definitions.Divisors.NormNegCmConstantEqAtAllEmbeddings
import Development.AbelianVarietyTheory.Definitions.HeightFunctions.NormComparisonConstants
import Development.AbelianVarietyTheory.Proofs.HeightProofs.FieldSmallIffOpo
import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.LabelDatum

set_option synthInstance.maxHeartbeats 400000

noncomputable section

open NumberField IsDedekindDomain Formalism.BasicNotions Formalism.MainNotions Formalism.L2 Formalism.L2.DIV Formalism.L2.Indef Formalism.L2.Pj Formalism.IndefR.Links Formalism.IndefR.FWT
open ReciprocityTheory.ChartRestriction.G.Geo.Tor ReciprocityTheory.ChartRestriction.G.FD GlobalTheory.AllWt GlobalTheory.CompHt GlobalTheory.BigTop

namespace GlobalTheory.CovTop

attribute [local instance] Formalism.BasicNotions.Host.cmStar

variable {D : D7} {L : SizeData₂ D} {hT : GatTies D} {Gi : Formalism.MainNotions.G.Inst D L} {Gl : Formalism.MainNotions.G.LatInst D} {Kc : Formalism.MainNotions.G.Consts}
  {Y0 : DivX D} {cX : ExtraC} {ex : Extra D L hT Gi Gl Kc Y0 cX} {Csz : ℝ} (p : PtAt ex Csz) (i : Fin D.R.m)

abbrev unitE : ℝ := p.Z.l3u

abbrev mainT : ℝ := p.Z.l3m i

abbrev dat : Datum p.T.Q.H := p.T.Q.Dw ((i : ℕ) + 1)

abbrev Gk : WTZ D.host.E := wtZ (wtA (p.κ i)) (p.κ i).n

abbrev Gs (s : ℤ) : WTZ D.host.E := shiftG (dat p i) (wtA (p.κ i)) (p.κ i).n s



abbrev kap : ℝ := sizeK (dat p i) (wtA (p.κ i)) (p.κ i).n

abbrev Cov : Type 1 := Deep p.T.toCore ((i : ℕ) + 1)

abbrev latDeep (Y : Cov p i) := Y.latOver (Gk p i) (typeK p.fw p.F.lv2 i)





def muCore : ℝ := slope_sq (nrmK p.fw i) (latTypeK p.fw p.F.lv2 i)










def LowAt (C : ℝ) : Prop := -mainT p i - C * unitE p ≤ muCore p i


variable (Y : Cov p i)

def GoodCov : Prop :=
  Y.GoodL L.sc.L (391 * zBase L ^ 2) ∧
  (∀ σ, GoodEmb Y.d.c₂ σ → ∀ g τ k, ‖dmin ((Y.U σ).X (Y.dict σ g).1).Gm (Y.dict σ g).2 τ k‖ = 1) ∧
  ∀ σ, GoodEmb Y.d.c₂ σ → ∃ hr : (D.sp.W ((i : ℕ) + 1)).rank = D.R.r, ∀ k, ModelW (D.sp.W ((i : ℕ) + 1)) hr ((Y.U σ).X k)


def RingAt : Prop :=
  slope_sq (Y.nrm (Gk p i)) (latDeep p i Y) - 2 * L.sc.b ≤ muCore p i


def RkAt (PP : ℝ) : Prop :=
  (Y.rk (Gs p i (cZero D ((i : ℕ) + 1))) : ℝ) ≤ (1 + L.sc.b / (PP * kap p i)) * Y.rk (Gs p i (-(cZero D ((i : ℕ) + 1))))










def RecTied (D : D7) (L : SizeData₂ D) : Prop := GlobalTheory.FinalJoin2.FieldSmall D L ∧ GlobalTheory.GLq.ESerTie D






def RowsT : Prop := p.Rows ∧ RecTied D L

def EvTied {eps : ℝ} (Fm : FamP eps) (Q : ∀ (x : ℝ) (hx : Fm.x1 < x) (ι : Fm.Ix x), Pt Fm x hx ι → Prop) : Prop :=
  ∃ x0 : ℝ, ∀ (x : ℝ) (hx : Fm.x1 < x), x0 ≤ x → ∀ (ι : Fm.Ix x) (p : Pt Fm x hx ι), RowsT p → Q x hx ι p




def Lifts (Q : ∀ {eps : ℝ} (Fm : FamP eps) (x : ℝ) (hx : Fm.x1 < x) (ι : Fm.Ix x) (p : Pt Fm x hx ι) (i : Fin (Fm.D x ι).R.m)
    (PP C : ℝ), Prop) : Prop :=
  Closed FamHyp fun Fm _ => ∃ C : ℝ, 0 ≤ C ∧ EvTied Fm fun x hx ι p => ∀ i, Q Fm x hx ι p i (Fm.parT x hx ι).PP C

def Covers (Q : ∀ {eps : ℝ} (Fm : FamP eps) (x : ℝ) (hx : Fm.x1 < x) (ι : Fm.Ix x) (p : Pt Fm x hx ι) (i : Fin (Fm.D x ι).R.m)
    (_Y : Cov p i) (PP C : ℝ), Prop) : Prop :=
  Lifts fun Fm x hx ι p i PP C => (i : ℕ) + 1 < (Fm.D x ι).R.m →
    ∀ Y : Cov p i, GoodCov p i Y → Q Fm x hx ι p i Y PP C










def Low : Prop := Lifts fun _ _ _ _ p i _ C => LowAt p i C


def LowDef : Prop := Lifts fun Fm x _ ι p i _ C => (i : ℕ) + 1 = (Fm.D x ι).R.m → LowAt p i C



def Ring : Prop := Covers fun _ _ _ _ p i Y _ _ => RingAt p i Y


def Rk : Prop := Covers fun _ _ _ _ p i Y PP _ => RkAt p i Y PP












example (h : Low) : LowDef :=
  Closed.imp h fun _ _ _ ⟨C, h0, a, h⟩ => ⟨C, h0, a, fun x hx hle ι p hp i _ => h x hx hle ι p hp i⟩

example (h : Formalism.MainNotions.WeightAlgebra.PO D L < 0) : ¬ RecTied D L := fun h' =>
  absurd ((Real.log_natCast_nonneg _).trans h'.1.1) (not_le.2 h)

end GlobalTheory.CovTop

end
