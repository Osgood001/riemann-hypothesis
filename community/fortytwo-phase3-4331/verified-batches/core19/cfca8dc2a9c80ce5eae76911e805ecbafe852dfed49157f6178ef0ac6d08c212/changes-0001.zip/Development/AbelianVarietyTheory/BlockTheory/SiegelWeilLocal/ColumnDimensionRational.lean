import Mathlib
import Formalism.SharpRestriction.GlobalSchurBounds.GeneralLinearActions.GenusMassVolumes
import Formalism.LocalToGlobal.Columns.GenericUnipotentCharacter
import Development.AbelianVarietyTheory.Definitions.SemilocalFrames.FrameLats

noncomputable section

open NumberField IsDedekindDomain MeasureTheory Matrix
open scoped TensorProduct nonZeroDivisors
open Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes GlobalTheory.SgAlg GlobalTheory.SgGlob

namespace GlobalTheory.IndefiniteRowSideFullHecke.ParabolicSubgroups

section Groups

variable {A : Type} [CommRing A] {n r : ℕ}

def fixG (σ : A →+* A) (J : Matrix (Fin n) (Fin n) A) (P : Matrix (Fin n) (Fin (r + 1)) A)
    (f : Matrix (Fin n) (Fin r) A) : Subgroup ↥(Formalism.UG.UJ σ J) where
  carrier := {g | (g.1 : Matrix (Fin n) (Fin n) A) * P = P ∧ (g.1 : Matrix (Fin n) (Fin n) A) * f = f}
  one_mem' := by simp
  mul_mem' := by
    rintro a b ⟨h1, h2⟩ ⟨h3, h4⟩
    refine ⟨?_, ?_⟩
    · simp only [Subgroup.coe_mul, Units.val_mul, Matrix.mul_assoc, h3, h1]
    · simp only [Subgroup.coe_mul, Units.val_mul, Matrix.mul_assoc, h4, h2]
  inv_mem' := by
    rintro a ⟨h1, h2⟩
    refine ⟨?_, ?_⟩
    · conv_lhs => rw [← h1]
      rw [Subgroup.coe_inv, ← Matrix.mul_assoc, Units.inv_mul, Matrix.one_mul]
    · conv_lhs => rw [← h2]
      rw [Subgroup.coe_inv, ← Matrix.mul_assoc, Units.inv_mul, Matrix.one_mul]


end Groups

section Points

variable {F E : Type} [Field F] [Field E] [Algebra F E] (R : Type) [CommRing R] [Algebra F R]
  (σ : E →ₐ[F] E) {n r : ℕ} (J : Matrix (Fin n) (Fin n) E)

def Hp (P : Matrix (Fin n) (Fin (r + 1)) E) (f : Matrix (Fin n) (Fin r) E) : Subgroup (HA R σ J) :=
  fixG (sigR R σ) (JR R J) (P.map (inclR R)) (f.map (inclR R))


def Sp (P : Matrix (Fin n) (Fin (r + 1)) E) : Set (HA R σ J) :=
  {g | InS (sigR R σ) (JR R J) (P.map (inclR R))
    (HA.mat R σ J g : Matrix (Fin n) (Fin n) (R ⊗[F] E))}

theorem sig_incl (x : E) : sigR R σ (inclR R x) = inclR R (σ x) := by simp [sigR, inclR]

theorem bc_mem (γ : ↥(Formalism.UG.UJ (σ : E →+* E) J)) : Formalism.UG.bc (inclR R) γ.1 ∈ HR R σ J := by
  have h : Formalism.UG.cT (σ : E →+* E) (γ.1 : Matrix (Fin n) (Fin n) E) * J * γ.1 = J := γ.2
  show Formalism.UG.cT (sigR R σ) ((γ.1 : Matrix (Fin n) (Fin n) E).map (inclR R)) * J.map (inclR R) *
    (γ.1 : Matrix (Fin n) (Fin n) E).map (inclR R) = J.map (inclR R)
  have h2 : Formalism.UG.cT (sigR R σ) ((γ.1 : Matrix (Fin n) (Fin n) E).map (inclR R)) =
      (Formalism.UG.cT (σ : E →+* E) (γ.1 : Matrix (Fin n) (Fin n) E)).map (inclR (F := F) R) := by
    ext i j
    simp [Formalism.UG.cT, sig_incl]
  rw [h2, ← Matrix.map_mul, ← Matrix.map_mul, h]

def ratG : ↥(Formalism.UG.UJ (σ : E →+* E) J) →* HA R σ J :=
  ((Formalism.UG.bc (inclR R)).comp (Formalism.UG.UJ (σ : E →+* E) J).subtype).codRestrict (HR R σ J)
    (bc_mem R σ J)

abbrev HF (P : Matrix (Fin n) (Fin (r + 1)) E) (f : Matrix (Fin n) (Fin r) E) :=
  fixG (σ : E →+* E) J P f

theorem ratG_mem_Hp (P : Matrix (Fin n) (Fin (r + 1)) E) (f : Matrix (Fin n) (Fin r) E)
    (γ : ↥(HF σ J P f)) : ratG R σ J γ.1 ∈ Hp R σ J P f := by
  obtain ⟨h1, h2⟩ := γ.2
  refine ⟨?_, ?_⟩
  · show (γ.1.1 : Matrix (Fin n) (Fin n) E).map (inclR (F := F) R) * P.map (inclR R) = P.map (inclR R)
    rw [← Matrix.map_mul, h1]
  · show (γ.1.1 : Matrix (Fin n) (Fin n) E).map (inclR (F := F) R) * f.map (inclR R) = f.map (inclR R)
    rw [← Matrix.map_mul, h2]

def ratH (P : Matrix (Fin n) (Fin (r + 1)) E) (f : Matrix (Fin n) (Fin r) E) :
    ↥(HF σ J P f) →* ↥(Hp R σ J P f) :=
  ((ratG R σ J).comp (HF σ J P f).subtype).codRestrict (Hp R σ J P f) (ratG_mem_Hp R σ J P f)


def act (g : HA R σ J) (x : Fin n → R ⊗[F] E) : Fin n → R ⊗[F] E :=
  (HA.mat R σ J g : Matrix (Fin n) (Fin n) (R ⊗[F] E)).mulVec x






end Points

section Levels

variable {F E : Type} [Field F] [NumberField F] [Field E] [NumberField E] [Algebra F E]
  (σ : E →ₐ[F] E) {n r k : ℕ} (J : Matrix (Fin n) (Fin n) E)


variable (F) in

def vecF (x : Fin n → E) : Fin n → Af F ⊗[F] E := fun i => inclR (Af F) (x i)

variable (F) in

def hat (Λ : Submodule (𝓞 E) (Fin n → E)) : AddSubgroup (Fin n → Af F ⊗[F] E) :=
  AddSubgroup.closure {y | ∃ (t : Af F) (x : Fin n → E),
    (∀ v, evalV F v t ∈ v.adicCompletionIntegers F) ∧ x ∈ Λ ∧ y = t • vecF F x}

variable (F) in

def hatI (I : Ideal (𝓞 E)) (Λ : Submodule (𝓞 E) (Fin n → E)) : AddSubgroup (Fin n → Af F ⊗[F] E) :=
  hat F (I • Λ)



variable (F) in

def Typed (g₁ g₂ : ℕ) : Set (HeightOneSpectrum (𝓞 F)) :=
  {p | (g₁ : 𝓞 F) ∈ p.asIdeal ∨ (g₂ : 𝓞 F) ∈ p.asIdeal}

def ga (k g : ℕ) : ENNReal :=
  (Nat.card (GL (Fin k) (ZMod g)) : ENNReal) / (Nat.card ↥(Formalism.L2.Col.HU (ZMod g) k) : ENNReal)

open Classical in
variable (F) in

def Gam1 (k g₁ g₂ : ℕ) : ENNReal :=
  ∏ᶠ p ∈ Typed F g₁ g₂, ga k (if (g₁ : 𝓞 F) ∈ p.asIdeal then g₁ else g₂)

variable (P : Matrix (Fin n) (Fin (r + 1)) E) (f : Matrix (Fin n) (Fin r) E)
  (Λ : Submodule (𝓞 E) (Fin n → E)) (g₁ g₂ : ℕ)
  (w : HeightOneSpectrum (𝓞 F) → HeightOneSpectrum (𝓞 E))
  (ε : HeightOneSpectrum (𝓞 F) → Fin k → Fin n → E)





def cols {V : Type} [AddCommGroup V] [Module ℂ V] (Kl : Subgroup ↥(Hp (Af F) σ J P f))
    (ψ : ↥Kl →* ℂˣ) (π : Representation ℂ ↥(Hp (Ainf F) σ J P f) V) :
    Submodule ℂ (↥(Hp (Af F) σ J P f) → V) where
  carrier := {φ | ∀ (γ : ↥(HF σ J P f)) (x : ↥(Hp (Af F) σ J P f)) (κ : ↥Kl),
    φ (ratH (Af F) σ J P f γ * x * κ) = (((ψ κ)⁻¹ : ℂˣ) : ℂ) • π (ratH (Ainf F) σ J P f γ) (φ x)}
  zero_mem' := fun γ x κ => by simp
  add_mem' := fun {a b} ha hb γ x κ => by simp only [Pi.add_apply, ha γ x κ, hb γ x κ, map_add, smul_add]
  smul_mem' := fun c a ha γ x κ => by
    simp only [Pi.smul_apply, ha γ x κ, map_smul]; rw [smul_comm]






end Levels



example (g : ℕ) : ga 0 g = 1 := by
  have h1 : Nat.card (GL (Fin 0) (ZMod g)) = 1 := Nat.card_unique
  have h2 : Nat.card ↥(Formalism.L2.Col.HU (ZMod g) 0) = 1 := Nat.card_unique
  simp [ga, h1, h2]

end GlobalTheory.IndefiniteRowSideFullHecke.ParabolicSubgroups
