import Mathlib
import Development.AbelianVarietyTheory.Definitions.GlobalTwisting.LatIntZero
import Formalism.LocalToGlobal.KernelLattices.LateralTheory
import Formalism.LocalToGlobal.KernelLattices.DeterminantCokernelCount.CokernelIndexFactors.StatementB
import Formalism.LocalToGlobal.GlobalTheory.GL3.PLinkThU
import Formalism.LocalToGlobal.GlobalTheory.GL3.PHfTrace
import Formalism.LocalToGlobal.GlobalTheory.GL3.PThIndep
import Formalism.LocalToGlobal.GlobalTheory.GL3.PSelfDual
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.SpanRangeEmb4EqTop
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.CmBaseFieldIntegersAndCurveIdealFacts

open NumberField Formalism.BasicNotions Classical Formalism.MainNotions Formalism.MainNotions.TaylorLogMetric Formalism.L2.Ker GlobalTheory.MomN
open scoped ComplexOrder

noncomputable section

namespace GlobalTheory.MomSetup

open Formalism.L2.GlobalTheoryTheory.IntegralLatticeDensity

variable {D : D7} {N N' : ℕ}

abbrev Ix (D : D7) (N N' : ℕ) : Type := D.what₂.Tau × Fin N' × Fin N









end GlobalTheory.MomSetup

namespace GlobalTheory.MomSetup

open Formalism.L2.GlobalTheoryTheory.IntegralLatticeDensity

variable {D : D7} {N N' : ℕ} {cc : Ideal (𝓞 D.host.K)} {δ : ℂ}

theorem embT_Kc (τ : D.what₂.Tau) (k : D.host.K) : embT D τ (k : D.host.E) = D.host.φ₀ (k : D.host.E) :=
  FL.embT_K D τ _ k.2

theorem embV_zero : embV D (tor0 D cc δ) (0 : Matrix (Fin N') (Fin N) D.host.E) = 0 := by
  funext τ i j; simp [embV, tor0]

theorem embV_add (A B : Matrix (Fin N') (Fin N) D.host.E) :
    embV D (tor0 D cc δ) (A + B) = embV D (tor0 D cc δ) A + embV D (tor0 D cc δ) B := by
  funext τ i j; simp [embV, tor0]

theorem embV_neg (A : Matrix (Fin N') (Fin N) D.host.E) :
    embV D (tor0 D cc δ) (-A) = -embV D (tor0 D cc δ) A := by
  funext τ i j; simp [embV, tor0]

theorem embV_smulK (k : D.host.K) (A : Matrix (Fin N') (Fin N) D.host.E) :
    embV D (tor0 D cc δ) ((k : D.host.E) • A) = D.host.φ₀ (k : D.host.E) • embV D (tor0 D cc δ) A := by
  funext τ i j; simp [embV, tor0, embT_Kc]






end GlobalTheory.MomSetup

namespace GlobalTheory.MomSetup

open Formalism.L2.GlobalTheoryTheory.IntegralLatticeDensity

variable {D : D7} {N N' : ℕ} {cc : Ideal (𝓞 D.host.K)} {δ : ℂ}




end GlobalTheory.MomSetup

namespace GlobalTheory.MomSetup

open Formalism.L2.GlobalTheoryTheory.IntegralLatticeDensity


end GlobalTheory.MomSetup
