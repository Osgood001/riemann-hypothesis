import Mathlib

open scoped Matrix ComplexOrder

namespace GlobalTheory


end GlobalTheory
