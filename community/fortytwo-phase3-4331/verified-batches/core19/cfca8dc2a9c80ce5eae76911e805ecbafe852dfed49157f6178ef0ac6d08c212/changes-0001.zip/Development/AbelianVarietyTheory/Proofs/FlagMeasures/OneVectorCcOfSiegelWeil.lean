import Mathlib
import Development.AbelianVarietyTheory.Definitions.SemilocalFrames.SiegelMeanCc
import Formalism.UnipotentAdelicQuotients.SiegelWeilUnitaryConvergent

open MeasureTheory NumberField IsDedekindDomain
open scoped TensorProduct

noncomputable section

namespace GlobalTheory.GaussMean.OneVec

open Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.MainNotions.StandardLattice

section Transport

variable {X Y : Type} [AddCommGroup X] [TopologicalSpace X] [IsTopologicalAddGroup X] [MeasurableSpace X] [BorelSpace X]
  [AddCommGroup Y] [TopologicalSpace Y] [IsTopologicalAddGroup Y] [MeasurableSpace Y] [BorelSpace Y]


omit [IsTopologicalAddGroup X] [IsTopologicalAddGroup Y] in

theorem density_comp {V Z : Type} [MeasurableSpace V] (e : X ≃ₜ+ Y) {μ : Measure V} {ν : Measure X}
    {f : V → Z} {ι : Y → Z} (hι : Function.Injective ι) {f' : V → X} (hf : ∀ v, f v = ι (e (f' v)))
    {B' : Set Y} {B : Set X} (hB : ∀ s ∈ B, e s ∈ B') {Φ : V → ℂ} {g : Y → ℂ}
    (h : IsContDensityOn μ f ι (ν.map e) B' Φ g) : IsContDensityOn μ f' id ν B Φ (fun s => g (e s)) := by
  obtain ⟨hg, hS⟩ := h
  set m : X ≃ᵐ Y := e.toHomeomorph.toMeasurableEquiv with hm
  refine ⟨hg.comp e.continuous.continuousOn (fun s hs => hB s hs), fun S hSc hSB => ?_⟩
  have h1 := hS (e '' S) (hSc.image e.continuous) (by rintro _ ⟨s, hs, rfl⟩; exact hB s (hSB hs))
  have hpre : f ⁻¹' (ι '' (e '' S)) = f' ⁻¹' (id '' S) := by
    ext v
    constructor
    · rintro ⟨y, ⟨s, hs, rfl⟩, hy⟩
      rw [hf v] at hy
      have hs' : s = f' v := EquivLike.injective e (hι hy)
      exact ⟨f' v, hs' ▸ hs, rfl⟩
    · rintro ⟨s, hs, hsv⟩
      exact ⟨e s, ⟨s, hs, rfl⟩, by rw [hf v, ← hsv]; rfl⟩
  rw [hpre] at h1
  rw [h1]
  have hmap : ν.map e = ν.map m := rfl
  rw [hmap, setIntegral_map_equiv]
  rw [show ⇑m ⁻¹' (⇑e '' S) = S from Set.preimage_image_eq S (EquivLike.injective e)]
  rfl

end Transport

section Field

variable {F E : Type} [Field F] [NumberField F] [Field E] [NumberField E] [Algebra F E] {σ : E →ₐ[F] E}

theorem sigma_sigma (h : IsCMExt F E σ) (x : E) : σ (σ x) = x := by
  obtain ⟨τ⟩ : Nonempty (E →+* ℂ) := ⟨(IsAlgClosed.lift : E →ₐ[ℚ] ℂ).toRingHom⟩
  apply τ.injective
  rw [h.2.2.2 τ, h.2.2.2 τ, star_star]

private theorem exists_not_fixed_of_isCMExt (h : IsCMExt F E σ) : ∃ y : E, σ y ≠ y := by
  by_contra hno
  push Not at hno
  obtain ⟨w⟩ : Nonempty (InfinitePlace E) := inferInstance
  have hc := h.2.1.isComplex w
  rw [InfinitePlace.isComplex_iff] at hc
  apply hc
  rw [ComplexEmbedding.isReal_iff]
  ext x
  rw [ComplexEmbedding.conjugate_coe_eq, starRingEnd_apply, ← h.2.2.2, hno]

private theorem exists_witt_eq_teich_add_p_teich_frob_symm_add_p_sq_mul (h : IsCMExt F E σ) :
    ∃ w : E, σ w = -w ∧ ∀ x : E, ∃ a b : F, x = algebraMap F E a + algebraMap F E b * w := by
  obtain ⟨y, hy⟩ := exists_not_fixed_of_isCMExt h
  refine ⟨y - σ y, by rw [map_sub, sigma_sigma h]; ring, ?_⟩
  have hw : y - σ y ≠ 0 := sub_ne_zero.mpr (Ne.symm hy)
  have hli : LinearIndependent F ![(1 : E), y - σ y] := by
    rw [LinearIndependent.pair_iff]
    intro s t hst
    rw [Algebra.smul_def, Algebra.smul_def, mul_one] at hst
    have h2 := congrArg σ hst
    simp only [map_add, map_mul, AlgHom.commutes, map_sub, sigma_sigma h, map_zero] at h2
    have h3 : (2 : E) * algebraMap F E t * (y - σ y) = 0 := by linear_combination hst - h2
    have ht : algebraMap F E t = 0 := by
      rcases mul_eq_zero.mp h3 with h4 | h4
      · rcases mul_eq_zero.mp h4 with h5 | h5
        · exact absurd h5 two_ne_zero
        · exact h5
      · exact absurd h4 hw
    have ht' : t = 0 := (algebraMap F E).injective (by rw [ht, map_zero])
    subst ht'
    refine ⟨(algebraMap F E).injective ?_, rfl⟩
    simpa using hst
  have hsp := hli.span_eq_top_of_card_eq_finrank (by rw [Fintype.card_fin, h.2.2.1])
  intro x
  obtain ⟨c, hc⟩ := (Submodule.mem_span_range_iff_exists_fun F).mp (hsp ▸ Submodule.mem_top : x ∈ _)
  refine ⟨c 0, c 1, ?_⟩
  rw [← hc, Fin.sum_univ_two]
  simp [Algebra.smul_def]

theorem add_sigma (h : IsCMExt F E σ) (x : E) : x + σ x = algebraMap F E (Algebra.trace F E x) := by
  obtain ⟨w, hw, hdec⟩ := exists_witt_eq_teich_add_p_teich_frob_symm_add_p_sq_mul h
  have htw : Algebra.trace F E w = 0 := by
    let σe : E ≃ₐ[F] E := AlgEquiv.ofAlgHom σ σ (AlgHom.ext fun z => sigma_sigma h z)
      (AlgHom.ext fun z => sigma_sigma h z)
    have h1 := Algebra.trace_eq_of_algEquiv σe w
    change Algebra.trace F E (σ w) = _ at h1
    rw [hw, map_neg] at h1
    have h2 : (2 : F) * Algebra.trace F E w = 0 := by linear_combination -h1
    simpa using h2
  obtain ⟨a, b, rfl⟩ := hdec x
  have e1 : σ (algebraMap F E a + algebraMap F E b * w) = algebraMap F E a - algebraMap F E b * w := by
    rw [map_add, map_mul, AlgHom.commutes, AlgHom.commutes, hw]
    ring
  have e2 : Algebra.trace F E (algebraMap F E a + algebraMap F E b * w) = 2 * a := by
    rw [map_add, ← Algebra.smul_def, map_smul, htw, smul_zero, add_zero, Algebra.trace_algebraMap, h.2.2.1, nsmul_eq_mul,
      Nat.cast_ofNat]
  rw [e1, e2, map_mul, map_ofNat]
  ring

variable (R : Type) [CommRing R] [Algebra F R]

theorem trace_tmul (r : R) (x : E) :
    Algebra.trace R (R ⊗[F] E) (r ⊗ₜ[F] x) = r * algebraMap F R (Algebra.trace F E x) := by
  have e : r ⊗ₜ[F] x = r • ((1 : R) ⊗ₜ[F] x) := by rw [TensorProduct.smul_tmul', smul_eq_mul, mul_one]
  rw [e, map_smul, smul_eq_mul]
  congr 1
  rw [Algebra.trace_apply, Algebra.trace_apply]
  have hl : Algebra.lmul R (R ⊗[F] E) ((1 : R) ⊗ₜ[F] x) = (Algebra.lmul F E x).baseChange R := by
    refine LinearMap.ext fun z => ?_
    induction z using TensorProduct.induction_on with
    | zero => simp
    | tmul a y => simp [Algebra.TensorProduct.tmul_mul_tmul]
    | add p q hp hq => rw [map_add, map_add, hp, hq]
  rw [hl, LinearMap.trace_baseChange]

theorem add_sigR (h : IsCMExt F E σ) (z : R ⊗[F] E) :
    z + sigR R σ z = algebraMap R (R ⊗[F] E) (Algebra.trace R (R ⊗[F] E) z) := by
  induction z using TensorProduct.induction_on with
  | zero => simp
  | tmul r x =>
    rw [trace_tmul]
    have hs : sigR R σ (r ⊗ₜ[F] x) = r ⊗ₜ[F] σ x := by simp [sigR]
    rw [hs, ← TensorProduct.tmul_add, add_sigma h, Algebra.TensorProduct.algebraMap_apply,
      Algebra.algebraMap_self_apply, Algebra.algebraMap_eq_smul_one (A := E),
      ← TensorProduct.smul_tmul, Algebra.smul_def, mul_comm]
  | add p q hp hq => rw [map_add, map_add, map_add, ← hp, ← hq]; abel







variable [TopologicalSpace R] [IsTopologicalRing R]








end Field



section Sd

variable {F E : Type} [Field F] [NumberField F] [Field E] [NumberField E] [Algebra F E] {σ : E →ₐ[F] E}
  {R : Type} [CommRing R] [Algebra F R] [TopologicalSpace R] [IsTopologicalRing R] [MeasurableSpace R]
  [BorelSpace R]




end Sd


end GlobalTheory.GaussMean.OneVec

namespace GlobalTheory.GaussMean

open Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.MainNotions.StandardLattice OneVec


end GlobalTheory.GaussMean
