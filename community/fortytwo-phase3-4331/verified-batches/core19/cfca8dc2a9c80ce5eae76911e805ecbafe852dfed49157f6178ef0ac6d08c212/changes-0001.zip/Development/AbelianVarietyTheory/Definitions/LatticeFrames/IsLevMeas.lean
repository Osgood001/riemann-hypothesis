import Mathlib
import Development.AbelianVarietyTheory.Definitions.LatticeFrames.ChainParSucc
import Development.AbelianVarietyTheory.Definitions.LatticeFrames.ParBoundW
import Development.AbelianVarietyTheory.Definitions.LatticeFrames.IntegrandSZero
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.HalfLinearCocycle
import Development.AbelianVarietyTheory.Definitions.Foundations.SmoothPartStable
import Development.AbelianVarietyTheory.Definitions.LatticeFrames.IsCoType

noncomputable section

open Formalism.BasicNotions Formalism.BasicNotions.TH Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.MainNotions.StandardLattice Formalism.MainNotions.S MeasureTheory IsDedekindDomain NumberField Matrix
open Formalism.L2.Theta Formalism.L2.DIV Formalism.IndefR Formalism.IndefR.Links Formalism.IndefR.Mult Formalism.IndefR.Datum
open scoped TensorProduct InnerProductSpace ComplexConjugate
open GlobalTheory.ChainOnto
open GlobalTheory.IndefiniteRowSideFullHecke.RestrictedTensorSplitting (SplitProj IsProjAt IsIdemOf LiftsChar rdA grpCo frCo gAt)
open GlobalTheory.IndefiniteRowSideFullHecke.VolumeFlatSection (Blocks)

namespace GlobalTheory.ChainTw

attribute [local instance] Formalism.BasicNotions.Host.cmStar GlobalTheory.LocalData.complRel GlobalTheory.LocalData.isLocalField

variable {D : D7}

structure Twist (D : D7) where
  Pg : Finset (Pl D.host.E)
  Q : Finset (Pl D.host.E)
  chi : ℕ → ∀ PP : Pl D.host.E, (kP PP)ˣ →* ℂˣ
  ξ : ∀ PP : Pl D.host.E, (kP PP)ˣ →* ℂˣ

open Classical in

structure Twist.Is (c : Com D) (w : Twist D) : Prop where
  com : c.Is
  union : c.Pg = w.Pg ∪ w.Q
  disj : Disjoint w.Pg w.Q
  chiPg : ∀ j, ∀ PP ∈ w.Pg, c.chi j PP = w.chi j PP
  chiQ : ∀ j, ∀ PP ∈ w.Q, c.chi j PP = (w.ξ PP)⁻¹
  ne : ∀ PP ∈ w.Q, w.ξ PP ≠ 1
  grp : ∀ g, g ∈ c.P.H ↔ ∀ PP : c.Pg, PP.1 ∈ w.Pg → g PP = 1
  chr : c.P.chi = 1

def flat (c : Com D) (w : Twist D) (j : ℕ) (s : PiLocalization₂ D) (hr : D.R.r ≤ s.V.rank) : PiLocalization₂ D :=
  { s with L := Lev.datY s.V.rank D.R.r D.R.t j hr c.Pg ∅ c.P c.chi w.ξ Lev.Frm.B }

def IsStage (c : Com D) (w : Twist D) (j : ℕ) (s : PiLocalization₂ D) : Prop :=
  ∃ hr, s.L = Lev.datY s.V.rank D.R.r D.R.t j hr w.Pg w.Q (LevelP.triv _ _ _) w.chi w.ξ Lev.Frm.B ∧ (flat c w j s hr).Is c j

variable {c : Com D} {s s' : PiLocalization₂ D}

structure IsStep (w : Twist D) (j : ℕ) (p : Step c s s') : Prop where
  weil : IsWeilDatumO c.ψ s.V s'.V (c.chS j) (c.chT j) p.ω
  vec : ∃ f₀, IsStepVecOf c.ψ c.θ s.V s'.V (cart s.M) (cart s'.M) s.Λ s'.Λ s.β s'.β s.L (w.chi j) w.Q w.ξ f₀ p.f
  theta : ∀ φ, IsThetaFunO c.ψ s.V s'.V (p.pt φ)
  it : IsItW c.θ s.M s'.M p.ω p.pt p.It
  io : Lift.IsIo s'.ν s'.fd (thetaKO p.ω) p.pt p.It (s'.CC c) (s.CC c) p.io

def ForStageQ (D : D7) (Φ : ∀ (_ : Com D) (_ : Twist D) (_ : ℕ) (_ : PiLocalization₂ D), Prop) : Prop :=
  ∀ (c : Com D) (w : Twist D), w.Is c → ∀ j ≤ D.R.m, ∀ s : PiLocalization₂ D, IsStage c w j s → Φ c w j s




def qPar (c : Com D) (PP : Pl D.host.E) (x : (AE D)ˣ) (k : ℕ) : Multiset ℂˣ :=
  Nat.rec 0 (fun i B => B.map (· * (Circle.toUnits (c.chS (i + 1) x) * (Circle.toUnits (c.chT (i + 1) x))⁻¹)) +
    GlobalTheory.LFun.seg PP (Circle.toUnits (c.chS (i + 1) x)) D.R.t) k



def blockL (c : Com D) (k : ℕ) (PP : Pl D.host.E) : ℂ :=
  ∏ i ∈ Finset.Icc 1 k, ∏ n ∈ Finset.Icc 1 D.R.t,
    ((1 - (GlobalTheory.LFun.val (F := D.host.F) (c.μ i * (c.μ (k + 1))⁻¹) PP : ℂ) * ((Ideal.absNorm PP.asIdeal : ℂ) ^ n)⁻¹) *
      (1 - (GlobalTheory.LFun.val (F := D.host.F) (c.μ i * (c.μ (k + 1))⁻¹) PP : ℂ)⁻¹ * ((Ideal.absNorm PP.asIdeal : ℂ) ^ n)⁻¹))⁻¹



























open Classical in

def Twist.S₀ (w : Twist D) : Set (HeightOneSpectrum (𝓞 D.host.F)) := (w.Pg.image fun PP => PP.under (𝓞 D.host.F) : Finset _)






example (c : Com D) (PP : Pl D.host.E) (x : (AE D)ˣ) : qPar c PP x 0 = 0 := rfl

example (c : Com D) (PP : Pl D.host.E) : blockL c 0 PP = 1 := by simp [blockL]

end GlobalTheory.ChainTw

end
