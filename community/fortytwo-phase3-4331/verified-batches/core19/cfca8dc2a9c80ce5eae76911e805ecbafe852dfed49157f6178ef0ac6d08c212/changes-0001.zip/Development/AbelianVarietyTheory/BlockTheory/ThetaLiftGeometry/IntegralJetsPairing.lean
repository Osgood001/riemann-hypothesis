import Mathlib
import Formalism.LocalRingCardinality.DataKerI
import Formalism.SharpRestriction.GlobalSchurBounds.GL3Theta
import Formalism.LocalToGlobal.KernelLattices.LateralTheory

open Formalism.MainNotions.G Formalism.BasicNotions Formalism.MainNotions NumberField

noncomputable section

namespace GlobalTheory.IndefiniteRowSideFullHecke.IntegralJetsPairing







open Classical in

def chgCoef (D : D7) {p : ℕ} [Fact p.Prime] (lam : TaylorLogMetric.Qbar →+* ℂ_[p]) {N N' : ℕ} (g : Bool × HH D → ℂ_[p])
    (P : Bool × HH D → Matrix (Fin N) (Fin N) D.host.E) (P' : Bool × HH D → Matrix (Fin N') (Fin N') D.host.E)
    (k : D.what₂.Tau × Fin N' × Fin N) (x : (Bool × HH D) × Fin N × Fin N') : ℂ_[p] :=
  if tauPl D x.1 = k.1 then
    g x.1 * TaylorLogMetric.tauEmb D lam (tauPl D x.1) (P' x.1 k.2.1 x.2.2) *
      TaylorLogMetric.tauEmb D lam (tauPl D x.1) ((P x.1)⁻¹ x.2.1 k.2.2)
  else 0




end GlobalTheory.IndefiniteRowSideFullHecke.IntegralJetsPairing
