import Mathlib
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.CosetRefinement
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RelIndexOfLeNsmul
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.RationalPoints
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HermitianLatticeTransportPreservesSelfDual
import Development.AbelianVarietyTheory.Proofs.FoundationProofs.IdealPeriodLatticeOfCurveDatum
import Development.AbelianVarietyTheory.Proofs.FoundationProofs.InducedTypeThetaGenusOnePermutes
open NumberField IsDedekindDomain Formalism.BasicNotions Formalism.MainNotions Formalism.L2.DIV Formalism.L2.Col Formalism.L2.Ker GlobalTheory.IndefiniteRowSideFullHecke.PlaceLogThetaBounds GlobalTheory.ColNorms
open scoped ComplexOrder

noncomputable section

namespace GlobalTheory.ColNorms.IndPres

open Formalism.L2.Th1.H

def Sm (x : ℂ) : Prop := x ∈ TaylorLogMetric.Qbar ∧ ∀ ρ : TaylorLogMetric.Qbar →ₐ[ℚ] ℂ, ‖StandardLatticesGL3.cj TaylorLogMetric.Qbar ρ x‖ ≤ 1

theorem cj_coe (ρ : TaylorLogMetric.Qbar →ₐ[ℚ] ℂ) (x : ℂ) (hx : x ∈ TaylorLogMetric.Qbar) : StandardLatticesGL3.cj TaylorLogMetric.Qbar ρ x = ρ ⟨x, hx⟩ := by
  simp only [StandardLatticesGL3.cj, TaylorLogMetric.liftM, dif_pos hx]

theorem sm_iff (x : ℂ) : Sm x ↔ ∃ y : TaylorLogMetric.Qbar, (y : ℂ) = x ∧ ∀ ρ : TaylorLogMetric.Qbar →ₐ[ℚ] ℂ, ‖ρ y‖ ≤ 1 := by
  constructor
  · rintro ⟨h, h'⟩
    exact ⟨⟨x, h⟩, rfl, fun ρ => by rw [← cj_coe]; exact h' ρ⟩
  · rintro ⟨y, rfl, h⟩
    exact ⟨y.2, fun ρ => by rw [cj_coe ρ _ y.2]; exact h ρ⟩



theorem Sm.mul {x y : ℂ} (hx : Sm x) (hy : Sm y) : Sm (x * y) := by
  obtain ⟨u, rfl, hu⟩ := (sm_iff _).1 hx
  obtain ⟨v, rfl, hv⟩ := (sm_iff _).1 hy
  refine (sm_iff _).2 ⟨u * v, rfl, fun ρ => ?_⟩
  rw [map_mul, norm_mul]
  exact mul_le_one₀ (hu ρ) (norm_nonneg _) (hv ρ)






section Gen

variable {V : Type} [AddCommGroup V] [Module ℂ V]



end Gen



section Host

variable {D : D7} {X : Fields} (s : Seam D X) {a b : ℕ}






end Host


end GlobalTheory.ColNorms.IndPres
