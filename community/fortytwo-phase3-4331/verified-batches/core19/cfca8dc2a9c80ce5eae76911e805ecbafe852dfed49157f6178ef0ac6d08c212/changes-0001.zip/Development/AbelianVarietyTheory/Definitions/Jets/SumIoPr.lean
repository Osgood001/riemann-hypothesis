import Mathlib
import Formalism.RealPlaceAnalysis.StatementKT
import Formalism.FormalDegreeBessel.StatementDS

open Finset
open scoped InnerProductSpace

noncomputable section

namespace BranchingSupport

section alg

variable {M : Type} [NormedAddCommGroup M] [InnerProductSpace ℂ M] {n : ℕ}

def CasKLe (ε : Fin n → Bool) (E : Fin n → Fin n → Module.End ℂ M) (c : ℝ) (w : M) : Prop :=
  ∃ S : Submodule ℂ M, FiniteDimensional ℂ S ∧ (∀ a b, ε a = ε b → ∀ x ∈ S, E a b x ∈ S) ∧ w ∈ S ∧
    ∀ x ∈ S, (⟪x, Formalism.REAL.CasK ε E x⟫_ℂ).re ≤ c ^ 2 * ‖x‖ ^ 2

def WtNear (E : Fin n → Fin n → Module.End ℂ M) (Λ : Fin n → ℝ) (t : ℝ) : Submodule ℂ M :=
  Submodule.span ℂ {x | ∃ ω : Fin n → ℝ, ∑ a, |ω a - Λ a| ≤ t ∧ Formalism.REAL.IsWeight E ω x}

def Lev (ε : Fin n → Bool) (E : Fin n → Fin n → Module.End ℂ M) (mu : Fin n → ℝ) (j : ℕ) (w : M) : Prop :=
  CasKLe ε E (Real.sqrt (Formalism.REAL.ckv ε (Formalism.QuantumDeterminants.lowK ε mu)) + 4 * (n : ℝ) * (j : ℝ)) w ∧
    w ∈ WtNear E (Formalism.QuantumDeterminants.lowK ε mu) (j : ℝ)



def dualTens (E : Fin n → Fin n → Module.End ℂ M) (a b : Fin n) (x : Fin n → M) : Fin n → M :=
  fun i => E a b (x i) - if i = b then x a else 0

def hhJ (ε : Fin n → Bool) (x y : Fin n → M) : ℂ := ∑ c, (if ε c then 1 else -1) * ⟪y c, x c⟫_ℂ


structure AlgTens (ε : Fin n → Bool) (E : Fin n → Fin n → Module.End ℂ M) (N : Fin n → Type)
    [∀ s, NormedAddCommGroup (N s)] [∀ s, InnerProductSpace ℂ (N s)]
    (F : ∀ s, Fin n → Fin n → Module.End ℂ (N s)) (io : ∀ s, N s →ₗ[ℂ] (Fin n → M))
    (pr : ∀ s, (Fin n → M) →ₗ[ℂ] N s) : Prop where
  io_comm : ∀ s a b y, io s (F s a b y) = dualTens E a b (io s y)
  pr_comm : ∀ s a b x, pr s (dualTens E a b x) = F s a b (pr s x)
  sum_io_pr : ∀ x, ∑ s, io s (pr s x) = x
  pr_io : ∀ s y, pr s (io s y) = y
  pr_io_ne : ∀ s t, s ≠ t → ∀ y, pr s (io t y) = 0
  orth : ∀ s t, s ≠ t → ∀ y y', hhJ ε (io s y) (io t y') = 0
  sign : ∀ s, ∃ e : ℝ, (e = 1 ∨ e = -1) ∧ ∀ y y', hhJ ε (io s y) (io s y') = (e : ℂ) * ⟪y', y⟫_ℂ

end alg


end BranchingSupport
