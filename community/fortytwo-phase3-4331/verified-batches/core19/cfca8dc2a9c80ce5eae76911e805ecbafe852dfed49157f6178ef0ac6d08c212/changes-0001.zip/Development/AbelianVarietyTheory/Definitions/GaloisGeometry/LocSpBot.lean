import Mathlib
import Formalism.LocalToGlobal.GroupLattices.ComparisonMaps.ValRat
import Formalism.LocalToGlobal.PairingIndexBounds.OrthogonalChartLevels.IsOrthCo

noncomputable section

namespace GlobalTheory.TwV

open NumberField IsDedekindDomain Formalism.MainNotions.G Formalism.L2.G.Cmp Formalism.L2.Forms Formalism.UG
open scoped TensorProduct


variable {F E : Type} [Field F] [NumberField F] [Field E] [NumberField E] [Algebra F E] {n p : ℕ} {G : GAtP p}





end GlobalTheory.TwV

end
