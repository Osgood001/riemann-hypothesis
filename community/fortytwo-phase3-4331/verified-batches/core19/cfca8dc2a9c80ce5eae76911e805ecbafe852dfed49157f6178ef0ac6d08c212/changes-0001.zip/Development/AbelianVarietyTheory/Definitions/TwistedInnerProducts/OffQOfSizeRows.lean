import Mathlib
import Development.AbelianVarietyTheory.BlockTheory.DivisorBase.LevelPlusSubgroup
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.CuspAlongSmoothRows
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.ThetaSourceAction
import Development.AbelianVarietyTheory.Definitions.LatticeFrames.IsThetaFam
import Development.AbelianVarietyTheory.Counterexamples.JetSurvey.OwnPrimeIntegralOfBqd
import Development.AutomorphicArithmetic.CyclotomicBounds.RamifiedDiscriminants.FunKit

noncomputable section

open Formalism.BasicNotions Formalism.BasicNotions.TH Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.MainNotions.StandardLattice Formalism.L2.Theta Formalism.IndefR Formalism.IndefR.Datum Formalism.IndefR.Links Formalism.IndefR.Mult Formalism.L2.DIV
open IsDedekindDomain NumberField MeasureTheory GlobalTheory.ChiGrid GlobalTheory.FunObj GlobalTheory.Grow
open GlobalTheory.IndefiniteRowSideFullHecke.LevelPlusSubgroup (coefPlus Cols SizeRows)
open scoped TensorProduct

namespace GlobalTheory.SepRows

attribute [local instance] Formalism.BasicNotions.Host.cmStar

variable {D : D7} {T : Type} {L : LevCh D T} {sc : Consts}


variable (L) in

def levRow : Subgroup (GA D (Yc D 0)) :=
  Lev.levA (Yc D 0) (congLev D.sp.cm (Yc D 0).gram (L.ΛY 0) (Ideal.span {((D.host.g 0 * D.host.g 1 : ℕ) : 𝓞 D.host.E)}))

variable (L) in

abbrev Rows (θ : InfFam D) {S : D.what₂.Tau → SPar} (M : DSModel (Yc D 0) S) : Submodule ℂ (SmT M →ₗ[ℂ] (GA D (Yc D 0) → ℂ)) :=
  MultT θ M (levRow L : Set _) 1

variable (G : GridData L sc)

def lev (X : Node) : Subgroup (GA D (G.V X)) := Lev.levA (G.V X) (G.levCong X)


def depLat (p : Pair T) : AddSubgroup (WO (G.pS p) (G.pT p)) where
  carrier := {u | u ∈ latO (G.pS p) (G.pT p) (G.latS p : Set _) (G.latT p : Set _) (fun _ => True) ∧
    ∀ e : AE D, IsIdemSum e G.pl.W0 → e • u ∈ hatMx (G.modul • homLat (G.latS p) (G.latT p))}
  zero_mem' := ⟨zero_mem _, fun e _ => by rw [smul_zero]; exact zero_mem _⟩
  add_mem' := fun ha hb => ⟨add_mem ha.1 hb.1, fun e he => by rw [smul_add]; exact add_mem (ha.2 e he) (hb.2 e he)⟩
  neg_mem' := fun ha => ⟨neg_mem ha.1, fun e he => by rw [smul_neg]; exact neg_mem (ha.2 e he)⟩

variable {G} (W : G.Weil)





variable (G) in

abbrev CoreVol : Type := ∀ i, GlobalTheory.Unf.Vol (G.V (.core i))




variable (G) in

def per0 (M : Vol G) (F : Fn G (.core 0)) (u : GA D (Yc D 0) → ℂ) : ℂ :=
  ∫ h in M.fd (.grid 0 0), F (stabilizerEmbedding G.sp.dec0 h) * u h ∂M.ν (.grid 0 0)

abbrev GP := ∀ {D : D7} {T : Type} {L : LevCh D T} {sc : Consts} {G : GridData L sc}, G.Weil → Vol G → Prop

def OffQ (D : D7) : Prop := Nat.Coprime D.host.pde (D.host.QS * D.host.q) ∧ Nat.Coprime D.host.pde' (D.host.QS * D.host.q)

def All (Q : GP) : Prop :=
  ∀ (D : D7), OffQ D → ∀ (T : Type) (L : LevCh D T) (μ0 : T), L.Is μ0 → ∀ (sc : Consts) (G : GridData L sc) (W : G.Weil) (M : Vol G),
    M.IsRow → Q W M

def Gap (Q : GP) : Prop :=
  ∀ (D : D7), OffQ D → GlobalTheory.IndefiniteRowSideFullHecke.CuspAlongSmoothLifts.Sizes D → ∀ (T : Type) (L : LevCh D T) (μ0 : T), L.Is μ0 → ∀ (sc : Consts), sc.cGap = 1 →
    ∀ (G : GridData L sc) (W : G.Weil) (M : Vol G), M.IsRow → Q W M







def Factor : Prop := Gap fun {D} _ {L} _ {G} W M => ∀ M₀ : DSModel (Yc D 0) (parB (Ptw D) 0), cart M₀ = W.cart (.grid 0 0) →
  ∀ w : SmT M₀, ∃ a : G.RealVec → Module.Dual ℂ (coefPlus G W.θ).W → ℂ, ∀ t ∈ Rows L W.θ M₀, ∀ Ψ ∈ Cols G W.θ, ∀ Φ,
    ∃ l : ℂ, ∀ ρ ξ, fPsiPhi W M ρ ξ Ψ Φ (t w) = a ρ ξ * l









end GlobalTheory.SepRows

end
