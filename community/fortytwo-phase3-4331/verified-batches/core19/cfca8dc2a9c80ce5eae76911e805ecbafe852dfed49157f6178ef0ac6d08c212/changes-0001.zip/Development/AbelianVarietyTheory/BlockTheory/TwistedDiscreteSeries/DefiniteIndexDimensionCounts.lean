import Mathlib
import Formalism.LocalToGlobal.IndefiniteReal.LinksChar
import Formalism.SharpRestriction.ElevenLe
import Formalism.LocalRingCardinality.DataParams
import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.LabelDatum

noncomputable section

open Formalism.BasicNotions Formalism.BasicNotions.TH Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.MainNotions.StandardLattice Formalism.MainNotions.S IsDedekindDomain NumberField
open Formalism.L2.Theta Formalism.L2.DIV Formalism.L2.Indef Formalism.DivisionValues
open Formalism.IndefR.Lev Formalism.IndefR.Mult Formalism.IndefR.Cx Formalism.IndefR.Links

namespace GlobalTheory.IndefiniteRowSideFullHecke.DegreeClassification

attribute [local instance] Formalism.BasicNotions.Host.cmStar

section Objects

variable {D : D7} {G : Type} [Group G] [Fintype G] {Pl0 T : Type} {A : FamIn D.what₂.LL G Pl0 T D.R.m}
  {Ks : Type} [Field Ks] [NumberField Ks] [Algebra Ks D.what₂.LL] (R : RealDat D A Ks) (F : Face D A)





def levB (b : Bool) : LevelP R.Pg D.R.r ℂ := R.levL F b (sg0 D A)



def allAt (b : Bool) (i : Fin D.R.m) : Submodule ℂ (MMap (R.MW i (sg0 D A))) :=
  Mult R.θ (R.MW i (sg0 D A)) (levS _ (R.βW i) (R.datWp i (levB R F b))) (levChi _ (R.βW i) (R.datWp i (levB R F b)))

def d0 (b : Bool) (i : Fin D.R.m) : ℕ := Module.finrank ℂ (allAt R F b i)

def dGood (b : Bool) (i : Fin D.R.m) : ℕ := Module.finrank ℂ (R.Wat i (sg0 D A) (levB R F b))





def GoodShare (δ : ℝ) (b : Bool) (i : Fin D.R.m) : Prop :=
  (1 - δ) * (d0 R F b i : ℝ) ≤ (dGood R F b i : ℝ) ∧ 0 < (1 - δ) * (d0 R F b i : ℝ)

structure HidaSetting : Prop where
  lev : R.toLevCh.Is A.μ0
  grp : R.IsGrp F
  fam : R.IsFam
  models : R.IsModels
  chain : R.IsChain
  thP : R.IsThP
  scal : R.IsScal F

theorem GoodShare.ne_bot {δ : ℝ} {b : Bool} {i : Fin D.R.m} (h : GoodShare R F δ b i) :
    R.Wat i (sg0 D A) (levB R F b) ≠ ⊥ := by
  intro h0
  have h1 : (0 : ℝ) < dGood R F b i := lt_of_lt_of_le h.2 h.1
  unfold dGood at h1
  rw [h0, finrank_bot] at h1
  simp at h1

end Objects





end GlobalTheory.IndefiniteRowSideFullHecke.DegreeClassification

end
