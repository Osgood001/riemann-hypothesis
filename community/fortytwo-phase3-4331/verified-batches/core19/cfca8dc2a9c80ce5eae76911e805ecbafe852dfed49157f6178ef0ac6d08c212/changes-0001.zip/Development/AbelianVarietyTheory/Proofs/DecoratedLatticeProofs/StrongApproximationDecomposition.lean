import Mathlib
import Development.AbelianVarietyTheory.Definitions.LatticeFrames.SplitPart
import Development.AbelianVarietyTheory.PublishedTheorems.TwistedTraceFormula.NotIsCompactUnivFv
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.SupportedSubgroupSplitCommutePrimeIdempotents
import Development.AbelianVarietyTheory.Proofs.AdelicLatticeProofs.IsOpenCongruenceIdelesAndRealFiniteParts
import Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.ExistsSplitIdempotentsOfRelTraceOneModTwo

noncomputable section
open Formalism.BasicNotions Formalism.BasicNotions.TH Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.MainNotions.StandardLattice Formalism.L2.Theta Formalism.IndefR Formalism.IndefR.Datum Formalism.IndefR.Links Formalism.L2.Forms Formalism.L2.Ker Formalism.UG
open NumberField IsDedekindDomain Matrix MeasureTheory GlobalTheory.Mem GlobalTheory.Mem.Col2 GlobalTheory.MixPer GlobalTheory.Core.Rk GlobalTheory.AdForm
open scoped TensorProduct Classical
attribute [local instance] Formalism.BasicNotions.Host.cmStar

namespace GlobalTheory.SplitDec

open GlobalTheory.IdemSupport

theorem map_mul_apply_mem {A B n : Type} [CommRing A] [CommRing B] [Fintype n] (φ : A →+* B) (S : Subring B)
    {a b : Matrix n n A} (ha : ∀ i j, φ (a i j) ∈ S) (hb : ∀ i j, φ (b i j) ∈ S) (i j : n) : φ ((a * b) i j) ∈ S := by
  rw [Matrix.mul_apply, map_sum]
  exact sum_mem fun l _ => by rw [map_mul]; exact mul_mem (ha i l) (hb l j)



variable {D : D7}



theorem int_iff (z : AE D) : finPart D z ∈ intAE D ↔ toEAf D z ∈ Formalism.L2.Herm.intAf D.host.F D.host.E :=
  mem_intAE_iff (finPart D z)

def IntM (V : HSp D) (k : GA D V) : Prop := ∀ i j, toEAf D (mt V k i j) ∈ Formalism.L2.Herm.intAf D.host.F D.host.E

theorem IntM.mul {V : HSp D} {k k' : GA D V} (h : IntM V k) (h' : IntM V k') : IntM V (k * k') := by
  intro i j
  rw [mt_mul]
  exact map_mul_apply_mem (toEAf D) _ h h' i j


theorem gramA_one {V : HSp D} (hV : V.gram = 1) : V.gram.map (incA D) = 1 := by
  rw [hV]; exact Matrix.map_one _ (map_zero _) (map_one _)

theorem mt_inv {V : HSp D} (hV : V.gram = 1) (k : GA D V) : mt V k⁻¹ = ((mt V k).map (cA D))ᵀ := by
  have h : ((mt V k).map (cA D))ᵀ * V.gram.map (incA D) * mt V k = V.gram.map (incA D) := k.2
  rw [gramA_one hV, Matrix.mul_one] at h
  have e : mt V k * mt V k⁻¹ = 1 := by rw [← mt_mul, mul_inv_cancel, mt_one]
  calc mt V k⁻¹ = (((mt V k).map (cA D))ᵀ * mt V k) * mt V k⁻¹ := by rw [h, Matrix.one_mul]
    _ = _ := by rw [Matrix.mul_assoc, e, Matrix.mul_one]

theorem IntM.inv {V : HSp D} (hV : V.gram = 1) {k : GA D V} (h : IntM V k) : IntM V k⁻¹ := by
  intro i j
  rw [mt_inv hV]
  exact (int_iff _).1 (finPart_cA_mem ((int_iff _).2 (h j i)))










section Loc

variable {Φ : AE D →+* FiniteAdeleRing (𝓞 D.host.E) D.host.E} (hΦ : Comp D Φ)
include hΦ





end Loc




end GlobalTheory.SplitDec

end
