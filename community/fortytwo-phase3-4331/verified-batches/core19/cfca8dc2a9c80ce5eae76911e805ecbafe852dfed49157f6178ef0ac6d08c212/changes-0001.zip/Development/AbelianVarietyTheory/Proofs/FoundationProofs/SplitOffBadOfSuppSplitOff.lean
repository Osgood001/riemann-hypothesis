import Mathlib
import Formalism.LocalToGlobal.IndefiniteReal.ThPinsR
import Formalism.LocalToGlobal.IndefiniteReal.LinksChar
import Formalism.LocalToGlobal.ProjectiveLattices.ThClassPinsRec
import Development.AbelianVarietyTheory.BlockTheory.TorsionBlocks.SublevelSplitting
import Development.AbelianVarietyTheory.Proofs.AdelicLatticeProofs.MovedOfSplitPl
import Development.AbelianVarietyTheory.Proofs.AdelicLatticeProofs.IsSplitPlaceOfSplitPl
import Development.AbelianVarietyTheory.Proofs.UnitaryExistence.CompletedLatticeEqAdelicCompletionAndGram
import Development.AbelianVarietyTheory.Proofs.UnitaryExistence.AdelicUnitaryEqRealMulFiniteSplit
import Development.AbelianVarietyTheory.Proofs.UnitaryExistence.RationalPointsAdelicUnitaryEqUnitary
import Development.AbelianVarietyTheory.Proofs.UnitaryExistence.ExistsPrincipalLevelSubgroupOpen
import Development.AbelianVarietyTheory.Proofs.FoundationProofs.ExistsSplitAt
import Development.AbelianVarietyTheory.Proofs.FoundationProofs.EvalVAlgebraMapMem
import Development.AbelianVarietyTheory.Proofs.FoundationProofs.FinCongMemLevEnv

noncomputable section

open NumberField IsDedekindDomain Formalism.BasicNotions Formalism.BasicNotions.TH Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.L2.Theta Formalism.IndefR Formalism.IndefR.Links
open scoped TensorProduct Matrix
attribute [local instance] Formalism.BasicNotions.Host.cmStar

namespace GlobalTheory.RepsCompare

open GlobalTheory.IndefiniteRowSideFullHecke.SublevelSplitting

section Generic

theorem moved_of_hom {F E : Type} [Field F] [NumberField F] [Field E] [NumberField E] [Algebra F E] (c : E ≃ₐ[F] E)
    (hcc : ∀ x, c (c x) = x) (hc : c ≠ 1) (v : HeightOneSpectrum (𝓞 F)) (φ : E →+* v.adicCompletion F)
    (hφ : ∀ t : F, φ (algebraMap F E t) = algebraMap F (v.adicCompletion F) t)
    (hint : ∀ x : 𝓞 E, Valued.v (φ x) ≤ 1) (P : HeightOneSpectrum (𝓞 E))
    (hP : ∀ x : 𝓞 E, x ∈ P.asIdeal ↔ Valued.v (φ x) < 1) : GlobalTheory.UnRep.Moved c P.asIdeal := by
  by_contra hn
  let σ : 𝓞 E ≃+* 𝓞 E := RingOfIntegers.mapRingEquiv c.toRingEquiv
  have hσ : ∀ x : 𝓞 E, ((σ x : 𝓞 E) : E) = c x := fun _ => rfl
  have one : ∀ b : 𝓞 E, b ∉ P.asIdeal → Valued.v (φ b) = 1 := fun b hb =>
    le_antisymm (hint b) (not_lt.1 fun h => hb ((hP b).2 h))
  have key : ∀ b : 𝓞 E, b ∉ P.asIdeal → σ b ∉ P.asIdeal := fun b hb h => hn ⟨σ b, h, b, (hcc _).symm, hb⟩
  obtain ⟨z, hz⟩ : ∃ z, c z ≠ z := by
    by_contra h
    exact hc (AlgEquiv.ext fun x => by simpa using not_exists.1 h x)
  have hab : φ z - φ (c z) ≠ 0 := sub_ne_zero.2 fun h => hz (φ.injective h).symm
  have hab' : Valued.v (φ z - φ (c z)) ≠ 0 := (Valuation.ne_zero_iff _).2 hab
  obtain ⟨t, ht⟩ : ∃ t : F, Valued.v (φ z - algebraMap F (v.adicCompletion F) t) < Valued.v (φ z - φ (c z)) := by
    have hd : DenseRange (algebraMap F (v.adicCompletion F)) := HeightOneSpectrum.denseRange_algebraMap (K := F) v
    have hN : {y : v.adicCompletion F | Valued.v (φ z - y) < Valued.v (φ z - φ (c z))} ∈ nhds (φ z) := by
      have ho := (Valued.isOpen_ball (v.adicCompletion F) (Valued.v.restrict (φ z - φ (c z)))).preimage
        (continuous_const.sub continuous_id : Continuous fun y : v.adicCompletion F => φ z - y)
      simp only [Set.preimage_ofPred_eq, Valuation.restrict_lt_iff] at ho
      refine ho.mem_nhds ?_
      show Valued.v (φ z - φ z) < _
      rw [sub_self, map_zero]
      exact zero_lt_iff.2 hab'
    obtain ⟨t, ht⟩ := hd.mem_nhds hN
    exact ⟨t, ht⟩
  have hb : Valued.v (φ (c z) - algebraMap F (v.adicCompletion F) t) = Valued.v (φ z - φ (c z)) := by
    rw [show φ (c z) - algebraMap F (v.adicCompletion F) t =
      (φ z - algebraMap F (v.adicCompletion F) t) - (φ z - φ (c z)) by ring]
    exact Valuation.map_sub_eq_of_lt_right _ ht
  have h1 : Valued.v (φ (z - algebraMap F E t)) < Valued.v (φ (c (z - algebraMap F E t))) := by
    rw [map_sub c, c.commutes, map_sub φ, map_sub φ, hφ, hb]
    exact ht
  generalize z - algebraMap F E t = u at h1
  obtain ⟨a, b, h⟩ := HeightOneSpectrum.exists_primeCompl_mul_eq_or_mul_eq P (K := E) (u / c u)
  have hu : c u ≠ 0 := fun h0 => by
    rw [h0, map_zero, map_zero] at h1
    exact not_lt_zero h1
  refine absurd h1 (not_lt.2 ?_)
  rw [div_mul_eq_mul_div, div_mul_eq_mul_div, div_eq_iff hu, div_eq_iff hu] at h
  rcases h with h | h
  · have h2 : c u * (σ b.1 : 𝓞 E) = (σ a : 𝓞 E) * u := by
      have := congrArg c h
      rwa [map_mul, map_mul, hcc] at this
    have h3 := congrArg (fun x => Valued.v (φ x)) h2
    simp only [map_mul, one _ (key _ b.2), mul_one] at h3
    rw [h3]
    exact mul_le_of_le_one_left' (hint _)
  · have h2 : u * (a : E) = ((b.1 : 𝓞 E) : E) * c u := h
    have h3 := congrArg (fun x => Valued.v (φ x)) h2
    simp only [map_mul, one _ b.2, one_mul] at h3
    rw [← h3]
    exact mul_le_of_le_one_right' (hint _)

variable {G Γ : Type} [Group G] [Group Γ] (ι : Γ →* G)


end Generic

section Support

open GlobalTheory.IdemModTwo GlobalTheory.SplitIdem GlobalTheory.IdemPrime GlobalTheory.UnRep GlobalTheory.Member

variable {D : D7}


theorem cF_ne_one (D : D7) : cF D ≠ 1 := (latHat_eq_hat_and_gram D D.sp.X').2.2.2.2.2.2.1



theorem exists_splitAt_of_isIdemAt {e : AE D} {P : HeightOneSpectrum (𝓞 D.host.E)} (h : Formalism.L2.NTheta.IsIdemAt e P) :
    ∃ v, SplitAt D v e ∧ SplitPl (cF D) v ∧ P.asIdeal.comap (algebraMap (𝓞 D.host.F) (𝓞 D.host.E)) = v.asIdeal := by
  obtain ⟨v, he⟩ := (isSplitIdem_iff e).1 h.1
  obtain ⟨Q, hQ, hQv⟩ := exists_isIdemAt D v e he
  obtain rfl : P = Q := HeightOneSpectrum.ext (Ideal.ext fun x => by
    by_cases hx : x = 0
    · rw [hx]; exact iff_of_true (zero_mem _) (zero_mem _)
    · rw [h.2 x hx, hQ.2 x hx])
  obtain ⟨φ, hφ⟩ := exists_hom he
  refine ⟨v, he, ⟨P.asIdeal, P.isPrime, hQv,
    moved_of_hom (cF D) (fun x => star_star x) (cF_ne_one D) v φ (hom_algebraMap he hφ) (fun x => ?_) P fun x => ?_⟩, hQv⟩
  · rw [← mem_iff he, ← hφ, RingHom.map_mul]
    exact mul_mem_int (finPart_mem he) (AddSubgroup.subset_closure
      ⟨1, fun w => by rw [map_one]; exact one_mem _, x, rfl⟩)
  · by_cases hx : x = 0
    · subst hx
      refine iff_of_true (zero_mem _) ?_
      show Valued.v (φ 0) < 1
      rw [map_zero, map_zero]; exact zero_lt_one
    · have hx0 : Valued.v (φ x) ≠ 0 := by
        rw [Valuation.ne_zero_iff, map_ne_zero]
        exact fun h => hx (Subtype.ext h)
      rw [h.2 x hx, hφ, mem_iff he, map_inv₀, map_inv₀, not_le, one_lt_inv₀ (zero_lt_iff.2 hx0)]




end Support

section Lattices

open GlobalTheory.AdLat GlobalTheory.UnRep GlobalTheory.UnRep.FullReps GlobalTheory.Member

variable {D : D7}








theorem isUnA_gf (V : HSp D) (g : Bridge.Gf V) : IsUnA (cF D) V.gramᵀ g.1.1 := by
  obtain ⟨_, g, rfl⟩ := g
  intro x y
  rw [GlobalTheory.UnitarySplit.hermA_eq, GlobalTheory.UnitarySplit.hermA_eq]
  exact (RatElt.mem_UJ_iff _ _ _).1 (GlobalTheory.UnitarySplit.finHom_mem V g) y x






end Lattices

section Row

open Formalism.L2.DIV

variable {D : D7} {G : Type} [Group G] [Fintype G] {Pl0 T : Type} {A : FamIn D.what₂.LL G Pl0 T D.R.m}
  {Ks : Type} [Field Ks] [NumberField Ks] [Algebra Ks D.what₂.LL] (R : RealDat D A Ks) (i : Fin D.R.m) (t : T)




end Row

end GlobalTheory.RepsCompare

end
