import Mathlib
import Formalism.LocalToGlobal.Columns.CoefCol
import Formalism.LocalToGlobal.Columns.DecoFin
import Development.AbelianVarietyTheory.BlockTheory.GlobalSignature.IndexExponentDegree
import Development.AbelianVarietyTheory.BlockTheory.GlobalSignature.JetSumTable
import Development.AbelianVarietyTheory.BlockTheory.GlobalSignature.CharacterValuation

noncomputable section

namespace GlobalTheory.KerT

open NumberField IsDedekindDomain
open Formalism.BasicNotions Formalism.HermitianLatticesTheory Formalism.MainNotions Formalism.L2.DIV Formalism.L2.Col Formalism.L2.Ker
open GlobalTheory.IndefiniteRowSideFullHecke.IndexExponentDegree (AgreeOff InBox JetsIn moveScal)

variable {X : Fields} {Pr : Primes X} {R : Ranks} (W : Wts X Pr.Word R) (Ch : Chars X Pr R.m)
  (sel : HeightOneSpectrum (𝓞 X.F) → HeightOneSpectrum (𝓞 X.E)) {S : Set ℕ}
  (mu : Tup X.F X.E X.K S) (cst : LocCst X (rowSG Pr sel mu)) (A : Amb X) (u : Pr.Word) (i j : ℕ)

def ker (N : Submodule (𝓞 X.E) (Sp X.E (R.N i))) (fr : Frs X.E (R.N i) (rowSG Pr sel mu))
    (N' : Submodule (𝓞 X.E) (Sp X.E (R.N j))) (fr' : Frs X.E (R.N j) (rowSG Pr sel mu)) (Ξ : HomE X.E (R.N i) (R.N j) → X.K) :
    VV X.K (W.lamTrue u i) →ₗ[X.K] VV X.K (W.lamTrue u j) :=
  kerOf (stepT W Ch sel mu cst A u i (W.lamTrue u j)) (Sall sel mu u) (cAof sel mu cst) (cBof sel mu cst u) N fr N' fr' Ξ

def term {SG SG' : Finset (HeightOneSpectrum (𝓞 X.E))} (d : DecoSet X.E (R.N i) (Pr.vT u) SG)
    (fr : Frs X.E (R.N i) (rowSG Pr sel mu)) (d' : DecoSet X.E (R.N j) (Pr.vT u) SG') (fr' : Frs X.E (R.N j) (rowSG Pr sel mu))
    (Ξ₀ : HomE X.E (R.N i) (R.N j) → X.K) : VV X.K (W.lamTrue u i) →ₗ[X.K] VV X.K (W.lamTrue u j) :=
  ker W Ch sel mu cst A u i j d.1.N fr d'.1.N fr' fun x => phiT X.K d.1 d'.1 x * Ξ₀ x

def InBoxOfRowSelection {a b : ℕ} (N : Submodule (𝓞 X.E) (Sp X.E a)) (N' : Submodule (𝓞 X.E) (Sp X.E b)) (Ξ₀ : HomE X.E a b → X.K) : Prop :=
  InBox (rowSG Pr sel mu) (cAof sel mu cst) (cBof sel mu cst u) N N' Ξ₀

abbrev Framed {n : ℕ} {SB : Finset (HeightOneSpectrum (𝓞 X.E))} (N : Submodule (𝓞 X.E) (Sp X.E n)) (fr : Frs X.E n SB) : Prop :=
  GlobalTheory.IndefiniteRowSideFullHecke.CharacterValuation.IsFrames N fr










def AlcoveAt : Prop :=
  ∀ τ (a b : Fin (R.N j)), 2 * ((W.lamTrue u j τ).w a - (W.lamTrue u j τ).w b + (R.N j : ℤ)) < (Pr.T u : ℤ)

structure Hyp (Z : Dat) {H : D7} (s : Seam H Z.X) (cc : Ideal (𝓞 H.host.K)) (δ : ℂ) (χ : TaylorLogMetric.IdE H → ℂ) (cD : H.what₂.Tau → ℂ)
    (sel : HeightOneSpectrum (𝓞 Z.X.F) → HeightOneSpectrum (𝓞 Z.X.E)) (S : Set ℕ) (mu : Tup Z.X.F Z.X.E Z.X.K S)
    (cst : LocCst Z.X (rowSG Z.Pr sel mu)) (u : Z.Pr.Word) : Prop where
  ok : Z.Ok
  ana : GlobalTheory.IndefiniteRowSideFullHecke.JetSumTable.AnaOk Z s cc δ χ cD
  chiK : GlobalTheory.IndefiniteRowSideFullHecke.CharacterValuation.ChiInK s χ
  isSel : IsSel Z.X sel
  host : hostS H.host.q H.host.d (Z.Pr.g 0) (Z.Pr.g 1) (Set.range Z.Pr.T) ⊆ S
  small : ∀ l ∈ H.host.small, l ∈ S
  cop : ∀ P ∈ Sall sel mu u, Nat.Coprime (Ideal.absNorm cc) (Ideal.absNorm P.asIdeal)
  cst_ok : cst.Ok
  tied : ∃ (m0 : Fin Z.R.m → Formalism.L2.Host.HChar Z.X.E) (eta : Formalism.L2.Host.HChar Z.X.E),
    Z.Ch.Tied Z.sig0 (fun j τ => (Z.W.row τ).e j) m0 eta ∧ MuqTieG (Pr := Z.Pr) (R := Z.R) sel mu cst Z.sig0 m0

section Position

variable {Pr : Primes X} {u : Pr.Word} {SG : Finset (HeightOneSpectrum (𝓞 X.E))} {n : ℕ}

theorem moveHyp_of_notMem (hPr : Pr.Ok) (h : ∀ w ∈ SG, (Pr.T u : 𝓞 X.E) ∉ w.asIdeal) (P : Pr.vT u) :
    MoveHyp (Pr.vT u) SG P := by
  refine ⟨(moveHyp_of_ok hPr u P).ne, (moveHyp_of_ok hPr u P).st, fun w => ⟨fun e => ?_, fun e => ?_⟩⟩
  · apply h w.1 w.2
    rw [e]
    exact T_mem hPr u P
  · apply h w.1 w.2
    rw [e, mem_conjP, map_natCast]
    exact T_mem hPr u P




end Position

variable {sel u} in

theorem T_notMem_rowSG (hPr : Pr.Ok) (hsel : IsSel X sel) (hT : Pr.T u ∈ S) :
    ∀ w ∈ rowSG Pr sel mu, (Pr.T u : 𝓞 X.E) ∉ w.asIdeal := by
  classical
  intro w hw hm
  rcases Finset.mem_union.1 hw with h | h
  · exact T_notMem_vGs hPr u ⟨w, h⟩ hm
  · unfold QE at h
    split_ifs at h with hf
    · obtain ⟨v, hv, rfl⟩ := Finset.mem_image.1 h
      have hv' : v ∈ Qprime (mu : Chr X.F X.E X.K) := hf.mem_toFinset.1 hv
      have hg : GoodPl X.E S v := by
        by_contra hg
        exact hv' (Subgroup.mem_iInf.1 (Subgroup.mem_iInf.1 mu.2.2 v) hg)
      have h1 : (Pr.T u : 𝓞 X.F) ∈ v.asIdeal := by
        rw [← hsel v, Ideal.under_def, Ideal.mem_comap, map_natCast]
        exact hm
      apply hg.2.2
      have h2 : ringChar (𝓞 X.F ⧸ v.asIdeal) = Pr.T u := by
        have := v.isPrime
        have h3 : ((Pr.T u : ℕ) : 𝓞 X.F ⧸ v.asIdeal) = 0 := by
          rw [← map_natCast (Ideal.Quotient.mk v.asIdeal), Ideal.Quotient.eq_zero_iff_mem]
          exact h1
        exact ((Nat.dvd_prime (hPr.T_prime u)).1 (ringChar.dvd h3)).resolve_left CharP.ringChar_ne_one
      show ringChar (𝓞 X.F ⧸ v.asIdeal) ∈ S
      rw [h2]
      exact hT
    · simp at h

variable {W u j} in

theorem alcoveAt_of_sizes {a : ℝ} (h : Sizes Pr W a) (hj : j ≤ R.m) : AlcoveAt W u j := by
  intro τ s t
  have h1 := h.two_spread_lt u j hj τ
  have h0 := R.N_pos j
  rw [DomWeight.spread, dif_pos h0] at h1
  have h2 : (W.lamTrue u j τ).w s ≤ (W.lamTrue u j τ).w ⟨0, h0⟩ := (W.lamTrue u j τ).anti (Nat.zero_le _)
  have h3 : (W.lamTrue u j τ).w ⟨R.N j - 1, by omega⟩ ≤ (W.lamTrue u j τ).w t :=
    (W.lamTrue u j τ).anti (show t.1 ≤ R.N j - 1 by have := t.2; omega)
  omega

namespace Hyp

variable {Z : Dat} {H : D7} {s : Seam H Z.X} {cc : Ideal (𝓞 H.host.K)} {δ : ℂ} {χ : TaylorLogMetric.IdE H → ℂ} {cD : H.what₂.Tau → ℂ}
  {sel : HeightOneSpectrum (𝓞 Z.X.F) → HeightOneSpectrum (𝓞 Z.X.E)} {S : Set ℕ} {mu : Tup Z.X.F Z.X.E Z.X.K S}
  {cst : LocCst Z.X (rowSG Z.Pr sel mu)} {u : Z.Pr.Word}






end Hyp

open Classical in

theorem offBox_indicator {a b : ℕ} (N : Submodule (𝓞 X.E) (Sp X.E a)) (N' : Submodule (𝓞 X.E) (Sp X.E b)) :
    InBoxOfRowSelection sel mu cst u N N' fun x => if x ∈ homAt (rowSG Pr sel mu) N N' then (1 : X.K) else 0 := by
  refine ⟨fun x hx => ?_, fun x y hy => ?_⟩
  · have h : x ∈ homAt (rowSG Pr sel mu) N N' := by
      by_contra h
      exact hx (if_neg h)
    exact Submodule.smul_mem _ _ h
  · obtain ⟨z, hz, rfl⟩ := hy
    have h : ((cBof sel mu cst u : 𝓞 X.E) • (LinearMap.id : HomE X.E a b →ₗ[𝓞 X.E] HomE X.E a b)) z ∈
        homAt (rowSG Pr sel mu) N N' := Submodule.smul_mem _ _ hz
    simp only [Submodule.add_mem_iff_left _ h]

example {n : ℕ} (SB : Finset (HeightOneSpectrum (𝓞 X.E))) : Framed (SB := SB) (stdLat X.E n) fun _ => 1 := fun _ _ => Iff.rfl

example (hPr : Pr.Ok) (P : Pr.vT u) : MoveHyp (Pr.vT u) ∅ P ∧ MoveHyp (Pr.vT u) Pr.vGs P :=
  ⟨moveHyp_of_notMem hPr (by simp) P, moveHyp_of_ok hPr u P⟩

example (P : Pr.vT u) : ¬ MoveHyp (Pr.vT u) {P.1} P := fun h => (h.sg ⟨P.1, Finset.mem_singleton_self _⟩).1 rfl


example {SG SG' : Finset (HeightOneSpectrum (𝓞 X.E))} (d : DecoSet X.E (R.N i) (Pr.vT u) SG)
    (fr : Frs X.E (R.N i) (rowSG Pr sel mu)) (d' : DecoSet X.E (R.N j) (Pr.vT u) SG') (fr' : Frs X.E (R.N j) (rowSG Pr sel mu)) :
    term W Ch sel mu cst A u i j d fr d' fr' (fun _ => 0) = 0 := by
  simp [term, ker, kerOf, latSum]

end GlobalTheory.KerT
