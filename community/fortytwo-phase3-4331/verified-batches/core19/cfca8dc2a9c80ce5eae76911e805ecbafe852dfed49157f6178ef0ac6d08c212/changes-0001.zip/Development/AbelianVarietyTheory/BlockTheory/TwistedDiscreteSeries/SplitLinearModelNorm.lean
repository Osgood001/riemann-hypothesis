import Mathlib
import Formalism.LocalToGlobal.IndefiniteReal.DatumVec

noncomputable section

open Formalism.BasicNotions Formalism.BasicNotions.TH Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.MainNotions.StandardLattice Formalism.L2.Theta Formalism.IndefR.Datum IsDedekindDomain NumberField
open scoped TensorProduct

namespace GlobalTheory.IndefiniteRowSideFullHecke.SplitLinearModelNorm

attribute [local instance] Formalism.BasicNotions.Host.cmStar

def absV (F : Type) [Field F] [NumberField F] (v : HeightOneSpectrum (𝓞 F)) (y : (Fv F v)ˣ) : ℝ :=
  ((Ideal.absNorm v.asIdeal : ℕ) : ℝ) ^ (WithZero.log (Valued.v (y : Fv F v)))


def normV (D : D7) (v : HeightOneSpectrum (𝓞 D.host.F)) : (AE D)ˣ →* (Fv D.host.F v)ˣ :=
  Units.map (((evalV D.host.F v).comp (sndA D.host.F)).toRingHom.toMonoidHom.comp
    (Algebra.norm (AF D.host.F) (S := AE D)))


def absFin (D : D7) (x : (AE D)ˣ) : ℝ := ∏ᶠ v, absV D.host.F v (normV D v x)



example (D : D7) : absFin D 1 = 1 := by simp [absFin, absV]

variable {D : D7}

def subst (S T : HSp D) (g : GA D S) (h : GA D T) (x : WO S T) : WO S T :=
  HMul.hMul (HMul.hMul (mt T h⁻¹) (x : Matrix (Fin T.rank) (Fin S.rank) (AE D))) (mt S g)

example (S T : HSp D) (g : GA D S) (h : GA D T) (x : WO S T) : subst S T g h x = actO S T g⁻¹ h⁻¹ x := by
  simp [subst, actO]





end GlobalTheory.IndefiniteRowSideFullHecke.SplitLinearModelNorm

end
