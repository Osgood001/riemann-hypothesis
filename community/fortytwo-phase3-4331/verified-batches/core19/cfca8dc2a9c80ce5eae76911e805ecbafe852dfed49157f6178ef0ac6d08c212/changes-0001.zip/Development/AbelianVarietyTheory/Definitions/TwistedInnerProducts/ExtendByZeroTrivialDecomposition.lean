import Mathlib
import Development.AbelianVarietyTheory.Definitions.TwistedInnerProducts.TowerEx
import Development.AbelianVarietyTheory.Proofs.DecoratedLatticeProofs.CmHostImaginaryGeneratorNeZero
import Development.AbelianVarietyTheory.Proofs.DecoratedLatticeProofs.WittDecompositionMixedCoordsRankZero
import Development.AbelianVarietyTheory.Proofs.DecoratedLatticeProofs.ThetaHeisenbergConjugationNegHermitianSpace
import Development.AbelianVarietyTheory.Proofs.AdelicLatticeProofs.EqZeroOfLintegralEqZero
import Development.AbelianVarietyTheory.Proofs.AdelicLatticeProofs.RealIdemMulOfReal
import Development.AbelianVarietyTheory.Proofs.AdelicLatticeProofs.MapFinNeg
import Development.AbelianVarietyTheory.Proofs.AdelicLatticeProofs.IsSelfDualCLatFrame
import Development.AbelianVarietyTheory.Proofs.TwistedOperators.InfPartOneSubEInfSmul
import Development.AbelianVarietyTheory.Proofs.TwistedOperators.WeilLatticeVacuumStabilizerSplittingCharacters
import Development.AbelianVarietyTheory.Proofs.TwistedOperators.IsCompactParahoricLevelAndContainsLifts
import Development.AbelianVarietyTheory.Proofs.TwistedOperators.RowBesZeroE
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsWeilDatumPowersUnramifiedEtaTilde
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.AbsNormCoprimeOfSup

noncomputable section

open Formalism.BasicNotions Formalism.BasicNotions.TH Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.MainNotions.StandardLattice Formalism.L2.Theta Formalism.IndefR Formalism.IndefR.Datum Formalism.IndefR.Links MeasureTheory IsDedekindDomain NumberField Matrix
open GlobalTheory.MixModel GlobalTheory.MixPer GlobalTheory.Grow GlobalTheory.Unf GlobalTheory.ChiGrid GlobalTheory.FunObj GlobalTheory.SepRows GlobalTheory.Asc
open scoped TensorProduct
attribute [local instance] Formalism.BasicNotions.Host.cmStar

namespace GlobalTheory.AscInh

variable {D : D7} {ψ : AddChar (AF D.host.F) ℂ}







theorem stab_compact_open (W : HSp D) (β : GL (Fin W.rank) (Lev.EAf D)) :
    IsCompact (Lev.levA W (Formalism.L2.DIV.St β) : Set (GA D W)) ∧
      IsOpen (((Lev.levA W (Formalism.L2.DIV.St β)).subgroupOf (GfC W) : Subgroup (GfC W)) : Set (GfC W)) := by
  have := Formalism.L2.GlobalTheoryTheory.GenusMassVolumes.Unfold.topGroupHA D.sp.cm.sig W.gram
  have ho : IsOpen (((Formalism.L2.DIV.St β).comap (Lev.finE W) : Subgroup (GA D W)) : Set (GA D W)) := by
    refine Subgroup.isOpen_of_mem_nhds _ (g := 1) ?_
    filter_upwards [GlobalTheory.ThetaIntegrand.eventually_princ W β ∅] with κ hh
    exact hh.2.1
  obtain ⟨C, hC, hCm⟩ := GlobalTheory.ParahoricCompact.exists_compact W β
  refine ⟨hC.of_isClosed_subset ((GlobalTheory.Ker.CongTop.isClosed_GfC W).inter (Subgroup.isClosed_of_isOpen _ ho))
    fun k hk => hCm k hk.1 hk.2, ?_⟩
  convert ho.preimage (continuous_subtype_val (p := fun x => x ∈ GfC W)) using 1
  ext k
  exact ⟨fun hk => hk.2, fun hk => ⟨k.2, hk⟩⟩







variable {T : Type} {L : LevCh D T} {sc : Consts} (G : GridData L sc)




end GlobalTheory.AscInh

end
