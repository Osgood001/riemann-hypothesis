import Mathlib
import Formalism.SharpRestriction.Divisibility.LiftErrorLocal
import Formalism.SharpRestriction.GlobalSchurBounds.GL3Theta
import Formalism.LocalRingCardinality.DataKerP
import Formalism.LocalRingCardinality.DataKerI
import Formalism.LocalToGlobal.Divisibility.CoefMod

noncomputable section

namespace GlobalTheory.IndefiniteRowSideFullHecke.IntegralityWeylConditions

open NumberField Formalism.BasicNotions Formalism.MainNotions Formalism.MainNotions.TaylorLogMetric Formalism.MainNotions.GL3Theta



variable {D : D7}




















end GlobalTheory.IndefiniteRowSideFullHecke.IntegralityWeylConditions

end
