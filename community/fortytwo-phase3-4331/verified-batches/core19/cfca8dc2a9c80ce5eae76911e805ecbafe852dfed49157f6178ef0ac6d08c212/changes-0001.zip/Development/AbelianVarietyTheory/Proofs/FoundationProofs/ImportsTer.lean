import Mathlib

namespace GlobalTheory.SpanScalarMembership

open NumberField


end GlobalTheory.SpanScalarMembership
