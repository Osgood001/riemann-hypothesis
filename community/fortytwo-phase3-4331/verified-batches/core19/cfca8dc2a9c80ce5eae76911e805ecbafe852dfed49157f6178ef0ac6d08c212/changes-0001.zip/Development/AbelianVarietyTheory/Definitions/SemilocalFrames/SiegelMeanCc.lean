import Mathlib
import Development.AbelianVarietyTheory.Definitions.SemilocalFrames.GaugeUnfold
import Formalism.SharpRestriction.GlobalSchurBounds.StandardLattice

open MeasureTheory NumberField Matrix Finset IsDedekindDomain
open scoped TensorProduct

noncomputable section

namespace GlobalTheory.GaussMean

open Formalism.MainNotions.S GlobalTheory.Count GlobalTheory.FlagMeas Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.MainNotions.StandardLattice




end GlobalTheory.GaussMean
