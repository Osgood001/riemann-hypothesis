import Mathlib
import Development.AbelianVarietyTheory.Definitions.TwistedInnerProducts.TowerEx

noncomputable section

open Formalism.BasicNotions Formalism.BasicNotions.TH Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.MainNotions.StandardLattice Formalism.L2.Theta Formalism.IndefR Formalism.IndefR.Datum Formalism.IndefR.Links MeasureTheory IsDedekindDomain NumberField Matrix
open GlobalTheory.MixModel GlobalTheory.MixPer GlobalTheory.Grow GlobalTheory.Unf GlobalTheory.ChiGrid GlobalTheory.FunObj GlobalTheory.SepRows
open scoped TensorProduct
attribute [local instance] Formalism.BasicNotions.Host.cmStar

namespace GlobalTheory.Asc

variable {D : D7}

set_option genSizeOfSpec false in
set_option genInjectivity false in

structure Gen (ψ : AddChar (AF D.host.F) ℂ) (V V₀ W : HSp D) (ρ : ℕ) (Y : Type) [MeasurableSpace Y] where
  d : HypDec V V₀ ρ
  χV : (AE D)ˣ →* Circle
  χW : (AE D)ˣ →* Circle
  om : Om V W
  vS : VolM D W.rank ρ
  vN : VolN d
  vb : VolM D ρ V₀.rank
  vU : VolU D ρ
  vW : GlobalTheory.Unf.Vol W
  x₀ : Matrix (Fin W.rank) (Fin ρ) D.host.E
  m : Measure Y
  g : Y → GA D V₀
  Th : Y → GA D V → ℂ

namespace Gen

variable {ψ : AddChar (AF D.host.F) ℂ} {V V₀ W : HSp D} {ρ : ℕ} {Y : Type} [TopologicalSpace Y] [MeasurableSpace Y]
  (a : Gen ψ V V₀ W ρ Y)

structure Is : Prop where
  weil : IsWeilDatumO ψ V W a.χV a.χW a.om
  base : IsBase W a.x₀
  sfin : SFinite a.m
  g : Continuous a.g
  th : ∀ y, IsTh ψ a.d W a.x₀ (a.Th y)
  cont : Continuous fun p : Y × flagN a.d => a.Th p.1 p.2.1
  small : ∃ M : Y → ℝ, Measurable M ∧ (∀ y, ∀ n ∈ flagN a.d, ‖a.Th y n‖ ≤ M y) ∧
    ∀ k : ℕ, Integrable (fun y => M y * quotHeight V₀ (a.g y) ^ k) a.m


def ker (G : GA D W → ℂ) (Φ : WO V W → ℂ) (h : GA D W) : ℂ :=
  G h * ∫ y, fl ψ a.d W a.vS a.vb a.vU (a.Th y) (rat a.x₀) (a.om (a.d.emb0 (a.g y), h) Φ) ∂a.m



end Gen

def strip (W : HSp D) (R : Subgroup (GA D W)) (C : Set (GA D W)) : Set (GA D W) := {h | ∃ r ∈ R, ∃ c ∈ C, ∃ b ∈ GfC W, h = r * c * b}

variable {T : Type} {L : LevCh D T} {sc : Consts} {G : GridData L sc} (W : G.Weil) (M : GlobalTheory.FunObj.Vol G) (v : CoreVol G) (F : Frames G)
  (Ψ : ∀ i, Fn G (.core i)) (u : GA D (Yc D 0) → ℂ)









example (W : HSp D) (R : Subgroup (GA D W)) : (1 : GA D W) ∈ strip W R {1} := ⟨1, one_mem _, 1, rfl, 1, one_mem _, by simp⟩

end GlobalTheory.Asc

end
