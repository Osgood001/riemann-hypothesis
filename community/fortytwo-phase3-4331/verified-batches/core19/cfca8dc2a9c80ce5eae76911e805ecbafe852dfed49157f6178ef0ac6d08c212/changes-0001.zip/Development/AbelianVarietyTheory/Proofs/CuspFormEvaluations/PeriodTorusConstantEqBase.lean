import Mathlib
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.SquareIntegrability.TorusAtPf
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.SquareIntegrability.TorusAtDataPf
import Development.AbelianVarietyTheory.Definitions.ThetaValues.PolyDerivSmulLetter
import Development.AbelianVarietyTheory.Proofs.TorusSplitting.EqTopOfForallEmbAllMem
import Development.AbelianVarietyTheory.Proofs.TorusSplitting.SumCMulImHermCEqSignMulTrace
import Development.AbelianVarietyTheory.Proofs.TorusSplitting.ExistsTorusCoordinates
import Development.AbelianVarietyTheory.Proofs.TorusSplitting.TorusAtExistsOfParts
import Development.AbelianVarietyTheory.Proofs.UnitaryExistence.MemIffConjugateNotMem

open NumberField Matrix
open scoped ComplexConjugate
open ReciprocityTheory.ChartRestriction.G ReciprocityTheory.ChartRestriction.G.FD ReciprocityTheory.ChartRestriction.G.I2
open ReciprocityTheory.ChartRestriction.G.I2.TorusAtDataPf (conj_conj_X)

namespace GlobalTheory.PerTorus

noncomputable section

open ThFr TorusCoord TorusAtAssembly

variable {E : Type} [Field E] [NumberField E] [IsCMField E] {r : ℕ} (X : Data E r)

open Classical in

def dimPer (σ : E →+* ℂ) : ℕ := if σ ∈ X.Ψ then r - X.p0 else X.p0

theorem dimPer_mem {σ : E →+* ℂ} (h : σ ∈ X.Ψ) : dimPer X σ = r - X.p0 := by simp [dimPer, h]

theorem dimPer_not_mem {σ : E →+* ℂ} (h : σ ∉ X.Ψ) : dimPer X σ = X.p0 := by simp [dimPer, h]



open Classical in

def rowFn (i : Idx (dimPer X)) : X.Ψ × Fin r :=
  if h : i.1 ∈ X.Ψ then (⟨i.1, h⟩, ⟨X.p0 + i.2.1, by
      have := lt_of_lt_of_eq i.2.2 (dimPer_mem X h); omega⟩)
  else (⟨ComplexEmbedding.conjugate i.1, conj_mem X h⟩, ⟨X.p0 - 1 - i.2.1, by
      have := lt_of_lt_of_eq i.2.2 (dimPer_not_mem X h); have := X.p0_le; omega⟩)














section Orth

variable {X} {x : Frame X.Ψ r}
  (hx : ∀ τ : X.Ψ, gram τ.1 X.Gm (mat x τ) =
    Matrix.diagonal fun a : Fin r => ((sgn X.p0 (a : ℕ) : ℝ) : ℂ))
include hx










end Orth

section Torus

variable {Y : DataX E r} {x : Frame Y.Ψ r}
  (hx : ∀ τ : Y.Ψ, gram τ.1 Y.Gm (mat x τ) =
    Matrix.diagonal fun a : Fin r => ((sgn Y.p0 (a : ℕ) : ℝ) : ℂ))






variable {w₀ : 𝓞 E} (hw : (w₀ : E) + cc (w₀ : E) = 1)

include hw in
theorem coe_one_sub : ((1 - w₀ : 𝓞 E) : E) = cc (w₀ : E) := by
  rw [← sub_eq_iff_eq_add'.2 hw.symm]
  simp



end Torus

end

end GlobalTheory.PerTorus
