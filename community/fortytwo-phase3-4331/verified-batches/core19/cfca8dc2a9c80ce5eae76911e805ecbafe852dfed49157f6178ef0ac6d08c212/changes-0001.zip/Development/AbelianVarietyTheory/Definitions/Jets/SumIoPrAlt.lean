import Mathlib
import Formalism.HermitianCurvature.BesselNonvanishingReduction
import Formalism.HermitianCurvature.StatementQ
import Formalism.PeriodIntegrals.CapelliEig
import Formalism.HermitianCurvature.HermitianCurvatureProofs.SmoothAdd

open Matrix MeasureTheory Finset
open scoped InnerProductSpace ENNReal

noncomputable section

namespace BranchingSupport

open Formalism.FourierDecayAlt Formalism.FourierDecayAlt.ThreeDimData

abbrev GG (k r : ℕ) : Set (Mx k r) := Formalism.QuantumDeterminants.UH (Formalism.QuantumDeterminants.Hpk k r)

structure Rep (k r : ℕ) : Type 1 where
  H : Type
  [nacg : NormedAddCommGroup H]
  [ips : InnerProductSpace ℂ H]
  [cs : CompleteSpace H]
  σ : Mx k r → (H →L[ℂ] H)

attribute [instance] Rep.nacg Rep.ips Rep.cs

variable {k r : ℕ}

abbrev Rep.sm (R : Rep k r) : Set R.H := PI.UpqRep.smoothVecs (k := k) (r := r) R.σ







structure SmMap (R R' : Rep k r) (T : R.H → R'.H) : Prop where
  mem : ∀ v ∈ R.sm, T v ∈ R'.sm
  add : ∀ v ∈ R.sm, ∀ w ∈ R.sm, T (v + w) = T v + T w
  smul : ∀ (a : ℂ), ∀ v ∈ R.sm, T (a • v) = a • T v
  cont : ∀ W : List (Mx k r), (∀ X ∈ W, PI.UpqRep.InLieHpk k r X) →
    PI.BesselMapUniq.IsCWCont (k := k) (r := r) R.σ
      (fun v => PI.UpqRep.dsigW (k := k) (r := r) R'.σ W (T v))

section tens

variable {ι κ : Type} [Fintype ι] [DecidableEq ι] [Fintype κ] [DecidableEq κ]

def act (ρ : Mx k r → Matrix ι ι ℂ) (R : Rep k r) (g : Mx k r) (x : ι → R.H) : ι → R.H :=
  fun i => ∑ j, ρ g i j • R.σ g (x j)

def hh (Γ : Matrix ι ι ℂ) (R : Rep k r) (x y : ι → R.H) : ℂ := ∑ i, ∑ j, Γ i j * ⟪y i, x j⟫_ℂ



structure TensRaw (ρ : Mx k r → Matrix ι ι ℂ) (R : Rep k r) (RI : κ → Rep k r)
    (io : ∀ I, ι → (RI I).H → R.H) (pr : ∀ I, ι → R.H → (RI I).H) : Prop where
  io_sm : ∀ I c, SmMap (RI I) R (io I c)
  pr_sm : ∀ I c, SmMap R (RI I) (pr I c)
  io_eq : ∀ I, ∀ g ∈ GG k r, ∀ y ∈ (RI I).sm, (fun c => io I c ((RI I).σ g y)) = act ρ R g (fun c => io I c y)
  pr_eq : ∀ I, ∀ g ∈ GG k r, ∀ x : ι → R.H, (∀ c, x c ∈ R.sm) →
    ∑ c, pr I c (act ρ R g x c) = (RI I).σ g (∑ c, pr I c (x c))
  sum_io_pr : ∀ x : ι → R.H, (∀ c, x c ∈ R.sm) → ∀ c, ∑ I, io I c (∑ d, pr I d (x d)) = x c
  pr_io : ∀ I, ∀ y ∈ (RI I).sm, ∑ c, pr I c (io I c y) = y
  pr_io_ne : ∀ I J, I ≠ J → ∀ y ∈ (RI J).sm, ∑ c, pr I c (io J c y) = 0

structure TensH (ρ : Mx k r → Matrix ι ι ℂ) (Γ : Matrix ι ι ℂ) (R : Rep k r) (RI : κ → Rep k r)
    (io : ∀ I, ι → (RI I).H → R.H) (pr : ∀ I, ι → R.H → (RI I).H) (ep : κ → ℝ) : Prop where
  raw : TensRaw ρ R RI io pr
  ep_sq : ∀ I, ep I = 1 ∨ ep I = -1
  iso : ∀ I, ∀ y ∈ (RI I).sm, ∀ y' ∈ (RI I).sm,
    hh Γ R (fun c => io I c y) (fun c => io I c y') = (ep I : ℂ) * ⟪y', y⟫_ℂ
  orth : ∀ I J, I ≠ J → ∀ y ∈ (RI I).sm, ∀ y' ∈ (RI J).sm, hh Γ R (fun c => io I c y) (fun c => io J c y') = 0


end tens







section side

variable {Wp : Type} [NormedAddCommGroup Wp] [InnerProductSpace ℂ Wp] [CompleteSpace Wp]






end side




end BranchingSupport
