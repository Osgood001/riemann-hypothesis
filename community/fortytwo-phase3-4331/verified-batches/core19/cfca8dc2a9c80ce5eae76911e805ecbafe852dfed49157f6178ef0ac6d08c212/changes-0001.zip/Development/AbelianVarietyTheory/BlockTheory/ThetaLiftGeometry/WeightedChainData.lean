import Mathlib
import Formalism.LocalRingCardinality.DataKerI
import Formalism.LocalRingCardinality.DataAmbForm
import Formalism.SharpRestriction.GlobalSchurBounds.GL3Theta
import Formalism.LocalToGlobal.KernelLattices.ThDistC

open NumberField IsDedekindDomain

noncomputable section

namespace GlobalTheory.IndefiniteRowSideFullHecke.WeightedChainData

open Formalism.BasicNotions Formalism.HermitianLatticesTheory Formalism.MainNotions Formalism.L2.DIV Formalism.L2.Col Formalism.L2.Ker

def cpy (E : Type) [Field E] (a b : ℕ) : Sp E a →ₗ[E] Sp E b :=
  LinearMap.pi fun l : Fin b => atNL E a l.1


section Frames

variable (D : D7) {N : ℕ} {Y : Type} (frm : Y → D.what₂.Tau → Matrix (Fin N) (Fin N) ℂ)




end Frames

structure ChainData (D : D7) (u : D.what₂.Word) (μ : D.what₂.Tup) where
  X : Fields
  s : Seam D X
  Pr : Primes X

  w : Pr.Word
  Ch : Chars X Pr D.R.m

  sel : HeightOneSpectrum (𝓞 X.F) → HeightOneSpectrum (𝓞 X.E)
  S : Set ℕ

  xi : Tup X.F X.E X.K S
  cst : LocCst X (rowSG Pr sel xi)
  L : ChIdx X Pr D.R (QE sel (xi : Chr X.F X.E X.K))
  G : ChGlob X D.R.m
  δ : ℂ
  B : Base D D.host.ccK δ
  idl : D.Dt ⧸ D.UO → TaylorLogMetric.IdE D
  O : GL3Theta.LiftObj D (D.chTw u μ)

  lamTop : rowSG Pr sel xi → Submodule (𝓞 X.E) (Sp X.E (D.R.N D.R.m - 1 + 0))

  depth : rowSG Pr sel xi → ℕ

  rep : ∀ i, (D.chTw u μ).cls i →
    Option (L.β i) × DecoF X.E (D.R.N i) (Pr.vT w) ∅ (rowSG Pr sel xi) × Set (Sp X.E (D.R.N i))

namespace ChainData

variable {D : D7} {u : D.what₂.Word} {μ : D.what₂.Tup} (T : ChainData D u μ)

abbrev SB : Finset (HeightOneSpectrum (𝓞 T.X.E)) := rowSG T.Pr T.sel T.xi

abbrev Pt (i : ℕ) : Type := DecoF T.X.E (D.R.N i) (T.Pr.vT T.w) ∅ T.SB

abbrev Lab (i : ℕ) : Type := Option (T.L.β i) × T.Pt i × Set (Sp T.X.E (D.R.N i))

abbrev AutX (i : ℕ) : Type := Sp T.X.E (D.R.N i) ≃ₗ[T.X.E] Sp T.X.E (D.R.N i)

abbrev XP : Type := Sp T.X.E (D.R.N D.R.m - 1 + 0)

def hOf (i : ℕ) (b : Option (T.L.β i)) (P : T.SB) : AutY T.X D.R i :=
  b.elim 1 fun a => T.L.h i a P

open Classical in

def Jtop (P : T.SB) : Subgroup (T.XP ≃ₗ[T.X.E] T.XP) :=
  if P.1 ∈ T.Pr.vGs then
    (if T.cst.sharp then LocE.JGsym P.1 (qOf P.1) D.R.k D.R.rS D.R.r D.R.t (D.R.N D.R.m - 1) 0
      else LocE.JG P.1 (qOf P.1) D.R.k D.R.r D.R.t (D.R.N D.R.m - 1) 0)
  else LocE.JQ P.1 (qOf P.1) D.R.r (D.R.N D.R.m - 1) 0

open Classical in

def lamM (P : T.SB) (h : T.XP ≃ₗ[T.X.E] T.XP) : T.X.K :=
  if P.1 ∈ T.Pr.vGs then
    (if T.cst.sharp then
        LocE.lamGBS (qOf P.1) (psi0P T.Ch P.1) (chiP T.Ch P.1) D.R.k D.R.r D.R.t D.R.m (D.R.N D.R.m - 1) 0 h.toLinearMap
      else LocE.lamGB (qOf P.1) (psi0P T.Ch P.1) (chiP T.Ch P.1) D.R.k D.R.r D.R.t D.R.m (D.R.N D.R.m - 1) 0 h.toLinearMap)
  else LocE.lamQB (resChar (T.xi : Chr T.X.F T.X.E T.X.K) P.1) D.R.r (D.R.N D.R.m - 1) h.toLinearMap

open Classical in

def InTopLat (i : ℕ) (P : T.SB) (y : Sp T.X.E (D.R.N i)) : Prop :=
  cpy T.X.E _ _ y ∈ (if P.1 ∈ T.Pr.vGs then stdAt T.X.E (D.R.N D.R.m - 1 + 0) P.1 else T.lamTop P) ∧
    IntAt P.1 (atNL T.X.E (D.R.N i) (D.R.N D.R.m - 1) y)

open Classical in

def InTopCong (i : ℕ) (P : T.SB) (k : T.AutX i) : Prop :=
  (∀ y, T.InTopLat i P (k y) ↔ T.InTopLat i P y) ∧
    ∀ y, T.InTopLat i P y →
      T.InTopLat i P ((((qOf P.1 : ℕ) : T.X.E) ^ (if P.1 ∈ T.Pr.vGs then 1 else T.depth P))⁻¹ • (k y - y))





def locDatum (i : ℕ) (p : T.Lab i) (p' : T.Lab (i + 1)) (x : HomE T.X.E (D.R.N i) (D.R.N (i + 1))) (P : T.SB) : T.X.K :=
  if i + 2 < D.R.m then
    XiAt T.Ch T.sel T.xi T.cst i P (T.hOf i p.1 P) (T.hOf (i + 1) p'.1 P) (inFr (p.2.1.fr P) (p'.2.1.fr P) x)
  else if i + 2 = D.R.m then
    PsiAt T.Ch T.sel T.xi T.cst i P (T.hOf i p.1 P) (inFr (p.2.1.fr P) (p'.2.1.fr P) x)
      ((p'.2.1.fr P).symm (repY p'.2.2))
  else
    PhiTop T.Ch T.xi T.cst.sharp (D.R.m - 2) P.1
        (cpy T.X.E _ _ ∘ₗ inFr (p.2.1.fr P) (p'.2.1.fr P) x ∘ₗ cpy T.X.E _ _) *
      ftY T.sel T.xi T.cst P
        (((((T.Pr.piT T.w : 𝓞 T.X.E) : T.X.E))⁻¹ • atNL T.X.E (D.R.N (i + 1)) (D.R.N D.R.m - 1)) ∘ₗ
          inFr (p.2.1.fr P) (p'.2.1.fr P) x)
        ((p.2.1.fr P).symm (repY p.2.2))

def datum (i : ℕ) (p : T.Lab i) (p' : T.Lab (i + 1)) (x : HomE T.X.E (D.R.N i) (D.R.N (i + 1))) : T.X.K :=
  phiT T.X.K p.2.1.deco.1 p'.2.1.deco.1 x * ∏ P : T.SB, T.locDatum i p p' x P

def amb : Amb T.X := ambOf T.s T.B (TaylorLogMetric.chiRec D T.idl) T.O.dgen

def theta (i : ℕ) (p : T.Lab i) (p' : T.Lab (i + 1)) : TaylorLogMetric.VC D (D.R.N i) (D.R.N (i + 1)) → ℂ := fun z =>
  thC (T.X.embC T.amb.σ₀) T.amb.δ T.amb.d T.amb.sc T.amb.AA (Sall T.sel T.xi T.w) p.2.1.deco.1.N p'.2.1.deco.1.N
    (levC T.sel T.xi T.cst T.w) (fun x => T.s.σ₀ (T.datum i p p' x))
    (T.amb.e (D.R.N i) (D.R.N (i + 1)) p.2.1.deco.1.N p'.2.1.deco.1.N) fun τ => z (T.s.iT τ)















end ChainData



end GlobalTheory.IndefiniteRowSideFullHecke.WeightedChainData
