import Mathlib
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.SquareIntegrability.TorusAtData
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.FundamentalDomainPointBound
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.ModerateCoefficientPositivity
import Development.AbelianVarietyTheory.Proofs.CuspFormEvaluations.NormalisedThetaNormInvariant
import Development.AbelianVarietyTheory.Proofs.CuspFormEvaluations.FirstMinimumPrincipalTorusAtOrthonormalFrame
import Development.AbelianVarietyTheory.Proofs.CuspFormEvaluations.PeriodTorusConstantEqBase
import Development.AbelianVarietyTheory.Proofs.ModuliProofs.UnimodularSymplecticCoordinatesAndLatticeRank
import Development.AbelianVarietyTheory.Proofs.TorusHaarMeasure.LatDen

open NumberField ReciprocityTheory.ChartRestriction.G.FD ReciprocityTheory.ChartRestriction.G.I2

namespace GlobalTheory.ThetaHol

open Matrix Complex MeasureTheory
open scoped ComplexConjugate Real
open ReciprocityTheory.ChartRestriction.G
open ReciprocityTheory.ChartRestriction.G.Geo.Tor (thetaChar omegaStd hermForm)
open GlobalTheory.ThFr GlobalTheory.CanTh

noncomputable section

section Char

variable {g : ℕ}



end Char

section Conj

variable {E : Type} [Field E] [NumberField E] (T : PT E) {ι : Type} [Fintype ι]
  (e : ι ≃ Idx T.dim)


def cj : Vsp T.dim ≃ₗ[ℝ] EuclideanSpace ℂ ι where
  toFun y := WithLp.toLp 2 fun i => conj (y (e i))
  invFun z := WithLp.toLp 2 fun j => conj (z (e.symm j))
  map_add' y z := by ext i; simp
  map_smul' c y := by ext i; simp
  left_inv y := by ext j; simp
  right_inv z := by ext i; simp



variable (Y : GT ι) (F : EuclideanSpace ℂ ι → ℂ)



variable {T e Y F} (hL : ∀ y, y ∈ T.L ↔ cj T e y ∈ lat Y.b)
  (hka : ∀ y ∈ T.L, Y.ka (cj T e y) = T.eps y) (hF : F ∈ Y.Sec 1)
include hL hka hF




end Conj

section Lattice

variable {E : Type} [Field E] [NumberField E] [IsCMField E] {r : ℕ}

open SemicharIndep in

theorem exists_sign (X : Data E r) : ∃ σ : ℤ, (σ = 1 ∨ σ = -1) ∧ ∀ u v, EF X u v = σ * B X u v := by
  rcases EF_eq_or X with h | h
  · exact ⟨-1, Or.inr rfl, fun u v => by rw [h, EFf_eq]; simp⟩
  · exact ⟨1, Or.inl rfl, fun u v => by rw [h, EFf_eq]; simp⟩

theorem finrank_lattice (X : Data E r) : Module.Free ℤ X.Λ ∧ Module.Finite ℤ X.Λ ∧
    Module.finrank ℤ X.Λ = 2 * (X.Ψ.card * r) := by
  obtain ⟨b, hb⟩ := CMLattice.exists_basis_lattice E r X
  obtain ⟨τ⟩ : Nonempty X.Ψ := by
    obtain ⟨τ⟩ : Nonempty (E →+* ℂ) := inferInstance
    by_cases h : τ ∈ X.Ψ
    · exact ⟨⟨τ, h⟩⟩
    · exact ⟨⟨_, TorusCoord.conj_mem X h⟩⟩
  let f : X.Λ →+ Submodule.span ℤ (Set.range b) :=
    { toFun := fun v => ⟨fun τ => Data.emb τ.1 v, (hb _).2 ⟨v, v.2, rfl⟩⟩
      map_zero' := by ext τ a; simp [Data.emb]
      map_add' := fun u v => by ext τ a; simp [Data.emb] }
  have hf : Function.Bijective f := by
    constructor
    · intro u v h
      ext a
      exact τ.1.injective (congrFun (congrFun (congrArg Subtype.val h) τ) a)
    · rintro ⟨y, hy⟩
      obtain ⟨v, hv, rfl⟩ := (hb y).1 hy
      exact ⟨⟨v, hv⟩, rfl⟩
  let c := (b.restrictScalars ℤ).map (LinearEquiv.ofBijective f.toIntLinearMap hf).symm
  exact ⟨Module.Free.of_basis c, Module.Finite.of_basis c, by
    rw [Module.finrank_eq_card_basis c, Fintype.card_fin]⟩

open SemicharIndep in

theorem exists_isSympl (X : DataX E r) :
    ∃ bas : (Fin (X.Ψ.card * r) ⊕ Fin (X.Ψ.card * r) → ℤ) ≃ₗ[ℤ] X.Λ, IsSympl X.toData bas := by
  obtain ⟨h1, h2, h3⟩ := finrank_lattice X.toData
  obtain ⟨σ, hσ, hE⟩ := exists_sign X.toData
  have hσ2 : σ * σ = 1 := by rcases hσ with rfl | rfl <;> rfl
  choose k hk using fun u v : X.Λ => B_int X u.2 v.2
  have hl (u u' v) : k (u + u') v = k u v + k u' v := by
    have := B_add_left X.toData u u' v
    rw [← Submodule.coe_add, hk, hk, hk] at this
    exact_mod_cast this
  have hr (u v v') : k u (v + v') = k u v + k u v' := by
    have := B_add_right X.toData u v v'
    rw [← Submodule.coe_add, hk, hk, hk] at this
    exact_mod_cast this
  have hsk (u v) : k u v = -k v u := by
    have := B_skew X.toData u v
    rw [hk, hk] at this
    exact_mod_cast this
  let β : LinearMap.BilinForm ℤ X.Λ :=
    (AddMonoidHom.mk' (fun u => (AddMonoidHom.mk' (fun v => -σ * k u v) fun v v' => by
      rw [hr, mul_add]).toIntLinearMap) fun u u' => by
        ext v
        change -σ * k (u + u') v = -σ * k u v + -σ * k u' v
        rw [hl, mul_add]).toIntLinearMap
  have hβ (u v) : β u v = -σ * k u v := rfl
  have hsurj : Function.Surjective β := by
    intro φ
    obtain ⟨u, hu, h⟩ := X.EF_perf (σ • φ).toAddMonoidHom
    refine ⟨⟨u, hu⟩, LinearMap.ext fun v => ?_⟩
    have h' := h v
    rw [EFf_eq, hk ⟨u, hu⟩ v] at h'
    have h'' : σ * φ v = -k ⟨u, hu⟩ v := by exact_mod_cast h'
    rw [hβ]
    linear_combination (-σ) * h'' + φ v * hσ2
  have hinj : Function.Injective β := by
    rw [injective_iff_map_eq_zero]
    intro x hx
    refine (Module.forall_dual_apply_eq_zero_iff ℤ x).1 fun φ => ?_
    obtain ⟨u, rfl⟩ := hsurj φ
    have := LinearMap.congr_fun hx u
    rw [hβ, LinearMap.zero_apply] at this
    rw [hβ, hsk]
    linear_combination -this
  obtain ⟨bas, hbas⟩ := unimodular_symplectic_coordinates_and_lattice_rank.1 X.Λ β _
    ⟨hinj, hsurj⟩ (fun x => by
      have := hsk x x
      rw [hβ, show k x x = 0 by omega, mul_zero]) h3
  refine ⟨bas, fun a b => ?_⟩
  rw [hE, hk, ← hbas, hβ]
  push_cast
  ring

variable {X : Data E r} {g : ℕ} {bas : (Fin g ⊕ Fin g → ℤ) ≃ₗ[ℤ] X.Λ}
  (idx : Fin g ≃ X.Ψ × Fin r)

theorem exists_coord (hs : IsSympl X bas) (v : Fin r → E) : ∃ a b : Fin g → ℝ, ∀ x ∈ X.dom,
    hMat X bas idx x *ᵥ (per X x v ∘ idx) =
      (fun i => (b i : ℂ)) + tauMat X bas idx x *ᵥ fun i => (a i : ℂ) := by
  obtain ⟨n, hn, hv⟩ := (LatDen.latDen r X).1 v
  obtain ⟨m, hm⟩ := bas.surjective ⟨_, hv⟩
  refine ⟨fun i => m (.inr i) / n, fun i => m (.inl i) / n, fun x hx => ?_⟩
  have h := hMat_mulVec_per X bas idx (isUnit_det_perMat idx hs hx) m
  have hn' : (n : ℂ) ≠ 0 := Nat.cast_ne_zero.2 hn.ne'
  have e : per X x v ∘ idx = (n : ℂ)⁻¹ • (per X x (bas m) ∘ idx) := by
    funext i
    rw [hm]
    simp [per_smul, hn']
  have e2 (s : Fin g → Fin g ⊕ Fin g) : (fun i => (((m (s i) : ℝ) / n : ℝ) : ℂ)) =
      (n : ℂ)⁻¹ • fun i => (m (s i) : ℂ) := by
    funext i
    simp [div_eq_inv_mul]
  rw [e, mulVec_smul, h, e2, e2, mulVec_smul, smul_add]




end Lattice

section Adapted

variable {E : Type} [Field E] [NumberField E] [IsCMField E] {r : ℕ} {X : Data E r}
  {x : Frame X.Ψ r} (A : TorusAt X x)





end Adapted

section Main

variable {E : Type} [Field E] [NumberField E] [IsCMField E] {r : ℕ} {X : DataX E r} {g : ℕ}
  {bas : (Fin g ⊕ Fin g → ℤ) ≃ₗ[ℤ] X.Λ}



end Main


end

end GlobalTheory.ThetaHol
