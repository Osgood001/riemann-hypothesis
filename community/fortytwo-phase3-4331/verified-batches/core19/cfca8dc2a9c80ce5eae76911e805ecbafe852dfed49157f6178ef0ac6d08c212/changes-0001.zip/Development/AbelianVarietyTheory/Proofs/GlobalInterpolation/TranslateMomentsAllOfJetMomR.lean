import Mathlib
import Formalism.LocalToGlobal.KernelLattices.DeterminantCokernelCount.JetMomEquiv
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.VacuumEntireAndNormalizedJetsAlgebraic
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.TranslateMomentsAll
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.WopAddLattice
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.ExistsCoprimeMulIntegral
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.ExistsRatNear
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.ExistsContinuousCharacter
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.AlgEntireTranslate
import Development.AbelianVarietyTheory.Proofs.JetHarmonics.ExistsTraceOne
import Development.AbelianVarietyTheory.BlockTheory.JetGauges.MomentCombSplitting

noncomputable section

open NumberField Formalism.BasicNotions Formalism.MainNotions Formalism.MainNotions.TaylorLogMetric Formalism.L2.Ker GlobalTheory.IndefiniteRowSideFullHecke.ParabolicPointMembership GlobalTheory.PlaceComponents GlobalTheory.QuadSubfield
open Formalism.L2.GlobalTheoryTheory.IntegralLatticeDensity

namespace GlobalTheory.MomT.FromComb

variable {D : D7} {p : ℕ} [Fact p.Prime] (lam : Qbar →+* ℂ_[p])






variable {cc : Ideal (𝓞 D.host.K)} {δ : ℂ} {N N' : ℕ} {L : Submodule (𝓞 D.host.E) (Fin N → D.host.E)}
  {L' : Submodule (𝓞 D.host.E) (Fin N' → D.host.E)}























end GlobalTheory.MomT.FromComb
