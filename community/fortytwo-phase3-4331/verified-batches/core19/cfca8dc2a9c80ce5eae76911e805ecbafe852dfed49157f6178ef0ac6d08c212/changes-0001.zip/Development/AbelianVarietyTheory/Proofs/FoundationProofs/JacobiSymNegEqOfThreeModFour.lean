import Mathlib
import Formalism.GL3MeanSquares.PrimeCountAsymptoticInProgressions

namespace GlobalTheory



end GlobalTheory
