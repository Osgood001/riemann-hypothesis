import Mathlib
import Formalism.LocalToGlobal.IndefiniteReal.ScalarOnPartsFull
import Development.AbelianVarietyTheory.Definitions.Foundations.HermitianSpaceBaseLatticeEqFrameLattice

noncomputable section

namespace GlobalTheory.AdelicU.Model

open scoped TensorProduct NNReal Matrix
open NumberField IsDedekindDomain Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.UG

variable {F E : Type} [Field F] [NumberField F] [Field E] [NumberField E] [Algebra F E] (σ : E →ₐ[F] E)

variable (E) in

def hyp : Matrix (Fin 2) (Fin 2) E := !![0, 1; 1, 0]

omit [NumberField F] [NumberField E] in
theorem isHermND_hyp : IsHermND σ (hyp E) :=
  ⟨fun i j => by fin_cases i <;> fin_cases j <;> simp [hyp], by simp [hyp, Matrix.det_fin_two]⟩

omit [NumberField E] in
theorem tmul_mul_inv {v : HeightOneSpectrum (𝓞 F)} (a : (Fv F v)ˣ) :
    ((a : Fv F v) ⊗ₜ[F] (1 : E)) * (((a⁻¹ : (Fv F v)ˣ) : Fv F v) ⊗ₜ[F] (1 : E)) = 1 := by
  rw [Algebra.TensorProduct.tmul_mul_tmul, Units.mul_inv, mul_one]; rfl

omit [NumberField E] in
theorem inv_mul_tmul {v : HeightOneSpectrum (𝓞 F)} (a : (Fv F v)ˣ) :
    (((a⁻¹ : (Fv F v)ˣ) : Fv F v) ⊗ₜ[F] (1 : E)) * ((a : Fv F v) ⊗ₜ[F] (1 : E)) = 1 := by
  rw [mul_comm, tmul_mul_inv]

variable (E) in

def torMat {v : HeightOneSpectrum (𝓞 F)} (a : (Fv F v)ˣ) : Matrix (Fin 2) (Fin 2) (Fv F v ⊗[F] E) :=
  !![(a : Fv F v) ⊗ₜ[F] (1 : E), 0; 0, ((a⁻¹ : (Fv F v)ˣ) : Fv F v) ⊗ₜ[F] (1 : E)]

omit [NumberField E] in
theorem torMat_mul_inv {v : HeightOneSpectrum (𝓞 F)} (a : (Fv F v)ˣ) : torMat E a * torMat E a⁻¹ = 1 := by
  have h1 := tmul_mul_inv (E := E) a
  have h2 := inv_mul_tmul (E := E) a
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp only [torMat, Matrix.mul_apply, Fin.sum_univ_two, inv_inv] <;> simp [-Units.val_inv_eq_inv_val, h1, h2, Algebra.TensorProduct.one_def]










variable {σ} in

theorem height_ofInf_definite (h : IsCMExt F E σ) {n : ℕ} (w : InfinitePlace F)
    (x : GArch σ (1 : Matrix (Fin n) (Fin n) E) w) : height σ 1 (embArch σ 1 w x) = 1 := by
  have key : ∀ y : GArch σ (1 : Matrix (Fin n) (Fin n) E) w,
      matHom _ σ 1 y ∈ UJ (Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes.sigR w.Completion σ) 1 := fun y => by
    have : y.1 ∈ UJ (Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes.sigR w.Completion σ) (JR w.Completion (1 : Matrix (Fin n) (Fin n) E)) := y.2
    rwa [show JR w.Completion (1 : Matrix (Fin n) (Fin n) E) = 1 by simp [JR]] at this
  rw [height_embArch, htInf, htOf_eq_one]
  exact ⟨normInf_le_one_of_unitary h (key x), normInf_le_one_of_unitary h (inv_mem (key x))⟩

section Supp

omit [NumberField E] in
theorem map_map_tens {R R' R'' : Type} [CommRing R] [Algebra F R] [CommRing R'] [Algebra F R'] [CommRing R'']
    [Algebra F R''] (φ : R →ₐ[F] R') (ψ : R' →ₐ[F] R'') (y : R ⊗[F] E) :
    Algebra.TensorProduct.map ψ (AlgHom.id F E) (Algebra.TensorProduct.map φ (AlgHom.id F E) y) =
      Algebra.TensorProduct.map (ψ.comp φ) (AlgHom.id F E) y := by
  rw [← AlgHom.comp_apply, ← Algebra.TensorProduct.map_comp, AlgHom.comp_id]

omit [NumberField E] in
theorem adTens_eq_one {y : AF F ⊗[F] E} (h1 : ∀ w, compInf F E w y = 1) (h2 : ∀ v, compFin F E v y = 1) : y = 1 := by
  have := GlobalTheory.AutFunCounterexample.tens_inj (F := F) (E := E) (A := Ainf F) (B := Af F) (n := 1) (Matrix.of fun _ _ => y)
    (by
      ext i j
      rw [Subsingleton.elim i j, Matrix.one_apply_eq]
      exact GlobalTheory.AutFunCompare.infTens_ext fun w => (map_map_tens _ _ y).trans ((h1 w).trans (map_one _).symm))
    (by
      ext i j
      rw [Subsingleton.elim i j, Matrix.one_apply_eq]
      exact GlobalTheory.LatticeLocalGlobal.ext_components _ _ fun v =>
        (map_map_tens _ _ y).trans ((h2 v).trans (map_one _).symm))
  exact congrFun (congrFun this 0) 0


open Formalism.BasicNotions Formalism.BasicNotions.TH Formalism.L2.Theta
attribute [local instance] Formalism.BasicNotions.Host.cmStar




end Supp

section More







end More

end GlobalTheory.AdelicU.Model
