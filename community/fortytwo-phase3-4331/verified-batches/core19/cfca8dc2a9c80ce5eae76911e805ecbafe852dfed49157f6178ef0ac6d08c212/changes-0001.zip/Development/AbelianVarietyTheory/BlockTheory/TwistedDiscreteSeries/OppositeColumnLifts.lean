import Mathlib
import Formalism.LocalToGlobal.IndefiniteReal.LinksChar
import Development.AbelianVarietyTheory.Definitions.TwistedInnerProducts.NodeYPredEqChainVertexAtRowZeroLast

noncomputable section

open Formalism.BasicNotions Formalism.BasicNotions.TH Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.MainNotions.StandardLattice Formalism.MainNotions.S MeasureTheory IsDedekindDomain NumberField Matrix
open Formalism.L2.Theta Formalism.L2.DIV Formalism.L2.Indef Formalism.DivisionValues
open Formalism.IndefR Formalism.IndefR.Links Formalism.IndefR.Mult Formalism.IndefR.Datum
open GlobalTheory.Grid
open scoped Pointwise TensorProduct InnerProductSpace

attribute [local instance] Formalism.BasicNotions.Host.cmStar

namespace GlobalTheory.IndefiniteRowSideFullHecke.IwahoriMembership

variable {D : D7}

section Local

variable (D) in

abbrev Oh : Subring (Datum.EAf D) := Formalism.L2.Herm.intAf D.host.F D.host.E

def InI (I : Ideal (𝓞 D.host.E)) (z : Datum.EAf D) : Prop := ∃ h : z ∈ Oh D, (⟨z, h⟩ : Oh D) ∈ idS D.host.F I



variable (e : AE D) (I : Ideal (𝓞 D.host.E)) (ν : (AE D)ˣ →* Circle)





variable {a a' d₁ d₂ : ℕ}




variable (hd : a + a' = d₁ + d₂) (h : GL (Fin (d₁ + d₂)) (AE D))






end Local

section Models

variable (ψ : AddChar (AF D.host.F) ℂ)

open Classical in

def IsDatOwn (ε : Bool) (S T : Node D) (e : AE D) (f₀ : WO S.V T.V → ℂ)
    (φ : Matrix (Fin T.V.rank) (Fin S.V.rank) (Datum.EAf D) → ℂ) (f : WO S.V T.V → ℂ) : Prop :=
  IsSBHalf e (latO (sgn ε S.V) T.V S.Λ T.Λ fun _ => True)
      (fun x : WO S.V T.V => if IsHalf e x then φ (frMapO S.V T.V S.β T.β x) else 0) ∧
    IsThetaAt ψ (symplO (sgn ε S.V) T.V) (heisO ψ (sgn ε S.V) T.V) e (latO (sgn ε S.V) T.V S.Λ T.Λ fun _ => True) 1 f₀
      (fun x : WO S.V T.V => if IsHalf e x then φ (frMapO S.V T.V S.β T.β x) else 0) f

open Classical in

def IsDatDual (S T : Node D) (e : AE D) (f₀ : WO S.V T.V → ℂ)
    (φ : Matrix (Fin S.V.rank) (Fin T.V.rank) (Datum.EAf D) → ℂ) (f : WO S.V T.V → ℂ) : Prop :=
  IsSBHalf (cA D e) (latO S.V T.V S.Λ T.Λ fun _ => True)
      (fun x : WO S.V T.V => if IsHalf (cA D e) x then φ (frMapAdj S.V T.V S.β T.β x) else 0) ∧
    IsThetaAt ψ (symplO S.V T.V) (heisO ψ S.V T.V) (cA D e) (latO S.V T.V S.Λ T.Λ fun _ => True) 1 f₀
      (fun x : WO S.V T.V => if IsHalf (cA D e) x then φ (frMapAdj S.V T.V S.β T.β x) else 0) f

end Models

section Grid

variable {G₀ : Type} [Group G₀] [Fintype G₀] {Pl0 T : Type} {A : FamIn D.what₂.LL G₀ Pl0 T D.R.m}
  {Ks : Type} [Field Ks] [NumberField Ks] [Algebra Ks D.what₂.LL] {R : RealDat D A Ks} (G : GridDat R)



open Classical in

def places (t : T) : Finset (Pl D.host.E) := G.toPlaceDat.W R.Pg ∪ R.Q t

open Classical in

def depth (t : T) : Ideal (𝓞 D.host.E) := G.lvl R * ∏ w ∈ R.Q t \ G.toPlaceDat.W R.Pg, w.asIdeal





variable (D) in

def cTot (c : T → ℕ → ℕ → ℂ) (t : T) : ℂ := ∏ i ∈ Finset.range D.R.m, ∏ j ∈ Finset.range D.R.m, c t i j

structure Pt where

  X : ∀ i j, WO (G.V (i + 1) j).V (G.V i j).V

  th : ∀ i j, WO (G.V i j).V (G.V i (j + 1)).V

variable {G} in

def Pt.AgreeOff (i j : ℕ) (p q : Pt G) : Prop :=
  (∀ i' j', ¬ (i' = i ∧ (j' = j ∨ j' = j + 1)) → p.X i' j' = q.X i' j') ∧
    ∀ i' j', ¬ (j' = j ∧ (i' = i ∨ i' = i + 1)) → p.th i' j' = q.th i' j'

















end Grid



section Basic₂




variable {G₀ : Type} [Group G₀] [Fintype G₀] {Pl0 T : Type} {A : FamIn D.what₂.LL G₀ Pl0 T D.R.m}
  {Ks : Type} [Field Ks] [NumberField Ks] [Algebra Ks D.what₂.LL] {R : RealDat D A Ks} {G : GridDat R}




end Basic₂

end GlobalTheory.IndefiniteRowSideFullHecke.IwahoriMembership

end
