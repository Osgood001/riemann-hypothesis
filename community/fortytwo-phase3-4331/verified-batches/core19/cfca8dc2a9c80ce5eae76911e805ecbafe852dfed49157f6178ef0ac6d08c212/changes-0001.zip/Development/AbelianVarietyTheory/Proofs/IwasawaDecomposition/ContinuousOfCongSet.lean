import Mathlib
import Development.AbelianVarietyTheory.Definitions.AutomorphicMembership.TrueColumnChoicesHeckeCharReferenceEqOne
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.UnitOpenAndCongrOpen
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.IdeleCharacterTrivialOnLocalUnits
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.HeckeCharacterUnramifiedAeAndExistsLevel
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.ExistsProdInfMulFinPart
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.UnderEqOfMapEq

noncomputable section

open NumberField IsDedekindDomain Formalism.BasicNotions Formalism.FrobeniusOrbits Neutral.B1 ReciprocityTheory.Neutral.Bridge.HCFR Formalism.L2.Host GlobalTheory.Mem GlobalTheory.Mem.Chr GlobalTheory.Mem.Col2
open Formalism.L2.DIV (AfE RInt congN congU intU suppAt inertAt wildAt ratId idF GoodPl)
open scoped TensorProduct

namespace GlobalTheory.Mem.ReadEx

variable {F E : Type} [Field F] [NumberField F] [Field E] [NumberField E] [Algebra F E]

variable (F E) in

def toIdl : (AfE F E)ˣ →* Ideles E :=
  Units.map ((MonoidHom.inr (InfiniteAdeleRing E) (FiniteAdeleRing (𝓞 E) E)).comp
    (afIso F E : AfE F E →* FiniteAdeleRing (𝓞 E) E))


theorem toIdl_snd (y : (AfE F E)ˣ) : (toIdl F E y : AdeleRing (𝓞 E) E).2 = afIso F E y := rfl

theorem toIdl_finAf (a : Ideles E) : toIdl F E (finAf F E a) = finPartI E a :=
  Units.ext (Prod.ext rfl (afIso_finAf F E a))

theorem mem_intU_iff (y : (AfE F E)ˣ) : y ∈ intU F E ↔ toIdl F E y ∈ unitIdl E := by
  constructor
  · rintro ⟨h1, h2⟩ P
    have k1 : Valued.v (afIso F E (y : AfE F E) P) ≤ 1 := (mem_rInt_iff F E _).1 h1 P
    have k2 : Valued.v (afIso F E ((y⁻¹ : (AfE F E)ˣ) : AfE F E) P) ≤ 1 := (mem_rInt_iff F E _).1 h2 P
    have h : afIso F E (y : AfE F E) P * afIso F E ((y⁻¹ : (AfE F E)ˣ) : AfE F E) P = 1 := by
      have := congrArg (fun z => afIso F E z P) y.mul_inv
      simp only [map_mul, map_one] at this
      exact this
    have h3 := congrArg (Valued.v : Valuation (P.adicCompletion E) _) h
    rw [map_mul, map_one] at h3
    refine le_antisymm k1 ?_
    rw [← h3]
    exact mul_le_of_le_one_right' k2
  · intro h
    refine ⟨(mem_rInt_iff F E _).2 fun P => (h P).le, (mem_rInt_iff F E _).2 fun P => ?_⟩
    have h' := (unitIdl E).inv_mem h
    rw [← map_inv] at h'
    exact (h' P).le

theorem mem_congU_iff (I : Ideal (RInt F E)) (y : (AfE F E)ˣ) :
    y ∈ congU F E I ↔ y ∈ intU F E ∧ ∃ z ∈ I, (z : AfE F E) = y - 1 := by
  constructor
  · rintro ⟨u, hu, rfl⟩
    exact ⟨⟨(u : RInt F E).2, ((u⁻¹ : (RInt F E)ˣ) : RInt F E).2⟩, _, (Formalism.L2.DIV.mem_kerRed I u).1 hu, rfl⟩
  · rintro ⟨⟨h1, h2⟩, z, hz, e⟩
    refine ⟨⟨⟨_, h1⟩, ⟨_, h2⟩, Subtype.ext y.mul_inv, Subtype.ext y.inv_mul⟩,
      (Formalism.L2.DIV.mem_kerRed I _).2 ?_, Units.ext rfl⟩
    convert hz using 1
    exact Subtype.ext e.symm

theorem mem_congN_iff (N : ℕ) (y : (AfE F E)ˣ) :
    y ∈ congN F E N ↔ y ∈ intU F E ∧ ∃ c ∈ RInt F E, c * N = y - 1 := by
  unfold congN
  rw [mem_congU_iff]
  refine and_congr_right fun _ => ⟨?_, ?_⟩
  · rintro ⟨z, hz, e⟩
    obtain ⟨c, rfl⟩ := Ideal.mem_span_singleton'.1 hz
    exact ⟨c, c.2, by simpa using e⟩
  · rintro ⟨c, hc, e⟩
    exact ⟨⟨c, hc⟩ * N, Ideal.mem_span_singleton'.2 ⟨_, rfl⟩, by simpa using e⟩

def congSet (L : Type) [Field L] [NumberField L] (N : ℕ) : Set (Ideles L) :=
  {a | a ∈ unitIdl L ∧ ∀ v, (algebraMap L (FiniteAdeleRing (𝓞 L) L) (N : L)⁻¹ * ((a : AdeleRing (𝓞 L) L).2 - 1)) v ∈
    v.adicCompletionIntegers L}

theorem isOpen_congSet (L : Type) [Field L] [NumberField L] (N : ℕ) : IsOpen (congSet L N) := by
  have hV : IsOpen {a : FiniteAdeleRing (𝓞 L) L | ∀ v, a v ∈ v.adicCompletionIntegers L} :=
    RestrictedProduct.isOpen_forall_mem (fun v => Valued.isOpen_valuationSubring _)
  have c1 : Continuous fun a : Ideles L => (a : AdeleRing (𝓞 L) L).2 := continuous_snd.comp Units.continuous_val
  exact UnitOpen.isOpen_unitIdl.inter (hV.preimage (continuous_const.mul (c1.sub continuous_const)))

theorem one_mem_congSet (L : Type) [Field L] [NumberField L] (N : ℕ) : (1 : Ideles L) ∈ congSet L N := by
  refine ⟨one_mem _, fun v => ?_⟩
  have h : ((1 : Ideles L) : AdeleRing (𝓞 L) L).2 = 1 := rfl
  rw [h, sub_self, mul_zero]
  exact zero_mem _

theorem continuous_of_congSet {L : Type} [Field L] [NumberField L] (ψ : Ideles L →* ℂˣ) (N : ℕ)
    (h : ∀ a ∈ congSet L N, ψ a = 1) : Continuous ψ := by
  refine continuous_of_continuousAt_one ψ ?_
  refine (continuousAt_const (y := (1 : ℂˣ))).congr ?_
  filter_upwards [(isOpen_congSet L N).mem_nhds (one_mem_congSet L N)] with a ha
  exact (h a ha).symm

theorem inv_mul_mul_nat {L : Type} [Field L] [NumberField L] {N : ℕ} (hN : 0 < N) (z : FiniteAdeleRing (𝓞 L) L) :
    algebraMap L (FiniteAdeleRing (𝓞 L) L) (N : L)⁻¹ * z * N = z := by
  rw [mul_right_comm, ← map_natCast (algebraMap L (FiniteAdeleRing (𝓞 L) L)), ← map_mul,
    inv_mul_cancel₀ (Nat.cast_ne_zero.2 hN.ne'), map_one, one_mul]

theorem finAf_mem_congN {N : ℕ} (hN : 0 < N) {a : Ideles E} (ha : a ∈ congSet E N) : finAf F E a ∈ congN F E N := by
  rw [mem_congN_iff, mem_intU_iff, toIdl_finAf]
  refine ⟨ha.1, (afIso F E).symm (algebraMap E _ (N : E)⁻¹ * ((a : AdeleRing (𝓞 E) E).2 - 1)), ?_, ?_⟩
  · rw [mem_rInt_iff, RingEquiv.apply_symm_apply]
    exact ha.2
  · apply (afIso F E).injective
    rw [map_mul, RingEquiv.apply_symm_apply, map_natCast, inv_mul_mul_nat hN, map_sub, map_one, afIso_finAf]

theorem finAf_diag (k : Eˣ) : finAf F E (diagUnits E k) = ratId F E k :=
  Units.ext ((afIso F E).injective ((afIso_finAf F E _).trans (afIso_tmul_one F E k).symm))

theorem exists_reads {K : Type} [Field K] (σ : K →+* ℂ) (μ : Formalism.L2.DIV.Chr F E K) (h1 : (ratId F E).range ≤ μ.ker)
    (h2 : μ ∈ Formalism.L2.DIV.openChr F E K) : ∃ ξ : HChar E, Reads σ μ ξ := by
  obtain ⟨N, hN, h2⟩ := h2
  refine ⟨⟨(Units.map (σ : K →* ℂ)).comp (μ.comp (finAf F E)), continuous_of_congSet _ N fun a ha => ?_, fun k => ?_⟩,
    fun a => rfl⟩
  · have h : μ (finAf F E a) = 1 := h2 (finAf_mem_congN hN ha)
    rw [MonoidHom.comp_apply, MonoidHom.comp_apply, h, map_one]
  · have h : μ (ratId F E k) = 1 := h1 ⟨k, rfl⟩
    rw [MonoidHom.comp_apply, MonoidHom.comp_apply, finAf_diag, h, map_one]




variable (F) in

def evP (P : HeightOneSpectrum (𝓞 E)) : AfE F E →+* P.adicCompletion E where
  toFun z := afIso F E z P
  map_one' := by rw [map_one]; rfl
  map_mul' a b := by rw [map_mul]; rfl
  map_zero' := by rw [map_zero]; rfl
  map_add' a b := by rw [map_add]; rfl

theorem le_exp_neg_one {γ : WithZero (Multiplicative ℤ)} (h : γ < 1) : γ ≤ WithZero.exp (-((1 : ℕ) : ℤ)) := by
  rcases eq_or_ne γ 0 with rfl | h0
  · exact zero_le'
  · rw [← WithZero.exp_log h0] at h ⊢
    rw [← WithZero.exp_zero, WithZero.exp_lt_exp] at h
    rw [WithZero.exp_le_exp]
    omega


theorem map_toIdl_eq_one {ξ : HChar E} (ht : ∀ P, ξ.TameAt P) {y : (AfE F E)ˣ} (hy : y ∈ intU F E)
    (h : ∀ P, ¬ ξ.UnrAt P → Valued.v (evP F P (y - 1)) ≤ WithZero.exp (-((1 : ℕ) : ℤ))) : ξ.1 (toIdl F E y) = 1 := by
  have hu := (mem_intU_iff y).1 hy
  refine LocTriv.eq_one_of_local E ξ.1 ξ.2.1 _ hu (fun _ => rfl) fun P x hx => ?_
  have hx1 : IsUnitAt P x := by
    unfold IsUnitAt
    rw [hx]
    exact hu P
  by_cases hP : ξ.UnrAt P
  · exact hP x hx1
  · refine ht P x hx1 ?_
    have h1 := h P hP
    rw [map_sub, map_one] at h1
    rw [hx]
    exact h1






variable (F E) in

def finF : Ideles F →* (AfE F E)ˣ :=
  (idF F E).comp (Units.map (MonoidHom.snd (InfiniteAdeleRing F) (FiniteAdeleRing (𝓞 F) F)))







end GlobalTheory.Mem.ReadEx

end
