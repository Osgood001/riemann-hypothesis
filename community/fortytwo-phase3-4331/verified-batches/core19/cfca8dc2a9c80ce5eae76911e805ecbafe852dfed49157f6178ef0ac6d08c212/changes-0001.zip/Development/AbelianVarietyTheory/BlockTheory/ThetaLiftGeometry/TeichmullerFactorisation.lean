import Mathlib
import Formalism.LocalRingCardinality.DataKerI
import Formalism.SharpRestriction.GlobalSchurBounds.GL3Theta
import Formalism.LocalToGlobal.KernelLattices.LateralTheory

noncomputable section

open NumberField Formalism.BasicNotions Formalism.MainNotions Classical

namespace GlobalTheory.IndefiniteRowSideFullHecke.TeichmullerFactorisation




section Beta

variable {l d : ℕ} [Fact l.Prime] [NeZero d]


def TeichInv (be : MvPowerSeries (ZMod d) ℂ_[l]) : Prop :=
  ∀ u : ℂ_[l], u ^ (l ^ d - 1) = 1 →
    MvPowerSeries.rescale (fun s : ZMod d => if Even s.val then u ^ (l ^ s.val) else (u ^ (l ^ s.val))⁻¹) be = be

def degEven (n : ZMod d →₀ ℕ) : ℕ := ∑ s : ZMod d, if Even s.val then n s else 0

def degOdd (n : ZMod d →₀ ℕ) : ℕ := ∑ s : ZMod d, if Even s.val then 0 else n s

def NoLowTerms (be : MvPowerSeries (ZMod d) ℂ_[l]) : Prop :=
  ∀ n : ZMod d →₀ ℕ, (degEven n = 0 ∨ degOdd n = 0 ∨ (degEven n = 1 ∧ degOdd n = 1)) → MvPowerSeries.coeff n be = 0



example : NoLowTerms (0 : MvPowerSeries (ZMod d) ℂ_[l]) ∧ TeichInv (0 : MvPowerSeries (ZMod d) ℂ_[l]) :=
  ⟨fun _ _ => by simp, fun _ _ => map_zero _⟩

example : ¬ NoLowTerms (MvPowerSeries.monomial (Finsupp.single (0 : ZMod 2) 1 + Finsupp.single 1 1) (1 : ℂ_[l])) := by
  intro h
  have := h (Finsupp.single (0 : ZMod 2) 1 + Finsupp.single 1 1) (Or.inr (Or.inr ⟨?_, ?_⟩))
  · simp at this
  all_goals
    have hu : (Finset.univ : Finset (ZMod 2)) = {0, 1} := by decide
    have h01 : (0 : ZMod 2) ≠ 1 := by decide
    have hv : (1 : ZMod 2).val = 1 := rfl
    simp [degEven, degOdd, hu, Finset.sum_pair h01, hv, h01, h01.symm]

end Beta

section Local

variable (D : D7) {l : ℕ} [Fact l.Prime] (lam : TaylorLogMetric.Qbar →+* ℂ_[l])








end Local












end GlobalTheory.IndefiniteRowSideFullHecke.TeichmullerFactorisation
