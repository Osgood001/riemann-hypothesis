import Mathlib
import Development.AbelianVarietyTheory.Statements.PlaceShiftStatements.DefiniteBound
import Development.AbelianVarietyTheory.Proofs.UnitaryExistence.ExistsIdempotentIsUnitOneAddOrSubAdele
import Development.AbelianVarietyTheory.Proofs.UnitaryExistence.Hilbert90AdeleRingTensorQuadratic
import Development.AbelianVarietyTheory.Proofs.AdelicLatticeProofs.MemRangeOfOneTmulMem

namespace GlobalTheory.UCls.NormOne

open NumberField IsDedekindDomain GlobalTheory.AdLat
open scoped TensorProduct nonZeroDivisors

variable {F E : Type} [Field F] [NumberField F] [Field E] [NumberField E] [Algebra F E]

omit [NumberField E] in
theorem sg_tmul (c : E ≃ₐ[F] E) (a : FiniteAdeleRing (𝓞 F) F) (x : E) :
    sg (FiniteAdeleRing (𝓞 F) F) c (a ⊗ₜ x) = a ⊗ₜ c x := by
  simp [sg]

omit [NumberField E] in
theorem sg_sg (c : E ≃ₐ[F] E) (hcc : ∀ x, c (c x) = x) (z : RA F E) :
    sg (FiniteAdeleRing (𝓞 F) F) c (sg (FiniteAdeleRing (𝓞 F) F) c z) = z := by
  induction z using TensorProduct.induction_on with
  | zero => simp
  | tmul a x => rw [sg_tmul, sg_tmul, hcc]
  | add x y hx hy => rw [map_add, map_add, hx, hy]

omit [NumberField E] in

theorem finiteAdele_quadratic_exists_unit_eq_mul_sg (c : E ≃ₐ[F] E) (hcc : ∀ x, c (c x) = x)
    (hfix : ∀ x, c x = x → ∃ t : F, x = algebraMap F E t) (hc : c ≠ 1) (u : RA F E)
    (hu : u * sg (FiniteAdeleRing (𝓞 F) F) c u = 1) :
    ∃ x : (RA F E)ˣ, (x : RA F E) = u * sg (FiniteAdeleRing (𝓞 F) F) c x := by
  have hT : ∀ z : RA F E, ∃ t : FiniteAdeleRing (𝓞 F) F,
      z + sg (FiniteAdeleRing (𝓞 F) F) c z = t ⊗ₜ 1 := by
    intro z
    induction z using TensorProduct.induction_on with
    | zero => exact ⟨0, by simp⟩
    | tmul a x =>
      obtain ⟨t, ht⟩ := hfix (x + c x) (by rw [map_add, hcc, add_comm])
      refine ⟨t • a, ?_⟩
      rw [sg_tmul, ← TensorProduct.tmul_add, ht, Algebra.algebraMap_eq_smul_one,
        TensorProduct.smul_tmul]
    | add x y hx hy =>
      obtain ⟨t, ht⟩ := hx
      obtain ⟨t', ht'⟩ := hy
      refine ⟨t + t', ?_⟩
      rw [map_add, TensorProduct.add_tmul, ← ht, ← ht']; ring
  obtain ⟨y, hy⟩ : ∃ y, c y ≠ y := by
    by_contra h
    push Not at h
    exact hc (AlgEquiv.ext h)
  obtain ⟨t, ht⟩ := hT u
  obtain ⟨e, he, hun⟩ := GlobalTheory.AdIdem.finite_part (𝓞 F) F ((2 : F)⁻¹ • t)
  let ι : FiniteAdeleRing (𝓞 F) F →+* RA F E := Algebra.TensorProduct.includeLeftRingHom
  have hι : ∀ a, ι a = a ⊗ₜ 1 := fun a => rfl
  let κ : E →ₐ[F] RA F E := Algebra.TensorProduct.includeRight
  have hκ : ∀ a, κ a = 1 ⊗ₜ a := fun a => rfl
  have h2 : IsUnit (2 : RA F E) := by
    have := (IsUnit.mk0 (2 : F) two_ne_zero).map (algebraMap F (RA F E))
    rwa [map_ofNat] at this
  refine hilbert90_involution_of_idempotent_unit (sg (FiniteAdeleRing (𝓞 F) F) c : _ →+* _) (sg_sg c hcc) u (κ (y - c y)) (ι e)
    (ι ((2 : F)⁻¹ • t)) hu ?_ ?_ h2 ?_ ?_ ?_ ?_
  · change sg _ c _ = _
    rw [← map_neg, hκ, hκ, sg_tmul, map_sub, hcc, neg_sub]
  · exact (IsUnit.mk0 _ (sub_ne_zero.2 hy.symm)).map κ
  · rw [← map_mul, he]
  · change sg _ c _ = _
    rw [hι, sg_tmul, map_one]
  · change u + sg _ c u = _
    rw [ht, two_mul, ← map_add, ← add_smul, hι]
    norm_num
  · have := hun.map ι
    simpa only [map_add, map_mul, map_sub, map_one] using this

omit [NumberField E] in
theorem one_tmul_natCast (d : ℕ) :
    ((1 : FiniteAdeleRing (𝓞 F) F) ⊗ₜ[F] (d : E) : RA F E) = d :=
  map_natCast (Algebra.TensorProduct.includeRight : E →ₐ[F] RA F E) d

omit [NumberField E] in
theorem one_tmul_mul (x y : E) :
    ((1 : FiniteAdeleRing (𝓞 F) F) ⊗ₜ[F] (x * y) : RA F E) = 1 ⊗ₜ[F] x * 1 ⊗ₜ[F] y := by
  rw [Algebra.TensorProduct.tmul_mul_tmul, one_mul]



omit [NumberField E] in

theorem exists_quot {z w' : RA F E} {I I' : Ideal (𝓞 E)} {a b : 𝓞 E}
    (hab : Ideal.span {a} * I ≤ Ideal.span {b} * I')
    (hz : ∃ x ∈ I, ∃ e ∈ I, ∃ h ∈ hat1 F (Set.range (algebraMap (𝓞 E) E)),
        z = (1 : FiniteAdeleRing (𝓞 F) F) ⊗ₜ[F] (x : E) +
          (1 : FiniteAdeleRing (𝓞 F) F) ⊗ₜ[F] (e : E) * h)
    (hw : ∀ x ∈ I', w' * (1 : FiniteAdeleRing (𝓞 F) F) ⊗ₜ[F] (x : E) ∈
        hat1 F (Set.range (algebraMap (𝓞 E) E))) :
    ∃ k ∈ hat1 F (Set.range (algebraMap (𝓞 E) E)),
      (1 : FiniteAdeleRing (𝓞 F) F) ⊗ₜ[F] (a : E) * z * w' =
        (1 : FiniteAdeleRing (𝓞 F) F) ⊗ₜ[F] (b : E) * k := by
  obtain ⟨x, hx, e, he, h, hh, rfl⟩ := hz
  have key : ∀ x ∈ I, ∃ x' ∈ I', ((1 : FiniteAdeleRing (𝓞 F) F) ⊗ₜ[F] (a : E) : RA F E) * 1 ⊗ₜ[F] (x : E)
      = 1 ⊗ₜ[F] (b : E) * 1 ⊗ₜ[F] (x' : E) := by
    intro x hx
    obtain ⟨x', hx', e⟩ := Ideal.mem_span_singleton_mul.1
      (hab (Ideal.mul_mem_mul (Ideal.mem_span_singleton_self a) hx))
    refine ⟨x', hx', ?_⟩
    rw [← one_tmul_mul, ← one_tmul_mul]
    congr 1
    exact_mod_cast e.symm
  obtain ⟨x', hx', ex⟩ := key x hx
  obtain ⟨e', he', ee⟩ := key e he
  refine ⟨_, add_mem (hw x' hx') (GlobalTheory.AdIdem.mul_mem_hat F E (hw e' he') hh), ?_⟩
  linear_combination w' * ex + w' * h * ee


end GlobalTheory.UCls.NormOne

open NumberField Matrix GlobalTheory.AdLat GlobalTheory.UCls ReciprocityTheory.ChartRestriction.G.FD
open scoped TensorProduct

