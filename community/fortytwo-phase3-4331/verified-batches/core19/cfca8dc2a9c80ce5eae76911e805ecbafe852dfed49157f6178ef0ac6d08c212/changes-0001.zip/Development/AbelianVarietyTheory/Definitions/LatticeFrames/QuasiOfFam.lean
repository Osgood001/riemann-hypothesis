import Mathlib
import Development.AbelianVarietyTheory.Definitions.LatticeFrames.IsQuasiFam

noncomputable section

open Formalism.BasicNotions Formalism.BasicNotions.TH Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.MainNotions.StandardLattice Formalism.L2.Theta Formalism.IndefR.Datum MeasureTheory IsDedekindDomain NumberField Matrix
open GlobalTheory.MixModel GlobalTheory.MixPer GlobalTheory.Grow
open scoped TensorProduct
attribute [local instance] Formalism.BasicNotions.Host.cmStar

namespace GlobalTheory.Unf.FB

variable {D : D7} {ψ : AddChar (AF D.host.F) ℂ} {σ : ℕ}

def x0 (B : BesLev D σ) : Mx D B.V.rank (σ + 1) := xLast B.d (vecB B.o B.ζ)

def zl (B : BesLev D σ) : Mx D B.L.rank (σ + 1) := zEll B.L (σ + 1) B.ζ






def th (J : JacLev D (σ + 1)) (ψ : AddChar (AF D.host.F) ℂ) (B : BesLev D σ) (y : WO J.W₀ B.L → ℂ) (n : GA D J.W) : ℂ :=
  star (jacS ψ J.d B.L (zl B) n y 0) * star (psiFlag ψ J.d n)

variable {J : JacLev D (σ + 1)} {B : BesLev D σ} (s : StepFB ψ J B)









end GlobalTheory.Unf.FB

end
