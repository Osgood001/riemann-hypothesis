import Mathlib
import Development.AbelianVarietyTheory.Definitions.LatticeFrames.SplitPart
import Development.AbelianVarietyTheory.Proofs.TwistedOperators.WeilActionSchrodingerModelFiniteIdempotent
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsSelfDualCHLat
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.IdempotentMulEqZeroOfOrthogonal
open Formalism.BasicNotions Formalism.BasicNotions.TH Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.MainNotions.StandardLattice Formalism.L2.Theta Formalism.IndefR Formalism.IndefR.Datum Formalism.IndefR.Links Formalism.L2.Forms Formalism.L2.Ker Formalism.UG
open NumberField IsDedekindDomain Matrix MeasureTheory GlobalTheory.Mem GlobalTheory.Mem.Col2 GlobalTheory.MixPer GlobalTheory.Core.Rk GlobalTheory.AdForm
open scoped TensorProduct Classical
attribute [local instance] Formalism.BasicNotions.Host.cmStar

noncomputable section
namespace GlobalTheory.SplitMove
variable {D : D7}

def intSub (D : D7) (n : ℕ) : Submodule (𝓞 D.host.E) (Fin n → D.host.E) where
  carrier := intVec D n
  add_mem' := fun ha hb k => (ha k).add (hb k)
  zero_mem' := fun _ => isIntegral_zero
  smul_mem' := fun c x hx k => by
    show IsIntegral ℤ ((c : D.host.E) * x k)
    exact (RingOfIntegers.isIntegral_coe c).mul (hx k)

theorem coe_intSub (n : ℕ) : ((intSub D n : Submodule (𝓞 D.host.E) (Fin n → D.host.E)) : Set (Fin n → D.host.E)) = intVec D n := rfl

set_option maxHeartbeats 1000000 in
theorem hat_intVec_iff (D : D7) (n : ℕ) (z : Fin n → GlobalTheory.AdLat.RA D.host.F D.host.E) :
    z ∈ GlobalTheory.AdLat.hat D.host.F (intVec D n) ↔
      ∀ i, Algebra.TensorProduct.comm D.host.F (Formalism.L2.Herm.Af D.host.F) D.host.E (z i) ∈ Formalism.L2.Herm.intAf D.host.F D.host.E := by
  set cm := Algebra.TensorProduct.comm D.host.F (Formalism.L2.Herm.Af D.host.F) D.host.E

  have mono : ∀ m ∈ Submonoid.closure ((Set.range fun x : Formalism.UG.intOE D.host.E => (x : D.host.E) ⊗ₜ[D.host.F] (1 : Formalism.L2.Herm.Af D.host.F)) ∪
      Set.range fun y : Formalism.UG.intAd D.host.F => (1 : D.host.E) ⊗ₜ[D.host.F] (y : Formalism.L2.Herm.Af D.host.F)),
      ∃ x : D.host.E, IsIntegral ℤ x ∧ ∃ a : Formalism.L2.Herm.Af D.host.F, a ∈ Formalism.UG.intAd D.host.F ∧ m = x ⊗ₜ[D.host.F] a := by
    intro m hm
    induction hm using Submonoid.closure_induction with
    | mem m hm =>
      rcases hm with ⟨⟨x, b, rfl⟩, rfl⟩ | ⟨⟨y, hy⟩, rfl⟩
      · exact ⟨algebraMap (𝓞 D.host.E) D.host.E b, RingOfIntegers.isIntegral_coe b, 1, one_mem _, rfl⟩
      · exact ⟨1, isIntegral_one, y, hy, rfl⟩
    | one => exact ⟨1, isIntegral_one, 1, one_mem _, rfl⟩
    | mul m m' _ _ h h' =>
      obtain ⟨x, hx, a, ha, rfl⟩ := h
      obtain ⟨x', hx', a', ha', rfl⟩ := h'
      exact ⟨x * x', hx.mul hx', a * a', mul_mem ha ha', by rw [Algebra.TensorProduct.tmul_mul_tmul]⟩
  have single : ∀ (i : Fin n) (t : D.host.E ⊗[D.host.F] Formalism.L2.Herm.Af D.host.F), t ∈ Formalism.L2.Herm.intAf D.host.F D.host.E →
      Pi.single i (cm.symm t) ∈ GlobalTheory.AdLat.hat D.host.F (intVec D n) := by
    intro i t ht
    rw [Formalism.L2.Herm.intAf, Formalism.UG.tensInt, Subring.mem_closure_iff] at ht
    induction ht using AddSubgroup.closure_induction with
    | mem m hm =>
      obtain ⟨x, hx, a, ha, rfl⟩ := mono m hm
      refine AddSubgroup.subset_closure ⟨a, ha, Pi.single i x, fun k => ?_, ?_⟩
      · by_cases hk : k = i
        · subst hk; simpa using hx
        · rw [Pi.single_eq_of_ne hk]; exact isIntegral_zero
      · funext k
        by_cases hk : k = i
        · subst hk; simp [cm]
        · simp [Pi.single_eq_of_ne hk]
    | zero => simp
    | add s t _ _ hs ht => rw [map_add, Pi.single_add]; exact add_mem hs ht
    | neg s _ hs => rw [map_neg, Pi.single_neg]; exact neg_mem hs
  constructor
  · intro hz
    induction hz using AddSubgroup.closure_induction with
    | mem w hw =>
      obtain ⟨a, ha, x, hx, rfl⟩ := hw
      intro i
      have : cm (a ⊗ₜ[D.host.F] x i) = (x i ⊗ₜ[D.host.F] (1 : Formalism.L2.Herm.Af D.host.F)) * ((1 : D.host.E) ⊗ₜ[D.host.F] a) := by
        simp [cm, Algebra.TensorProduct.tmul_mul_tmul]
      rw [this]
      refine mul_mem (Subring.subset_closure (Or.inl ⟨⟨x i, ⟨⟨x i, hx i⟩, rfl⟩⟩, rfl⟩))
        (Subring.subset_closure (Or.inr ⟨⟨a, ha⟩, rfl⟩))
    | zero => intro i; simp
    | add s t _ _ hs ht => intro i; rw [Pi.add_apply, map_add]; exact add_mem (hs i) (ht i)
    | neg s _ hs => intro i; rw [Pi.neg_apply, map_neg]; exact neg_mem (hs i)
  · intro hz
    rw [← Finset.univ_sum_single z]
    refine sum_mem fun i _ => ?_
    have h1 := single i _ (hz i)
    rwa [AlgEquiv.symm_apply_apply] at h1

theorem dual_intVec (D : D7) (n : ℕ) (v : Fin n → D.host.E) :
    (∀ y ∈ intVec D n, ∑ a, ∑ b, v a * (1 : Matrix (Fin n) (Fin n) D.host.E) a b * GlobalTheory.Member.cF D (y b) ∈
      (1 : FractionalIdeal (nonZeroDivisors (𝓞 D.host.E)) D.host.E)) ↔ v ∈ intVec D n := by
  have es : ∀ y : Fin n → D.host.E, ∑ a, ∑ b, v a * (1 : Matrix (Fin n) (Fin n) D.host.E) a b * GlobalTheory.Member.cF D (y b) =
      ∑ a, v a * GlobalTheory.Member.cF D (y a) := fun y => by
    refine Finset.sum_congr rfl fun a _ => ?_
    simp [Matrix.one_apply]
  have mem : ∀ x : D.host.E, x ∈ (1 : FractionalIdeal (nonZeroDivisors (𝓞 D.host.E)) D.host.E) ↔ IsIntegral ℤ x := by
    intro x
    rw [FractionalIdeal.mem_one_iff]
    constructor
    · rintro ⟨b, rfl⟩; exact RingOfIntegers.isIntegral_coe b
    · intro hx; exact ⟨⟨x, hx⟩, rfl⟩
  simp only [es, mem]
  constructor
  · intro h i
    have hi := h (Pi.single i 1) (fun k => by
      by_cases hk : k = i
      · subst hk; simp only [Pi.single_eq_same]; exact isIntegral_one
      · rw [Pi.single_eq_of_ne hk]; exact isIntegral_zero)
    have e : ∑ a, v a * GlobalTheory.Member.cF D ((Pi.single i (1 : D.host.E) : Fin n → D.host.E) a) = v i := by
      rw [Finset.sum_eq_single i]
      · simp
      · intro b _ hb; rw [Pi.single_eq_of_ne hb, map_zero, mul_zero]
      · intro hi; exact absurd (Finset.mem_univ i) hi
    rw [e] at hi
    exact hi
  · intro hv y hy
    refine IsIntegral.sum _ fun a _ => (hv a).mul ?_
    exact (hy a).map ((GlobalTheory.Member.cF D : D.host.E →+* D.host.E).toIntAlgHom)

theorem intSub_fg (n : ℕ) : (intSub D n).FG := by
  let φ : (Fin n → 𝓞 D.host.E) →ₗ[𝓞 D.host.E] (Fin n → D.host.E) :=
    LinearMap.pi fun i => (Algebra.linearMap (𝓞 D.host.E) D.host.E).comp (LinearMap.proj i)
  have e : intSub D n = Submodule.map φ ⊤ := by
    ext x
    constructor
    · intro hx
      refine ⟨fun i => ⟨x i, hx i⟩, trivial, ?_⟩
      funext i; rfl
    · rintro ⟨y, -, rfl⟩ i
      exact RingOfIntegers.isIntegral_coe (y i)
  rw [e]
  exact (Module.Finite.fg_top (R := 𝓞 D.host.E) (M := Fin n → 𝓞 D.host.E)).map φ

theorem intSub_span (n : ℕ) : Submodule.span D.host.E (intSub D n : Set (Fin n → D.host.E)) = ⊤ := by
  refine eq_top_iff.2 ?_
  rw [← (Pi.basisFun D.host.E (Fin n)).span_eq]
  refine Submodule.span_mono ?_
  rintro _ ⟨i, rfl⟩ k
  rw [Pi.basisFun_apply]
  by_cases h : i = k
  · subst h; simp only [Pi.single_eq_same]; exact isIntegral_one
  · rw [Pi.single_eq_of_ne' h]; exact isIntegral_zero

instance intSub_isLattice (n : ℕ) : Submodule.IsLattice D.host.E (intSub D n) := ⟨intSub_fg n, intSub_span n⟩

theorem sum_swap_one (n : ℕ) (x y : Fin n → D.host.E) :
    ∑ i, ∑ j, star (x i) * (1 : Matrix (Fin n) (Fin n) D.host.E) i j * y j =
      ∑ a, ∑ b, y a * (1 : Matrix (Fin n) (Fin n) D.host.E) a b * GlobalTheory.Member.cF D (x b) := by
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun a _ => Finset.sum_congr rfl fun b _ => ?_
  change star (x b) * (1 : Matrix (Fin n) (Fin n) D.host.E) b a * y a = y a * (1 : Matrix (Fin n) (Fin n) D.host.E) a b * star (x b)
  rw [Matrix.one_apply, Matrix.one_apply]
  by_cases h : a = b
  · subst h; simp; ring
  · simp [h, Ne.symm h]


theorem latOf_eq (V : HSp D) (g : GA D V) (N : Submodule (𝓞 D.host.E) (Fin V.rank → D.host.E))
    (hN : Moves V rfl g N) :
    (N : Set (Fin V.rank → D.host.E)) = GlobalTheory.AdLat.latOf D.host.F (finHom V g).1 (intVec D V.rank) := by
  have inv : ∀ y, (finHom V g⁻¹).1 *ᵥ ((finHom V g).1 *ᵥ y) = y := fun y => by
    rw [Matrix.mulVec_mulVec, map_inv, Units.inv_mul, Matrix.one_mulVec]
  have inv' : ∀ y, (finHom V g).1 *ᵥ ((finHom V g⁻¹).1 *ᵥ y) = y := fun y => by
    rw [Matrix.mulVec_mulVec, map_inv, Units.mul_inv, Matrix.one_mulVec]
  have ent : ∀ (x : Fin V.rank → D.host.E) i,
      Algebra.TensorProduct.comm D.host.F (Formalism.L2.Herm.Af D.host.F) D.host.E
        (((finHom V g⁻¹).1 *ᵥ GlobalTheory.AdLat.fv D.host.F x) i) =
      (finM V rfl g⁻¹ *ᵥ fun j => eToEAf D (x j)) i := by
    intro x i
    simp only [GlobalTheory.AdForm.finM, Matrix.mulVec, dotProduct, map_sum, map_mul, Matrix.reindex_apply,
      finCongr_refl, Equiv.refl_symm, Equiv.coe_refl, Matrix.submatrix_id_id]
    refine Finset.sum_congr rfl fun j _ => ?_
    congr 1
  ext x
  change x ∈ N ↔ GlobalTheory.AdLat.fv D.host.F x ∈ (finHom V g).1.mulVec '' _
  rw [hN x]
  constructor
  · intro hx
    refine ⟨(finHom V g⁻¹).1 *ᵥ GlobalTheory.AdLat.fv D.host.F x, (hat_intVec_iff D V.rank _).2 fun i => ?_, inv' _⟩
    rw [ent]; exact hx i
  · rintro ⟨y, hy, hxy⟩ i
    rw [← ent, ← hxy, inv]
    exact (hat_intVec_iff D V.rank y).1 hy i

theorem exists_eq_latOf (V : HSp D) (g : GA D V) (N : Submodule (𝓞 D.host.E) (Fin V.rank → D.host.E))
    (hN : Moves V rfl g N) : N.FG ∧ Submodule.span D.host.E (N : Set (Fin V.rank → D.host.E)) = ⊤ ∧
      (GlobalTheory.AdLat.hat D.host.F (N : Set (Fin V.rank → D.host.E)) : Set (Fin V.rank → GlobalTheory.AdLat.RA D.host.F D.host.E)) =
        (finHom V g).1.mulVec '' (GlobalTheory.AdLat.hat D.host.F (intVec D V.rank)) := by
  obtain ⟨Λ, hΛ, hfg, hsp, hhat⟩ := GlobalTheory.AdLat.exists_lattice_latOf D.host.F D.host.E V.rank (intSub D V.rank)
    (finHom V g) (intSub_fg _) (intSub_span _)
  obtain rfl : Λ = N := SetLike.coe_injective (hΛ.trans (latOf_eq V g N hN).symm)
  exact ⟨hfg, hsp, hhat⟩


theorem selfDual_move (V : HSp D) (hV : V.gram = 1) (g : GA D V) (N : Submodule (𝓞 D.host.E) (Fin V.rank → D.host.E))
    (hN : Moves V rfl g N) : IsSelfDualC V N := by
  obtain ⟨hfg, hsp, -⟩ := exists_eq_latOf V g N hN
  refine ⟨⟨hfg, hsp⟩, fun y => ?_⟩
  obtain ⟨-, -, -, -, c2, -⟩ := GlobalTheory.Member.latHat_eq_hat_and_gram D V
  have hU := GlobalTheory.RepsCompare.isUnA_gf V (Formalism.IndefR.FWT.fin V g)
  rw [hV, Matrix.transpose_one] at hU
  have key := GlobalTheory.AdLat.latOf_selfDual D.host.F D.host.E V.rank (intSub D V.rank) (GlobalTheory.Member.cF D) 1 1 (finHom V g)
    (intSub_fg _) (intSub_span _) c2 (fun a b => by
      rw [Matrix.one_apply, Matrix.one_apply]
      by_cases h : a = b
      · subst h; simp
      · simp [h, Ne.symm h]) (by simp) one_ne_zero (fun v => dual_intVec D V.rank v) hU
  rw [coe_intSub, ← latOf_eq V g N hN] at key
  rw [hV, ← SetLike.mem_coe, ← key y]
  refine forall_congr' fun x => imp_congr_right fun _ => ?_
  rw [sum_swap_one, FractionalIdeal.mem_one_iff]

variable {S T : HSp D}




end GlobalTheory.SplitMove

namespace GlobalTheory.SplitMove


end GlobalTheory.SplitMove
