import Mathlib
import Formalism.DoubleCosetMeasures.StatementV

noncomputable section

open MeasureTheory Matrix ComplexConjugate ValuativeRel Formalism.DoubleCosetMeasures

namespace GlobalTheory.IndefiniteRowSideFullHecke.LocalIntegralGL

section Algebraic

variable {F : Type} [Field F] {r t : ℕ}












end Algebraic

section Local

variable {F : Type} [Field F] [ValuativeRel F]





end Local


end GlobalTheory.IndefiniteRowSideFullHecke.LocalIntegralGL
