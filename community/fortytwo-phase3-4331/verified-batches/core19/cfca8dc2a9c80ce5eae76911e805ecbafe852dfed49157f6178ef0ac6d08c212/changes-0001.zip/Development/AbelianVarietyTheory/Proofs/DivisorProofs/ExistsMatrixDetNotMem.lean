import Mathlib
import Formalism.LocalToGlobal.ProjectiveLattices.ThClass
import Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.ExistsEqSumIndicatorOfRightInvariant
import Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.ProjectiveOfFg
import Development.AbelianVarietyTheory.Counterexamples.LevelGroupExamples.ZeroNotAdmissibleOfRankPos
import Development.AbelianVarietyTheory.Counterexamples.JetSurvey.UnimodularStandardLattice

set_option autoImplicit false

noncomputable section

open NumberField IsDedekindDomain Formalism.L2.Pj GlobalTheory.IndefiniteRowSideFullHecke.UnitaryAdjointCongruence ReciprocityTheory.ChartRestriction.G ReciprocityTheory.ChartRestriction.G.Geo.Tor
open scoped Matrix

namespace GlobalTheory.DatumMove

section Algebra

variable {O Q n : Type*} [CommRing O] [AddCommGroup Q] [Module O Q] [Fintype n] [DecidableEq n]






end Algebra

section Arith

variable {E : Type} [Field E] [NumberField E] [IsCMField E] {n : ℕ}

open GlobalTheory.RepTrivial GlobalTheory.LevelPairing


private theorem span_singleton_smul_le_iff {R M : Type*} [CommRing R] [AddCommGroup M] [Module R M] (k : R)
    (N N' : Submodule R M) : Ideal.span {k} • N ≤ N' ↔ ∀ x ∈ N, k • x ∈ N' := by
  rw [Submodule.smul_le]
  constructor
  · intro h x hx
    exact h _ (Ideal.mem_span_singleton_self _) x hx
  · intro h r hr x hx
    obtain ⟨c, rfl⟩ := Ideal.mem_span_singleton'.1 hr
    rw [mul_smul]
    exact N'.smul_mem c (h x hx)

omit [IsCMField E] in

theorem trivAt_act {γ : Matrix (Fin n) (Fin n) E} {Λ : GenLat E n} {m : ℕ}
    (h : (actLat γ ⟨stdLat E n⟩).TrivAt m) (hΛ : Λ.TrivAt m) : (actLat γ Λ).TrivAt m := by
  obtain ⟨k1, hk1, h1, h1'⟩ := h
  obtain ⟨k2, hk2, h2, h2'⟩ := hΛ
  rw [span_singleton_smul_le_iff] at h1 h1' h2 h2'
  refine ⟨k1 * k2, Nat.Coprime.mul hk1 hk2, (span_singleton_smul_le_iff _ _ _).2 ?_, (span_singleton_smul_le_iff _ _ _).2 ?_⟩
  · intro y hy
    obtain ⟨x, hx, rfl⟩ := Submodule.mem_map.1 hy
    have := h1 _ (Submodule.mem_map_of_mem (f := (Matrix.mulVecLin γ).restrictScalars (𝓞 E)) (h2 x hx))
    rw [map_smul, smul_smul] at this
    rw [Nat.cast_mul]
    exact this
  · intro y hy
    obtain ⟨x, hx, hxy⟩ := Submodule.mem_map.1 (h1' y hy)
    have := Submodule.mem_map_of_mem (f := (Matrix.mulVecLin γ).restrictScalars (𝓞 E)) (h2' x hx)
    rw [map_smul, hxy, smul_smul] at this
    rw [Nat.cast_mul, mul_comm (k1 : 𝓞 E)]
    exact this

omit [IsCMField E] in

theorem exists_levOK {γ : Matrix (Fin n) (Fin n) E} {Λ : GenLat E n} {N M : ℕ}
    (h : (actLat γ ⟨stdLat E n⟩).TrivAt 2) (hΛ : Λ.LevOK N M) : ∃ N', (actLat γ Λ).LevOK N' M := by
  obtain ⟨k, hk, -, h1'⟩ := h
  obtain ⟨hN, hMN, h2⟩ := hΛ
  rw [span_singleton_smul_le_iff] at h1' h2
  have hko : Odd k := by
    first
      | exact Nat.Coprime.odd_of_right hk
      | exact Nat.coprime_two_right_iff_odd.1 hk
      | exact (Nat.coprime_two_right_iff_odd k).1 hk
  refine ⟨N * k, hN.mul hko, Dvd.dvd.mul_right hMN k, (span_singleton_smul_le_iff _ _ _).2 fun y hy => ?_⟩
  refine Submodule.mem_inf.2 ⟨?_, (stdLat E n).smul_mem _ hy⟩
  obtain ⟨x, hx, hxy⟩ := Submodule.mem_map.1 (h1' y hy)
  have := Submodule.mem_map_of_mem (f := (Matrix.mulVecLin γ).restrictScalars (𝓞 E)) (Submodule.mem_inf.1 (h2 x hx)).1
  rw [map_smul, hxy, smul_smul] at this
  rw [Nat.cast_mul]
  exact this

variable {H : Host E} {Dw : Datum H} {l : Level H}









end Arith

end GlobalTheory.DatumMove
