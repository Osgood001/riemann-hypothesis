import Mathlib
import Development.AbelianVarietyTheory.Definitions.Divisors.CTSmallCone
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsRationalDarbouxHermitianTensorAdeles
import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.AdelicLocalCompactness.AdeleLC

noncomputable section

namespace GlobalTheory.ThK.Check

open scoped TensorProduct NNReal Matrix
open NumberField IsDedekindDomain MeasureTheory Filter Topology Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes
open GlobalTheory.WeilM GlobalTheory.AdelicU GlobalTheory.LFun GlobalTheory.IndefiniteRowSideFullHecke.WeilTensorModels
open GlobalTheory.Doubling (absE)

variable {F E : Type} [Field F] [NumberField F] [Field E] [NumberField E] [Algebra F E] {σ : E →ₐ[F] E}
variable {n d n₁ d₁ : ℕ} {X : Spc F E n} {W : Spc F E d} {W₁ : Spc F E d₁}









example (a a' : ℝ) : (1 - a) / 2 + (a + a' - 1) / 2 = a' / 2 ∧ (1 - a') / 2 + (a + a' - 1) / 2 = a / 2 := by
  constructor <;> ring

def intLat (E : Type) [Field E] [NumberField E] (n : ℕ) : Submodule (𝓞 E) (Fin n → E) :=
  Submodule.pi Set.univ fun _ => ((1 : FractionalIdeal (nonZeroDivisors (𝓞 E)) E) : Submodule (𝓞 E) E)

variable (F) in

def hyp (ε : E) : Spc F E 2 := ⟨!![0, 1; ε, 0], intLat E 2, fun _ => !![0, 1; 1, 0], fun _ => 1⟩

variable (F E) in

def pt : Spc F E 0 := ⟨1, ⊤, fun _ => 1, fun _ => 1⟩

variable (E) in

def pl : Plane E 2 0 := ⟨![1, 0], ![0, 1], 0, 1⟩




theorem resEta_div {K : Subgroup (AF F)ˣ} {χ χ' : Chr F E} {a b m : ℕ} (h : ResEtaPow K χ a) (h' : ResEtaPow K χ' b)
    (hm : m = a + b) : ResEtaPow K (χ / χ') m := fun x => by
  rw [MonoidHom.div_apply, Circle.coe_div, h x, h' x, hm]
  split_ifs
  · simp
  · rcases neg_one_pow_eq_or ℂ b with e | e <;> simp [pow_add, e, div_neg]

theorem isHecke_div {χ χ' : Chr F E} (h : IsHecke F E χ) (h' : IsHecke F E χ') : IsHecke F E (χ / χ') :=
  ⟨h.1.div' h'.1, fun x => by rw [MonoidHom.div_apply, h.2 x, h'.2 x, div_one]⟩

theorem isPair_of_isTriple {a a' : ℕ} {B : Base F E} {G : Geo σ a a'} {Y : Chars F E} {om : Rep σ G.V G.W} {om' : Rep σ G.V' G.W}
    (h : IsTriple B G Y om om') :
    IsPair B G.M Y.β (Y.β / Y.α) om (a - G.p) G.p (a + a' - (G.p + G.q)) (G.p + G.q) ∧
      IsPair B G.M' Y.α (Y.α / Y.β) om' G.q (a' - G.q) (a + a' - (G.p + G.q)) (G.p + G.q) :=
  ⟨⟨h.base, h.geo.hV, h.geo.hW, h.geo.hM, h.chars.heckeβ, isHecke_div h.chars.heckeβ h.chars.heckeα, h.chars.resβ,
      resEta_div h.chars.resβ h.chars.resα rfl, h.weil⟩,
    h.base, h.geo.hV', h.geo.hW, h.geo.hM', h.chars.heckeα, isHecke_div h.chars.heckeα h.chars.heckeβ, h.chars.resα,
      resEta_div h.chars.resα h.chars.resβ (add_comm _ _), h.weil'⟩


theorem intInd_mem_SB {κ : Type} [Fintype κ] (v : HeightOneSpectrum (𝓞 F)) :
    Set.indicator {x : κ → Fv F v | ∀ k, x k ∈ v.adicCompletionIntegers F} 1 ∈ GlobalTheory.WeilM.SB (κ → Fv F v) := by
  have hU : {x : κ → Fv F v | ∀ k, x k ∈ v.adicCompletionIntegers F} =
      Set.pi Set.univ (fun _ => (v.adicCompletionIntegers F : Set (Fv F v))) := by
    ext x; simp
  have hO : IsOpen (v.adicCompletionIntegers F : Set (Fv F v)) := Valued.isOpen_integer _
  have hC : IsClosed (v.adicCompletionIntegers F : Set (Fv F v)) := Valued.isClosed_integer _
  have hK : IsCompact (v.adicCompletionIntegers F : Set (Fv F v)) :=
    PI.AdicCompletionValuation.isCompact_adicCompletionIntegers F v
  rw [hU]
  have hUo : IsOpen (Set.pi Set.univ (fun _ : κ => (v.adicCompletionIntegers F : Set (Fv F v)))) :=
    isOpen_set_pi Set.finite_univ (fun _ _ => hO)
  have hUc : IsClosed (Set.pi Set.univ (fun _ : κ => (v.adicCompletionIntegers F : Set (Fv F v)))) :=
    isClosed_set_pi (fun _ _ => hC)
  have hUk : IsCompact (Set.pi Set.univ (fun _ : κ => (v.adicCompletionIntegers F : Set (Fv F v)))) :=
    isCompact_univ_pi (fun _ => hK)
  generalize Set.pi Set.univ (fun _ : κ => (v.adicCompletionIntegers F : Set (Fv F v))) = U at hUo hUc hUk ⊢
  refine ⟨IsLocallyConstant.iff_isOpen_fiber.2 fun y => ?_, ?_⟩
  · by_cases h1 : (1 : ℂ) = y
    · have : U.indicator 1 ⁻¹' {y} = U := by
        ext x
        by_cases hx : x ∈ U <;> simp [hx, ← h1]
      rw [this]; exact hUo
    · by_cases h0 : (0 : ℂ) = y
      · have : U.indicator 1 ⁻¹' {y} = Uᶜ := by
          ext x
          by_cases hx : x ∈ U <;> simp [hx, ← h0]
        rw [this]; exact hUc.isOpen_compl
      · have : U.indicator 1 ⁻¹' {y} = ∅ := by
          ext x
          by_cases hx : x ∈ U <;> simp [hx] <;> assumption
        rw [this]; exact isOpen_empty
  · exact hUk.of_isClosed_subset (isClosed_tsupport _)
      (closure_minimal Set.support_indicator_subset hUc)

open scoped Classical in

def oneS (κ : Type) [Fintype κ] [IsEmpty κ] : SInf F κ :=
  HasCompactSupport.toSchwartzMap (f := fun _ => (1 : ℂ)) (HasCompactSupport.of_compactSpace _) contDiff_const

def evOrigin (R κ κ' : Type) [Zero R] : ((κ → R) → ℂ) →ₗ[ℂ] ((κ' → R) → ℂ) where
  toFun Φ := fun _ => Φ 0
  map_add' _ _ := rfl
  map_smul' _ _ := rfl

theorem const_mem_SB {R κ : Type} [TopologicalSpace R] [IsEmpty κ] (φ : (κ → R) → ℂ) : φ ∈ SB (κ → R) :=
  ⟨IsLocallyConstant.of_discrete _, HasCompactSupport.of_compactSpace _⟩

open scoped Classical in

theorem isEv_origin (B : Base F E) {n₁ d₁ : ℕ} [IsEmpty (Fin n₁ × Fin d₁)] {X₁ : Spc F E n₁} {W₁ : Spc F E d₁} (M : Model σ X W)
    (M₁ : Model σ X₁ W₁) (hv : ∀ v, M₁.vac v = fun _ => M.vac v 0) (ι : Matrix (Fin n) (Fin n₁) E) (ι' : Matrix (Fin d) (Fin d₁) E)
    (I : Set (Matrix (Fin n) (Fin d) (AE F E))) (hI : ∀ u ∈ I, (M.co.e u).1 = 0) :
    IsEv B M M₁ ι ι' I (evOrigin (AF F) _ _) where
  maps := fun Φ _ => by
    refine Submodule.subset_span ⟨Φ 0 • oneS (F := F) _, fun _ => 1, const_mem_SB _, ?_⟩
    funext x
    simp [pureA, evOrigin, oneS]
  Heisenberg₂ := fun z Φ _ => by
    have hz : z = 0 := by
      ext i j
      exact isEmptyElim (i, j)
    subst hz
    funext x
    simp [Darboux.rho, schr, evOrigin]
  inv := fun u hu Φ _ => by
    funext x
    simp [Darboux.rho, schr, evOrigin, hI u hu]
  loc := by
    refine ⟨((BoundedContinuousFunction.evalCLM ℂ (0 : Fin n × Fin d → mixedEmbedding.mixedSpace F)).comp
        (SchwartzMap.toBoundedContinuousFunctionCLM ℂ _ ℂ)).smulRight (oneS _), fun v => evOrigin _ _ _, ?_,
      fun v => ⟨(hv v).symm, ?_⟩, fun f φ _ _ => ?_⟩
    · intro h
      let b : ContDiffBump (0 : Fin n × Fin d → mixedEmbedding.mixedSpace F) := ⟨1, 2, one_pos, one_lt_two⟩
      have hs : HasCompactSupport (fun x => ((b x : ℝ) : ℂ)) := b.hasCompactSupport.comp_left (g := fun t : ℝ => (t : ℂ)) (by simp)
      have hc : ContDiff ℝ (⊤ : ℕ∞) (fun x => ((b x : ℝ) : ℂ)) := Complex.ofRealCLM.contDiff.comp b.contDiff
      have h1 := congrArg (fun T : SInf F (Fin n × Fin d) →L[ℂ] SInf F (Fin n₁ × Fin d₁) => T (hs.toSchwartzMap hc) 0) h
      have h2 : b 0 = 1 := b.one_of_mem_closedBall (by simp [b])
      simp [h2, oneS] at h1
    · refine le_antisymm ?_ fun φ _ => ⟨φ 0 • _, Submodule.smul_mem _ _ (intInd_mem_SB v), ?_⟩
      · rintro _ ⟨φ, -, rfl⟩
        exact const_mem_SB _
      · funext x
        rw [Subsingleton.elim x 0]
        simp [evOrigin, Set.indicator, zero_mem]
    · funext x
      have e1 : (fun i : Fin n × Fin d => evI F ((0 : Fin n × Fin d → AF F) i)) = 0 :=
        funext fun _ => map_zero (InfiniteAdeleRing.ringEquiv_mixedSpace F)
      have e2 : ∀ v, (fun i : Fin n × Fin d => evFin F v ((0 : Fin n × Fin d → AF F) i)) = 0 := fun v => funext fun _ => map_zero _
      simp only [GlobalTheory.IndefiniteRowSideFullHecke.WeilTensorModels.pure, evOrigin, LinearMap.coe_mk, AddHom.coe_mk, e1, e2]
      simp [oneS]



example {a a' : ℕ} (h : a' < a) (he : Even (a + a')) :
    (a : ℝ) / 2 - (((a - a') / 2 : ℕ) : ℝ) = a' / 2 ∧ ((a' : ℝ) - 2) / 2 + (((a - a') / 2 + 1 : ℕ) : ℝ) = a / 2 := by
  obtain ⟨k, hk⟩ := he
  have e : a = a' + 2 * ((a - a') / 2) := by omega
  generalize (a - a') / 2 = x at e
  subst e
  push_cast
  constructor <;> ring

example (Y : Chars F E) (t s : (AE F E)ˣ) (h : Y.ν s = (Y.ν t)⁻¹) : Y.β t * (Y.ν s)⁻¹ = Y.α t ∧ Y.α t * Y.ν s = Y.β t := by
  rw [h, Chars.ν, MonoidHom.div_apply]
  constructor <;> simp

end GlobalTheory.ThK.Check

end
