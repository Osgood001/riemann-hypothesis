import Mathlib
import Development.AbelianVarietyTheory.Definitions.Divisors.ExistsNotRelZero
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ValuationLeOneOfMem
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.UnderMemAndPlaceAboveEqOfMem

noncomputable section

open Formalism.BasicNotions Formalism.BasicNotions.TH Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.MainNotions.StandardLattice Formalism.L2.Theta Formalism.IndefR.Datum Formalism.IndefR.Links
open IsDedekindDomain NumberField MeasureTheory Matrix
open scoped TensorProduct

set_option synthInstance.maxHeartbeats 400000
set_option maxHeartbeats 800000

namespace GlobalTheory.FunObj.LocTensor

open GlobalTheory.ChiGrid GlobalTheory.SplitFlip GlobalTheory.SplitWeil GlobalTheory.StdFrames Formalism.L2.DIV ValuativeRel GlobalTheory.PlaceModel

attribute [local instance] Formalism.BasicNotions.Host.cmStar GlobalTheory.LocalData.complRel GlobalTheory.LocalData.isLocalField borelKw borelSpaceKw



variable {D : D7}


variable {S T : HSp D} {ΛS : Submodule (𝓞 D.host.E) (Fin S.rank → D.host.E)}
  {ΛT : Submodule (𝓞 D.host.E) (Fin T.rank → D.host.E)}









variable {T₀ : Type} {L : LevCh D T₀} {sc : Consts} {G : GridData L sc}


variable {W : G.Weil} (B : Frames G) (ρ : RealMatch W) (t : T₀) (i j : Fin D.R.m) {μ₀ : T₀}



theorem exists_idemSum_locPl (hL : L.Is μ₀) (G : GridData L sc) (t : T₀) : ∃ e, IsIdemSum e (locPl G t) := by
  refine GlobalTheory.GridIdem.exists_isIdemSum _ (fun w hw => ?_) fun w hw w' hw' h => Good.under_injOn hL G t hw hw' h
  rcases Good.locPl_cases hw with ⟨a, b⟩ | ⟨-, -, b⟩
  · exact b ▸ G.pl.w_split _ a
  · exact exists_isIdemAt fun h => (hL.Q_pl t w b).2 w b ((GlobalTheory.IdemSupport.isConjPl_iff _ _).2 h.symm)


end GlobalTheory.FunObj.LocTensor

end
