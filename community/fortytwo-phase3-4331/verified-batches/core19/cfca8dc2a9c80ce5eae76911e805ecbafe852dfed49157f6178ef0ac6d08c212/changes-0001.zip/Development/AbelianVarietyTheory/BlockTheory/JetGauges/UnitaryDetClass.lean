import Mathlib
import Formalism.LocalToGlobal.ProjectiveLattices.ThShort
import Formalism.LocalToGlobal.ProjectiveLattices.ThGerm

set_option autoImplicit false

noncomputable section

namespace GlobalTheory.IndefiniteRowSideFullHecke.UnitaryDetClass

open NumberField MvPolynomial ReciprocityTheory.ChartRestriction.G.Geo.Tor Formalism.L2.Pj

section Lattices

variable {E : Type} [Field E] [NumberField E] [IsCMField E] {n : ℕ}

def IsUnitary (γ : Matrix (Fin n) (Fin n) E) : Prop :=
  (γ.map (IsCMField.complexConj E)).transpose * γ = 1

def Carries (γ : Matrix (Fin n) (Fin n) E) (Λ Λ' : GenLat E n) : Prop :=
  ∀ v' : Fin n → E, v' ∈ Λ'.La ↔ ∃ v ∈ Λ.La, γ.mulVec v = v'

def CongrAt (Q : ℕ) (u v : Fin n → E) : Prop :=
  ∃ k : ℕ, Nat.Coprime k Q ∧ ∀ j, ∃ s : 𝓞 E, (k : E) * (u j - v j) = (Q : E) * (s : E)

abbrev StdMod (E : Type) [Field E] [NumberField E] (n Q : ℕ) : Type :=
  Fin n → 𝓞 E ⧸ Ideal.span {(Q : 𝓞 E)}

def IsMarking (Q : ℕ) (Λ : GenLat E n) (κ : Λ.La →ₗ[𝓞 E] StdMod E n Q) : Prop :=
  Function.Surjective κ ∧
  (∀ v : Λ.La, κ v = 0 ↔ ∃ u : Λ.La, v = Q • u) ∧
  ∀ (v w : Λ.La) (x y : Fin n → 𝓞 E),
    (∀ j, κ v j = Ideal.Quotient.mk _ (x j)) → (∀ j, κ w j = Ideal.Quotient.mk _ (y j)) →
      ∃ s : 𝓞 E, ∑ j, IsCMField.complexConj E ((v : Fin n → E) j) * (w : Fin n → E) j -
        ∑ j, IsCMField.complexConj E (x j : E) * (y j : E) = (Q : E) * (s : E)



def IsTrivRep (bad Q : ℕ) (Λ : GenLat E n) : Prop := Λ.Unimod ∧ Λ.TrivAt bad ∧ Λ.TrivAt Q


example : IsUnitary (1 : Matrix (Fin n) (Fin n) E) := by
  simp [IsUnitary, Matrix.map_one]

example (Λ : GenLat E n) : Carries 1 Λ Λ := fun v => by simp

example (Q : ℕ) (v : Fin n → E) : CongrAt Q v v := ⟨1, by simp, fun _ => ⟨0, by simp⟩⟩

end Lattices

variable {E : Type} [Field E] [NumberField E] [IsCMField E] {H : Host E} {Dw : Datum H} {l : Level H}
variable (Xo : Moduli Dw l) (c : Coeff l)

def push {n : ℕ} (γ : Matrix (Fin n) (Fin n) E) :
    MvPolynomial (LtN Dw n) c.F →ₐ[c.F] MvPolynomial (LtN Dw n) c.F :=
  aeval fun ℓ : LtN Dw n => letB c ℓ.1 ℓ.2.1 fun k => γ k ℓ.2.2

example {n : ℕ} (ℓ : LtN Dw n) : push c (1 : Matrix (Fin n) (Fin n) E) (X ℓ) = X ℓ := by
  obtain ⟨σ, i, j⟩ := ℓ
  simp [push, letB, Matrix.one_apply, apply_ite, ite_mul]




open Classical in

def detChar {n : ℕ} (d : (E →+* ℂ) → ℤ) (γ : Matrix (Fin n) (Fin n) E) : c.F :=
  ∏ τ ∈ Finset.univ.filter (InPsi H), embF c τ γ.det ^ d τ


open Classical in

def ScalarLaw (Dw : Datum H) {n : ℕ} (bad Q : ℕ) (u : GenLat E n → c.F) (e : (E →+* ℂ) → ℤ) : Prop :=
  u ⟨stdLat E n⟩ = betaH (Dw := Dw) c (⟨stdLat E n⟩ : GenLat E n) ∧
  ∀ Λ : GenLat E n, IsTrivRep bad Q Λ →
    (∀ σ : c.F →+* ℂ, ‖σ (u Λ)‖ = 1) ∧
    Submodule.span (𝓞 c.F) {u Λ} * ∏ τ ∈ Finset.univ.filter (InPsi H), idealAt c Λ.La τ ^ (-e τ).toNat =
      ∏ τ ∈ Finset.univ.filter (InPsi H), idealAt c Λ.La τ ^ (e τ).toNat












end GlobalTheory.IndefiniteRowSideFullHecke.UnitaryDetClass
