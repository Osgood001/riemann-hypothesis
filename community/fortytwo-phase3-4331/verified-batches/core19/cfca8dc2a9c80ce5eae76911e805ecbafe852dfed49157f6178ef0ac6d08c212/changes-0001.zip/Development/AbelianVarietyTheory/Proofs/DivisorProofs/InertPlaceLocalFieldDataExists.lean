import Mathlib
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsFinMapsOfForall
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.OneMemKAt
import Development.AbelianVarietyTheory.PublishedTheorems.GaloisGeometry₂.HoweUnram
import Development.AbelianVarietyTheory.Proofs.FoundationProofs.ExistsUniqueIsConjAt
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LatAtVAtStable
open NumberField IsDedekindDomain Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes GlobalTheory.WeilM GlobalTheory.AdelicU GlobalTheory.LFun GlobalTheory.IndefiniteRowSideFullHecke.WeilTensorModels GlobalTheory.KFinLoc
open scoped TensorProduct Matrix

noncomputable section

namespace GlobalTheory.InertLocField

variable {F E : Type} [Field F] [NumberField F] [Field E] [NumberField E] [Algebra F E]

theorem liftV_mul (v : Pl F) (a b : Fv F v) :
    GlobalTheory.LatVac.liftV v (a * b) = GlobalTheory.LatVac.liftV v a * GlobalTheory.LatVac.liftV v b := by
  refine Prod.ext ?_ ?_
  · change (0 : Ainf F) = 0 * 0
    rw [mul_zero]
  · change GlobalTheory.AdelicU.singleFin v (a * b) = GlobalTheory.AdelicU.singleFin v a * GlobalTheory.AdelicU.singleFin v b
    exact GlobalTheory.AdelicU.singleFin_mul v a b

theorem liftV_one_mul (v : Pl F) (a : AF F) :
    GlobalTheory.LatVac.liftV v 1 * a = GlobalTheory.LatVac.liftV v (evFin F v a) := by
  refine Prod.ext ?_ ?_
  · change (0 : Ainf F) * a.1 = 0
    rw [zero_mul]
  · change GlobalTheory.AdelicU.singleFin v 1 * a.2 = GlobalTheory.AdelicU.singleFin v (evalV F v a.2)
    apply GlobalTheory.AdelicU.af_ext
    intro u
    rw [map_mul]
    by_cases hu : u = v
    · subst hu
      rw [GlobalTheory.AdelicU.evalV_singleFin_self, GlobalTheory.AdelicU.evalV_singleFin_self, one_mul]
    · rw [GlobalTheory.AdelicU.evalV_singleFin_ne hu, GlobalTheory.AdelicU.evalV_singleFin_ne hu, zero_mul]

theorem evFin_one_sub (v : Pl F) : evFin F v (1 - GlobalTheory.LatVac.liftV v 1) = 0 := by
  rw [map_sub, map_one, GlobalTheory.LatVac.evFin_liftV, sub_self]

theorem eq_liftV_of_at (v : Pl F) {a : AF F} (ha : At (evFin F v) a) :
    a = GlobalTheory.LatVac.liftV v (evFin F v a) := by
  have h := ha _ (evFin_one_sub v)
  rw [smul_eq_mul, sub_mul, one_mul, sub_eq_zero, liftV_one_mul] at h
  exact h

variable (E) in

def liftT (v : Pl F) : Fv F v ⊗[F] E →ₗ[F] AE F E := TensorProduct.map (GlobalTheory.LatVac.liftV v) LinearMap.id

theorem liftT_tmul (v : Pl F) (a : Fv F v) (e : E) :
    liftT E v (a ⊗ₜ[F] e) = GlobalTheory.LatVac.liftV v a ⊗ₜ[F] e := rfl

variable (E) in

def evT (v : Pl F) : AE F E →ₐ[F] Fv F v ⊗[F] E := Algebra.TensorProduct.map (evFin F v) (AlgHom.id F E)

theorem evT_liftT (v : Pl F) (y : Fv F v ⊗[F] E) : evT E v (liftT E v y) = y := by
  induction y using TensorProduct.induction_on with
  | zero => simp
  | tmul a e =>
    rw [liftT_tmul]
    change evFin F v (GlobalTheory.LatVac.liftV v a) ⊗ₜ[F] e = a ⊗ₜ[F] e
    rw [GlobalTheory.LatVac.evFin_liftV]
  | add x y hx hy => rw [map_add, map_add, hx, hy]

theorem liftT_injective (v : Pl F) : Function.Injective (liftT E v) :=
  Function.LeftInverse.injective (evT_liftT (E := E) v)

theorem liftV_one_smul (v : Pl F) (z : AE F E) : GlobalTheory.LatVac.liftV v 1 • z = liftT E v (evT E v z) := by
  induction z using TensorProduct.induction_on with
  | zero => simp
  | tmul a e =>
    rw [TensorProduct.smul_tmul', smul_eq_mul, liftV_one_mul]
    rfl
  | add x y hx hy => rw [smul_add, hx, hy, map_add, map_add]

theorem at_liftT (v : Pl F) (y : Fv F v ⊗[F] E) : At (evFin F v) (liftT E v y) := by
  intro u hu
  induction y using TensorProduct.induction_on with
  | zero => simp
  | tmul a e =>
    rw [liftT_tmul, TensorProduct.smul_tmul', smul_eq_mul, eq_liftV_of_at v (GlobalTheory.LatVac.at_liftV v a),
      ← liftV_one_mul, ← mul_assoc, mul_comm u, liftV_one_mul, hu, map_zero, zero_mul, TensorProduct.zero_tmul]
  | add x y hx hy => rw [map_add, smul_add, hx, hy, add_zero]

theorem at_iff (v : Pl F) (z : AE F E) : At (evFin F v) z ↔ ∃ y, liftT E v y = z := by
  refine ⟨fun hz => ⟨evT E v z, ?_⟩, fun ⟨y, hy⟩ => hy ▸ at_liftT v y⟩
  have h := hz _ (evFin_one_sub v)
  rw [sub_smul, one_smul, sub_eq_zero, liftV_one_smul] at h
  exact h.symm

theorem liftT_mul (v : Pl F) (y y' : Fv F v ⊗[F] E) : liftT E v (y * y') = liftT E v y * liftT E v y' := by
  induction y using TensorProduct.induction_on with
  | zero => simp
  | add x z hx hz => rw [add_mul, map_add, hx, hz, map_add, add_mul]
  | tmul a e =>
    induction y' using TensorProduct.induction_on with
    | zero => simp
    | add x z hx hz => rw [mul_add, map_add, hx, hz, map_add, mul_add]
    | tmul b f =>
      rw [Algebra.TensorProduct.tmul_mul_tmul, liftT_tmul, liftT_tmul, liftT_tmul, liftV_mul,
        Algebra.TensorProduct.tmul_mul_tmul]

theorem liftT_sigR (σ : E →ₐ[F] E) (v : Pl F) (y : Fv F v ⊗[F] E) :
    liftT E v (sigR (Fv F v) σ y) = cA σ (liftT E v y) := by
  induction y using TensorProduct.induction_on with
  | zero => simp
  | tmul a e => rfl
  | add x y hx hy => rw [map_add, map_add, hx, hy, map_add, map_add]

end GlobalTheory.InertLocField

namespace GlobalTheory.InertLocField

variable {F E : Type} [Field F] [NumberField F] [Field E] [NumberField E] [Algebra F E]

theorem trace_tmul_base {R : Type} [CommRing R] [Algebra F R] (a : R) (e : E) :
    Algebra.trace R (R ⊗[F] E) (a ⊗ₜ[F] e) = a * algebraMap F R (Algebra.trace F E e) := by
  have h1 : a ⊗ₜ[F] e = a • ((1 : R) ⊗ₜ[F] e) := by
    rw [TensorProduct.smul_tmul', smul_eq_mul, mul_one]
  rw [h1, map_smul, Algebra.trace_apply, Algebra.trace_apply, ← Algebra.baseChange_lmul,
    LinearMap.trace_baseChange, smul_eq_mul]

theorem liftV_mul_algebraMap (v : Pl F) (t : Fv F v) (r : F) :
    GlobalTheory.LatVac.liftV v t * algebraMap F (AF F) r = GlobalTheory.LatVac.liftV v (algebraMap F (Fv F v) r * t) := by
  rw [← Algebra.smul_def, LinearMap.map_smul, Algebra.smul_def, mul_comm]

theorem trace_liftT (v : Pl F) (y : Fv F v ⊗[F] E) :
    Algebra.trace (AF F) (AE F E) (liftT E v y) =
      GlobalTheory.LatVac.liftV v (Algebra.trace (Fv F v) (Fv F v ⊗[F] E) y) := by
  induction y using TensorProduct.induction_on with
  | zero => simp
  | tmul a e =>
    rw [liftT_tmul, trace_tmul_base, trace_tmul_base, liftV_mul_algebraMap, mul_comm]
  | add x y hx hy => rw [map_add, map_add, hx, hy, map_add, map_add]



theorem half_mem (v : Pl F) (h : (2 : 𝓞 F) ∉ v.asIdeal) :
    algebraMap F (Fv F v) 2⁻¹ ∈ v.adicCompletionIntegers F := by
  have hval : Valued.v (algebraMap F (Fv F v) ((2 : 𝓞 F) : F)) = v.valuation F ((2 : 𝓞 F) : F) :=
    HeightOneSpectrum.valuedAdicCompletion_eq_valuation' v _
  have h1 : v.valuation F ((2 : 𝓞 F) : F) = 1 :=
    le_antisymm (v.valuation_le_one _) (not_lt.1 (mt (v.valuation_lt_one_iff_mem _).1 h))
  have h2 : ((2 : 𝓞 F) : F) = 2 := rfl
  rw [h2] at hval h1
  change Valued.v (algebraMap F (Fv F v) 2⁻¹) ≤ 1
  rw [map_inv₀, map_inv₀, hval, h1, inv_one]

end GlobalTheory.InertLocField

namespace GlobalTheory.InertLocField

open InertChart


end GlobalTheory.InertLocField
