import Mathlib
import Development.AbelianVarietyTheory.Definitions.LatticeFrames.PhiTopAgree

open Formalism.L2.Col

noncomputable section
namespace GlobalTheory.SymBridge


end GlobalTheory.SymBridge
