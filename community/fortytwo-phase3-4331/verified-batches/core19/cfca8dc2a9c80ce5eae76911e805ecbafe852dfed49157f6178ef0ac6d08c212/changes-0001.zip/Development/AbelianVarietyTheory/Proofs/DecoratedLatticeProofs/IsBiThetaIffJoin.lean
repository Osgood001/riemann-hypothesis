import Mathlib
import Development.AbelianVarietyTheory.Definitions.LatticeFrames.IsBiSmooth
import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.ConjugateAdjointDagger
import Development.AbelianVarietyTheory.Definitions.Foundations.ExistsGLSubmatrix

noncomputable section

open Formalism.BasicNotions Formalism.BasicNotions.TH Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.MainNotions.StandardLattice Formalism.L2.Theta Formalism.IndefR.Datum MeasureTheory IsDedekindDomain NumberField Matrix
open GlobalTheory.MixModel GlobalTheory.SeeSaw GlobalTheory.ChiGrid GlobalTheory.IndefiniteRowSideFullHecke.ConjugateAdjointDagger
open scoped TensorProduct
attribute [local instance] Formalism.BasicNotions.Host.cmStar

namespace GlobalTheory.BiTransfer

variable {D : D7}

def sumDec (A B : HSp D) : OrthDec (GlobalTheory.Doubling.hsum A B) A B where
  iA := (fromRows (1 : Matrix (Fin A.rank) (Fin A.rank) D.host.E) (0 : Matrix (Fin B.rank) (Fin A.rank) D.host.E)).submatrix
    finSumFinEquiv.symm id
  iB := (fromRows (0 : Matrix (Fin A.rank) (Fin B.rank) D.host.E) (1 : Matrix (Fin B.rank) (Fin B.rank) D.host.E)).submatrix
    finSumFinEquiv.symm id
  isoA := by
    rw [GlobalTheory.Doubling.gram_hsum, conjTranspose_submatrix]
    unfold GlobalTheory.Doubling.blkMat
    simp [submatrix_mul_equiv, conjTranspose_fromRows_eq_fromCols_conjTranspose, fromCols_mul_fromBlocks, fromCols_mul_fromRows]
  isoB := by
    rw [GlobalTheory.Doubling.gram_hsum, conjTranspose_submatrix]
    unfold GlobalTheory.Doubling.blkMat
    simp [submatrix_mul_equiv, conjTranspose_fromRows_eq_fromCols_conjTranspose, fromCols_mul_fromBlocks, fromCols_mul_fromRows]
  orth := by
    rw [GlobalTheory.Doubling.gram_hsum, conjTranspose_submatrix]
    unfold GlobalTheory.Doubling.blkMat
    simp [submatrix_mul_equiv, conjTranspose_fromRows_eq_fromCols_conjTranspose, fromCols_mul_fromBlocks, fromCols_mul_fromRows]
  rank_add := rfl












variable {W A A' : HSp D} (d : OrthDec W A (negSp A')) (S : HSp D)

















variable {S} {ψ : AddChar (AF D.host.F) ℂ} {C : WO A S → WO S A' → ℂ}










end GlobalTheory.BiTransfer

end
