import Mathlib
import Formalism.LocalRingCardinality.DataKerI
import Formalism.SharpRestriction.GlobalSchurBounds.GL3Theta
import Formalism.LocalToGlobal.KernelLattices.LateralTheory

noncomputable section

namespace GlobalTheory.IndefiniteRowSideFullHecke.ShapeDegreeParity

open NumberField Formalism.BasicNotions Formalism.MainNotions Formalism.MainNotions.G Formalism.MainNotions.TaylorLogMetric Formalism.MainNotions.GL3Theta Classical

section Local

variable (l : ℕ) [Fact l.Prime] (d : ℕ) [NeZero d]


variable {d}



variable {l}






end Local

abbrev Lt (D : D7) : Type := Bool × HH D




section Coord

variable (D : D7) {l : ℕ} [Fact l.Prime] (lam : Qbar →+* ℂ_[l])








variable (l)


variable {l}



end Coord








end GlobalTheory.IndefiniteRowSideFullHecke.ShapeDegreeParity
