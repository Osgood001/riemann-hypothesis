import Mathlib
import Development.AbelianVarietyTheory.Definitions.LatticeFrames.PhiTopAgree
import Development.AbelianVarietyTheory.Definitions.LatticeFrames.ToOneSucc

open NumberField IsDedekindDomain MeasureTheory ValuativeRel Matrix
open Formalism.BasicNotions Formalism.HermitianLatticesTheory Formalism.L2.DIV Formalism.L2.Col

noncomputable section
namespace GlobalTheory.TwBridge
open GlobalTheory.SplitWeil GlobalTheory.RootEx GlobalTheory.StepData GlobalTheory.SymBridge

variable {X : Fields} {Pr : Primes X} {R : Ranks} (Ch : Chars X Pr R.m)
  (sel : HeightOneSpectrum (𝓞 X.F) → HeightOneSpectrum (𝓞 X.E)) {S₀ : Set ℕ}
  (mu : Tup X.F X.E X.K S₀) (cst : LocCst X (rowSG Pr sel mu)) (σ₀ : X.K →+* ℂ) (P : rowSG Pr sel mu)
  {k : Type} [Field k] [ValuativeRel k] [TopologicalSpace k] [IsNonarchimedeanLocalField k] (ι : X.E →+* k)

structure TwData (k : Type) [Field k] [ValuativeRel k] [TopologicalSpace k] [IsNonarchimedeanLocalField k] where
  ϖ : kˣ
  unif : GlobalTheory.IndefiniteRowSideFullHecke.FramePositiveSum.IsUnif ϖ
  ψ : AddChar k Circle
  cont : Continuous ψ
  cond : HasConductor ψ 1
  δ : kˣ →* ℂˣ
  tame : IsTame δ
  η : ℕ → kˣ →* ℂˣ
  unr : ∀ j, IsUnram (η j)
  sg : ℂ

variable (s : ℕ) (W : TwData k)

abbrev TwData.T (R : Ranks) : Chain k s (XIx (Fin R.k) (Fin R.t)) (Ix (Fin R.k ⊕ Fin (s + 1)) (Fin R.t) (s + 2)) :=
  twistChain s (Fin R.t) (Fin R.k) W.δ W.tame W.η

structure AtTwist : Prop where
  nmem : P.1 ∉ Pr.vGs
  steps : R.m = s + 2
  compl : IsCompl P.1 (qOf P.1) ι W.ϖ
  psi : ∀ a, IntAt P.1 ((qOf P.1 : X.E) ^ cst.D P * a) → (W.ψ (ι a) : ℂ) = σ₀ (cst.psi P a)
  del : ∀ a (u : kˣ), IntAt P.1 a → IsUnit (redP P.1 a) → (u : k) = ι a →
    (W.δ u : ℂ) = (σ₀ (LocE.unitV (resChar (mu : Chr X.F X.E X.K) P.1) a))⁻¹
  mu : ∀ i, i < R.m → ((W.η (i + 1) * W.δ) W.ϖ : ℂ) = σ₀ (cst.muq (i + 1) P)
  sq : σ₀ (cst.sq P) = W.sg * (Real.sqrt (qOf P.1) : ℂ)

def IsOrdY {j c : ℕ} (e : XIx (Fin R.k) (Fin R.t) j ⊕ Fin c ≃ Fin (R.N j + cOf R j)) : Prop := IsOrd (yPos xPos (R.N j)) e

def IsGL {j c : ℕ} (γ : AutY X R j) (g : GL (XIx (Fin R.k) (Fin R.t) j ⊕ Fin c) k) : Prop :=
  ∃ e : XIx (Fin R.k) (Fin R.t) j ⊕ Fin c ≃ Fin (R.N j + cOf R j), IsOrdY e ∧ g.val = toLoc ι e e γ.toLinearMap

def sgn {j : ℕ} (γ : AutY X R j) (n : ℕ) : ℂ := W.sg ^ (LocE.vP P.1 (qOf P.1) ((LinearEquiv.det γ : X.Eˣ) : X.E) * n)



variable [MeasurableSpace k] [BorelSpace k] (ν : Measure k)



variable (L : ChIdx X Pr R (QE sel (mu : Chr X.F X.E X.K)))






end GlobalTheory.TwBridge
