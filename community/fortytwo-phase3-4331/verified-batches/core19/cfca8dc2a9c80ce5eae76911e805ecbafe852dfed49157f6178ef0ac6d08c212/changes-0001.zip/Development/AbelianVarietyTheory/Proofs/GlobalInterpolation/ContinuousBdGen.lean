import Mathlib
import Development.AbelianVarietyTheory.Definitions.GlobalTwisting.DecayZero

open NumberField IsDedekindDomain MeasureTheory Topology Filter Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes GlobalTheory.GaugeEx GlobalTheory.SWQ
open scoped TensorProduct NNReal ENNReal

noncomputable section

namespace GlobalTheory.SWQ

variable {F : Type} [Field F] [NumberField F] {N : ℕ}

theorem re_add (x y : Ainf F) (w : InfinitePlace F) : re (x + y) w = re x w + re y w := by
  have : (x + y) w = x w + y w := rfl
  simp only [re, this, map_add, Complex.add_re]


theorem re_mul [IsTotallyReal F] (x y : Ainf F) (w : InfinitePlace F) :
    re (x * y) w = re x w * re y w := by
  have hw : w.IsReal := IsTotallyReal.isReal w
  have : (x * y) w = x w * y w := rfl
  simp only [re, this, ← InfinitePlace.Completion.extensionEmbeddingOfIsReal_apply hw, map_mul,
    Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im, mul_zero, sub_zero]

theorem re_sum [IsTotallyReal F] {ι : Type} (s : Finset ι) (f : ι → Ainf F) (w : InfinitePlace F) :
    re (∑ i ∈ s, f i) w = ∑ i ∈ s, re (f i) w := by
  classical
  induction s using Finset.induction_on with
  | empty =>
    have : (0 : Ainf F) w = 0 := rfl
    simp [re, this]
  | insert i s hi ih => rw [Finset.sum_insert hi, Finset.sum_insert hi, re_add, ih]










end GlobalTheory.SWQ

noncomputable section

namespace GlobalTheory.SWQ






end GlobalTheory.SWQ
