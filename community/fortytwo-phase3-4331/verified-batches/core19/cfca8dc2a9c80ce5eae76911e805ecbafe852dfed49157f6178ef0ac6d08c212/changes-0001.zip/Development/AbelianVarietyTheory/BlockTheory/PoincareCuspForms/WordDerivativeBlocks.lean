import Mathlib

open scoped BigOperators

noncomputable section

namespace GlobalTheory.IndefiniteRowSideFullHecke.WordBlockPolynomials

abbrev Letter {ι : Type} (dim : ι → ℕ) (n : ℕ) : Type := Fin n × (Σ s : ι, Fin (dim s))

structure Block {ι : Type} (dim : ι → ℕ) (n : ℕ) where
  emb : ι
  size : ℕ
  expo : ℕ
  one_le_size : 1 ≤ size
  size_le : size ≤ dim emb
  one_le_expo : 1 ≤ expo
  col : Fin size ↪ Fin n
  vec : Fin size → EuclideanSpace ℂ (Fin (dim emb))
  orthonormal_vec : Orthonormal ℂ vec

variable {ι : Type} {dim : ι → ℕ} {n : ℕ}



structure BlockSystem {ι : Type} (dim : ι → ℕ) (n : ℕ) where
  card : ℕ
  block : Fin card → Block dim n
  disjoint : Pairwise fun j j' =>
    Disjoint (Set.range (block j).col) (Set.range (block j').col)


def BlockSystem.degree (S : BlockSystem dim n) : ℕ :=
  ∑ j, (S.block j).size * (S.block j).expo





def exampleBlock : Block (fun _ : Fin 2 => 2) 3 where
  emb := 0
  size := 2
  expo := 3
  one_le_size := by norm_num
  size_le := le_rfl
  one_le_expo := by norm_num
  col := Fin.castLEEmb (by norm_num)
  vec := EuclideanSpace.basisFun (Fin 2) ℂ
  orthonormal_vec := (EuclideanSpace.basisFun (Fin 2) ℂ).orthonormal

def exampleSystem : BlockSystem (fun _ : Fin 2 => 2) 3 where
  card := 1
  block := fun _ => exampleBlock
  disjoint := Subsingleton.pairwise

example : exampleSystem.degree = 6 := by
  decide

section Operator

variable {Λ W : Type} [NormedAddCommGroup W] [NormedSpace ℂ W]

def wordDeriv (dir : Λ → W) (l : List Λ) (F : W → ℂ) (p : W) : ℂ :=
  iteratedFDeriv ℂ l.length F p fun j => dir (l.get j)

def applyAt (dir : Λ → W) (P : MvPolynomial Λ ℂ) (F : W → ℂ) (p : W) : ℂ :=
  ∑ μ ∈ P.support, P.coeff μ * wordDeriv dir (Finsupp.toMultiset μ).toList F p



example (dir : Λ → W) (F : W → ℂ) (p : W) : applyAt dir 1 F p = F p := by
  classical
  have h : (Finsupp.toMultiset (0 : Λ →₀ ℕ)).toList = [] := by simp
  simp only [applyAt, MvPolynomial.support_one, Finset.sum_singleton, h]
  simp [wordDeriv]

end Operator

section Columns

variable {V : Type} [NormedAddCommGroup V] [NormedSpace ℂ V]



end Columns

def gDim (f r : ℕ) : ℕ := f * r

def bigR (rd : ℝ) : ℝ := rd ^ 7

def dStar (f m : ℕ) : ℕ := 2 * f * m

def omStar (f : ℕ) (rd : ℝ) : ℝ := 2 * (f : ℝ) ^ ((3 : ℝ) / 2) * rd

def thSq (f : ℕ) (rd : ℝ) (q : ℕ) (R₀ : ℝ) : ℝ := f * R₀ ^ 2 * bigR rd ^ 3 / q

def th (f : ℕ) (rd : ℝ) (q : ℕ) (R₀ : ℝ) : ℝ := Real.sqrt (thSq f rd q R₀)

def bZero (rd : ℝ) (q : ℕ) (R₀ : ℝ) : ℝ := q / (R₀ ^ 2 * bigR rd ^ 4)

def tZero (rd : ℝ) (q : ℕ) (R₀ : ℝ) : ℝ := q * bZero rd q R₀

def mOne (f m : ℕ) (rd : ℝ) : ℝ := 90 * (m : ℝ) ^ 2 * (dStar f m : ℝ) ^ 2 * rd


def ph (f : ℕ) (rd : ℝ) (q : ℕ) (R₀ : ℝ) (la : Set.Ioi (0 : ℝ)) : ℝ :=
  if (la : ℝ) < th f rd q R₀ then 2 * f / (rd ^ 2 * (la : ℝ) ^ 2) else 0


structure Params {ι : Type} (dim : ι → ℕ) (f r : ℕ) (rd : ℝ) (D n : ℕ) where
  q : ℕ
  R₀ : ℝ
  m : ℕ
  one_le_m : 1 ≤ m
  min_dim_le : ∃ s, dim s ≤ m
  m_pow_le : m ^ 4 ≤ f
  f_sq_le : (f : ℝ) ^ 2 ≤ rd
  sixteen_le : 16 ≤ rd
  two_le_fr : 2 ≤ f * r
  three_le_q : 3 ≤ q
  one_le_D : 1 ≤ D
  one_le_n : 1 ≤ n
  R₀_pos : 0 < R₀
  R₀_sq : max (270 : ℝ) (90 * ((gDim f r : ℝ) + D)) ≤ R₀ ^ 2
  threshold_lt : (dStar f m : ℝ) ^ 2 * omStar f rd * thSq f rd q R₀ < 1
  one_le_bZero : 1 ≤ bZero rd q R₀
  mOne_le : mOne f m rd ≤ (q : ℝ) / 2
  D_le_q : D ≤ q
  tZero_ge_log : 4 * (D : ℝ) * (7 + Real.log ((q : ℝ) * D)) + (dStar f m : ℝ) + 1 ≤ tZero rd q R₀
  tZero_ge_rank : (gDim f r : ℝ) * Real.log 2 + 2 * (dStar f m : ℝ) + 3 +
    ((D : ℝ) + 1) * ((r : ℝ) * Real.log r + 3 * r + 3) ≤ tZero rd q R₀

structure ParamsWithLevel {ι : Type} (dim : ι → ℕ) (f r : ℕ) (rd : ℝ) (D n : ℕ)
    extends Params dim f r rd D n where
  r₁ : ℕ
  two_le_r₁ : 2 ≤ r₁















namespace Params

variable {f r : ℕ} {rd : ℝ} {D : ℕ} (P : Params dim f r rd D n)

def ph (la : Set.Ioi (0 : ℝ)) : ℝ := WordBlockPolynomials.ph f rd P.q P.R₀ la







end Params

end GlobalTheory.IndefiniteRowSideFullHecke.WordBlockPolynomials
