import Mathlib
import Formalism.LocalToGlobal.ProjectiveLattices.ThShort
import Formalism.LocalToGlobal.ProjectiveLattices.ThProps
import Formalism.LocalToGlobal.ProjectiveLattices.ThGerm

set_option autoImplicit false

noncomputable section

namespace GlobalTheory.IndefiniteRowSideFullHecke.UnitaryAdjointCongruence

open NumberField MvPolynomial Formalism.L2.Pj ReciprocityTheory.ChartRestriction.G.Geo.Tor

section Lattices

variable {E : Type} [Field E] [NumberField E] [IsCMField E] {n : ℕ}

def adjM (γ : Matrix (Fin n) (Fin n) E) : Matrix (Fin n) (Fin n) E :=
  Matrix.of fun i j => IsCMField.complexConj E (γ j i)

def IsUnitaryM (γ : Matrix (Fin n) (Fin n) E) : Prop := adjM γ * γ = 1

def actLat (γ : Matrix (Fin n) (Fin n) E) (Λ : GenLat E n) : GenLat E n :=
  ⟨Λ.La.map ((Matrix.mulVecLin γ).restrictScalars (𝓞 E))⟩

def CongAt (m : ℕ) (x y : Fin n → E) : Prop :=
  ∃ k : ℕ, Nat.Coprime k m ∧ ∀ j, ∃ b : 𝓞 E, (k : E) * (x j - y j) = (m : E) * (b : E)

abbrev StdMod (E : Type) [Field E] (n m : ℕ) : Type := Fin n → 𝓞 E ⧸ Ideal.span {(m : 𝓞 E)}

def IsIsomMod (Λ : GenLat E n) (m : ℕ) (ι : Λ.La →ₗ[𝓞 E] StdMod E n m) : Prop :=
  Function.Surjective ι ∧
  (∀ v : Λ.La, ι v = 0 ↔ ∃ u ∈ Λ.La, (v : Fin n → E) = (m : E) • u) ∧
  ∀ (v w : Λ.La) (x y : Fin n → 𝓞 E), (∀ j, ι v j = Ideal.Quotient.mk _ (x j)) →
    (∀ j, ι w j = Ideal.Quotient.mk _ (y j)) →
    ∃ b : 𝓞 E, ∑ j, (v : Fin n → E) j * IsCMField.complexConj E ((w : Fin n → E) j) -
      ∑ j, (x j : E) * IsCMField.complexConj E (y j : E) = (m : E) * (b : E)

def IsRep (Λ : GenLat E n) (m : ℕ) (ι : Λ.La →ₗ[𝓞 E] StdMod E n m) (bad : ℕ)
    (γ : Matrix (Fin n) (Fin n) E) : Prop :=
  IsUnitaryM γ ∧ (actLat γ Λ).TrivAt bad ∧ (actLat γ Λ).TrivAt m ∧
  ∀ (v : Λ.La) (x : Fin n → 𝓞 E), (∀ j, ι v j = Ideal.Quotient.mk _ (x j)) →
    CongAt m (γ.mulVec v) fun j => (x j : E)

def RepExists (E : Type) [Field E] [NumberField E] [IsCMField E] (n : ℕ) : Prop :=
  Algebra.Unramified (𝓞 (maximalRealSubfield E)) (𝓞 E) →
  ∀ (m bad : ℕ), 0 < m → 0 < bad → ∀ (Λ : GenLat E n) (ι : Λ.La →ₗ[𝓞 E] StdMod E n m),
    Λ.Unimod → IsIsomMod Λ m ι → ∃ γ, IsRep Λ m ι bad γ

end Lattices

variable {E : Type} [Field E] [NumberField E] [IsCMField E] {H : Host E} {Dw : Datum H} {l : Level H}
variable (Xo : Moduli Dw l) (c : Coeff l)

def pushLet {n : ℕ} (γ : Matrix (Fin n) (Fin n) E) :
    MvPolynomial (LtN Dw n) c.F →ₐ[c.F] MvPolynomial (LtN Dw n) c.F :=
  aeval fun ℓ : LtN Dw n => letB c ℓ.1 ℓ.2.1 fun k => γ k ℓ.2.2

set_option autoImplicit false in
open NumberField MvPolynomial in
variable {E : Type} [Field E] [NumberField E] [IsCMField E] {H : _root_.ReciprocityTheory.ChartRestriction.G.Geo.Tor.Host E} {Dw : _root_.ReciprocityTheory.ChartRestriction.G.Geo.Tor.Datum H}
  {l : _root_.ReciprocityTheory.ChartRestriction.G.Geo.Tor.Level H} in
variable (Xo : _root_.ReciprocityTheory.ChartRestriction.G.Geo.Tor.Moduli Dw l) (c : _root_.ReciprocityTheory.ChartRestriction.G.Geo.Tor.Coeff l) in
theorem _root_.GlobalTheory.IndefiniteRowSideFullHecke.UnitaryAdjointCongruence.pushLet_letB {n : ℕ} (γ : Matrix (Fin n) (Fin n) E)
    (σ : E →+* ℂ) (i : Fin (Dw.mult σ)) (b : Fin n → E) :
    _root_.GlobalTheory.IndefiniteRowSideFullHecke.UnitaryAdjointCongruence.pushLet c γ (_root_.Formalism.L2.Pj.letB c σ i b) = _root_.Formalism.L2.Pj.letB c σ i (γ.mulVec b) := by
  unfold _root_.GlobalTheory.IndefiniteRowSideFullHecke.UnitaryAdjointCongruence.pushLet _root_.Formalism.L2.Pj.letB
  simp only [map_sum, map_mul, aeval_C, aeval_X, Matrix.mulVec, dotProduct, Finset.mul_sum,
    Finset.sum_mul, MvPolynomial.algebraMap_eq]
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun k _ => Finset.sum_congr rfl fun j _ => ?_
  ring



variable (Dw) in

def IsBeta {n : ℕ} (Λ : GenLat E n) (β : c.F) : Prop :=
  β ≠ 0 ∧ BetaIs (Dw := Dw) c Λ β ∧ BetaAbs (Dw := Dw) c Λ β

variable (l) in

def BadOK (bad : ℕ) : Prop :=
  0 < bad ∧ 2 ∣ bad ∧ l.M ∣ bad ∧ ∀ p : ℕ, p.Prime → (p : ℤ) ∣ NumberField.discr E → p ∣ bad












end GlobalTheory.IndefiniteRowSideFullHecke.UnitaryAdjointCongruence
