import Mathlib
import Development.AbelianVarietyTheory.Definitions.Divisors.MatchingOfParts
import Development.AbelianVarietyTheory.Definitions.Divisors.DiscreteSeriesHermitianUnique
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LatAtVAtStable
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.EqOfComponentTensorAdelicFunctionEq
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsFactorPureTensorComponentAtPlace
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.IsStdCharNegOneOfStandardTraceAdelicAddChar
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.AdelicRapidDecayOfMemAdelicSchwartzSpace
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExtendByZeroMemSchA
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.RapidDecayAdelicIntegrablePeriodisationContinuou
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.TotallyRealSelfAnnihilatorAdeleCharacter
import Development.AbelianVarietyTheory.Proofs.TwistedOperators.EqZeroOfFourierEqZero
open GlobalTheory.IndefiniteRowSideFullHecke.WeilTensorModels NumberField IsDedekindDomain Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes GlobalTheory.WeilM GlobalTheory.AdelicU GlobalTheory.LFun

noncomputable section
namespace GlobalTheory.SplitSvN
open MeasureTheory Matrix ComplexConjugate




variable {F : Type} [Field F] [NumberField F]

theorem schA_facts (hF : IsTotallyReal F) {κ : Type} [Fintype κ] [MeasurableSpace (κ → AF F)] [BorelSpace (κ → AF F)]
    {Φ : (κ → AF F) → ℂ} (hΦ : Φ ∈ schA F κ) : Continuous Φ ∧ (∃ C, ∀ x, ‖Φ x‖ ≤ C) ∧
      ∀ μ : Measure (κ → AF F), μ.IsAddHaarMeasure → Integrable Φ μ := by
  haveI := GlobalTheory.AdelicUnitaryTop.locallyCompact_adele F
  haveI := GlobalTheory.AdelicUnitaryTop.secondCountable_adele F
  haveI := GlobalTheory.AdelicUnitaryTop.t2Space_adeleRing_numberField F
  haveI : BorelSpace (AF F) := ⟨rfl⟩
  let j : Fin (Fintype.card κ) ≃ κ := (Fintype.equivFin κ).symm
  let r : (κ → AF F) ≃ₜ+ (Fin (Fintype.card κ) → AF F) :=
    { toFun := fun x => x ∘ j
      invFun := fun y => y ∘ j.symm
      left_inv := fun x => funext fun i => by simp
      right_inv := fun y => funext fun i => by simp
      map_add' := fun _ _ => rfl
      continuous_toFun := continuous_pi fun i => continuous_apply _
      continuous_invFun := continuous_pi fun i => continuous_apply _ }
  have hd := GlobalTheory.SchwartzDecay.decay_of_mem_schA F _ _ (GlobalTheory.RestrSchA.mem_schA_comp_extend F j j.injective Φ hΦ)
  set Φ' := fun y : Fin (Fintype.card κ) → AF F => Φ (Function.extend j y 0) with hΦ'
  have e : Φ = Φ' ∘ r := funext fun x => by
    show Φ x = Φ (Function.extend j (x ∘ j) 0)
    congr 1
    funext i
    obtain ⟨k, rfl⟩ := j.surjective i
    rw [j.injective.extend_apply]
    rfl
  refine ⟨e ▸ hd.1.comp r.continuous, ?_, fun μ hμ => ?_⟩
  · obtain ⟨C, hC⟩ := hd.2.2 0
    exact ⟨C, fun x => by rw [e]; simpa using hC (r x)⟩
  · have hi := (GlobalTheory.decay_integrable_periodise F _ hF Φ' hd).1 (μ.map r) (r.isAddHaarMeasure_map μ)
    rw [e]
    exact hi.comp_measurable r.continuous.measurable

def infOne : AF F := ((1 : InfiniteAdeleRing F), (0 : FiniteAdeleRing (𝓞 F) F))

def idem (S : Finset (Pl F)) : AF F :=
  infOne + ∑ w ∈ S, GlobalTheory.LatVac.liftV w 1

theorem fstA_idem (S : Finset (Pl F)) : fstA F (idem S) = 1 := by
  have h0 : fstA F (infOne (F := F)) = 1 := rfl
  have hl : ∀ w : Pl F, fstA F (GlobalTheory.LatVac.liftV w 1) = 0 := fun w => rfl
  rw [idem, map_add, map_sum, h0, Finset.sum_eq_zero fun w _ => hl w, add_zero]

open Classical in
theorem evFin_idem (S : Finset (Pl F)) (w : Pl F) : evFin F w (idem S) = if w ∈ S then 1 else 0 := by
  have h0 : evFin F w (infOne (F := F)) = 0 :=
    map_zero (evalV F w)
  have hs : ∑ x ∈ S, evFin F w (GlobalTheory.LatVac.liftV x 1) = ∑ x ∈ S, if w = x then (1 : Fv F w) else 0 := by
    refine Finset.sum_congr rfl fun x _ => ?_
    by_cases hx : w = x
    · subst hx; rw [if_pos rfl, GlobalTheory.LatVac.evFin_liftV]
    · rw [if_neg hx]; exact evalV_singleFin_ne hx _
  rw [idem, map_add, map_sum, h0, hs, Finset.sum_ite_eq S w (fun _ => (1 : Fv F w)), zero_add]

theorem evI_idem_mul (S : Finset (Pl F)) (t : AF F) : evI F (idem S * t) = evI F t := by
  change InfiniteAdeleRing.ringEquiv_mixedSpace F (fstA F (idem S * t)) =
    InfiniteAdeleRing.ringEquiv_mixedSpace F (fstA F t)
  rw [map_mul (fstA F), fstA_idem, one_mul]



open Classical in

theorem pure_split {κ : Type} [Fintype κ] (S : Finset (Pl F)) (f : SInf F κ) (φ ω : ∀ w : Pl F, (κ → Fv F w) → ℂ)
    (hω : ∀ᶠ w in Filter.cofinite, ω w = Set.indicator {x | ∀ i, x i ∈ w.adicCompletionIntegers F} 1)
    (hφ : ∀ w, w ∉ S → φ w = ω w) (x : κ → AF F) :
    pure f φ x = (fun z : κ → AF F => f (fun i => evI F (z i)) * ∏ w ∈ S, φ w fun i => evFin F w (z i)) (idem S • x) *
      (fun z : κ → AF F => ∏ᶠ w, if w ∈ S then (1 : ℂ) else ω w fun i => evFin F w (z i)) (x - idem S • x) := by
  have e1 : ∏ w ∈ S, φ w (fun i => evFin F w ((idem S • x) i)) =
      ∏ᶠ w, if w ∈ S then φ w (fun i => evFin F w (x i)) else 1 := by
    rw [finprod_eq_prod_of_mulSupport_subset (s := S) _ (fun w hw => by
      by_contra h
      exact hw (if_neg h))]
    refine Finset.prod_congr rfl fun w hw => ?_
    rw [if_pos hw]
    congr 1
    funext i
    rw [Pi.smul_apply, smul_eq_mul, map_mul, evFin_idem, if_pos hw, one_mul]
  have e2 : (∏ᶠ w, if w ∈ S then (1 : ℂ) else ω w fun i => evFin F w ((x - idem S • x) i)) =
      ∏ᶠ w, if w ∈ S then (1 : ℂ) else ω w fun i => evFin F w (x i) := by
    refine finprod_congr fun w => ?_
    split_ifs with hw
    · rfl
    · congr 1
      funext i
      rw [Pi.sub_apply, Pi.smul_apply, smul_eq_mul, map_sub, map_mul, evFin_idem, if_neg hw, zero_mul, sub_zero]
  simp only [GlobalTheory.IndefiniteRowSideFullHecke.WeilTensorModels.pure]
  rw [e1, e2, mul_assoc, ← finprod_mul_distrib]
  · congr 1
    · simp only [Pi.smul_apply, smul_eq_mul, evI_idem_mul]
    · refine finprod_congr fun w => ?_
      split_ifs with hw
      · rw [mul_one]
      · rw [one_mul, hφ w hw]
  · exact S.finite_toSet.subset fun w hw => by
      by_contra h
      exact hw (if_neg h)
  · exact (GlobalTheory.PureFactor.mulSupport_finite ω hω x).subset fun w hw => by
      intro h
      apply hw
      beta_reduce at h ⊢
      rw [h, ite_self]


end GlobalTheory.SplitSvN

end
