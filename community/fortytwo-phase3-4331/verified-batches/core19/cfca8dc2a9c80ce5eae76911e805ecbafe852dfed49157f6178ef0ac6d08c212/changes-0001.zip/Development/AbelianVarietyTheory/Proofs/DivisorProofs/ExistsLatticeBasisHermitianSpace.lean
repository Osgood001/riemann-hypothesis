import Mathlib
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.FactorResIEqResS
import Development.AbelianVarietyTheory.Proofs.UnitaryExistence.CompletedLatticeEqAdelicCompletionAndGram
import Development.AbelianVarietyTheory.Proofs.RingsOfIntegers.IsPrincipalIdealRingLoc
import Development.AbelianVarietyTheory.Proofs.UnitaryExistence.ExistsRootNear
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.NatMulIntegral

set_option autoImplicit false

noncomputable section

namespace GlobalTheory.LatAdelicBasis

open NumberField IsDedekindDomain
open scoped TensorProduct Matrix


theorem exists_nat_multiples {E : Type} [Field E] [NumberField E] (s : Finset E) :
    ∃ N : ℕ, 0 < N ∧ ∀ x ∈ s, ∃ o : 𝓞 E, (N : E) * x = algebraMap (𝓞 E) E o := by
  obtain ⟨y, hy, h⟩ := exists_integral_multiples ℤ ℚ s
  refine ⟨(y * y).toNat, by have := mul_self_pos.2 hy; omega, fun x hx => ?_⟩
  obtain ⟨p, hp⟩ : ∃ p : 𝓞 E, algebraMap (𝓞 E) E p = y • x := ⟨⟨y • x, h x hx⟩, rfl⟩
  refine ⟨(y : 𝓞 E) * p, ?_⟩
  have : (((y * y).toNat : ℕ) : E) = (y : E) * y := by
    have h0 : (((y * y).toNat : ℕ) : ℤ) = y * y := Int.toNat_of_nonneg (mul_self_nonneg y)
    rw [← Int.cast_natCast, h0, Int.cast_mul]
  rw [this, map_mul, map_intCast, hp, zsmul_eq_mul, mul_assoc]

theorem exists_level {E : Type} [Field E] [NumberField E] {n : ℕ} (L : Submodule (𝓞 E) (Fin n → E)) (hfg : L.FG)
    (hsp : Submodule.span E (L : Set (Fin n → E)) = ⊤) :
    ∃ N : ℕ, 0 < N ∧ (∀ j, (N : E) • (Pi.single j 1 : Fin n → E) ∈ L) ∧
      ∀ x ∈ L, ∀ i, ∃ o : 𝓞 E, (N : E) * x i = algebraMap (𝓞 E) E o := by
  first
  | exact @_root_.GlobalTheory.CoordinateBasisBounds.main
  | exact _root_.GlobalTheory.CoordinateBasisBounds.main
  | (apply _root_.GlobalTheory.CoordinateBasisBounds.main <;> assumption)
  | (intros; apply _root_.GlobalTheory.CoordinateBasisBounds.main <;> assumption)
  | (intros; apply @_root_.GlobalTheory.CoordinateBasisBounds.main <;> first | assumption | infer_instance)
  | (intros; exact _root_.GlobalTheory.CoordinateBasisBounds.main ..)


variable (F E : Type) [Field F] [NumberField F] [Field E] [NumberField E] [Algebra F E]

theorem left_mem (o : 𝓞 E) :
    (algebraMap (𝓞 E) E o) ⊗ₜ[F] (1 : FiniteAdeleRing (𝓞 F) F) ∈ Formalism.L2.Herm.intAf F E :=
  Subring.subset_closure (Or.inl ⟨⟨_, o, rfl⟩, rfl⟩)

theorem right_mem (a : FiniteAdeleRing (𝓞 F) F) (ha : ∀ v, a v ∈ v.adicCompletionIntegers F) :
    (1 : E) ⊗ₜ[F] a ∈ Formalism.L2.Herm.intAf F E :=
  Subring.subset_closure (Or.inr ⟨⟨a, ha⟩, rfl⟩)



end GlobalTheory.LatAdelicBasis

namespace GlobalTheory.LatAdelicBasis

open NumberField IsDedekindDomain ReciprocityTheory.ChartRestriction.G.Geo.Tor Formalism.BasicNotions Formalism.BasicNotions.TH Formalism.L2.Theta Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.L2.Pj Formalism.IndefR.Lev GlobalTheory.IndefiniteRowSideFullHecke GlobalTheory.GeoActCompare
open scoped TensorProduct Matrix
attribute [local instance] Formalism.BasicNotions.Host.cmStar


end GlobalTheory.LatAdelicBasis
