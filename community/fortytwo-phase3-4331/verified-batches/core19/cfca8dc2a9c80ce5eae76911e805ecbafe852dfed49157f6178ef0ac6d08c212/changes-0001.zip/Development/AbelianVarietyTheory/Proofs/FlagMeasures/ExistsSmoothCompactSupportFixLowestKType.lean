import Mathlib
import Development.AbelianVarietyTheory.Statements.CuspFrameWeights.ConvolutionSmoothL2
import Development.AbelianVarietyTheory.Statements.CuspFrameWeights.DiscreteSpectrumKFiniteDecomposition
import Formalism.HarderNarasimhan.ShiftInvariance
import Development.AbelianVarietyTheory.Statements.CuspFrameWeights.EigenfunctionFiniteCoefficients
import Formalism.RealPlaceAnalysis.FinalF
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.KMapLowestKTypeSubspaceEqScalar

open MeasureTheory NumberField Matrix Finset Formalism.MainNotions.S Formalism.REAL Formalism.QuantumDeterminants GlobalTheory.Count GlobalTheory.Dec GlobalTheory.DSId
open scoped InnerProductSpace ComplexOrder ContDiff

namespace GlobalTheory

attribute [local instance] Matrix.normedAddCommGroup Matrix.normedSpace

private lemma hs_mul_sub_one_comm_of_mem_Kset {n : ℕ} (ε : Fin n → Bool) {k : Matrix (Fin n) (Fin n) ℂ}
    (hk : k ∈ Kset ε) (y : Matrix (Fin n) (Fin n) ℂ) :
    Formalism.REAL.hs (k * y - 1) = Formalism.REAL.hs (y * k - 1) := by
  have hu : k ∈ Matrix.unitaryGroup (Fin n) ℂ := hk.1
  have h1 : k * star k = 1 := Matrix.mem_unitaryGroup_iff.mp hu
  have h2 : star k * k = 1 := Matrix.mem_unitaryGroup_iff'.mp hu
  have e1 : k * y - 1 = k * (y - star k) := by rw [mul_sub, h1]
  have e2 : y * k - 1 = (y - star k) * k := by rw [sub_mul, h2]
  have hinv := (hSBall n ε).2 (y - star k) k hk
  rw [e1, e2, hinv.1, hinv.2]

private lemma norm_apply_sq_le_hs {n : ℕ} (A : Matrix (Fin n) (Fin n) ℂ) (i j : Fin n) :
    ‖A i j‖ ^ 2 ≤ Formalism.REAL.hs A := by
  unfold Formalism.REAL.hs
  calc ‖A i j‖ ^ 2 ≤ ∑ j', ‖A i j'‖ ^ 2 :=
        Finset.single_le_sum (f := fun j' => ‖A i j'‖ ^ 2) (fun _ _ => by positivity)
          (Finset.mem_univ j)
    _ ≤ ∑ i', ∑ j', ‖A i' j'‖ ^ 2 :=
        Finset.single_le_sum (f := fun i' => ∑ j', ‖A i' j'‖ ^ 2)
          (fun _ _ => Finset.sum_nonneg fun _ _ => by positivity) (Finset.mem_univ i)

private lemma contDiff_hs_sub_one {n : ℕ} :
    ContDiff ℝ ∞ (fun y : Matrix (Fin n) (Fin n) ℂ => Formalism.REAL.hs (y - 1)) := by
  unfold Formalism.REAL.hs
  refine ContDiff.sum fun i _ => ContDiff.sum fun j _ => ?_
  have hsub : ContDiff ℝ ∞ (fun y : Matrix (Fin n) (Fin n) ℂ => y - 1) :=
    contDiff_id.sub contDiff_const
  have hent : ContDiff ℝ ∞ (fun y : Matrix (Fin n) (Fin n) ℂ => (y - 1) i j) :=
    (contDiff_apply_apply ℝ ℂ i j).comp hsub
  exact (contDiff_norm_sq ℝ).comp hent

theorem exists_conjInvariant_bump (n : ℕ) (ε : Fin n → Bool) (U : Set (UJ ε))
    (hU : U ∈ nhds (1 : UJ ε)) :
    ∃ a : Matrix (Fin n) (Fin n) ℂ → ℝ, ContDiff ℝ ∞ a ∧ (∀ y, 0 ≤ a y) ∧ a 1 ≠ 0 ∧
      HasCompactSupport (fun g : UJ ε => a (umat g)) ∧ (∀ g : UJ ε, a (umat g) ≠ 0 → g ∈ U) ∧
      ∀ k ∈ Kset ε, ∀ y, a (k * y) = a (y * k) := by
  obtain ⟨hemb, -⟩ := uJEmb n ε
  have hU' : U ∈ Filter.comap (fun g : UJ ε => umat g) (nhds (umat (1 : UJ ε))) := by
    rw [← hemb.isInducing.nhds_eq_comap]; exact hU
  obtain ⟨V, hV, hVU⟩ := Filter.mem_comap.mp hU'
  obtain ⟨r, hr, hrV⟩ := Metric.mem_nhds_iff.mp hV
  have hone : umat (1 : UJ ε) = 1 := rfl
  have hqc : Continuous (fun y : Matrix (Fin n) (Fin n) ℂ => Formalism.REAL.hs (y - 1)) :=
    contDiff_hs_sub_one.continuous
  have hball : ∀ y : Matrix (Fin n) (Fin n) ℂ, Formalism.REAL.hs (y - 1) < r ^ 2 →
      y ∈ Metric.ball (umat (1 : UJ ε)) r := by
    intro y hy
    rw [Metric.mem_ball, dist_eq_norm, hone, Matrix.norm_lt_iff hr]
    intro i j
    exact lt_of_pow_lt_pow_left₀ 2 hr.le ((norm_apply_sq_le_hs (y - 1) i j).trans_lt hy)
  have hcb : {y : Matrix (Fin n) (Fin n) ℂ | Formalism.REAL.hs (y - 1) ≤ r ^ 2} ⊆
      Metric.closedBall (1 : Matrix (Fin n) (Fin n) ℂ) r := by
    intro y hy
    rw [Metric.mem_closedBall, dist_eq_norm, Matrix.norm_le_iff hr.le]
    intro i j
    exact (pow_le_pow_iff_left₀ (norm_nonneg _) hr.le two_ne_zero).mp
      ((norm_apply_sq_le_hs (y - 1) i j).trans hy)
  have hr2 : 0 < r ^ 2 := by positivity
  refine ⟨fun y => Real.smoothTransition ((r ^ 2 - Formalism.REAL.hs (y - 1)) / r ^ 2), ?_, ?_, ?_, ?_,
    ?_, ?_⟩
  · exact Real.smoothTransition.contDiff.comp
      ((contDiff_const.sub contDiff_hs_sub_one).div_const _)
  · intro y
    exact Real.smoothTransition.nonneg _
  · have h0 : Formalism.REAL.hs ((1 : Matrix (Fin n) (Fin n) ℂ) - 1) = 0 := by
      simp [Formalism.REAL.hs]
    simp only [h0, sub_zero, div_self hr2.ne']
    rw [Real.smoothTransition.one_of_one_le le_rfl]
    exact one_ne_zero
  · have hclosed : IsClosed {y : Matrix (Fin n) (Fin n) ℂ | Formalism.REAL.hs (y - 1) ≤ r ^ 2} :=
      isClosed_le hqc continuous_const
    haveI : ProperSpace (Matrix (Fin n) (Fin n) ℂ) :=
      inferInstanceAs (ProperSpace (Fin n → Fin n → ℂ))
    have hK : IsCompact {y : Matrix (Fin n) (Fin n) ℂ | Formalism.REAL.hs (y - 1) ≤ r ^ 2} :=
      (isCompact_closedBall (1 : Matrix (Fin n) (Fin n) ℂ) r).of_isClosed_subset hclosed hcb
    refine HasCompactSupport.intro' (hemb.isCompact_preimage hK)
      (hclosed.preimage hemb.continuous) ?_
    intro g hg
    simp only [Set.mem_preimage, Set.mem_setOf_eq, not_le] at hg
    exact Real.smoothTransition.zero_of_nonpos
      (div_nonpos_of_nonpos_of_nonneg (by linarith) hr2.le)
  · intro g hg
    apply hVU
    apply hrV
    apply hball
    by_contra h
    push_neg at h
    exact hg (Real.smoothTransition.zero_of_nonpos
      (div_nonpos_of_nonpos_of_nonneg (by linarith) hr2.le))
  · intro k hk y
    simp only [hs_mul_sub_one_comm_of_mem_Kset ε hk y]


end GlobalTheory
