import Mathlib
import Development.AbelianVarietyTheory.Statements.CuspFrameWeights.SameKindIsometric

open MeasureTheory NumberField Matrix Finset

noncomputable section

namespace GlobalTheory.GaussMean

open Formalism.MainNotions.S GlobalTheory.Count GlobalTheory.FlagMeas

def qEps {n : ℕ} (ε : Fin n → Bool) (y : Fin n → ℂ) : ℝ := ∑ i, (if ε i then 1 else -1) * ‖y i‖ ^ 2



def sgn (R : Type) [Ring R] (s : Bool) : R := if s then 1 else -1







example : qEps (fun _ : Fin 1 => true) (fun _ => 1) = 1 := by simp [qEps]

end GlobalTheory.GaussMean
