import Mathlib
import Development.AbelianVarietyTheory.Definitions.TwistedInnerProducts.WittSmallGroupEmbeddingMemPointwiseStabilizerIso

noncomputable section

open Formalism.BasicNotions Formalism.BasicNotions.TH Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.MainNotions.StandardLattice Formalism.L2.Theta Formalism.IndefR.Datum MeasureTheory IsDedekindDomain NumberField Matrix
open GlobalTheory.MixModel
open scoped TensorProduct

attribute [local instance] Formalism.BasicNotions.Host.cmStar

namespace GlobalTheory.MixPer.Check

variable {D : D7}


section Target

variable {ψ : AddChar (AF D.host.F) ℂ} {S T T₀ : HSp D} {ρ : ℕ} (d : HypDec T T₀ ρ) (n : GA D T) (β : Mx D ρ T₀.rank)
  (y : Mx D S.rank ρ)








end Target


section Source

variable {ψ : AddChar (AF D.host.F) ℂ} {S S₀ T : HSp D} {ρ : ℕ} (d : HypDec S S₀ ρ) (n : GA D S) (β : Mx D S₀.rank ρ)
  (x : Mx D T.rank ρ)







end Source











end GlobalTheory.MixPer.Check

end
