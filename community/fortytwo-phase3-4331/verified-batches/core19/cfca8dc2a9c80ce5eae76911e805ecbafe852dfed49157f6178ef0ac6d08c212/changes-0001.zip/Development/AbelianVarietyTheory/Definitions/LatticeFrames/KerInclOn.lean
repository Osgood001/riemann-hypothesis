import Mathlib
import Development.AbelianVarietyTheory.Definitions.LatticeFrames.UnfoldingConstantsPos

noncomputable section

namespace GlobalTheory.Core.Rk

open Formalism.BasicNotions Formalism.MainNotions.S
open scoped InnerProductSpace

variable (D : D7) (u : D.what₂.Word)


def mfL (L : ℝ) : ℝ := (D.R.m : ℝ) ^ 5 * D.R.f * L





def RankMu : Prop :=
  (d0 D u : ℝ) = ((D.mem u).A.duStar : ℝ) * (((D.mem u).A.T : ℝ) ^ D.R.k - 1) ^ D.R.f






namespace Pts

variable (F : Pts)






end Pts

end GlobalTheory.Core.Rk

end
