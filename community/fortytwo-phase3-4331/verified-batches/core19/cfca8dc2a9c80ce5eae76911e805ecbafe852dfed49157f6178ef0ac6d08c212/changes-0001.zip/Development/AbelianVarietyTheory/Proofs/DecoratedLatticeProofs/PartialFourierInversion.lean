import Mathlib
import Development.AbelianVarietyTheory.Definitions.LatticeFrames.ContrFactor
import Development.AbelianVarietyTheory.Definitions.LatticeFrames.AllPositions
import Development.AbelianVarietyTheory.Proofs.TwistedOperators.FourierTransformInversionLocalFieldPi

open MeasureTheory ValuativeRel Matrix GlobalTheory.SplitWeil GlobalTheory.RootEx GlobalTheory.StepData GlobalTheory.SymChain
open scoped Topology

noncomputable section
namespace GlobalTheory.LocFlat.PartialFourier

theorem eventually_add_invariant {X : Type*} [TopologicalSpace X] [AddCommGroup X] [IsTopologicalAddGroup X]
    {f : X → ℂ} (hf : f ∈ SB X) : ∀ᶠ t in 𝓝 (0 : X), ∀ x, f (x + t) = f x := by
  have h1 : ∀ᶠ t in 𝓝 (0 : X), ∀ x ∈ tsupport f, f (x + t) = f x := by
    refine IsCompact.eventually_forall_of_forall_eventually hf.2 fun x _ => ?_
    have h2 : IsLocallyConstant fun q : X × X => (f (q.2 + q.1), f q.2) :=
      (hf.1.comp_continuous (by fun_prop)).prodMk (hf.1.comp_continuous continuous_snd)
    filter_upwards [h2.eventually_eq (0, x)] with q hq
    simp only [Prod.mk.injEq, add_zero] at hq
    rw [hq.1, hq.2]
  have h1' : ∀ᶠ t in 𝓝 (0 : X), ∀ x ∈ tsupport f, f (x + -t) = f x :=
    (continuous_neg.tendsto' (0 : X) 0 neg_zero).eventually h1
  filter_upwards [h1, h1'] with t ht ht' x
  by_cases hx : x ∈ tsupport f
  · exact ht x hx
  by_cases hx' : x + t ∈ tsupport f
  · have := ht' _ hx'
    rw [add_neg_cancel_right] at this
    exact this.symm
  · rw [image_eq_zero_of_notMem_tsupport hx, image_eq_zero_of_notMem_tsupport hx']

variable {k : Type} [Field k] [ValuativeRel k] [TopologicalSpace k] [IsNonarchimedeanLocalField k]
  [MeasurableSpace k] [BorelSpace k]

omit [BorelSpace k] in

theorem partial_mem_SB {I J : Type} [Fintype I] [Fintype J] (ν : Measure k) {f : (I → k) × (J → k) → ℂ}
    (hf : f ∈ SB ((I → k) × (J → k))) :
    (fun x₁ : I → k => ∫ y : J → k, f (x₁, y) ∂(Measure.pi fun _ => ν)) ∈ SB (I → k) := by
  refine ⟨(IsLocallyConstant.iff_eventually_eq _).mpr fun x => ?_, ?_⟩
  · have h2 : Filter.Tendsto (fun z : I → k => ((z - x, 0) : (I → k) × (J → k))) (𝓝 x) (𝓝 0) := by
      have : Continuous (fun z : I → k => ((z - x, 0) : (I → k) × (J → k))) := by fun_prop
      convert this.tendsto x using 2
      simp only [sub_self]
      rfl
    filter_upwards [h2.eventually (eventually_add_invariant hf)] with z hz
    congr 1
    funext y
    have := hz (x, y)
    simpa using this
  · refine HasCompactSupport.intro (hf.2.image continuous_fst) fun x hx => ?_
    have : ∀ y, f (x, y) = 0 := fun y => image_eq_zero_of_notMem_tsupport fun h => hx ⟨_, h, rfl⟩
    simp [this]


end GlobalTheory.LocFlat.PartialFourier
