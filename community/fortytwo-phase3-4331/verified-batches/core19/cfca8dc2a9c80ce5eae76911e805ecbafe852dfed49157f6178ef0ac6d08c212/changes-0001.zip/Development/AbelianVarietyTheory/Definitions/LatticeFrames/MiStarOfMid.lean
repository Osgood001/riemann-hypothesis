import Mathlib
import Formalism.LocalToGlobal.IndefiniteReal.ZeroPartEigenvalueConvention
import Formalism.LocalToGlobal.IndefiniteReal.EvTieP
import Formalism.LocalToGlobal.IndefiniteReal.LiftGoodPartComplexEqRangeFamily

noncomputable section

open scoped InnerProductSpace
open Formalism.BasicNotions Formalism.DivisionValues Formalism.L2.Indef Formalism.L2.Theta Formalism.L2.DIV Formalism.IndefR.Cx Formalism.IndefR.Links

namespace GlobalTheory.MiS
open Formalism Formalism.IndefR

attribute [local instance] Formalism.BasicNotions.Host.cmStar

section FreeSingleHomotopyEquivDiscreteChains

variable {D : D7} {G : Type} [Group G] [Fintype G] {Pl0 I0 T : Type}
  {A3 : FamIn3 D.what₂.LL G Pl0 I0 (List ℕ) T D.R.m} {Ks : Type} [Field Ks] [NumberField Ks] [Algebra Ks D.what₂.LL]



open scoped InnerProductSpace in

def PairZeroAt (R : RealDat3 D A3 Ks) (F : Face3 D A3)
    (sEE : (R.toCx3 F).EE →ₗ⋆[ℂ] (F.fc (R.toCx3 F).zs).Sp.HH) (d : (R.toCx3 F).MIDat F.fc)
    (u : (F.fc (R.toCx3 F).zs).Dc.Mem) : Prop :=
  ∀ t (φ : Fin ((F.fc (R.toCx3 F).zs).Dc.a u) → D.what₂.LL) (v : Fin ((F.fc (R.toCx3 F).zs).Df1.nV t) → D.what₂.LL),
    ⟪sEE (d.V ((R.toCx3 F).Θ t ((R.toCx3 F).jR t (F.eV (R.toCx3 F).zs t v)))),
      (F.fc (R.toCx3 F).zs).Sp.Pu u ((d.U u).mulVec (cpt A3.fam3.F.v0.embedding φ))⟫_ℂ = 0


end FreeSingleHomotopyEquivDiscreteChains

section Gen

variable {K : Type} [Field K] [NumberField K] [StarRing K] {Bs : DefBase K} {A : DefAmb Bs} (X : CxData A)
  {fc : DefSub A → DefFace Bs} (cr : Crd A fc) (cv : CrdV A)






variable {X cr cv}

end Gen

end GlobalTheory.MiS

end
