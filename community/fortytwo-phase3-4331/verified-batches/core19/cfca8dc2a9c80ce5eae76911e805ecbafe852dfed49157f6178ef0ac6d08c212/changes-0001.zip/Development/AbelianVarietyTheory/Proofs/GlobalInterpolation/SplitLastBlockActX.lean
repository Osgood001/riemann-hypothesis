import Mathlib
import Formalism.LocalToGlobal.Columns.FiniteSumNonzeroLargeDepth
import Formalism.LocalToGlobal.Columns.CoefColLemmas
import Formalism.SharpRestriction.Divisibility.PrimeDegreeVariant

open MvPolynomial

noncomputable section

namespace GlobalTheory.BranchFormula

open Formalism.BasicNotions Formalism.L2.DIV Formalism.L2.Col Formalism.L2.Col.Br

def IsBlock {R : Type} [Zero R] {N n : ℕ} (hN : N = n + 1) (A' : Matrix (Fin N) (Fin N) R) (A : Matrix (Fin n) (Fin n) R) (t : R) :
    Prop :=
  (∀ a b : Fin n, A' (iC hN a) (iC hN b) = A a b) ∧
    (∀ a : Fin n, A' (iC hN a) (iL hN) = 0 ∧ A' (iL hN) (iC hN a) = 0) ∧ A' (iL hN) (iL hN) = t


theorem prod_split {M : Type*} [CommMonoid M] {N n : ℕ} (hN : N = n + 1) (f : Fin N → M) :
    ∏ a, f a = (∏ a : Fin n, f (iC hN a)) * f (iL hN) := by
  subst hN
  exact Fin.prod_univ_castSucc f


theorem IsBlock.det {R : Type} [CommRing R] {N n : ℕ} {hN : N = n + 1} {A' : Matrix (Fin N) (Fin N) R}
    {A : Matrix (Fin n) (Fin n) R} {t : R} (h : IsBlock hN A' A t) : A'.det = A.det * t := by
  subst hN
  rw [Matrix.det_succ_row A' (Fin.last n), Fin.sum_univ_castSucc, Finset.sum_eq_zero, zero_add]
  · have h1 : A'.submatrix (Fin.last n).succAbove (Fin.last n).succAbove = A := by
      ext a b
      simp only [Matrix.submatrix_apply, Fin.succAbove_last]
      exact h.1 a b
    have h2 : A' (Fin.last n) (Fin.last n) = t := h.2.2
    rw [h1, h2, ← two_mul, pow_mul]
    simp [mul_comm]
  · intro a _
    have h2 : A' (Fin.last n) a.castSucc = 0 := (h.2.1 a).2
    rw [h2]
    simp

variable (K : Type) [Field K] (ι : Type) {N n : ℕ} (hN : N = n + 1)

def splitLast (_hN : N = n + 1) : Pol K ι N →ₐ[K] MvPolynomial (ι × Fin n) (Pol K ι n) :=
  aeval fun v : ι × Fin N × Fin N =>
    if h2 : v.2.2.val < n then
      (if h1 : v.2.1.val < n then C (X (v.1, ⟨v.2.1.val, h1⟩, ⟨v.2.2.val, h2⟩)) else X (v.1, ⟨v.2.2.val, h2⟩))
    else 0

@[simp] theorem splitLast_X_up (τ : ι) (a s : Fin n) :
    splitLast K ι hN (X (τ, iC hN a, iC hN s)) = C (X (τ, a, s)) := by
  simp [splitLast, iC]

@[simp] theorem splitLast_X_lastRow (τ : ι) (s : Fin n) :
    splitLast K ι hN (X (τ, iL hN, iC hN s)) = X (τ, s) := by
  simp [splitLast, iC, iL]

@[simp] theorem splitLast_X_lastCol (τ : ι) (a : Fin N) :
    splitLast K ι hN (X (τ, a, iL hN)) = 0 := by
  simp [splitLast, iL]

def expOf {ι : Type} [Fintype ι] {n : ℕ} (b : ι → Fin n → ℕ) : ι × Fin n →₀ ℕ :=
  Finsupp.equivFunOnFinite.symm fun p => b p.1 p.2

@[simp] theorem expOf_apply {ι : Type} [Fintype ι] {n : ℕ} (b : ι → Fin n → ℕ) (p : ι × Fin n) : expOf b p = b p.1 p.2 := rfl

theorem coefLast_eq_coeff [Fintype ι] (b : ι → Fin n → ℕ) (F : Pol K ι N) :
    coefLast hN b F = coeff (expOf b) (splitLast K ι hN F) := by
  classical
  induction F using MvPolynomial.induction_on' with
  | add p q hp hq => simp [hp, hq]
  | monomial m a =>
    have e : (monomial m a : Pol K ι N) = a • monomial m 1 := by simp [smul_monomial]
    rw [e, map_smul, map_smul, coeff_smul]
    congr 1
    rw [coefLast_monomial]
    have hm : splitLast K ι hN (monomial m 1) =
        (∏ τ, ∏ a, (0 : MvPolynomial (ι × Fin n) (Pol K ι n)) ^ m (τ, a, iL hN)) *
          monomial (expOf fun τ s => m (τ, iL hN, iC hN s))
            (monomial (m.comapDomain (upVar hN) (upVar_inj hN).injOn) (1 : K)) := by
      rw [monomial_eq, C_1, one_mul, Finsupp.prod_fintype _ _ (by simp), map_prod, Fintype.prod_prod_type,
        monomial_eq, monomial_eq, C_1, one_mul, Finsupp.prod_fintype _ _ (by simp), Finsupp.prod_fintype _ _ (by simp),
        map_prod, Fintype.prod_prod_type, Fintype.prod_prod_type (f := fun p : ι × Fin n => _), ← Finset.prod_mul_distrib,
        ← Finset.prod_mul_distrib]
      refine Finset.prod_congr rfl fun τ _ => ?_
      rw [Fintype.prod_prod_type, Fintype.prod_prod_type]
      simp only [prod_split hN, map_pow, splitLast_X_up, splitLast_X_lastRow, splitLast_X_lastCol, expOf_apply,
        Finsupp.comapDomain_apply, upVar, Finset.prod_mul_distrib]
      ring
    rw [hm]
    by_cases h2 : ∀ τ a, m (τ, a, iL hN) = 0
    · simp only [h2, pow_zero, Finset.prod_const_one, one_mul, coeff_monomial]
      congr 1
      apply propext
      constructor
      · intro h
        ext p
        simp [h.1]
      · intro h
        exact ⟨fun τ s => by simpa using congrArg (fun e => e (τ, s)) h, h2⟩
    · rw [if_neg (fun h => h2 h.2)]
      push Not at h2
      obtain ⟨τ, a, h⟩ := h2
      rw [Finset.prod_eq_zero (Finset.mem_univ τ) (Finset.prod_eq_zero (Finset.mem_univ a) (zero_pow h))]
      simp

section Proj

variable {K ι} [Fintype ι] [CharZero K]

omit [Fintype ι] [CharZero K] in
theorem fockB_comm {σ : Type} (f g : MvPolynomial σ K) : fockB f g = fockB g f :=
  @fockSHerm K _ starRingOfComm _ g f





omit [CharZero K] in
theorem fockB_blockAct (U : ι → Matrix (Fin n) (Fin n) K) (F F' : Pol K ι n) :
    fockB (Formalism.GradedWeylDivisibility.blockAct K U F) F' = fockB F (Formalism.GradedWeylDivisibility.blockAct K (fun τ => (U τ).transpose) F') :=
  @fockSAdj K _ starRingOfComm ι _ n U F F'

omit [CharZero K] in
theorem blockAct_mem_VV (sg : ι → DomWeight n) (U : ι → Matrix (Fin n) (Fin n) K) {F : Pol K ι n} (hF : F ∈ VV K sg) :
    Formalism.GradedWeylDivisibility.blockAct K U F ∈ VV K sg :=
  (Formalism.GradedWeylDivisibility.blockActTensor K K ι n n U).2 (fun τ => nablaSq K n (sg τ)) (fun τ => nablaSq K n (sg τ))
    (fun _ f hf => Formalism.GradedWeylDivisibility.dualWeylRowStable K n n _ _ f hf) F hF


end Proj






end GlobalTheory.BranchFormula
