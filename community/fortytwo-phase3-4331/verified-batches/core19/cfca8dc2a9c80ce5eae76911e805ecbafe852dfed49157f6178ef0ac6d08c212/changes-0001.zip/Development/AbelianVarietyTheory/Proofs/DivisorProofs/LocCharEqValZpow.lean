import Mathlib
import Development.AbelianVarietyTheory.Definitions.Divisors.CTSmallCone
import Development.AbelianVarietyTheory.BlockTheory.DivisorBase.WeilTensorModels

noncomputable section

namespace GlobalTheory.UnrEuler

open NumberField IsDedekindDomain GlobalTheory.LFun GlobalTheory.IndefiniteRowSideFullHecke.WeilTensorModels
open scoped nonZeroDivisors
open Formalism.L2.Host (aboveF)
open Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes

variable {F E : Type} [Field F] [NumberField F] [Field E] [NumberField E] [Algebra F E]




variable (E) in

def diffE : FractionalIdeal (𝓞 E)⁰ E := ((differentIdeal ℤ (𝓞 E) : Ideal (𝓞 E)) : FractionalIdeal (𝓞 E)⁰ E)


def nrm (𝔞 : FractionalIdeal (𝓞 E)⁰ E) : ℝ := ((FractionalIdeal.absNorm 𝔞 : ℚ) : ℝ)


variable (F) in

def kaOne (a a' : ℕ) (𝔟 𝔠 : FractionalIdeal (𝓞 E)⁰ E) : ℝ :=
  (nrm 𝔠 * |(discr F : ℝ)|) ^ (-(a : ℝ) / 2) * nrm 𝔟 ^ (-(((a + a' : ℕ) : ℝ) - 2) / 2)

variable (F) in

def kaZero (a' : ℕ) (𝔠 : FractionalIdeal (𝓞 E)⁰ E) : ℝ := (nrm 𝔠 * |(discr F : ℝ)|) ^ (-(a' : ℝ) / 2)








end GlobalTheory.UnrEuler
