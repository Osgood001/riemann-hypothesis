import Mathlib
import Development.AbelianVarietyTheory.Definitions.LatticeFrames.VacOfShape

noncomputable section

open Formalism.BasicNotions Formalism.BasicNotions.TH Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.MainNotions.StandardLattice Formalism.L2.Theta Formalism.IndefR Formalism.IndefR.Links Formalism.IndefR.Mult Formalism.IndefR.Datum MeasureTheory IsDedekindDomain NumberField Matrix
open GlobalTheory.MixModel GlobalTheory.MixPer GlobalTheory.Grow GlobalTheory.Unf GlobalTheory.LatPair GlobalTheory.SplitWeil ValuativeRel IsLocalRing
open scoped TensorProduct
attribute [local instance] Formalism.BasicNotions.Host.cmStar
open GlobalTheory.FinPl

namespace GlobalTheory.SeeSaw

variable {D : D7} {c : Comm D}





variable {k : Type} [Field k] [ValuativeRel k] [TopologicalSpace k] [IsNonarchimedeanLocalField k] {ι : Type} (o : TDat c k ι)



structure ReadS (t : Tup c) (ε : ℕ → ι → 𝓀[k]ˣ) (S₀ : (ι → 𝓀[k]ˣ) → t.Col 0 → t.Col 0) : Prop where
  ram : ∀ j, j ≤ D.R.m → ∀ ψ ∈ t.Ram j, ∀ α y, t.rd j α ψ y ∈ o.Ram j
  S : ∀ j, j + 2 ≤ D.R.m → ∀ ψ ∈ t.Ram j, ∀ α y, t.rd j α (t.S j ψ) y = o.S ε j (t.rd j α ψ y)
  S₀ : ∀ η, ∀ ψ ∈ t.Ram 0, S₀ η ψ ∈ t.Ram 0 ∧ ∀ α y, t.rd 0 α (S₀ η ψ) y = o.S (fun _ => η) 0 (t.rd 0 α ψ y)



end GlobalTheory.SeeSaw

end
