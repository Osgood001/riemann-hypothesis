import Mathlib
import Development.AbelianVarietyTheory.Definitions.Foundations.ThetaSeriesTies
import Development.AbelianVarietyTheory.BlockTheory.NonGaloisCusps.PlaceBelowAllPowers
import Development.AbelianVarietyTheory.Proofs.FoundationProofs.GoodPartMemBasisSeries
import Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.LenRBaseChangeSubquotient
import Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.LengthCommensurableOfIsLatIn
import Formalism.LocalToGlobal.Columns.LocWLemmas
import Formalism.SharpRestriction.LevelLetterCocycles.TwGood
import Formalism.MirabolicMackeyTheory.MirabolicMackeyProofs.RamBasic
import Formalism.LocalToGlobal.Divisibility.LiftLatLemmas

set_option autoImplicit false

noncomputable section

namespace GlobalTheory.TwistIndex

open NumberField IsDedekindDomain
open scoped TensorProduct

section Local

open Formalism.L2.Col Formalism.EigenvalueLevelCeiling

variable {K : Type} [Field K] [NumberField K] {v : HeightOneSpectrum (𝓞 K)}
  {O' : Type} [CommRing O'] [IsDomain O'] [IsDiscreteValuationRing O'] {emb : K →+* FractionRing O'}

def Induces (emb : K →+* FractionRing O') (v : HeightOneSpectrum (𝓞 K)) : Prop :=
  ∀ x : K, v.valuation K x ≤ 1 ↔ emb x ∈ (algebraMap O' (FractionRing O')).range

def Induces.hom (h : Induces emb v) : Ow v →+* O' :=
  ((RingEquiv.ofBijective (algebraMap O' (FractionRing O')).rangeRestrict
    ⟨fun _ _ e => IsFractionRing.injective O' (FractionRing O') (congrArg Subtype.val e),
      RingHom.rangeRestrict_surjective _⟩).symm : _ →+* O').comp
    ((emb.comp (algebraMap (Ow v) K)).codRestrict _ fun r => (h _).1 ((mem_range_ow_iff v _).1 ⟨r, rfl⟩))

omit [IsDomain O'] [IsDiscreteValuationRing O'] in
theorem Induces.hom_spec (h : Induces emb v) (r : Ow v) :
    algebraMap O' (FractionRing O') (h.hom r) = emb (algebraMap (Ow v) K r) :=
  congrArg Subtype.val ((RingEquiv.ofBijective (algebraMap O' (FractionRing O')).rangeRestrict
    ⟨fun _ _ e => IsFractionRing.injective O' (FractionRing O') (congrArg Subtype.val e),
      RingHom.rangeRestrict_surjective _⟩).apply_symm_apply _)

theorem Induces.hom_injective (h : Induces emb v) : Function.Injective h.hom := fun a b e =>
  algebraMap_ow_injective v (emb.injective (by rw [← h.hom_spec, ← h.hom_spec, e]))

theorem Induces.hom_local (h : Induces emb v) : IsLocalHom h.hom := by
  refine ⟨fun r hr => ?_⟩
  obtain ⟨s, hs⟩ := hr.exists_right_inv
  have e : emb (algebraMap (Ow v) K r) * algebraMap O' (FractionRing O') s = 1 := by
    rw [← h.hom_spec, ← map_mul, hs, map_one]
  have r0 : algebraMap (Ow v) K r ≠ 0 := fun h0 => by simp [h0] at e
  obtain ⟨t, ht⟩ := (mem_range_ow_iff v _).2 ((h (algebraMap (Ow v) K r)⁻¹).2
    ⟨s, by rw [map_inv₀]; exact eq_inv_of_mul_eq_one_right e⟩)
  refine IsUnit.of_mul_eq_one t (algebraMap_ow_injective v ?_)
  rw [map_mul, ht, mul_inv_cancel₀ r0, map_one]

variable {V : Type} [AddCommGroup V] [Module K V] [Module (𝓞 K) V] [IsScalarTower (𝓞 K) K V]
  {W : Type} [AddCommGroup W] [Module (FractionRing O') W] [Module O' W] [IsScalarTower O' (FractionRing O') W]

omit [IsScalarTower (𝓞 K) K V] in

theorem relLength_read (h : Induces emb v) (rd : V →ₛₗ[emb] W) {ι : Type} [Fintype ι] (b : Module.Basis ι K V)
    (hli : LinearIndependent (FractionRing O') fun a => rd (b a)) :
    ∃ e : ℕ, 0 < e ∧ (∀ n : ℕ, IsDiscreteValuationRing.addVal O' (n : O') =
        IsDiscreteValuationRing.addVal (Ow v) (n : Ow v) * e) ∧
      ∀ A B : Submodule (𝓞 K) V,
        relLength (Submodule.span O' (rd '' A)) (Submodule.span O' (rd '' B)) = lenW v A B * e := by
  let _ : Algebra (Ow v) O' := h.hom.toAlgebra
  have : IsLocalHom (algebraMap (Ow v) O') := h.hom_local
  have : FaithfulSMul (Ow v) O' := (faithfulSMul_iff_algebraMap_injective _ _).2 h.hom_injective
  let _ : Module (Ow v) W := Module.compHom W h.hom
  have : IsScalarTower (Ow v) O' W := ⟨fun r s x => mul_smul (h.hom r) s x⟩
  have hr : ∀ (r : Ow v) (x : V), rd (r • x) = h.hom r • rd x := fun r x => by
    rw [ow_smul_def, map_smulₛₗ, ← h.hom_spec, algebraMap_smul]
  let r : V →ₗ[Ow v] W := ⟨rd.toAddHom, hr⟩
  let g : O' ⊗[Ow v] V →ₗ[O'] W := r.liftBaseChange O'
  have hg : ∀ (s : O') (x : V), g (s ⊗ₜ x) = s • rd x := fun s x => LinearMap.liftBaseChange_tmul _ _ _ _
  have hnorm : ∀ t : O' ⊗[Ow v] V, ∃ c : Ow v, c ≠ 0 ∧ ∃ s : ι → O', c • t = ∑ a, s a ⊗ₜ b a := by
    intro t
    induction t with
    | zero => exact ⟨1, one_ne_zero, 0, by simp⟩
    | tmul s x =>
      obtain ⟨c, hc⟩ := IsLocalization.exist_integer_multiples_of_finite (nonZeroDivisors (Ow v)) (b.repr x)
      choose y hy using hc
      refine ⟨c, nonZeroDivisors.coe_ne_zero c, fun a => y a • s, ?_⟩
      rw [← TensorProduct.tmul_smul]
      conv_lhs => rw [← b.sum_repr x, Finset.smul_sum, TensorProduct.tmul_sum]
      refine Finset.sum_congr rfl fun a _ => ?_
      rw [TensorProduct.smul_tmul, ← smul_assoc, ← hy a, algebraMap_smul]
    | add x y hx hy =>
      obtain ⟨c, hc, s, hs⟩ := hx
      obtain ⟨d, hd, u, hu⟩ := hy
      refine ⟨c * d, mul_ne_zero hc hd, d • s + c • u, ?_⟩
      rw [smul_add, mul_comm c d, mul_smul, hs, mul_comm d c, mul_smul, hu, Finset.smul_sum, Finset.smul_sum,
        ← Finset.sum_add_distrib]
      refine Finset.sum_congr rfl fun a _ => ?_
      simp only [Pi.add_apply, Pi.smul_apply, TensorProduct.add_tmul, TensorProduct.smul_tmul']
  have hinj : Function.Injective g := by
    rw [injective_iff_map_eq_zero]
    intro t ht
    obtain ⟨c, hc, s, hs⟩ := hnorm t
    have h1 : ∑ a, algebraMap O' (FractionRing O') (s a) • rd (b a) = 0 := by
      have := congrArg g hs
      rw [← algebraMap_smul O' c, map_smul, ht, smul_zero, map_sum] at this
      simpa only [hg, algebraMap_smul] using this.symm
    have h2 : ∀ a, s a = 0 := fun a => (map_eq_zero_iff _ (IsFractionRing.injective O' (FractionRing O'))).1
      (Fintype.linearIndependent_iff.1 hli _ h1 a)
    have h3 : c • t = 0 := by simp [hs, h2]
    have cK : algebraMap (Ow v) K c ≠ 0 := (map_ne_zero_iff _ (algebraMap_ow_injective v)).2 hc
    let f : V →ₗ[Ow v] V := (((algebraMap (Ow v) K c)⁻¹ • LinearMap.id : V →ₗ[K] V)).restrictScalars (Ow v)
    have h4 : ∀ u : O' ⊗[Ow v] V, f.lTensor O' (c • u) = u := by
      intro u
      induction u with
      | zero => simp
      | tmul s x =>
        rw [← TensorProduct.tmul_smul, LinearMap.lTensor_tmul]
        congr 1
        exact inv_smul_smul₀ cK x
      | add x y hx hy => rw [smul_add, map_add, hx, hy]
    rw [← h4 t, h3, map_zero]
  have hsp : ∀ A : Submodule (𝓞 K) V, Submodule.span O' (rd '' A) = ((atW v A).baseChange O').map g := by
    intro A
    rw [atW, Submodule.baseChange_span, Submodule.map_span, Set.image_image]
    congr 1
    exact Set.image_congr fun x _ => by simp [hg]
  refine ⟨_, ramificationIdx_maximalIdeal_pos (Ow v) O', fun n => ?_, fun A B => ?_⟩
  · rw [← addVal_algebraMap O', map_natCast (algebraMap (Ow v) O')]
  · rw [hsp, hsp, relLength_map_of_injective g hinj]
    exact length_baseChange_subquotient_dvr (Ow v) O' _ _

omit [NumberField K] [IsDomain O'] [IsDiscreteValuationRing O'] [Module (𝓞 K) V] [IsScalarTower (𝓞 K) K V] [Module O' W]
  [IsScalarTower O' (FractionRing O') W] in

theorem exists_read {ι : Type} [Fintype ι] (b : Module.Basis ι K V) (x : ι → W) :
    ∃ rd : V →ₛₗ[emb] W, ∀ a, rd (b a) = x a := by
  classical
  refine ⟨⟨⟨fun y => ∑ a, emb (b.repr y a) • x a, fun y z => ?_⟩, fun r y => ?_⟩, fun a => ?_⟩
  · simp [add_smul, Finset.sum_add_distrib]
  · simp [mul_smul, Finset.smul_sum]
  · simp [Finsupp.single_apply, apply_ite emb]

variable [StarRing K]



omit [StarRing K] in
theorem lix_eq_signedLength (v : HeightOneSpectrum (𝓞 K)) (A B : Submodule (𝓞 K) V) :
    lix v A B = signedLength (atW v A) (atW v B) := by
  rw [lix, ← lidxW_eq_lidx, lidxW, lenW_inf, inf_comm, lenW_inf]
  rfl


end Local

section Export

open Formalism.ConjugateSelfDual ReciprocityTheory.Gal Formalism.BasicNotions Formalism.MainNotions.IntegralHeckeForms GlobalTheory.ExportCompare
open GlobalTheory.IndefiniteRowSideFullHecke.ToricLatticeDenominators (FmExt eExt incl)

variable {D : D7} {N : NData D.R D.host D.what₂} {X : NTw D.R D.host D.what₂ D.LL0 N}
  (Y : NExp D.R D.host D.what₂ D.LL0 N X) (E : ExpDat Y) (i : X.Tw) (j : ℕ) (b : Bool) (k : ℕ) (Q : Finset (PlE D.host))
  (φ : G D.host.E N.Om →* (X.Ok i k)ˣ)
  (O' : Type) [CommRing O'] [IsDomain O'] [IsDiscreteValuationRing O'] [Algebra (X.O i) O'] [Algebra (X.Ok i k) O']
  [IsScalarTower (X.O i) (X.Ok i k) O']
  {K : Type} [Field K] [NumberField K] {emb : K →+* FractionRing O'}
  {V : Type} [AddCommGroup V] [Module K V] [Module (𝓞 K) V] [IsScalarTower (𝓞 K) K V]

def Reads (e : V →ₗ[K] V) (Θ Θψ : Submodule (𝓞 K) V) (rd : V →ₛₗ[emb] FmExt Y i j b O') : Prop :=
  (∃ (n : ℕ) (β : Module.Basis (Fin n) K V), LinearIndependent (FractionRing O') fun a => rd (β a)) ∧
  (∀ x, rd (e x) = eExt Y i j b O' (rd x)) ∧
  Submodule.span O' (rd '' Θ) =
    Submodule.span O' ((fun a => (1 : FractionRing O') ⊗ₜ[X.O i] Y.th i j b a) '' SgJ Y E i j b) ∧
  Submodule.span O' (rd '' Θψ) =
    Submodule.span O' (incl Y i j b O' k '' ⋃ a ∈ SgJ Y E i j b, Y.thPsi i j b k Q φ a)

variable {Y E i j b k Q φ O'}

omit [IsDomain O'] [IsDiscreteValuationRing O'] [NumberField K] in

theorem Reads.comap {V' : Type} [AddCommGroup V'] [Module K V'] [Module (𝓞 K) V'] [IsScalarTower (𝓞 K) K V']
    {e : V →ₗ[K] V} {Θ Θψ : Submodule (𝓞 K) V} {rd : V →ₛₗ[emb] FmExt Y i j b O'}
    (h : Reads Y E i j b k Q φ O' e Θ Θψ rd) (f : V' →ₗ[K] V) (hf : Function.Bijective f) {e' : V' →ₗ[K] V'}
    (he : f ∘ₗ e' = e ∘ₗ f) :
    Reads Y E i j b k Q φ O' e' (Θ.comap (f.restrictScalars (𝓞 K))) (Θψ.comap (f.restrictScalars (𝓞 K))) (rd.comp f) := by
  obtain ⟨⟨n, β, hβ⟩, h2, h3, h4⟩ := h
  have him : ∀ L : Submodule (𝓞 K) V, (rd.comp f) '' (L.comap (f.restrictScalars (𝓞 K))) = rd '' L := fun L => by
    rw [LinearMap.coe_comp, Set.image_comp]
    exact congrArg _ (Set.image_preimage_eq _ hf.2)
  refine ⟨⟨n, β.map (LinearEquiv.ofBijective f hf).symm, ?_⟩, fun x => ?_, by rw [him, h3], by rw [him, h4]⟩
  · convert hβ using 2 with a
    exact congrArg rd ((LinearEquiv.ofBijective f hf).apply_symm_apply _)
  · exact (congrArg rd (LinearMap.congr_fun he x)).trans (h2 _)


end Export

section Chain

open Formalism.DivisionValues Formalism.EigenvalueLevelCeiling Formalism.L2.Indef Formalism.L2.Indef.Tree

variable {K : Type} [Field K] [NumberField K] [StarRing K] {Bs : DefBase K} {Df : DefSide Bs} {S : IndefData Df}
  {P : Type} [Group P] [Finite P] {oc : OnConst}






end Chain

section Record

open Formalism.ConjugateSelfDual ReciprocityTheory.Gal Formalism.BasicNotions Formalism.MainNotions Formalism.MainNotions.DIV.Cons Formalism.L2.Pj Formalism.L2.Indef Formalism.L2.Indef.Tree
open Formalism.BasicNotions.TH Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.L2.Theta Formalism.L2.DIV Formalism.IndefR Formalism.IndefR.Links Formalism.IndefR.FWT
open GlobalTheory.OnTies GlobalTheory.IndefiniteRowSideFullHecke.PlaceBelowAllPowers
open GlobalTheory.IndefiniteRowSideFullHecke.ToricLatticeDenominators (FmExt)

attribute [local instance] Formalism.BasicNotions.Host.cmStar

variable {D : D7}




variable {Γ : Type} [Group Γ] [Fintype Γ] {Pl0 T0 : Type} (A : FamIn D.what₂.LL Γ Pl0 T0 D.R.m)


variable {Bs : DefBase D.what₂.LL} {Df : DefSide Bs} {S : IndefData Df} {P : Type} [Group P] [Finite P] {oc : OnConst}


variable {A}









end Record

end GlobalTheory.TwistIndex
