import Mathlib
import Formalism.LocalRingCardinality.CoeNeZeroOfNotMem
import Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.StrongApproximationUnitaryCongruence
import Development.AbelianVarietyTheory.BlockTheory.GlobalSignature.StandardDeterminantUnit

open NumberField IsDedekindDomain Matrix Filter Topology

noncomputable section

namespace GlobalTheory.StdReps

open Formalism.L2.Col Formalism.HermitianLatticesTheory

variable {E : Type} [Field E] [NumberField E] {n : ℕ}

abbrev abv (P : HeightOneSpectrum (𝓞 E)) : AbsoluteValue E ℝ := NumberField.HeightOneSpectrum.adicAbv E P










variable [StarRing E]


omit [StarRing E] in
theorem tendsto_comb {ST : Finset (HeightOneSpectrum (𝓞 E))} (e : ST → ℕ → E) (Q : ST)
    (h1 : Tendsto (fun k => abv Q.1 (e Q k - 1)) atTop (𝓝 0))
    (h0 : ∀ P : ST, P ≠ Q → Tendsto (fun k => abv Q.1 (e P k)) atTop (𝓝 0)) (c : ST → E) :
    Tendsto (fun k => abv Q.1 (∑ P, e P k * c P - c Q)) atTop (𝓝 0) := by
  classical
  let _ : NormedField E := (abv Q.1).toNormedField
  have t : Tendsto (fun k => ∑ P, e P k * c P) atTop (𝓝 (∑ P, (if P = Q then 1 else 0) * c P)) := by
    refine tendsto_finsetSum _ fun P _ => Tendsto.mul_const _ ?_
    split_ifs with h
    · subst h
      exact tendsto_iff_norm_sub_tendsto_zero.2 h1
    · exact tendsto_zero_iff_norm_tendsto_zero.2 (h0 P h)
  simp only [ite_mul, one_mul, zero_mul, Finset.sum_ite_eq', Finset.mem_univ, if_true] at t
  exact tendsto_iff_norm_sub_tendsto_zero.1 t









end GlobalTheory.StdReps
