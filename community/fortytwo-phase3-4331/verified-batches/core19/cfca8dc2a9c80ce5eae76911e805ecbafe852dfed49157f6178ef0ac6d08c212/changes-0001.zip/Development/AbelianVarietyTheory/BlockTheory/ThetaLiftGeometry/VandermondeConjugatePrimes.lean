import Mathlib
import Formalism.SharpRestriction.GlobalSchurBounds.GL3Theta
import Formalism.LocalRingCardinality.DataKerI
import Formalism.LocalToGlobal.KernelLattices.LateralTheory

noncomputable section

namespace GlobalTheory.IndefiniteRowSideFullHecke.VandermondeConjugatePrimes

open NumberField Formalism.BasicNotions Formalism.MainNotions Formalism.MainNotions.TaylorLogMetric Formalism.MainNotions.GL3Theta

section Beta

variable {l : ℕ} [Fact l.Prime]










end Beta

def embAt (D : D7) {l : ℕ} [Fact l.Prime] (lam : Qbar →+* ℂ_[l]) (τ : D.what₂.Tau) {N : ℕ}
    (x : Fin N → D.host.E) : Fin N → ℂ_[l] × ℂ_[l] :=
  fun k => (lamC lam (embT D τ (x k)), lamC lam (embT D τ (D.host.conj (x k))))

def latAt (D : D7) {l : ℕ} [Fact l.Prime] (lam : Qbar →+* ℂ_[l]) (τ : D.what₂.Tau) {N : ℕ}
    (L : Submodule (𝓞 D.host.E) (Fin N → D.host.E)) : Set (Fin N → ℂ_[l] × ℂ_[l]) :=
  closure (embAt D lam τ '' (L : Set (Fin N → D.host.E)))


def colMat {l : ℕ} [Fact l.Prime] {N : ℕ} (b : Fin N → Fin N → ℂ_[l] × ℂ_[l]) : Matrix (Fin N) (Fin N) ℂ_[l] :=
  Matrix.of fun k a => (b a k).1

open Classical in

def chgO (D : D7) {l : ℕ} [Fact l.Prime] {N N' : ℕ} (c0 : D.what₂.Tau → ℂ_[l])
    (b : D.what₂.Tau → Fin N → Fin N → ℂ_[l] × ℂ_[l]) (b' : D.what₂.Tau → Fin N' → Fin N' → ℂ_[l] × ℂ_[l])
    (k : D.what₂.Tau × Fin N' × Fin N) (x : (Bool × Formalism.MainNotions.G.HH D) × Fin N × Fin N') : ℂ_[l] :=
  if tauPl D x.1 = k.1 then c0 k.1 * colMat (b' k.1) k.2.1 x.2.2 * (colMat (b k.1))⁻¹ x.2.1 k.2.2 else 0

variable {D : D7} {Dx : DivX D} {Tw : TwForms D}











end GlobalTheory.IndefiniteRowSideFullHecke.VandermondeConjugatePrimes
