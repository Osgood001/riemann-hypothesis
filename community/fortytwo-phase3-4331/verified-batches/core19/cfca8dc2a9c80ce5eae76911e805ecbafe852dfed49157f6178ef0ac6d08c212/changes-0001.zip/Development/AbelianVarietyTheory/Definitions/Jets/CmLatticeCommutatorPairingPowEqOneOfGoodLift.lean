import Mathlib
import Development.AbelianVarietyTheory.Proofs.HomogeneousIdeals.ExistsVariableChangeEqLatticeCurve

noncomputable section
open PowerSeries
open scoped ComplexConjugate

namespace GlobalTheory.MomOne

def wK (d : ℕ) : ℂ := (1 + Complex.I * ((Real.sqrt d : ℝ) : ℂ)) / 2

def InOK (d : ℕ) (z : ℂ) : Prop := ∃ u v : ℤ, z = (u : ℂ) + (v : ℂ) * wK d

def Split (d q : ℕ) : Prop := (q = 2 ∧ d % 8 = 7) ∨ (q ≠ 2 ∧ jacobiSym (-(d : ℤ)) q = 1)

def eis (d k : ℕ) : ℂ := ∑' w : {w : ℂ // InOK d w ∧ w ≠ 0}, 1 / (w : ℂ) ^ (2 * k)

def discr (d : ℕ) : ℂ := (60 * eis d 2) ^ 3 - 27 * (140 * eis d 3) ^ 2

def IsOK (d : ℕ) (L : PeriodPair) : Prop := ∀ z : ℂ, z ∈ L.lattice ↔ InOK d z

def h1 (d : ℕ) (z w : ℂ) : ℂ := ((2 / Real.sqrt d : ℝ) : ℂ) * (z * conj w)



def kap1 (d : ℕ) (x y : ℂ) : ℂ := Complex.exp (-(2 * (Real.pi : ℂ) * Complex.I) * (((h1 d x y).im : ℝ) : ℂ))





variable {q : ℕ} [Fact q.Prime]








def shiftS (ζ : ℂ_[q]) (f : ℂ_[q]⟦X⟧) : ℂ_[q]⟦X⟧ :=
  PowerSeries.mk fun n => ∑' m, coeff m f * ((m.choose n : ℂ_[q]) * ζ ^ n * (ζ - 1) ^ (m - n))


structure Mdl (q : ℕ) [Fact q.Prime] where

  ι : ℂ ≃+* ℂ_[q]

  L : PeriodPair

  c : ℂ

  W : WeierstrassCurve ℂ_[q]

namespace Mdl
variable (M : Mdl q)


def x (z : ℂ) : ℂ := M.L.weierstrassP z / M.c ^ 2 - M.ι.symm (M.W.b₂ / 12)

def y (z : ℂ) : ℂ :=
  (M.L.derivWeierstrassP z / M.c ^ 3 - M.ι.symm M.W.a₁ * M.x z - M.ι.symm M.W.a₃) / 2

open Classical in

def u (z : ℂ) : ℂ := if z ∈ M.L.lattice then 0 else -M.x z / M.y z

open Classical in

def w (z : ℂ) : ℂ := if z ∈ M.L.lattice then 0 else -1 / M.y z





end Mdl

def Good (ι : ℂ ≃+* ℂ_[q]) (d n s : ℕ) (y : ℂ) : Prop :=
  ∃ v : ℂ, InOK d v ∧ ‖ι (conj v)‖ ≤ (q : ℝ) ^ (-(2 * n : ℤ)) ∧ y = (s : ℂ) * v / (q : ℂ) ^ n


namespace Basic
open Filter Topology




open PowerSeries in
open scoped ComplexConjugate in
variable {q : ℕ} [Fact q.Prime] in
open Filter Topology in

theorem _root_.GlobalTheory.MomOne.Basic.discr_eq {d : ℕ} {L : PeriodPair}
    (h : _root_.GlobalTheory.MomOne.IsOK d L) :
    _root_.GlobalTheory.MomOne.discr d = L.g₂ ^ 3 - 27 * L.g₃ ^ 2 ∧
      _root_.GlobalTheory.MomOne.discr d ≠ 0 := by
  have hG : ∀ k, 0 < k → _root_.GlobalTheory.MomOne.eis d k = L.G (2 * k) := by
    intro k hk
    unfold _root_.GlobalTheory.MomOne.eis PeriodPair.G
    have e1 := tsum_subtype {w : ℂ | _root_.GlobalTheory.MomOne.InOK d w ∧ w ≠ 0}
      (fun w : ℂ => 1 / w ^ (2 * k))
    have e2 := tsum_subtype (L.lattice : Set ℂ) (fun w : ℂ => (w ^ (2 * k))⁻¹)
    refine e1.trans (Eq.trans ?_ e2.symm)
    congr 1
    ext z
    by_cases hz : z = 0
    · subst hz
      have : (2 * k) ≠ 0 := by omega
      simp [Set.indicator, zero_pow this]
    · have hz' : z ∈ (L.lattice : Set ℂ) ↔ _root_.GlobalTheory.MomOne.InOK d z := h z
      by_cases hm : _root_.GlobalTheory.MomOne.InOK d z
      · simp [Set.indicator, hz, hm, hz'.2 hm]
      · simp [Set.indicator, hm, mt hz'.1 hm]
  have hdisc : _root_.GlobalTheory.MomOne.discr d = L.g₂ ^ 3 - 27 * L.g₃ ^ 2 := by
    unfold _root_.GlobalTheory.MomOne.discr PeriodPair.g₂ PeriodPair.g₃
    rw [hG 2 (by norm_num), hG 3 (by norm_num)]
  refine ⟨hdisc, ?_⟩
  rw [hdisc, ← _root_.GlobalTheory.latticeCurve_Δ]
  exact _root_.GlobalTheory.latticeCurve_Δ_ne_zero L

def okPair (d : ℕ) (hd : 0 < d) : PeriodPair := ⟨1, wK d, LinearIndependent.pair_iff.2 fun s t h => by
  have hs : Real.sqrt d ≠ 0 := by positivity
  have h2 := congrArg Complex.im h
  have h1 := congrArg Complex.re h
  simp [wK, hs] at h1 h2
  subst h2
  exact ⟨by simpa using h1, rfl⟩⟩

open PowerSeries in
open scoped ComplexConjugate in
variable {q : ℕ} [Fact q.Prime] in
open Filter Topology in

theorem _root_.GlobalTheory.MomOne.Basic.isOK_okPair (d : ℕ) (hd : 0 < d) :
    _root_.GlobalTheory.MomOne.IsOK d (_root_.GlobalTheory.MomOne.Basic.okPair d hd) := by
  intro z
  rw [PeriodPair.mem_lattice]
  constructor
  · rintro ⟨m, n, rfl⟩
    exact ⟨m, n, by simp [_root_.GlobalTheory.MomOne.Basic.okPair]⟩
  · rintro ⟨u, v, rfl⟩
    exact ⟨u, v, by simp [_root_.GlobalTheory.MomOne.Basic.okPair]⟩

open Cardinal in

theorem mk_le_of_denseRange {A X : Type} [MetricSpace X] (f : A → X) (hf : DenseRange f) (hA : #A ≤ 𝔠) :
    #X ≤ 𝔠 := by
  have h : ∀ x : X, ∃ s : ℕ → A, Filter.Tendsto (fun n => f (s n)) Filter.atTop (nhds x) := fun x => by
    obtain ⟨u, hu, hx⟩ := mem_closure_iff_seq_limit.1 (hf x)
    choose s hs using hu
    exact ⟨s, by simpa only [hs] using hx⟩
  choose s hs using h
  have hinj : Function.Injective s := fun x y hxy =>
    tendsto_nhds_unique (hs x) (by rw [hxy]; exact hs y)
  refine (Cardinal.mk_le_of_injective hinj).trans ?_
  rw [← Cardinal.power_def, Cardinal.mk_nat]
  exact (Cardinal.power_le_power_right hA).trans_eq Cardinal.continuum_power_aleph0

open PowerSeries in
open scoped ComplexConjugate in
variable {q : ℕ} [Fact q.Prime] in
open Filter Topology in
open Cardinal in
private theorem cardinal_le_seq_of_denseRange {X Y : Type} [TopologicalSpace X]
    [FrechetUrysohnSpace X] [T2Space X] (i : Y → X) (hi : DenseRange i) : #X ≤ #(ℕ → Y) := by
  have h : ∀ x : X, ∃ u : ℕ → Y, Tendsto (i ∘ u) atTop (𝓝 x) := by
    intro x
    have hx : x ∈ closure (Set.range i) := by rw [hi.closure_range]; trivial
    obtain ⟨v, hv, hlim⟩ := mem_closure_iff_seq_limit.1 hx
    choose u hu using hv
    refine ⟨u, ?_⟩
    have : i ∘ u = v := funext fun n => hu n
    rw [this]; exact hlim
  choose u hu using h
  refine Cardinal.mk_le_of_injective (f := u) fun x y hxy => ?_
  have := hu y
  rw [← hxy] at this
  exact tendsto_nhds_unique (hu x) this

open PowerSeries in
open scoped ComplexConjugate in
variable {q : ℕ} [Fact q.Prime] in
open Filter Topology in
open Cardinal in
private theorem cardinal_padicComplex_eq_continuum (q : ℕ) [Fact q.Prime] : #ℂ_[q] = 𝔠 := by
  have hQ : #ℚ_[q] ≤ 𝔠 := by
    calc #ℚ_[q] ≤ #(ℕ → ℚ) := cardinal_le_seq_of_denseRange _ (Padic.denseRange_ratCast q)
      _ = 𝔠 := by rw [← power_def, Cardinal.mk_eq_aleph0 ℚ, Cardinal.mk_nat, aleph0_power_aleph0]
  have hA : #(PadicAlgCl q) ≤ 𝔠 :=
    (Algebra.IsAlgebraic.cardinalMk_le_max ℚ_[q] (PadicAlgCl q)).trans
      (max_le hQ aleph0_le_continuum)
  apply le_antisymm
  · calc #ℂ_[q] ≤ #(ℕ → PadicAlgCl q) :=
          cardinal_le_seq_of_denseRange _ UniformSpace.Completion.denseRange_coe
      _ = #(PadicAlgCl q) ^ ℵ₀ := by rw [← power_def, Cardinal.mk_nat]
      _ ≤ 𝔠 ^ ℵ₀ := power_le_power_right hA
      _ = 𝔠 := continuum_power_aleph0
  · obtain ⟨f, -, -, hf⟩ := Perfect.exists_nat_bool_injection
      (PerfectSpace.univ_perfect (α := ℚ_[q])) ⟨0, trivial⟩
    calc 𝔠 = #(ℕ → Bool) := by rw [← power_def, mk_bool, Cardinal.mk_nat, two_power_aleph0]
      _ ≤ #ℚ_[q] := mk_le_of_injective hf
      _ ≤ #ℂ_[q] := mk_le_of_injective (algebraMap ℚ_[q] ℂ_[q]).injective

open PowerSeries in
open scoped ComplexConjugate in
variable {q : ℕ} [Fact q.Prime] in
open Filter Topology in
open Cardinal in

theorem _root_.GlobalTheory.MomOne.Basic.nonempty_iso (q : ℕ) [Fact q.Prime] :
    Nonempty (ℂ ≃+* ℂ_[q]) := by
  refine IsAlgClosed.ringEquiv_of_equiv_of_charZero ?_ ?_
  · rw [Cardinal.mk_complex]; exact aleph0_lt_continuum
  · exact Cardinal.eq.1 (by rw [Cardinal.mk_complex, cardinal_padicComplex_eq_continuum])


open PowerSeries in
open scoped ComplexConjugate in
variable {q : ℕ} [Fact q.Prime] in
open Filter Topology in

theorem _root_.GlobalTheory.MomOne.Basic.norm_nat_eq_one {m : ℕ} (h : Nat.Coprime q m) :
    ‖(m : ℂ_[q])‖ = 1 := by
  have h1 : (m : ℂ_[q]) = (((m : ℚ_[q]) : PadicAlgCl q) : ℂ_[q]) := by simp
  rw [h1, PadicComplex.norm_extends, PadicAlgCl.norm_extends, Padic.norm_natCast_eq_one_iff]
  exact h





open PowerSeries in
open scoped ComplexConjugate in
variable {q : ℕ} [Fact q.Prime] in
open Filter Topology in

theorem _root_.GlobalTheory.MomOne.Basic.cmLatticeCommutatorPairing_pow_eq_one_of_good_lift (ι : ℂ ≃+* ℂ_[q]) {d n s : ℕ}
    (hd : 0 < d) {y : ℂ} (h : _root_.GlobalTheory.MomOne.Good ι d n s y) :
    ι (_root_.GlobalTheory.MomOne.kap1 d 1 y) ^ (q ^ n) = 1 := by
  obtain ⟨v, ⟨u, w, rfl⟩, -, rfl⟩ := h
  have hq : 0 < q := (Fact.out : q.Prime).pos
  have hs : Real.sqrt d ≠ 0 := by positivity
  have hd2 : Real.sqrt d ^ 2 = d := Real.sq_sqrt (by positivity)
  have him : ((q : ℂ) ^ n).im = 0 := by
    rw [← Complex.ofReal_natCast, ← Complex.ofReal_pow, Complex.ofReal_im]
  have hre : ((q : ℂ) ^ n).re = (q : ℝ) ^ n := by
    rw [← Complex.ofReal_natCast, ← Complex.ofReal_pow, Complex.ofReal_re]
  have hIm : (_root_.GlobalTheory.MomOne.h1 d 1 ((s : ℂ) * ((u : ℂ) + (w : ℂ) *
      _root_.GlobalTheory.MomOne.wK d) / (q : ℂ) ^ n)).im = -((s : ℝ) * w) / (q : ℝ) ^ n := by
    simp [_root_.GlobalTheory.MomOne.h1, _root_.GlobalTheory.MomOne.wK, Complex.div_im,
      Complex.div_re, Complex.mul_im, Complex.mul_re, him, hre]
    field_simp
    rw [hd2]
    ring
  have key : _root_.GlobalTheory.MomOne.kap1 d 1 ((s : ℂ) * ((u : ℂ) + (w : ℂ) *
      _root_.GlobalTheory.MomOne.wK d) / (q : ℂ) ^ n) ^ (q ^ n) = 1 := by
    unfold _root_.GlobalTheory.MomOne.kap1
    rw [← Complex.exp_nat_mul, hIm]
    have hqn : ((q : ℂ) ^ n) ≠ 0 := pow_ne_zero _ (by exact_mod_cast hq.ne')
    have : ((q ^ n : ℕ) : ℂ) * (-(2 * (Real.pi : ℂ) * Complex.I) *
        ((-((s : ℝ) * w) / (q : ℝ) ^ n : ℝ) : ℂ)) = ((s * w : ℤ) : ℂ) * (2 * Real.pi * Complex.I) := by
      push_cast
      field_simp
    rw [this, Complex.exp_int_mul_two_pi_mul_I]
  rw [← map_pow, key, map_one]



open PowerSeries in
open scoped ComplexConjugate in
variable {q : ℕ} [Fact q.Prime] in
open Filter Topology in

theorem _root_.GlobalTheory.MomOne.Basic.cmLatticeHermitianForm_mul_left (d : ℕ) (a z w : ℂ) :
    _root_.GlobalTheory.MomOne.h1 d (a * z) w = a * _root_.GlobalTheory.MomOne.h1 d z w := by
  unfold _root_.GlobalTheory.MomOne.h1; ring


example : Split 7 2 := Or.inl ⟨rfl, rfl⟩

example : Split 7 11 := Or.inr ⟨by norm_num, by norm_num⟩

example : ¬ Split 7 3 := by norm_num [Split]

open PowerSeries in
open scoped ComplexConjugate in
variable {q : ℕ} [Fact q.Prime] in
open Filter Topology in

theorem _root_.GlobalTheory.MomOne.Basic.shiftS_one (f : ℂ_[q]⟦X⟧) :
    _root_.GlobalTheory.MomOne.shiftS 1 f = f := by
  ext n
  rw [_root_.GlobalTheory.MomOne.shiftS, coeff_mk, tsum_eq_single n]
  · simp
  · intro m hm
    rcases lt_or_gt_of_ne hm with hlt | hgt
    · simp [Nat.choose_eq_zero_of_lt hlt]
    · have : m - n ≠ 0 := by omega
      simp [zero_pow this]

end Basic

end GlobalTheory.MomOne
