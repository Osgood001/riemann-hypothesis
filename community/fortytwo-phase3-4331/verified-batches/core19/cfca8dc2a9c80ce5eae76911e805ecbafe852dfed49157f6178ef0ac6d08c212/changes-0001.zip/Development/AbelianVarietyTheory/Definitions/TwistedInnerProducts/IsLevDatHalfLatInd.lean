import Mathlib
import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.CompIntField

set_option autoImplicit false

noncomputable section

section

open Formalism.BasicNotions Formalism.BasicNotions.TH Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.MainNotions.StandardLattice Formalism.L2.Theta IsDedekindDomain NumberField Formalism.IndefR.Datum Formalism.IndefR.Lev Formalism.IndefR.NX
open scoped TensorProduct
open Classical

namespace GlobalTheory.Tow

attribute [local instance] Formalism.BasicNotions.Host.cmStar

variable {D : D7}

export GlobalTheory.TowerCov (IsLevN LevN LevN.one modN KgW InKN IsLevDat IsCompFn IsLevG serAt TowerRat AdaptL TowerInt)











example (E : ExpSet D) : (LevN.one E).1 = 1 := rfl

example (E : ExpSet D) : AdaptL E 1 :=
  ⟨1, one_mem _, 1, (mul_one _).symm, fun _ _ _ _ a b => by
    have h1 : Formalism.L2.Theta.mt E.V 1 = 1 := by unfold Formalism.L2.Theta.mt; rw [map_one]; rfl
    rw [h1, sub_self]
    simp⟩

example {E : ExpSet D} {O : Type} [CommRing O] {C : CoefLat E O} {Base : Set (GA D E.W → ℂ)} {L1 FO : Subfield ℂ}
    (T : GlobalTheory.TowerCov.TowerRat E C Base L1 FO) : GlobalTheory.Tow.TowerRat E C Base L1 FO := T

end GlobalTheory.Tow

end

end
