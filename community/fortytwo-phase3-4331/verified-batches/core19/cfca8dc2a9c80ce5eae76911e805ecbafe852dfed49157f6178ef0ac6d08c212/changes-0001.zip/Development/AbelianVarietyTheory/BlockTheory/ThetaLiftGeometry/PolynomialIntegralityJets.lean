import Mathlib
import Formalism.LocalRingCardinality.DataKerI
import Formalism.SharpRestriction.GlobalSchurBounds.GL3Theta
import Formalism.LocalToGlobal.KernelLattices.LateralTheory

open NumberField

noncomputable section

namespace GlobalTheory.IndefiniteRowSideFullHecke.PolynomialIntegralityJets

open Formalism.BasicNotions Formalism.MainNotions

def jetAt {σ : Type*} {p : ℕ} [Fact p.Prime] (F : MvPowerSeries σ ℂ_[p]) (α : σ →₀ ℕ) : ℂ_[p] :=
  (α.prod fun _ n => (n.factorial : ℂ_[p])) * MvPowerSeries.coeff α F

def JetsIntegral {σ : Type*} {p : ℕ} [Fact p.Prime] (F : MvPowerSeries σ ℂ_[p]) : Prop :=
  ∀ α, ‖jetAt F α‖ ≤ 1












example (p : ℕ) [hp : Fact p.Prime] :
    ¬ JetsIntegral (MvPowerSeries.monomial (Finsupp.single () 1) ((p : ℂ_[p])⁻¹) : MvPowerSeries Unit ℂ_[p]) := by
  intro h
  have h1 := h (Finsupp.single () 1)
  have h2 : ‖(p : ℂ_[p])‖ < 1 := by
    have : ((p : ℕ) : ℂ_[p]) = algebraMap ℚ_[p] ℂ_[p] (p : ℚ_[p]) := by simp
    rw [this, norm_algebraMap']
    exact Padic.norm_p_lt_one
  have h3 : (p : ℂ_[p]) ≠ 0 := by exact_mod_cast hp.out.ne_zero
  simp only [jetAt, MvPowerSeries.coeff_monomial_same] at h1
  rw [Finsupp.prod_single_index (by simp)] at h1
  simp only [Nat.factorial_one, Nat.cast_one, one_mul, norm_inv] at h1
  have h4 := norm_pos_iff.2 h3
  rw [inv_le_one₀ h4] at h1
  linarith

end GlobalTheory.IndefiniteRowSideFullHecke.PolynomialIntegralityJets
