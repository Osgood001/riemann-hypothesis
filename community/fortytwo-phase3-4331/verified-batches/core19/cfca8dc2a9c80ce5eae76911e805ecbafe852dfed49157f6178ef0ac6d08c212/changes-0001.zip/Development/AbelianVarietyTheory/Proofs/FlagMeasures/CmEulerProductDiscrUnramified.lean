import Mathlib
import Development.AbelianVarietyTheory.BlockTheory.GlobalSignature.SelfDualUnramifiedPlaces
import Development.AbelianVarietyTheory.Definitions.SemilocalFrames.GaugeUnfold
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.IsFieldAdicCompletionTensorOfInert
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.NotIsFieldAdicCompletionTensorOfSplit
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.QuadraticUnramifiedIffInertOrSplit
import Development.AbelianVarietyTheory.Proofs.FlagMeasures.RootDiscrGeThreeHalvesOfIsTotallyComplex
import Formalism.GL3MeanSquares.HookFormulaTorsion.SumWeightsOverPrimeLeHalfDegree

noncomputable section

open NumberField IsDedekindDomain
open scoped TensorProduct

namespace GlobalTheory.DensityEuler

open private euler_factor_log_bound partial_sums_log_euler_factor_le from Formalism.GL3MeanSquares.HookFormulaTorsion.SumWeightsOverPrimeLeHalfDegree

variable {F E : Type} [Field F] [NumberField F] [Field E] [NumberField E] [StarRing E] [Algebra F E]

def conjInt (hc : Formalism.BasicNotions.CMData F E) : 𝓞 E →ₐ[𝓞 F] 𝓞 E := RingOfIntegers.mapAlgHom hc.sig

theorem conjInt_coe (hc : Formalism.BasicNotions.CMData F E) (x : 𝓞 E) :
    algebraMap (𝓞 E) E (conjInt hc x) = star (algebraMap (𝓞 E) E x) := rfl



theorem comap_mem_primesOver (hc : Formalism.BasicNotions.CMData F E) (v : Ideal (𝓞 F)) {P : Ideal (𝓞 E)}
    (hP : P ∈ v.primesOver (𝓞 E)) : P.comap (conjInt hc) ∈ v.primesOver (𝓞 E) := by
  have := hP.1
  refine ⟨Ideal.comap_isPrime _ _, ⟨?_⟩⟩
  rw [hP.2.over]
  ext x
  simp only [Ideal.under, Ideal.mem_comap, AlgHom.commutes]

omit [NumberField F] [StarRing E] in
theorem isMaximal_of_mem (v : HeightOneSpectrum (𝓞 F)) {P : Ideal (𝓞 E)}
    (hP : P ∈ v.asIdeal.primesOver (𝓞 E)) : P.IsMaximal := by
  have := hP.1
  have := hP.2
  exact hP.1.isMaximal (Ideal.ne_bot_of_liesOver_of_ne_bot v.ne_bot P)

theorem comap_ne_of_inertiaDeg_eq_one (hc : Formalism.BasicNotions.CMData F E) (v : HeightOneSpectrum (𝓞 F))
    {P : Ideal (𝓞 E)} (hP : P ∈ v.asIdeal.primesOver (𝓞 E)) (hf : P.inertiaDeg (𝓞 F) = 1) :
    P.comap (conjInt hc) ≠ P := by
  intro h
  have hm := isMaximal_of_mem v hP
  have := hP.2
  have := v.isMaximal
  rw [Ideal.inertiaDeg_eq_of_isMaximal v.asIdeal P] at hf
  let : Field (𝓞 F ⧸ v.asIdeal) := Ideal.Quotient.field _
  let : Field (𝓞 E ⧸ P) := Ideal.Quotient.field _
  have hs := (Algebra.finrank_eq_one_iff_bijective_algebraMap.1 hf).2
  obtain ⟨θ, t, ht, hn⟩ := hc.cmUnram.2.2 P hm
  obtain ⟨a, ha⟩ := hs (Ideal.Quotient.mk P θ)
  obtain ⟨a, rfl⟩ := Ideal.Quotient.mk_surjective a
  have h1 : θ - algebraMap (𝓞 F) (𝓞 E) a ∈ P := by
    rw [← Ideal.Quotient.eq, ← ha]; rfl
  have h2 : t - algebraMap (𝓞 F) (𝓞 E) a ∈ P := by
    have ht' : t = conjInt hc θ :=
      IsFractionRing.injective (𝓞 E) E (ht.trans (conjInt_coe hc θ).symm)
    have h3 := h1
    rw [← h, Ideal.mem_comap, map_sub, AlgHom.commutes, ← ht'] at h3
    exact h3
  apply hn
  simpa using P.sub_mem h1 h2

omit [StarRing E] in
theorem sum_eq_two (h2 : Module.finrank F E = 2) (v : HeightOneSpectrum (𝓞 F))
    [Fintype (v.asIdeal.primesOver (𝓞 E))] :
    ∑ P : v.asIdeal.primesOver (𝓞 E), P.1.ramificationIdx (𝓞 F) * P.1.inertiaDeg (𝓞 F) = 2 := by
  have := v.isPrime
  have hsum := Ideal.sum_ramification_inertia_eq_finrank v.asIdeal (𝓞 E)
  rwa [← IsFractionRing.finrank_eq (𝓞 F) F (𝓞 E) E, h2] at hsum

theorem unramifiedPlace (hc : Formalism.BasicNotions.CMData F E) (v : HeightOneSpectrum (𝓞 F)) :
    GlobalTheory.IndefiniteRowSideFullHecke.SelfDualUnramifiedPlaces.UnramifiedPlace F E v := by
  classical
  intro w hw
  have := v.isMaximal
  have : (w.asIdeal.under (𝓞 F)).IsMaximal := by rw [← hw.over]; exact v.isMaximal
  refine Ideal.ramificationIdx_eq_one_iff.1 ?_
  have hsum := sum_eq_two hc.deg2 v
  have hP : w.asIdeal ∈ v.asIdeal.primesOver (𝓞 E) := ⟨w.isPrime, hw⟩
  have hpos : ∀ P : v.asIdeal.primesOver (𝓞 E),
      1 ≤ P.1.ramificationIdx (𝓞 F) * P.1.inertiaDeg (𝓞 F) := fun P =>
    Nat.mul_pos (Ideal.ramificationIdx_pos _ _) (Ideal.inertiaDeg_pos _ _)
  have he : 0 < w.asIdeal.ramificationIdx (𝓞 F) := Ideal.ramificationIdx_pos _ _
  have hf : 0 < w.asIdeal.inertiaDeg (𝓞 F) := Ideal.inertiaDeg_pos _ _
  have h1 : w.asIdeal.ramificationIdx (𝓞 F) * w.asIdeal.inertiaDeg (𝓞 F) ≤ 2 :=
    hsum ▸ Finset.single_le_sum
      (f := fun P : v.asIdeal.primesOver (𝓞 E) =>
        P.1.ramificationIdx (𝓞 F) * P.1.inertiaDeg (𝓞 F))
      (fun _ _ => Nat.zero_le _) (Finset.mem_univ ⟨_, hP⟩)
  by_contra hne
  have hf1 : w.asIdeal.inertiaDeg (𝓞 F) = 1 := by
    have : 2 ≤ w.asIdeal.ramificationIdx (𝓞 F) := by omega
    nlinarith
  have hneq := comap_ne_of_inertiaDeg_eq_one hc v hP hf1
  have h3 := Finset.add_le_sum (s := Finset.univ)
    (f := fun P : v.asIdeal.primesOver (𝓞 E) =>
        P.1.ramificationIdx (𝓞 F) * P.1.inertiaDeg (𝓞 F)) (fun _ _ => Nat.zero_le _)
    (Finset.mem_univ ⟨_, comap_mem_primesOver hc _ hP⟩) (Finset.mem_univ ⟨_, hP⟩)
    (fun h => hneq (congrArg Subtype.val h))
  have h4 := hpos ⟨_, comap_mem_primesOver hc _ hP⟩
  rw [hsum] at h3
  simp only [hf1] at h3 h4
  omega


def fibreEquiv (F E : Type) [Field F] [NumberField F] [Field E] [NumberField E] [Algebra F E] :
    (Σ v : HeightOneSpectrum (𝓞 F), v.asIdeal.primesOver (𝓞 E)) ≃
      {P : Ideal (𝓞 E) // P.IsMaximal} :=
  Equiv.ofBijective (fun x => ⟨x.2.1, isMaximal_of_mem x.1 x.2.2⟩) <| by
    constructor
    · rintro ⟨v, P, hP⟩ ⟨w, Q, hQ⟩ h
      obtain rfl : P = Q := congrArg Subtype.val h
      obtain rfl : v = w := HeightOneSpectrum.ext (hP.2.over.trans hQ.2.over.symm)
      rfl
    · rintro ⟨P, hP⟩
      have hm : (P.under (𝓞 F)).IsMaximal := Ideal.IsMaximal.under _ P
      exact ⟨⟨⟨P.under (𝓞 F), hm.isPrime,
        Ring.ne_bot_of_isMaximal_of_not_isField hm (RingOfIntegers.not_isField F)⟩,
        P, hP.isPrime, ⟨rfl⟩⟩, rfl⟩




theorem differentIdeal_eq_top (hc : Formalism.BasicNotions.CMData F E) : differentIdeal (𝓞 F) (𝓞 E) = ⊤ := by
  by_contra h
  obtain ⟨P, hP, hle⟩ := Ideal.exists_le_maximal _ h
  obtain ⟨⟨v, Q, hQ⟩, h⟩ := (fibreEquiv F E).surjective ⟨P, hP⟩
  obtain rfl : Q = P := congrArg Subtype.val h
  have := hQ.2
  have hu := unramifiedPlace hc v ⟨Q, hQ.1, Ideal.ne_bot_of_liesOver_of_ne_bot v.ne_bot Q⟩ hQ.2
  exact (not_dvd_differentIdeal_iff.2 hu) (Ideal.dvd_iff_le.2 hle)



end GlobalTheory.DensityEuler
