import Mathlib

open Metric Set Filter
open scoped Topology ContDiff Nat

namespace GlobalTheory.SCV

section Estimates

variable {E V : Type*} [NormedAddCommGroup E] [NormedSpace ℂ E]
  [NormedAddCommGroup V] [NormedSpace ℂ V]






end Estimates

section FiniteDimensional

variable {E V : Type*} [NormedAddCommGroup E] [NormedSpace ℂ E] [FiniteDimensional ℂ E]
  [NormedAddCommGroup V] [NormedSpace ℂ V] [CompleteSpace V]



















section Limits
















end Limits

end FiniteDimensional

end GlobalTheory.SCV
