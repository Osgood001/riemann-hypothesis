import Mathlib
import Formalism.HermitianLattices.StatementMass
import Formalism.SharpRestriction.GlobalSchurBounds.GeneralLinearActions.GenusMassVolumes

noncomputable section

namespace GlobalTheory.IndefiniteRowSideFullHecke.LocalDualIndex

open scoped TensorProduct
open NumberField IsDedekindDomain Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes

section Characters



















end Characters

section Densities

variable (F E : Type) [Field F] [NumberField F] [Field E] [Algebra F E]

open Classical in

def etaV (v : HeightOneSpectrum (𝓞 F)) : ℝ :=
  if IsField (Fv F v ⊗[F] E) then -1 else 1



end Densities


end GlobalTheory.IndefiniteRowSideFullHecke.LocalDualIndex
