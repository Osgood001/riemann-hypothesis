import Mathlib
import Formalism.UnipotentAdelicQuotients.SWXSDefs

noncomputable section

open Matrix TensorProduct NumberField IsDedekindDomain MeasureTheory Topology
open HeckeCharacterZeroLocus.SiegelWeilU

namespace GlobalTheory.IndefiniteRowSideFullHecke.SiegelWeilGramDensity

section Defs

variable {F E : Type} [Field F] [NumberField F] [Field E] [Algebra F E]


def hermInv (R : Type) [CommRing R] [Algebra F R] (σ : E →ₐ[F] E) (n : ℕ) : Set (HermR R σ n) :=
  {S | IsUnit (S : Matrix (Fin n) (Fin n) (R ⊗[F] E)).det}

def IsGramDensity (R : Type) [CommRing R] [Algebra F R] [TopologicalSpace R] (σ : E →ₐ[F] E)
    {M n : ℕ} (J : Matrix (Fin M) (Fin M) E)
    (dX : Measure (Fin n → Fin M → R ⊗[F] E)) (dS : Measure (HermR R σ n))
    (Φ : (Fin n → Fin M → R ⊗[F] E) → ℂ) (g : HermR R σ n → ℂ) : Prop :=
  IsContDensityOn dX (gramR R σ J)
    (fun S : HermR R σ n => (S : Matrix (Fin n) (Fin n) (R ⊗[F] E))) dS (hermInv R σ n) Φ g

def gramFibre (σ : E →ₐ[F] E) {M n : ℕ} (J : Matrix (Fin M) (Fin M) E)
    (T : Matrix (Fin n) (Fin n) E) : Set (Fin n → Fin M → E) :=
  {X | gramE σ J X = T}



end Defs




example {F E : Type} [Field F] [Field E] [Algebra F E] (σ : E →ₐ[F] E) (M : ℕ) :
    IsHermND σ (1 : Matrix (Fin M) (Fin M) E) := by
  refine ⟨fun i j => ?_, by simp⟩
  by_cases h : i = j
  · subst h; simp
  · simp [Matrix.one_apply, h, Ne.symm h]

example (M n r : ℕ) (h1 : 1 ≤ n) (h : 2 * n < M) (hr : 2 * r ≤ M) : n + 2 ≤ M ∧ n + r < M := by
  omega

end GlobalTheory.IndefiniteRowSideFullHecke.SiegelWeilGramDensity
