import Mathlib
import Development.AbelianVarietyTheory.Definitions.Foundations.MatrixMeasurableSpace
import Development.AbelianVarietyTheory.Definitions.Foundations.SimpleSum

open MeasureTheory ValuativeRel Matrix
open scoped NNReal ENNReal

noncomputable section
namespace GlobalTheory.IndefiniteRowSideFullHecke.FourierJacobiAverage
open GlobalTheory.SplitWeil GlobalTheory.RootEx

section Algebra
variable {k : Type} [Field k] {n : Type} [Fintype n] [DecidableEq n]




def schT (β₀ : n → k) (Φ₀ : (n → k) → ℂ) : (n → k) → ℂ := fun β => Φ₀ (β + β₀)

def schM (ψ : AddChar k Circle) (u : n → k) (Φ₀ : (n → k) → ℂ) : (n → k) → ℂ :=
  fun β => (ψ (u ⬝ᵥ β) : ℂ) * Φ₀ β

def colM {n' : Type} (c p : ℕ) (ξ : n → k) : Matrix (n ⊕ Fin c) (n' ⊕ Fin (c + 1)) k :=
  fromBlocks 0 (Matrix.of fun r i => if i.val + 1 = p then ξ r else 0) 0 0

def rowM (n : Type) {n' : Type} (c p : ℕ) (u' : n' → k) : Matrix (n ⊕ Fin c) (n' ⊕ Fin (c + 1)) k :=
  fromBlocks 0 0 (Matrix.of fun l s => if l.val + 1 = p then u' s else 0) 0


end Algebra

section Apply






end Apply

section Defs
variable {k : Type} [Field k] [ValuativeRel k] [TopologicalSpace k] [IsNonarchimedeanLocalField k]
variable {n n' : Type} [Fintype n] [DecidableEq n] [Fintype n'] [DecidableEq n']
variable {P A P' A' : Type} [AddCommGroup P] [Module ℂ P] [AddCommGroup A] [Module ℂ A]
  [AddCommGroup P'] [Module ℂ P'] [AddCommGroup A'] [Module ℂ A']





variable [MeasurableSpace k] [BorelSpace k]

def hat (ψ : AddChar k Circle) (ν : Measure k) (Φ₀ : (n → k) → ℂ) (u : n → k) : ℂ :=
  ∫ β, Φ₀ β * (ψ (u ⬝ᵥ β) : ℂ) ∂(Measure.pi fun _ => ν)










end Defs

section Statements
variable (k : Type) [Field k] [ValuativeRel k] [TopologicalSpace k] [IsNonarchimedeanLocalField k]
  [MeasurableSpace k] [BorelSpace k]







end Statements


example {k n : Type} [Field k] [Fintype n] [DecidableEq n] (ψ : AddChar k Circle) (u β₀ : n → k)
    (Φ₀ : (n → k) → ℂ) : schM ψ u (schT β₀ Φ₀) = (ψ (-(u ⬝ᵥ β₀)) : ℂ) • schT β₀ (schM ψ u Φ₀) := by
  funext β
  simp only [schM, schT, Pi.smul_apply, smul_eq_mul, dotProduct_add, ← mul_assoc, ← Circle.coe_mul,
    ← AddChar.map_add_eq_mul]
  congr 3
  ring

example {k n n' : Type} [Field k] {c p : ℕ} (x : Matrix (n ⊕ Fin c) (n' ⊕ Fin (c + 1)) k) (ξ : n → k) (u' : n' → k) :
    ch (x + colM c p ξ) = ch x ∧ ch (x + rowM n c p u') = ch x := by
  simp [ch, colM, rowM]

end GlobalTheory.IndefiniteRowSideFullHecke.FourierJacobiAverage
