import Mathlib
import Formalism.LocalRingCardinality.DataHost
import Formalism.LocalRingCardinality.DataRows
import Formalism.LocalRingCardinality.DataSpaces
import Formalism.LocalRingCardinality.DataTheta
import Formalism.LocalRingCardinality.RhoDetPrimeEqMuTildeMulChiPow
import Formalism.LocalToGlobal.BesselHermitianTheta.DefsReal
import Formalism.LocalToGlobal.BesselHermitianTheta.MinfDensity
import Formalism.LocalToGlobal.BesselHermitianTheta.TiedWeil
import Formalism.SharpRestriction.GlobalSchurBounds.GeneralLinearActions.GenusMassVolumes
import Formalism.SharpRestriction.RamificationFrobenius.TotientGaloisClasses.ConjEMemHostFIff

noncomputable section

open Formalism.BasicNotions Formalism.BasicNotions.TH Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.MainNotions.StandardLattice Formalism.L2.Theta MeasureTheory NumberField
open scoped TensorProduct

namespace GlobalTheory.IndefiniteRowSideFullHecke.FockOrthogonalDecomposition

attribute [local instance] Formalism.BasicNotions.Host.cmStar

variable {D : D7}

structure IsOrthDec (V : HSp D) (τ : D.what₂.Tau) (P N : Submodule D.host.E V.V) : Prop where
  compl : IsCompl P N
  orth : ∀ x ∈ P, ∀ y ∈ N, V.hT x y = 0
  pos : ∀ x ∈ P, x ≠ 0 → 0 < (tauE D τ (V.hT x x)).re
  neg : ∀ x ∈ N, x ≠ 0 → (tauE D τ (V.hT x x)).re < 0

def IsSignInv (V : HSp D) (τ : D.what₂.Tau) (s : Module.End D.host.E V.V) : Prop :=
  ∃ P N : Submodule D.host.E V.V, IsOrthDec V τ P N ∧ (∀ x ∈ P, s x = x) ∧ ∀ x ∈ N, s x = -x

abbrev InvFam (V : HSp D) : Type := D.what₂.Tau → Module.End D.host.E V.V


def thAt (V : HSp D) (τ : D.what₂.Tau) (s : Module.End D.host.E V.V) : Matrix (Fin V.rank) (Fin V.rank) ℂ :=
  (LinearMap.toMatrix V.frame V.frame s).map (tauE D τ)


abbrev InfFam (D : D7) : Type := D.what₂.Tau → (Ainf D.host.F ⊗[D.host.F] D.host.E →+* ℂ)




abbrev WC (V W : HSp D) : Type := Matrix (Fin V.rank) (Fin W.rank) ℂ

def wAt (θ : InfFam D) (V W : HSp D) (τ : D.what₂.Tau) (x : WA V W) : WC V W :=
  x.map fun a => θ τ (infPart D a)

def actC (V W : HSp D) (g : Matrix (Fin V.rank) (Fin V.rank) ℂ) (h : Matrix (Fin W.rank) (Fin W.rank) ℂ)
    (x : WC V W) : WC V W :=
  if V.rank ≤ W.rank then g.map (starRingEnd ℂ) * x * h.transpose
  else g * x * (h.map (starRingEnd ℂ)).transpose



def jAt (V W : HSp D) (τ : D.what₂.Tau) (s : Module.End D.host.E V.V) (s' : Module.End D.host.E W.V)
    (x : WC V W) : WC V W :=
  Complex.I • actC V W (thAt V τ s) (thAt W τ s') x



def IsRealLine (V W : HSp D) (L : ℝ →+ WA V W) : Prop :=
  Continuous L ∧ ∀ t, (L t).map (finPart D) = 0

def dHeis (ψ : AddChar (AF D.host.F) ℂ) (V W : HSp D) (L : ℝ →+ WA V W) (f : WA V W → ℂ) : WA V W → ℂ :=
  fun w => deriv (fun t : ℝ => Heisenberg₂ ψ V W (L t) f w) 0

def IsJPair (θ : InfFam D) (V W : HSp D) (s : InvFam V) (s' : InvFam W) (L L' : ℝ →+ WA V W) : Prop :=
  IsRealLine V W L ∧ IsRealLine V W L' ∧
    ∀ t τ, wAt θ V W τ (L' t) = jAt V W τ (s τ) (s' τ) (wAt θ V W τ (L t))

def cre (ψ : AddChar (AF D.host.F) ℂ) (V W : HSp D) (L L' : ℝ →+ WA V W) (f : WA V W → ℂ) : WA V W → ℂ :=
  dHeis ψ V W L f - Complex.I • dHeis ψ V W L' f

def ann (ψ : AddChar (AF D.host.F) ℂ) (V W : HSp D) (L L' : ℝ →+ WA V W) (f : WA V W → ℂ) : WA V W → ℂ :=
  dHeis ψ V W L f + Complex.I • dHeis ψ V W L' f

def IsVacuum (ψ : AddChar (AF D.host.F) ℂ) (θ : InfFam D) (V W : HSp D) (s : InvFam V) (s' : InvFam W)
    (f : WA V W → ℂ) : Prop :=
  IsThetaFun ψ V W f ∧ ∀ L L', IsJPair θ V W s s' L L' → ann ψ V W L L' f = 0

inductive IsFockMon (ψ : AddChar (AF D.host.F) ℂ) (θ : InfFam D) (V W : HSp D) (s : InvFam V) (s' : InvFam W) :
    (WA V W → ℂ) → Prop
  | vac (f : WA V W → ℂ) : IsVacuum ψ θ V W s s' f → IsFockMon ψ θ V W s s' f
  | cre (L L' : ℝ →+ WA V W) (f : WA V W → ℂ) : IsJPair θ V W s s' L L' → IsFockMon ψ θ V W s s' f →
      IsFockMon ψ θ V W s s' (cre ψ V W L L' f)


variable {X : ThetaX D}




















example (V : HSp D) (τ : D.what₂.Tau) (h : ∀ x : V.V, x ≠ 0 → 0 < (tauE D τ (V.hT x x)).re) : IsSignInv V τ 1 :=
  ⟨⊤, ⊥, ⟨isCompl_top_bot, fun x _ y hy => by rw [(Submodule.mem_bot _).1 hy, map_zero], fun x _ => h x,
    fun x hx hx' => absurd ((Submodule.mem_bot _).1 hx) hx'⟩, fun _ _ => rfl,
    fun x hx => by rw [(Submodule.mem_bot _).1 hx]; simp⟩

example (V W : HSp D) (τ : D.what₂.Tau) (x : WC V W) : jAt V W τ 1 1 x = Complex.I • x := by
  have h : ∀ U : HSp D, thAt U τ 1 = 1 := fun U => by
    simp only [thAt, LinearMap.toMatrix_one]
    exact Matrix.map_one _ (map_zero _) (map_one _)
  simp only [jAt, actC, h]
  split_ifs <;> simp


end GlobalTheory.IndefiniteRowSideFullHecke.FockOrthogonalDecomposition

end
