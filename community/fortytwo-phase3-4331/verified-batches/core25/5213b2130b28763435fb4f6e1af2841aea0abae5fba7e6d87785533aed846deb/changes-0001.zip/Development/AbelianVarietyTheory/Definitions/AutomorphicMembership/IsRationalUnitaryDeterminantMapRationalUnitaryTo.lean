import Mathlib
import Formalism.LocalRingCardinality.DataHost
import Formalism.LocalRingCardinality.Params
import Formalism.LocalRingCardinality.RhoDetPrimeEqMuTildeMulChiPow
import Formalism.LocalToGlobal.UnitaryNorms.CharHost
import Formalism.LocalToGlobal.UnitaryNorms.IsUnitaryNormOf
import Formalism.SharpRestriction.RamificationFrobenius.TotientGaloisClasses.ConjEMemHostFIff
import Formalism.SharpRestriction.RamificationFrobenius.TotientGaloisClasses.ZsmulGeneratorEqZeroOfProjection
import ReciprocityTheory.NeutralLocalFields.LocalFieldComparison.HCFFromRecipB
import ReciprocityTheory.NeutralLocalFields.Reciprocity

noncomputable section

open NumberField IsDedekindDomain Formalism.BasicNotions Formalism.FrobeniusOrbits Neutral.B1 ReciprocityTheory.Neutral.Bridge.HCFR Formalism.L2.Host

namespace GlobalTheory.Mem.Chr

section General

variable (L : Type) [Field L] [NumberField L]

def unitIdl : Subgroup (Ideles L) where
  carrier := {a | ∀ v, Valued.v ((a : AdeleRing (𝓞 L) L).2 v) = 1}
  one_mem' := fun v => by
    show Valued.v (1 : v.adicCompletion L) = 1
    exact map_one _
  mul_mem' := fun {a b} ha hb v => by
    show Valued.v ((a : AdeleRing (𝓞 L) L).2 v * (b : AdeleRing (𝓞 L) L).2 v) = 1
    rw [map_mul, ha v, hb v, one_mul]
  inv_mem' := fun {a} ha v => by
    have h : (a : AdeleRing (𝓞 L) L).2 v * ((a⁻¹ : Ideles L) : AdeleRing (𝓞 L) L).2 v = 1 :=
      congrArg (fun z : AdeleRing (𝓞 L) L => z.2 v) a.mul_inv
    have h2 := congrArg (Valued.v : Valuation (v.adicCompletion L) _) h
    rw [map_mul, ha v, one_mul, map_one] at h2
    exact h2

def finPartI : Ideles L →* Ideles L :=
  Units.map ((MonoidHom.inr (InfiniteAdeleRing L) (FiniteAdeleRing (𝓞 L) L)).comp
    (MonoidHom.snd (InfiniteAdeleRing L) (FiniteAdeleRing (𝓞 L) L)))

variable {L}

def locF (F : Type) [Field F] [NumberField F] [Algebra F L] (v : HeightOneSpectrum (𝓞 F)) (k : Fˣ) : Ideles L :=
  ∏ Q ∈ aboveF (L := L) F v, localIdele L Q (atFin Q (upF F k))

def ConjPl (c : L ≃+* L) (v v' : HeightOneSpectrum (𝓞 L)) : Prop :=
  ∀ x : L, v'.valuation L (c x) = v.valuation L x

structure IsConjI (c : L ≃+* L) (C : Ideles L →* Ideles L) : Prop where
  cont : Continuous C
  diag : ∀ k : Lˣ, C (diagUnits L k) = diagUnits L (Units.map (MonoidHomClass.toMonoidHom c) k)
  inf : ∀ (w : InfinitePlace L) (k : Lˣ), C (infIdele L w (atInf w k)) =
    infIdele L (w.comap (c.symm : L →+* L)) (atInf _ (Units.map (MonoidHomClass.toMonoidHom c) k))
  infRange : ∀ (w : InfinitePlace L) (y : (w.Completion)ˣ), ∃ y', C (infIdele L w y) = infIdele L (w.comap (c.symm : L →+* L)) y'
  loc : ∀ v v', ConjPl c v v' → ∀ k : Lˣ, C (localIdele L v (atFin v k)) =
    localIdele L v' (atFin v' (Units.map (MonoidHomClass.toMonoidHom c) k))
  locRange : ∀ v v', ConjPl c v v' → ∀ x, ∃ x', C (localIdele L v x) = localIdele L v' x'
  val : ∀ v v', ConjPl c v v' → ∀ a : Ideles L,
    Valued.v ((C a : AdeleRing (𝓞 L) L).2 v') = Valued.v ((a : AdeleRing (𝓞 L) L).2 v) ∧
    Valued.v ((C a : AdeleRing (𝓞 L) L).2 v' - 1) = Valued.v ((a : AdeleRing (𝓞 L) L).2 v - 1)



def ordSub (w : HeightOneSpectrum (𝓞 L)) (A : Submodule (𝓞 L) L) : ℤ :=
  sInf {n | ∃ k : Lˣ, (k : L) ∈ A ∧ ordF w k = n}


structure CMData (F : Type) [Field F] [NumberField F] [Algebra F L] (c : L ≃ₐ[F] L) {I : Type} (φ : I → L →+* ℂ) : Prop where
  real : IsTotallyReal F
  cplx : IsTotallyComplex L
  rank : Module.finrank F L = 2
  ne : c ≠ 1
  bij : Function.Bijective fun i => InfinitePlace.mk (φ i)

end General

instance framePsiFintype (φ : Formalism.HC.Frame) : Fintype φ.Psi := Fintype.ofFinite _

variable {R : Ranks} (H : Formalism.BasicNotions.Host R)

def congG : Set (Ideles H.E) :=
  {a | a ∈ unitIdl H.E ∧ ∀ k v, OverP H (H.g k) v → Valued.v ((a : AdeleRing (𝓞 H.E) H.E).2 v - 1) < 1}

def KD : Subgroup (Ideles H.E) :=
  Subgroup.closure (congG H ∪ {a | ∃ v k, a = locF H.F v k})

abbrev DtT : Type := Ideles H.E ⧸ KD H

open Classical in

def tildeD (χ : HChar H.E) : DtT H →* ℂˣ :=
  if h : KD H ≤ (χ.1.comp (finPartI H.E)).ker then QuotientGroup.lift (KD H) (χ.1.comp (finPartI H.E)) h else 1



def IsRationalUnitaryDeterminantMap (f : (letI := H.cmStar; unitary H.E) →* DtT H) : Prop :=
  letI := H.cmStar
  ∀ (k : H.Eˣ) (z : unitary H.E), (z : H.E) * H.conj (k : H.E) = k → QuotientGroup.mk (diagUnits H.E k) = f z

open Classical in

def e1T : (letI := H.cmStar; unitary H.E) →* DtT H := if h : ∃ f, IsRationalUnitaryDeterminantMap H f then h.choose else 1



structure HFrame (e : Fin R.m → R.Psi → ℚ) where
  P : PiBar H
  W : Omg H
  mu0 : Fin R.m → HChar H.E
  eta : HChar H.E
  chiPsi : HChar H.E
  del : HChar H.E
  del' : HChar H.E
  isMu0 : ∀ j, IsMu0 P W (e j) j.1 (mu0 j)
  isEta : IsEtaT H eta
  isChi : IsChiPsi H chiPsi
  isDel : IsDelta (H := H) H.pde del
  isDel' : IsDelta (H := H) H.pde' del'

structure DtPack where
  Dt : Type
  [instDt : CommGroup Dt]
  muTil : ℕ → Dt →* ℂˣ
  chiD : Dt →* ℂˣ
  UO : Subgroup Dt
  chiD_UO : ∀ x ∈ UO, chiD x = 1
  e1Dt : letI := H.cmStar; unitary H.E →* Dt
  rest_detCharacter_on_unitary_eq : letI := H.cmStar; ∀ z : unitary H.E,
    ((chiD (e1Dt z) : ℂˣ) : ℂ) = ∏ τ : R.Psi, (H.emb (τ : R.GG) (z : H.E))⁻¹
  relDet : letI := H.cmStar; ∀ N, SDLat H.E N → SDLat H.E N → Dt ⧸ UO
  relDet_self : letI := H.cmStar; ∀ N L, relDet N L L = 1
  relDet_mul : letI := H.cmStar; ∀ N L L' L'', relDet N L L' * relDet N L' L'' = relDet N L L''
  relDet_smul : letI := H.cmStar; ∀ N (L L' : SDLat H.E N) (γ : Matrix.unitaryGroup (Fin N) H.E),
    L'.1 = SDLat.smulLat (γ : Matrix (Fin N) (Fin N) H.E) L.1 → relDet N L L' =
      QuotientGroup.mk (e1Dt ⟨(γ : Matrix (Fin N) (Fin N) H.E).det, Matrix.det_of_mem_unitary γ.2⟩)

section API

variable {L : Type} [Field L] [NumberField L]













theorem ordF_unif_self (w : HeightOneSpectrum (𝓞 L)) : ordF w (unif w) = 1 := by
  have h : Valued.v (((unif w : Lˣ) : L) : w.adicCompletion L) = WithZero.exp (-1 : ℤ) := unif_spec w
  rw [HeightOneSpectrum.valuedAdicCompletion_eq_valuation'] at h
  simp [ordF, h]

theorem ordSub_span_singleton (w : HeightOneSpectrum (𝓞 L)) (u : Lˣ) :
    ordSub w (Submodule.span (𝓞 L) {(u : L)}) = ordF w u := by
  refine IsLeast.csInf_eq ⟨⟨u, Submodule.mem_span_singleton_self _, rfl⟩, ?_⟩
  rintro n ⟨k, hk, rfl⟩
  obtain ⟨a, ha⟩ := Submodule.mem_span_singleton.1 hk
  have hk0 : w.valuation L (k : L) ≠ 0 := by simp
  have hu0 : w.valuation L (u : L) ≠ 0 := by simp
  have hle : w.valuation L (k : L) ≤ w.valuation L (u : L) := by
    rw [← ha, Algebra.smul_def, map_mul]
    exact mul_le_of_le_one_left' (w.valuation_le_one a)
  unfold ordF
  exact neg_le_neg ((WithZero.log_le_log hk0 hu0).2 hle)

example (w : HeightOneSpectrum (𝓞 L)) : ordSub w (Submodule.span (𝓞 L) {((unif w : Lˣ) : L)}) = 1 := by
  rw [ordSub_span_singleton, ordF_unif_self]

end API

section Inhabitant

instance negTwoFact : Fact (∀ r : ℚ, r ^ 2 ≠ -2 + 0 * r) := ⟨fun r h => by nlinarith [sq_nonneg r]⟩

abbrev NegTwoField : Type := QuadraticAlgebra ℚ (-2) 0

instance negTwoNumberField : NumberField NegTwoField := NumberField.of_module_finite ℚ _




end Inhabitant









attribute [local instance] DtPack.instDt in

example (X : DtPack H) : letI := H.cmStar;
    ((X.chiD (X.e1Dt (-1)) : ℂˣ) : ℂ) = (-1) ^ Fintype.card (R.Psi) := by
  letI := H.cmStar
  rw [X.rest_detCharacter_on_unitary_eq]
  have e : ((-1 : unitary H.E) : H.E) = -1 := rfl
  simp [e]

end GlobalTheory.Mem.Chr
