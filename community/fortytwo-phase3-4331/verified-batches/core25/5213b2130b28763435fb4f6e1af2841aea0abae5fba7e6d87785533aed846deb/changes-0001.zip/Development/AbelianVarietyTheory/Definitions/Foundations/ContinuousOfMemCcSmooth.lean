import Mathlib
import Development.AbelianVarietyTheory.Definitions.Foundations.AestronglyMeasurableQuotMeasureIffLift
import Development.AbelianVarietyTheory.Definitions.Foundations.IsHilbertSchmidtOfFiniteDimensional
import Development.AbelianVarietyTheory.Definitions.Foundations.MatrixMeasurableSpace
import Development.AbelianVarietyTheory.Definitions.Foundations.MeasurePreservingRmulQuotMeas

open MeasureTheory Set GlobalTheory.AutomorphicL2Unitary GlobalTheory.OpTrace GlobalTheory.SplitWeil
open scoped ENNReal NNReal Topology Pointwise ComplexConjugate ContDiff InnerProductSpace

noncomputable section

namespace GlobalTheory.Orb

section Conv

variable {G : Type} [Group G] [TopologicalSpace G] [IsTopologicalGroup G]

theorem indicator_mem_SB {X : Type*} [TopologicalSpace X] [T2Space X] {U : Set X} (ho : IsOpen U)
    (hc : IsCompact U) : U.indicator (1 : X → ℂ) ∈ SB X := by
  refine ⟨(IsLocallyConstant.iff_exists_open _).2 fun g => ?_, .intro hc fun x hx => indicator_of_notMem hx _⟩
  by_cases hg : g ∈ U
  · exact ⟨U, ho, hg, fun x hx => by simp [hx, hg]⟩
  · exact ⟨Uᶜ, hc.isClosed.isOpen_compl, hg, fun x hx => by rw [indicator_of_notMem hx, indicator_of_notMem hg]⟩
















end Conv

section Type_

variable {G Q W : Type} [Group G] [Group Q] [AddCommGroup W] [Module ℂ W] [MeasurableSpace G] (μ : Measure G)
  {K : Subgroup G} (r : K →* Q) (τ : Representation ℂ Q W)

open Classical in

def typeIdem : G → ℂ := fun g =>
  if h : g ∈ K then (Module.finrank ℂ W : ℂ) * (μ.real K : ℂ)⁻¹ * conj (τ.character (r ⟨g, h⟩)) else 0

theorem typeIdem_coe (k : K) :
    typeIdem μ r τ k = (Module.finrank ℂ W : ℂ) * (μ.real K : ℂ)⁻¹ * conj (τ.character (r k)) := dif_pos k.2

theorem typeIdem_of_notMem {g : G} (h : g ∉ K) : typeIdem μ r τ g = 0 := dif_neg h




example : typeIdem μ r (Representation.trivial ℂ Q ℂ) = (μ.real K : ℂ)⁻¹ • (K : Set G).indicator 1 := by
  funext g
  by_cases h : g ∈ K
  · rw [typeIdem_coe μ r _ ⟨g, h⟩]
    simp [Representation.character, h]
  · simp [typeIdem_of_notMem μ r _ h, h]

end Type_

section Smooth

variable {H X : Type*} [TopologicalSpace H] [NormedAddCommGroup X] [NormedSpace ℝ X]

def CcSmooth (c : H → X) : Submodule ℂ (H → ℂ) where
  carrier := {f | HasCompactSupport f ∧ ∃ Φ : X → ℂ, ContDiff ℝ ∞ Φ ∧ ∀ g, f g = Φ (c g)}
  zero_mem' := ⟨HasCompactSupport.zero, 0, contDiff_const, fun _ => rfl⟩
  add_mem' := by
    rintro f f' ⟨h, Φ, hΦ, e⟩ ⟨h', Φ', hΦ', e'⟩
    exact ⟨h.add h', Φ + Φ', hΦ.add hΦ', fun g => by simp [e, e']⟩
  smul_mem' := by
    rintro a f ⟨h, Φ, hΦ, e⟩
    exact ⟨h.smul_left (f := fun _ => a), a • Φ, hΦ.const_smul a, fun g => by simp [e]⟩







end Smooth

def IsRegSS {A n : Type*} [CommRing A] [Fintype n] [DecidableEq n] (M : Matrix n n A) : Prop := M.charpoly.Separable

section Real

variable {H n : Type} [Group H] [TopologicalSpace H] [Fintype n] [DecidableEq n]
  {V W : Type} [NormedAddCommGroup V] [InnerProductSpace ℂ V] [NormedAddCommGroup W] [InnerProductSpace ℂ W]

def matCoord (ι : H →* Matrix n n ℂ) (g : H) : n → n → ℂ := fun i j => ι g i j

abbrev CcMat (ι : H →* Matrix n n ℂ) : Submodule ℂ (H → ℂ) := CcSmooth (matCoord ι)


def IsUnitEquiv (π : H →* (V →L[ℂ] V)) (π' : H →* (W →L[ℂ] W)) : Prop :=
  ∃ A : V ≃ₗᵢ[ℂ] W, ∀ g v, A (π g v) = π' g (A v)

variable [MeasurableSpace H]

def IsTempered (μ : Measure H) (π : H →* (V →L[ℂ] V)) : Prop :=
  ∃ v : V, v ≠ 0 ∧ ∀ ε : ℝ, 0 < ε → Integrable (fun g => ‖⟪v, π g v⟫_ℂ‖ ^ (2 + ε)) μ

variable [CompleteSpace V] [CompleteSpace W]

def IsCharFn (ι : H →* Matrix n n ℂ) (μ : Measure H) (π : H →* (V →L[ℂ] V)) (Θ : H → ℂ) : Prop :=
  LocallyIntegrable Θ μ ∧ (∀ s, IsRegSS (ι s) → ContinuousAt Θ s) ∧
    ∀ f ∈ CcMat ι, HasTrace (repOp π μ f) (∫ g, f g * Θ g ∂μ)

structure IsPseudoCoeff (ι : H →* Matrix n n ℂ) (μ : Measure H) (D : H →* (V →L[ℂ] V)) (f : H → ℂ) : Prop where

  mem : f ∈ CcMat ι

  trace_self : HasTrace (repOp D μ f) 1

  trace_other : ∀ (U : Type) [NormedAddCommGroup U] [InnerProductSpace ℂ U] [CompleteSpace U]
    (π : H →* (U →L[ℂ] U)), IsUnitaryRep π → IsTopIrreducible π → IsTempered μ π → ¬ IsUnitEquiv π D →
      HasTrace (repOp π μ f) 0

  orb_noncompact : ∀ s, IsRegSS (ι s) → ¬ IsCompact (cent s : Set H) →
    ∀ (dt : Measure (cent s)) [dt.IsHaarMeasure] [dt.IsMulRightInvariant], HasOrbInt μ s dt f 0

  orb_compact : ∃ Θ, IsCharFn ι μ D Θ ∧ ∀ s, IsRegSS (ι s) → IsCompact (cent s : Set H) →
    ∀ (dt : Measure (cent s)) [dt.IsHaarMeasure] [dt.IsMulRightInvariant],
      HasOrbInt μ s dt f (conj (Θ s) / dt.real univ)

variable [BorelSpace H]









example : ¬ IsRegSS (1 : Matrix (Fin 2) (Fin 2) ℂ) ∧ IsRegSS (Matrix.diagonal ![(1 : ℂ), -1]) := by
  constructor
  · rw [IsRegSS, ← Matrix.diagonal_one, Matrix.charpoly_diagonal, Polynomial.separable_prod_X_sub_C_iff]
    exact fun h => zero_ne_one (h (a₁ := 0) (a₂ := 1) rfl)
  · rw [IsRegSS, Matrix.charpoly_diagonal, Polynomial.separable_prod_X_sub_C_iff]
    intro a b h
    fin_cases a <;> fin_cases b <;> simp at h ⊢ <;> norm_num at h

end Real

end GlobalTheory.Orb
