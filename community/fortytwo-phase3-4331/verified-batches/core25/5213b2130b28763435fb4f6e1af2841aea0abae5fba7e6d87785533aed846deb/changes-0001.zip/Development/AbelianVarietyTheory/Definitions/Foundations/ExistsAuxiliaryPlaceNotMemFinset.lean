import Mathlib
import Formalism.LocalToGlobal.IndefiniteReal.ScalarOnPartsFull
import Formalism.SatakeDualWeyl.AdelicIwasawaHecke.GlintPrincRelIndexNeZero
import Development.AbelianVarietyTheory.Definitions.Foundations.ContinuousOfMemCcSmooth
import Development.AbelianVarietyTheory.Definitions.Foundations.IsRestrictedProdFinAwayIffIsProdMeasureFinAway
import Development.AbelianVarietyTheory.Definitions.Foundations.GLintEqKOAndPrincEqKOne
import Development.AbelianVarietyTheory.Definitions.TwistedInnerProducts.IsSubquotientDetRepParInd
import Development.AbelianVarietyTheory.Proofs.FoundationProofs.ExistsDualFamilyOfIsLattice
import Development.AbelianVarietyTheory.Proofs.FoundationProofs.LintegralFintypeProdEqProd
import Development.AbelianVarietyTheory.Proofs.FoundationProofs.ExistsArchEquivEq
import Development.AbelianVarietyTheory.Proofs.TwistedOperators.IwahoriProjSurjective

open MeasureTheory Set Filter GlobalTheory.AdelicU GlobalTheory.OpTrace GlobalTheory.SplitWeil NumberField IsDedekindDomain Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes
open GlobalTheory.AutomorphicL2Unitary (conv starFn IsTopIrreducible)
open scoped TensorProduct Topology Pointwise ComplexConjugate ContDiff Matrix

noncomputable section

namespace GlobalTheory.Orb

variable {F E : Type} [Field F] [NumberField F] [Field E] [NumberField E] [Algebra F E]
  (σ : E →ₐ[F] E) {n : ℕ} (J : Matrix (Fin n) (Fin n) E)

instance fintypeEmbOver (w : InfinitePlace F) : Fintype (EmbOver E w) := Fintype.ofFinite _

def archMat {w : InfinitePlace F} (τ : EmbOver E w) : GArch σ J w →* Matrix (Fin n) (Fin n) ℂ :=
  (infEmb τ).mapMatrix.toMonoidHom.comp ((Units.coeHom _).comp (matHom _ σ J))



omit [NumberField E] in

theorem archMat_apply {w : InfinitePlace F} (τ : EmbOver E w) (g : GArch σ J w) :
    archMat σ J τ g = (matHom _ σ J g).1.map (infEmb τ) := rfl

theorem archMat_eq_archEquiv {σ : E →ₐ[F] E} (h : IsCMExt F E σ) {w : InfinitePlace F} (τ : EmbOver E w)
    (g : GArch σ J w) : archMat σ J τ g = (archEquiv J h τ g).1.1 := rfl

theorem continuous_infEmb {w : InfinitePlace F} (τ : EmbOver E w) : Continuous (infEmb τ) := by
  have : IsModuleTopology w.Completion (w.Completion ⊗[F] E) := ⟨rfl⟩
  letI : Algebra w.Completion ℂ := (InfinitePlace.Completion.extensionEmbedding w).toAlgebra
  have : ContinuousSMul w.Completion ℂ :=
    ⟨((InfinitePlace.Completion.isometry_extensionEmbedding w).continuous.comp continuous_fst).mul continuous_snd⟩
  let L : w.Completion ⊗[F] E →ₗ[w.Completion] ℂ :=
    { toFun := infEmb τ
      map_add' := map_add _
      map_smul' := fun c y => by
        have : c • y = (c ⊗ₜ[F] (1 : E)) * y := by rw [Algebra.smul_def]; rfl
        rw [this, map_mul, infEmb_tmul, map_one, mul_one]; rfl }
  exact IsModuleTopology.continuous_of_linearMap L




variable {σ} in

theorem isEmbedding_archMat (h : IsCMExt F E σ) {w : InfinitePlace F} (τ : EmbOver E w) :
    Topology.IsEmbedding (matCoord (archMat σ J τ)) := by
  let e := RingEquiv.ofBijective _ (infEmb_bijective h τ)
  have hb : ∀ {A B : Type} [CommRing A] [CommRing B] [TopologicalSpace A] [TopologicalSpace B] (φ : A →+* B),
      Continuous φ → Continuous (Formalism.UG.bc (n := Fin n) φ) := fun φ hφ =>
    Units.continuous_iff.2 ⟨Units.continuous_val.matrix_map hφ, Units.continuous_coe_inv.matrix_map hφ⟩
  have h1 : Topology.IsEmbedding (Formalism.UG.bc (n := Fin n) (infEmb τ)) :=
    Function.LeftInverse.isEmbedding (f := Formalism.UG.bc (n := Fin n) e.symm.toRingHom)
      (fun x => Units.ext (Matrix.ext fun i j => e.symm_apply_apply _))
      (hb _ (Frames.continuous_infEmb_symm h τ)) (hb _ (continuous_infEmb τ))
  have h2 : Topology.IsEmbedding (Units.val : (Matrix (Fin n) (Fin n) ℂ)ˣ → Matrix (Fin n) (Fin n) ℂ) := by
    refine Units.isEmbedding_val_mk' (f := fun A => A⁻¹) (fun A hA => ?_) fun u => by simp
    have hd : A.det ≠ 0 := ((Matrix.isUnit_iff_isUnit_det A).1 hA).ne_zero
    exact (continuousAt_matrix_inv _ (by rw [Ring.inverse_eq_inv']; exact continuousAt_inv₀ hd)).continuousWithinAt
  exact h2.comp (h1.comp (isEmbedding_matHom _ σ J))

abbrev CcLoc (v : HeightOneSpectrum (𝓞 F)) : Submodule ℂ (GLoc σ J v → ℂ) := SB (GLoc σ J v)







def tensorFin (ff : ∀ v, GLoc σ J v → ℂ) : GFin σ J → ℂ := fun g => ∏ᶠ v, ff v (projFinLoc σ J v g)


variable (L : Submodule (𝓞 E) (Fin n → E))

def unitLoc (v : HeightOneSpectrum (𝓞 F)) : GLoc σ J v → ℂ := (stabLoc σ J L v : Set (GLoc σ J v)).indicator 1

def IsFinFamily (ff : ∀ v, GLoc σ J v → ℂ) : Prop :=
  (∀ v, ff v ∈ CcLoc σ J v) ∧ ∀ᶠ v in cofinite, ff v = unitLoc σ J L v


variable {σ J L} {ff : ∀ v, GLoc σ J v → ℂ}







variable [Submodule.IsLattice E L]

theorem unitLoc_mem (v : HeightOneSpectrum (𝓞 F)) : unitLoc σ J L v ∈ CcLoc σ J v :=
  indicator_mem_SB (isOpen_stabLoc σ J L v) (isCompact_stabLoc σ J L v)

theorem isFinFamily_unit : IsFinFamily σ J L (unitLoc σ J L) := ⟨unitLoc_mem, .of_forall fun _ => rfl⟩


theorem IsFinFamily.finite_mulSupport (h : IsFinFamily σ J L ff) (g : GFin σ J) :
    (Function.mulSupport fun v => ff v (projFinLoc σ J v g)).Finite :=
  (h.2.and (eventually_projFinLoc_mem_stabLoc σ J L g)).mono (q := fun v => ff v (projFinLoc σ J v g) = 1)
    fun v hv => by rw [hv.1, unitLoc, indicator_of_mem hv.2, Pi.one_apply]

theorem IsFinFamily.tensorFin_ne_zero_iff (h : IsFinFamily σ J L ff) (g : GFin σ J) :
    tensorFin σ J ff g ≠ 0 ↔ ∀ v, ff v (projFinLoc σ J v g) ≠ 0 := by
  refine ⟨fun hne v hv => hne (finprod_eq_zero _ v hv (h.finite_mulSupport g)), fun hne => ?_⟩
  rw [tensorFin, finprod_eq_prod _ (h.finite_mulSupport g)]
  exact Finset.prod_ne_zero_iff.2 fun v _ => hne v








variable (σ J L) in

structure SplitAt (v : HeightOneSpectrum (𝓞 F)) where

  emb : E →ₐ[F] Fv F v

  basis : GL (Fin n) (Fv F v)

  cm : IsCMExt F E σ

  herm : IsHermND σ J

  selfDual : IsSelfDualAt σ J L v

  isBasis : IsSplitBasis emb L basis

abbrev ResF (v : HeightOneSpectrum (𝓞 F)) : Type := IsLocalRing.ResidueField (v.adicCompletionIntegers F)

instance finite_GL_resF (v : HeightOneSpectrum (𝓞 F)) : Finite (GL (Fin n) (ResF v)) :=
  have : Finite (ResF v) := Formalism.UG.P.glint_finite_residueField v
  have : Finite (Matrix (Fin n) (Fin n) (ResF v)) := inferInstanceAs (Finite (Fin n → Fin n → ResF v))
  inferInstance

def IsUnif {v : HeightOneSpectrum (𝓞 F)} (ϖ : (Fv F v)ˣ) : Prop := Valued.v (ϖ : Fv F v) = WithZero.exp (-1 : ℤ)

def strictTorus {k : Type} [Field k] (n : ℕ) (ϖ : kˣ) : Set (Fin n → kˣ) :=
  {t | ∃ a : Fin n → ℤ, StrictAnti a ∧ t = fun i => ϖ ^ a i}





namespace SplitAt

omit [Submodule.IsLattice E L]

variable {v : HeightOneSpectrum (𝓞 F)}


















variable {W : Type} [AddCommGroup W] [Module ℂ W] (μ : Measure (GLoc σ J v))
  (τ : Representation ℂ (GL (Fin n) (ResF v)) W)



end SplitAt

variable (σ J L) in

structure TypeData where

  S : Finset (HeightOneSpectrum (𝓞 F))

  frame : ∀ v : S, SplitAt σ J L v

  W : S → Type
  [acg : ∀ v, AddCommGroup (W v)]
  [mod : ∀ v, Module ℂ (W v)]
  [fd : ∀ v, FiniteDimensional ℂ (W v)]

  τ : ∀ v : S, Representation ℂ (GL (Fin n) (ResF v.1)) (W v)

  irred : ∀ v, (τ v).IsIrreducible

attribute [instance] TypeData.acg TypeData.mod TypeData.fd

variable (σ J L) in

structure UnitaryAuxiliaryPlaceData where

  u : HeightOneSpectrum (𝓞 F)

  frame : SplitAt σ J L u

  ϖ : (Fv F u)ˣ

  unif : IsUnif ϖ



section ArchFamily

variable {Hs : InfinitePlace F → Type} [∀ w, NormedAddCommGroup (Hs w)] [∀ w, InnerProductSpace ℂ (Hs w)]
  [∀ w, CompleteSpace (Hs w)]



variable {Ψ : ∀ w : InfinitePlace F, EmbOver E w} {D : ∀ w, GArch σ J w →* (Hs w →L[ℂ] Hs w)} {T : TypeData σ J L} {U : UnitaryAuxiliaryPlaceData σ J L}
  {μa : ∀ w, Measure (GArch σ J w)} {μf : ∀ v, Measure (GLoc σ J v)}





end ArchFamily









section Cent







end Cent

section Record

open Formalism.BasicNotions Formalism.BasicNotions.TH Formalism.L2.Theta Formalism.IndefR.Mult Formalism.MainNotions.S






attribute [local instance] Formalism.BasicNotions.Host.cmStar

variable {D : D7} (V : HSp D)


instance isLattice_frameLat : Submodule.IsLattice D.host.E (frameLat V) := SelfDual.isLattice_frameLat V






















end Record

omit [Submodule.IsLattice E L] in

example {v : HeightOneSpectrum (𝓞 F)} {ϖ : (Fv F v)ˣ} (h : IsUnif ϖ) :
    ![ϖ, 1] ∈ strictTorus 2 ϖ ∧ ![1, ϖ] ∉ strictTorus 2 ϖ := by
  refine ⟨⟨![1, 0], Fin.strictAnti_iff_succ_lt.2 fun i => by fin_cases i; simp, funext fun i => by fin_cases i <;> simp⟩,
    fun ⟨a, ha, e⟩ => ?_⟩
  have key : ∀ m : ℤ, Valued.v ((ϖ ^ m : (Fv F v)ˣ) : Fv F v) = WithZero.exp (-m) := fun m => by
    rw [Units.val_zpow_eq_zpow_val, map_zpow₀, h, ← WithZero.exp_zsmul]; simp
  have h0 := key (a 0)
  have h1 := key (a 1)
  rw [← show (1 : (Fv F v)ˣ) = ϖ ^ a 0 from congrFun e 0, Units.val_one, map_one, ← WithZero.exp_zero,
    WithZero.exp_inj] at h0
  rw [← show ϖ = ϖ ^ a 1 from congrFun e 1, h, WithZero.exp_inj] at h1
  have := ha (show (0 : Fin 2) < 1 by decide)
  omega

example (g : GFin σ J) : tensorFin σ J (unitLoc σ J L) g ≠ 0 ↔ g ∈ levelOffFin σ J L ∅ := by
  simp [isFinFamily_unit.tensorFin_ne_zero_iff, unitLoc, mem_levelOffFin]

end GlobalTheory.Orb
