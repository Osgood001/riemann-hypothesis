import Mathlib
import Formalism.LocalToGlobal.IndefiniteReal.DatumVec
import Formalism.LocalToGlobal.BesselHermitianTheta.TiedBessel
import Formalism.LocalToGlobal.BesselHermitianTheta.LemmasWeil
import Formalism.LocalRingCardinality.SpanPowerMembership.Spaces
import Development.AbelianVarietyTheory.Proofs.AdelicLatticeProofs.ExistsNormaliseMeanSquareOfCocompact
import Development.AbelianVarietyTheory.Proofs.HeightProofs.EmbeddingXiZeroNeZero

noncomputable section

open Formalism.BasicNotions Formalism.BasicNotions.TH Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.MainNotions.StandardLattice Formalism.L2.Theta Formalism.IndefR.Datum MeasureTheory IsDedekindDomain NumberField Matrix
open scoped TensorProduct ContDiff Pointwise

attribute [local instance] Formalism.BasicNotions.Host.cmStar

namespace GlobalTheory.MixModel

variable {D : D7}

scoped infixl:70 " ⬝ " => HMul.hMul

def rat {m n : ℕ} (M : Matrix (Fin m) (Fin n) D.host.E) : Mx D m n := M.map (incA D)

def adj {m n : ℕ} (x : Mx D m n) : Mx D n m := (x.map (cA D))ᵀ

def ratMx (D : D7) (m n : ℕ) : AddSubgroup (Mx D m n) :=
  ((incA D).toAddMonoidHom.mapMatrix (m := Fin m) (n := Fin n)).range

def half (D : D7) : AE D := incA D (1 / 2)

def gA (S : HSp D) : Mx D S.rank S.rank := rat S.gram

def giA (S : HSp D) : Mx D S.rank S.rank := rat S.gram⁻¹

section Basic

variable {l m n : ℕ}







@[simp] theorem rat_mul (M : Matrix (Fin l) (Fin m) D.host.E) (N : Matrix (Fin m) (Fin n) D.host.E) :
    rat (M * N) = rat M ⬝ rat N := Matrix.map_mul

@[simp] theorem rat_add (M N : Matrix (Fin m) (Fin n) D.host.E) : rat (M + N) = rat M + rat N :=
  Matrix.map_add _ (map_add (incA D)) M N

@[simp] theorem rat_sub (M N : Matrix (Fin m) (Fin n) D.host.E) : rat (M - N) = rat M - rat N :=
  Matrix.map_sub _ (map_sub (incA D)) M N

@[simp] theorem rat_neg (M : Matrix (Fin m) (Fin n) D.host.E) : rat (-M) = -rat M := by
  funext i j; exact map_neg (incA D) (M i j)

@[simp] theorem rat_zero : rat (0 : Matrix (Fin m) (Fin n) D.host.E) = 0 :=
  Matrix.map_zero _ (map_zero (incA D))

@[simp] theorem rat_one : rat (1 : Matrix (Fin n) (Fin n) D.host.E) = 1 :=
  Matrix.map_one _ (map_zero (incA D)) (map_one (incA D))

@[simp] theorem rat_smul (a : D.host.E) (M : Matrix (Fin m) (Fin n) D.host.E) : rat (a • M) = incA D a • rat M := by
  funext i j; exact map_mul (incA D) a (M i j)

theorem rat_conjTranspose (M : Matrix (Fin m) (Fin n) D.host.E) : rat Mᴴ = adj (rat M) := rfl


@[simp] theorem adj_mul (x : Mx D l m) (y : Mx D m n) : adj (x ⬝ y) = adj y ⬝ adj x :=
  Formalism.UG.cT_mul (cA D) x y

@[simp] theorem adj_add (x y : Mx D m n) : adj (x + y) = adj x + adj y := by
  funext i j; exact map_add (cA D) (x j i) (y j i)

@[simp] theorem adj_sub (x y : Mx D m n) : adj (x - y) = adj x - adj y := by
  funext i j; exact map_sub (cA D) (x j i) (y j i)

@[simp] theorem adj_neg (x : Mx D m n) : adj (-x) = -adj x := by
  funext i j; exact map_neg (cA D) (x j i)

@[simp] theorem adj_zero : adj (0 : Mx D m n) = 0 := by
  funext i j; exact map_zero (cA D)

@[simp] theorem adj_one : adj (1 : Mx D n n) = 1 := Formalism.UG.cT_one (cA D)

@[simp] theorem adj_adj (x : Mx D m n) : adj (adj x) = x := by
  funext i j; exact cA_cA (x i j)

@[simp] theorem adj_smul (a : AE D) (x : Mx D m n) : adj (a • x) = cA D a • adj x := by
  funext i j; exact map_mul (cA D) a (x j i)


@[simp] theorem cA_half : cA D (half D) = half D := by
  rw [half, GlobalTheory.DualPairCheck.cA_incA]; congr 1; simp




end Basic

section Gram

variable (S : HSp D)

theorem gram_conjTranspose : S.gramᴴ = S.gram := by
  funext i j; exact GlobalTheory.DualPairCheck.gram_star S j i

theorem gram_isUnit_det : IsUnit S.gram.det := isUnit_iff_ne_zero.2 (gram_det_ne S)

theorem gramInv_conjTranspose : (S.gram⁻¹)ᴴ = S.gram⁻¹ := by
  rw [Matrix.conjTranspose_nonsing_inv, gram_conjTranspose]

@[simp] theorem adj_gA : adj (gA S) = gA S := by rw [gA, ← rat_conjTranspose, gram_conjTranspose]

@[simp] theorem adj_giA : adj (giA S) = giA S := by rw [giA, ← rat_conjTranspose, gramInv_conjTranspose]

@[simp] theorem giA_mul_gA : giA S * gA S = 1 := by
  rw [giA, gA, ← rat_mul, Matrix.nonsing_inv_mul _ (gram_isUnit_det S), rat_one]

@[simp] theorem gA_mul_giA : gA S * giA S = 1 := by
  rw [giA, gA, ← rat_mul, Matrix.mul_nonsing_inv _ (gram_isUnit_det S), rat_one]

@[simp] theorem giA_gA_cancel {n : ℕ} (x : Mx D S.rank n) : giA S ⬝ (gA S ⬝ x) = x := by
  rw [← Matrix.mul_assoc, giA_mul_gA, Matrix.one_mul]

@[simp] theorem gA_giA_cancel {n : ℕ} (x : Mx D S.rank n) : gA S ⬝ (giA S ⬝ x) = x := by
  rw [← Matrix.mul_assoc, gA_mul_giA, Matrix.one_mul]


end Gram

section Unit

variable (S : HSp D)


theorem mt_mul (g h : GA D S) : mt S (g * h) = mt S g * mt S h := rfl

@[simp] theorem mt_one : mt S 1 = 1 := rfl


theorem mt_mul_inv (g : GA D S) : mt S g * mt S g⁻¹ = 1 := by rw [← mt_mul, mul_inv_cancel, mt_one]



def ofMat (M : Mx D S.rank S.rank) (h : adj M * (gA S * M) = gA S) : GA D S :=
  have h1 : giA S * (adj M * gA S) * M = 1 := by
    rw [Matrix.mul_assoc, Matrix.mul_assoc, h, giA_mul_gA]
  (⟨⟨M, giA S * (adj M * gA S), mul_eq_one_comm.1 h1, h1⟩, (Matrix.mul_assoc _ _ _).trans h⟩ :
    HR (AF D.host.F) D.sp.cm.sig S.gram)

@[simp] theorem mt_ofMat (M : Mx D S.rank S.rank) (h : adj M * (gA S * M) = gA S) : mt S (ofMat S M h) = M := rfl





end Unit

section Rat







end Rat

section Lattice











end Lattice

section Product
















end Product

end GlobalTheory.MixModel

end
