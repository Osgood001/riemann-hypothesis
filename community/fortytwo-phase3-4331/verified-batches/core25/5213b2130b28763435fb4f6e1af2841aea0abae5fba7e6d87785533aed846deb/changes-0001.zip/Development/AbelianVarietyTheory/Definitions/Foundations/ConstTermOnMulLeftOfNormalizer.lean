import Mathlib
import Development.AbelianVarietyTheory.Definitions.Foundations.AestronglyMeasurableQuotMeasureIffLift
import Development.AbelianVarietyTheory.Proofs.HeightProofs.IntegrableOnFundamentalDomainOfCocompact

open MeasureTheory Set GlobalTheory.AutomorphicL2Unitary
open scoped ENNReal Pointwise

noncomputable section

namespace GlobalTheory.Cusp

variable {G : Type} [Group G] [TopologicalSpace G] (Γ N : Subgroup G)

def Cocompact : Prop := ∃ K : Set N, IsCompact K ∧ ∀ n : N, ∃ γ ∈ Γ.subgroupOf N, γ * n ∈ K

instance discreteTopology_subgroupOf [DiscreteTopology Γ] : DiscreteTopology (Γ.subgroupOf N) :=
  .of_continuous_injective (f := fun x : Γ.subgroupOf N => (⟨x.1.1, x.2⟩ : Γ))
    ((continuous_subtype_val.comp continuous_subtype_val).subtype_mk _)
    fun _ _ h => Subtype.ext (Subtype.ext (congrArg (fun z : Γ => z.1) h))

instance secondCountable_subgroup [SecondCountableTopology G] : SecondCountableTopology N :=
  TopologicalSpace.Subtype.secondCountableTopology _

variable [IsTopologicalGroup G] [SecondCountableTopology G] [MeasurableSpace G] [BorelSpace G] [DiscreteTopology Γ]
  [LocallyCompactSpace N]

def probMeasure : Measure (Quot (Γ.subgroupOf N)) :=
  (quotMeasure (Γ.subgroupOf N) Measure.haar univ)⁻¹ • quotMeasure (Γ.subgroupOf N) Measure.haar

def constTermOn (φ : G → ℂ) (x : G) : ℂ := ∫ q, φ ((q.out : N) * x) ∂probMeasure Γ N

variable {Γ N} {φ ψ : G → ℂ} {μ : Measure N} {𝓕 : Set N}

omit [TopologicalSpace G] [IsTopologicalGroup G] [SecondCountableTopology G] [MeasurableSpace G] [BorelSpace G]
  [DiscreteTopology Γ] [LocallyCompactSpace N] in

theorem leftInv_integrand (hφ : LeftInv Γ φ) (x : G) : LeftInv (Γ.subgroupOf N) fun n : N => φ (n * x) :=
  fun γ hγ n => by simp only [Subgroup.coe_mul, mul_assoc]; exact hφ _ hγ _

theorem probMeasure_eq (μ : Measure N) [μ.IsHaarMeasure] :
    probMeasure Γ N = (quotMeasure (Γ.subgroupOf N) μ univ)⁻¹ • quotMeasure (Γ.subgroupOf N) μ := by
  have h0 : ((Measure.haarScalarFactor μ Measure.haar : NNReal) : ℝ≥0∞) ≠ 0 :=
    ENNReal.coe_ne_zero.2 (Measure.haarScalarFactor_pos_of_isHaarMeasure μ Measure.haar).ne'
  conv_rhs => rw [Measure.isMulLeftInvariant_eq_smul μ Measure.haar]
  rw [ENNReal.smul_def, quotMeasure_smul, smul_smul, Measure.smul_apply, smul_eq_mul,
    ENNReal.mul_inv (Or.inl h0) (Or.inl ENNReal.coe_ne_top), mul_right_comm, ENNReal.inv_mul_cancel h0 ENNReal.coe_ne_top,
    one_mul, probMeasure]

theorem constTermOn_eq [μ.IsHaarMeasure] (h : IsFundamentalDomain (Γ.subgroupOf N) 𝓕 μ) (hφ : LeftInv Γ φ) (x : G) :
    constTermOn Γ N φ x = (μ.real 𝓕)⁻¹ • ∫ n in 𝓕, φ (n * x) ∂μ := by
  rw [constTermOn, probMeasure_eq μ, integral_smul_measure, quotMeasure_univ h, integral_quotMeasure h,
    ENNReal.toReal_inv, measureReal_def]
  exact congrArg _ (integral_congr_ae (.of_forall (leftInv_integrand hφ x).descend_mk))





namespace Cocompact

variable (hc : Cocompact Γ N)
include hc

omit [LocallyCompactSpace N] in

theorem integrableOn [μ.IsHaarMeasure] (h : IsFundamentalDomain (Γ.subgroupOf N) 𝓕 μ) (hφ : LeftInv Γ φ)
    (hφc : Continuous φ) (x : G) : IntegrableOn (fun n : N => φ (n * x)) 𝓕 μ :=
  let ⟨K, hK, hs⟩ := hc
  GlobalTheory.integrableOn_fundamentalDomain_of_cocompact N _ K hK hs μ inferInstance 𝓕 h _ (by fun_prop)
    (leftInv_integrand hφ x)

omit [LocallyCompactSpace N] in

theorem measure_ne_top [μ.IsHaarMeasure] (h : IsFundamentalDomain (Γ.subgroupOf N) 𝓕 μ) : μ 𝓕 ≠ ⊤ :=
  ((integrableOn_const_iff (C := (1 : ℂ))).1
    (hc.integrableOn h (φ := fun _ => 1) (fun _ _ _ => rfl) continuous_const 1)).elim (by simp) LT.lt.ne


theorem integrable (hφ : LeftInv Γ φ) (hφc : Continuous φ) (x : G) :
    Integrable (fun q : Quot (Γ.subgroupOf N) => φ ((q.out : N) * x)) (probMeasure Γ N) := by
  have h := isFundamentalDomain_stdDom (Γ.subgroupOf N) Measure.haar
  refine Integrable.smul_measure (memLp_one_iff_integrable.1 ((memLp_quotMeasure_iff h).2 ?_))
    (ENNReal.inv_ne_top.2 (NeZero.ne _))
  rw [show lift _ (fun q : Quot (Γ.subgroupOf N) => φ ((q.out : N) * x)) = _ from
    (leftInv_integrand (N := N) hφ x).lift_descend]
  exact memLp_one_iff_integrable.2 (hc.integrableOn h hφ hφc x)


theorem constTermOn_add (hφ : LeftInv Γ φ) (hφc : Continuous φ) (hψ : LeftInv Γ ψ) (hψc : Continuous ψ) (x : G) :
    constTermOn Γ N (φ + ψ) x = constTermOn Γ N φ x + constTermOn Γ N ψ x :=
  integral_add (hc.integrable hφ hφc x) (hc.integrable hψ hψc x)

theorem constTermOn_eq_zero_iff [μ.IsHaarMeasure] (h : IsFundamentalDomain (Γ.subgroupOf N) 𝓕 μ) (hφ : LeftInv Γ φ)
    (x : G) : constTermOn Γ N φ x = 0 ↔ ∫ n in 𝓕, φ (n * x) ∂μ = 0 :=
  (constTermOn_eq h hφ x).symm ▸ smul_eq_zero_iff_right (inv_ne_zero
    (ENNReal.toReal_ne_zero.2 ⟨h.measure_ne_zero (NeZero.ne μ), hc.measure_ne_top h⟩))




end Cocompact

end GlobalTheory.Cusp

end
