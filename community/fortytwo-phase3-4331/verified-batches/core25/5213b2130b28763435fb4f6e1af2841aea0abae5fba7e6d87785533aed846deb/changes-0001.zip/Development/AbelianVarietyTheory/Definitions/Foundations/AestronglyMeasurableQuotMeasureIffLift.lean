import Mathlib
import Development.AbelianVarietyTheory.Definitions.Foundations.HermitianSpaceBaseLatticeEqFrameLattice
import Development.AbelianVarietyTheory.Definitions.Foundations.OfInfProjInfMulOfFinProjFin
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.ExistsIsFundamentalDomain
import Development.AbelianVarietyTheory.Proofs.SiegelThetaTransformation.DiscreteTopologyRationalPointsHermitianSpace
import Formalism.LocalRingCardinality.DataHost
import Formalism.LocalRingCardinality.DataTheta
import Formalism.LocalRingCardinality.RhoDetPrimeEqMuTildeMulChiPow
import Formalism.LocalToGlobal.BesselHermitianTheta.IsAutFunDef
import Formalism.LocalToGlobal.ProjectiveLattices.IsProbabilityMeasureAutQuotientNormalized

open MeasureTheory Filter Set
open scoped InnerProductSpace ENNReal Topology Pointwise symmDiff ComplexConjugate

noncomputable section

namespace GlobalTheory.AutomorphicL2Unitary

section Subrep

variable {G H : Type*} [Group G] [NormedAddCommGroup H] [InnerProductSpace ℂ H]

def IsSubrep (π : G →* (H →L[ℂ] H)) (W : Submodule ℂ H) : Prop :=
  IsClosed (W : Set H) ∧ ∀ g, ∀ v ∈ W, π g v ∈ W

def IsTopIrreducible (π : G →* (H →L[ℂ] H)) : Prop :=
  Nontrivial H ∧ ∀ W, IsSubrep π W → W = ⊥ ∨ W = ⊤

def IsIrredSubrep (π : G →* (H →L[ℂ] H)) (W : Submodule ℂ H) : Prop :=
  IsSubrep π W ∧ W ≠ ⊥ ∧ ∀ U ≤ W, IsSubrep π U → U = ⊥ ∨ U = W

def disc (π : G →* (H →L[ℂ] H)) : Submodule ℂ H := (sSup {W | IsIrredSubrep π W}).topologicalClosure

variable {π : G →* (H →L[ℂ] H)} {W U : Submodule ℂ H}

def IsSubrep.rep (hW : IsSubrep π W) : G →* (W →L[ℂ] W) where
  toFun g := ((π g).comp W.subtypeL).codRestrict W fun v => hW.2 g v v.2
  map_one' := by ext v; simp
  map_mul' g h := by ext v; exact DFunLike.congr_fun (map_mul π g h) (v : H)

@[simp] theorem IsSubrep.coe_rep_apply (hW : IsSubrep π W) (g : G) (v : W) : (hW.rep g v : H) = π g v := rfl







theorem IsIrredSubrep.le_disc (hW : IsIrredSubrep π W) : W ≤ disc π :=
  (le_sSup (s := {W | IsIrredSubrep π W}) hW).trans (Submodule.le_topologicalClosure _)






theorem isIrredSubrep_span_singleton {v : H} (hv : v ≠ 0) (h : ∀ g, ∃ c : ℂ, π g v = c • v) :
    IsIrredSubrep π (ℂ ∙ v) := by
  refine ⟨⟨Submodule.closed_of_finiteDimensional _, fun g w hw => ?_⟩, by simpa using hv, fun U hU _ => ?_⟩
  · obtain ⟨a, rfl⟩ := Submodule.mem_span_singleton.1 hw
    obtain ⟨c, hc⟩ := h g
    rw [map_smul, hc]
    exact Submodule.smul_mem _ _ (Submodule.smul_mem _ _ (Submodule.mem_span_singleton_self v))
  · exact ((nonzero_span_atom v hv).le_iff).1 hU















end Subrep

section Quotient

variable {G : Type*} [Group G] (Γ : Subgroup G)

abbrev Quot : Type _ := Quotient (QuotientGroup.rightRel Γ)

abbrev mk (g : G) : Quot Γ := Quotient.mk _ g

def rmul (g : G) : Quot Γ → Quot Γ :=
  Quotient.map' (· * g) fun x y h => by simpa [QuotientGroup.rightRel_apply, mul_assoc] using h

def LeftInv {X : Type*} (φ : G → X) : Prop := ∀ γ ∈ Γ, ∀ g, φ (γ * g) = φ g

def descend {X : Type*} (φ : G → X) : Quot Γ → X := fun q => φ q.out

def lift {X : Type*} (F : Quot Γ → X) : G → X := fun g => F (mk Γ g)

def orbitSum (f : G → ℂ) (x : G) : ℂ := ∑' γ : Γ, f (γ * x)

def kernel (f : G → ℂ) (x y : G) : ℂ := ∑' γ : Γ, f (x⁻¹ * γ * y)

def kernelQ (f : G → ℂ) (p q : Quot Γ) : ℂ := kernel Γ f p.out q.out

def starFn (f : G → ℂ) : G → ℂ := fun g => conj (f g⁻¹)

variable {Γ}

theorem mk_eq_iff {x y : G} : mk Γ x = mk Γ y ↔ ∃ γ : Γ, γ * x = y :=
  Quotient.eq.trans <| QuotientGroup.rightRel_apply.trans
    ⟨fun h => ⟨⟨_, h⟩, by simp⟩, by rintro ⟨γ, rfl⟩; simp⟩

@[simp] theorem mk_mul (γ : Γ) (g : G) : mk Γ (γ * g) = mk Γ g := (mk_eq_iff.2 ⟨γ, rfl⟩).symm

@[simp] theorem rmul_mk (g x : G) : rmul Γ g (mk Γ x) = mk Γ (x * g) := rfl

@[simp] theorem rmul_one (q : Quot Γ) : rmul Γ 1 q = q := Quotient.inductionOn q fun x => by simp

theorem rmul_mul (g h : G) (q : Quot Γ) : rmul Γ (g * h) q = rmul Γ h (rmul Γ g q) :=
  Quotient.inductionOn q fun x => by simp [mul_assoc]

theorem leftInv_lift {X : Type*} (F : Quot Γ → X) : LeftInv Γ (lift Γ F) :=
  fun γ h g => congrArg F (mk_mul ⟨γ, h⟩ g)

theorem LeftInv.eq_of_mk_eq {X : Type*} {φ : G → X} (h : LeftInv Γ φ) {x y : G} (e : mk Γ x = mk Γ y) : φ x = φ y := by
  obtain ⟨γ, rfl⟩ := mk_eq_iff.1 e
  exact (h γ γ.2 x).symm

theorem LeftInv.descend_mk {X : Type*} {φ : G → X} (h : LeftInv Γ φ) (g : G) : descend Γ φ (mk Γ g) = φ g :=
  h.eq_of_mk_eq (Quotient.out_eq _)

theorem LeftInv.lift_descend {X : Type*} {φ : G → X} (h : LeftInv Γ φ) : lift Γ (descend Γ φ) = φ :=
  funext h.descend_mk

@[simp] theorem descend_lift {X : Type*} (F : Quot Γ → X) : descend Γ (lift Γ F) = F :=
  funext fun q => congrArg F (Quotient.out_eq q)


theorem leftInv_orbitSum (f : G → ℂ) : LeftInv Γ (orbitSum Γ f) := fun δ hδ x => by
  rw [orbitSum, orbitSum, ← (Equiv.mulRight (⟨δ, hδ⟩ : Γ)).tsum_eq fun γ : Γ => f (γ * x)]
  simp [mul_assoc]

theorem kernel_eq_orbitSum (f : G → ℂ) (x : G) : kernel Γ f x = orbitSum Γ fun y => f (x⁻¹ * y) := by
  funext y; simp only [kernel, orbitSum, mul_assoc]

@[simp] theorem starFn_starFn (f : G → ℂ) : starFn (starFn f) = f := by funext g; simp [starFn]

theorem kernel_starFn (f : G → ℂ) (x y : G) : kernel Γ (starFn f) x y = conj (kernel Γ f y x) := by
  rw [kernel, kernel, Complex.conj_tsum, ← (Equiv.inv Γ).tsum_eq]
  simp [starFn, mul_assoc]

theorem leftInv_kernel_right (f : G → ℂ) (x : G) : LeftInv Γ (kernel Γ f x) :=
  kernel_eq_orbitSum (Γ := Γ) f x ▸ leftInv_orbitSum _

theorem leftInv_kernel_left (f : G → ℂ) (y : G) : LeftInv Γ fun x => kernel Γ f x y := fun γ hγ x => by
  have h := kernel_starFn (Γ := Γ) (starFn f)
  rw [starFn_starFn] at h
  simp only [h, leftInv_kernel_right _ y γ hγ x]

@[simp] theorem kernelQ_mk (f : G → ℂ) (x y : G) : kernelQ Γ f (mk Γ x) (mk Γ y) = kernel Γ f x y :=
  ((leftInv_kernel_left f _).descend_mk x).trans ((leftInv_kernel_right f x).descend_mk y)

variable [TopologicalSpace G] [IsTopologicalGroup G]





omit [IsTopologicalGroup G] in

instance (priority := 50) countable_of_discrete [SecondCountableTopology G] [DiscreteTopology Γ] : Countable Γ :=
  TopologicalSpace.separableSpace_iff_countable.1 inferInstance

end Quotient

section Measure

variable {G : Type*} [Group G] [TopologicalSpace G] [IsTopologicalGroup G] [SecondCountableTopology G]
  [MeasurableSpace G] [BorelSpace G] (Γ : Subgroup G) [DiscreteTopology Γ]

def stdDom : Set G := (GlobalTheory.FundDomDiscrete.exists_measurable_section Γ).choose

theorem measurableSet_stdDom : MeasurableSet (stdDom Γ) :=
  (GlobalTheory.FundDomDiscrete.exists_measurable_section Γ).choose_spec.1

theorem existsUnique_stdDom (x : G) : ∃! γ : Γ, (γ : G) * x ∈ stdDom Γ :=
  (GlobalTheory.FundDomDiscrete.exists_measurable_section Γ).choose_spec.2 x

theorem isFundamentalDomain_stdDom (μ : Measure G) : IsFundamentalDomain Γ (stdDom Γ) μ :=
  .mk' (measurableSet_stdDom Γ).nullMeasurableSet (existsUnique_stdDom Γ)

def sec (q : Quot Γ) : G := (existsUnique_stdDom Γ q.out).choose * q.out

def quotMeasure (μ : Measure G) : Measure (Quot Γ) := (μ.restrict (stdDom Γ)).map (mk Γ)

variable {Γ} {μ : Measure G} {𝓕 : Set G}

@[simp] theorem mk_sec (q : Quot Γ) : mk Γ (sec Γ q) = q := (mk_mul _ _).trans (Quotient.out_eq q)

theorem sec_mem (q : Quot Γ) : sec Γ q ∈ stdDom Γ := (existsUnique_stdDom Γ q.out).choose_spec.1

theorem sec_eq {q : Quot Γ} {x : G} (hx : x ∈ stdDom Γ) (e : mk Γ x = q) : sec Γ q = x := by
  obtain ⟨γ, h⟩ := mk_eq_iff.1 (e.trans (mk_sec q).symm)
  have h1 : γ = 1 := (existsUnique_stdDom Γ x).unique (h ▸ sec_mem q) (by simpa using hx)
  rw [← h, h1]
  simp

omit [TopologicalSpace G] [IsTopologicalGroup G] [SecondCountableTopology G] [BorelSpace G] [DiscreteTopology Γ] in

theorem measurable_mk : Measurable (mk Γ) := measurable_quotient_mk''

theorem measurableEmbedding_sec : MeasurableEmbedding (sec Γ) where
  injective := Function.LeftInverse.injective mk_sec
  measurable := fun s hs => by
    have : mk Γ ⁻¹' (sec Γ ⁻¹' s) = ⋃ γ : Γ, (fun x => (γ : G) * x) ⁻¹' (s ∩ stdDom Γ) := by
      ext x
      simp only [mem_preimage, mem_iUnion, mem_inter_iff]
      refine ⟨fun h => ?_, fun ⟨γ, h1, h2⟩ => by rwa [sec_eq h2 (mk_mul γ x)]⟩
      obtain ⟨γ, e⟩ := mk_eq_iff.1 (mk_sec (mk Γ x)).symm
      exact ⟨γ, e ▸ h, e ▸ sec_mem _⟩
    change MeasurableSet (mk Γ ⁻¹' (sec Γ ⁻¹' s))
    rw [this]
    exact .iUnion fun γ => measurable_const_mul _ (hs.inter (measurableSet_stdDom Γ))
  measurableSet_image' := fun s hs => by
    have : sec Γ '' s = mk Γ ⁻¹' s ∩ stdDom Γ := by
      ext x
      exact ⟨by rintro ⟨q, h, rfl⟩; exact ⟨by simpa using h, sec_mem q⟩, fun h => ⟨_, h.1, sec_eq h.2 rfl⟩⟩
    rw [this]
    exact (measurable_mk hs).inter (measurableSet_stdDom Γ)

theorem measurable_rmul_uncurry : Measurable fun p : Quot Γ × G => rmul Γ p.2 p.1 := by
  have : (fun p : Quot Γ × G => rmul Γ p.2 p.1) = fun p => mk Γ (sec Γ p.1 * p.2) := by
    funext p; rw [← rmul_mk, mk_sec]
  rw [this]
  exact measurable_mk.comp ((measurableEmbedding_sec.measurable.comp measurable_fst).mul measurable_snd)

theorem measurable_rmul (g : G) : Measurable (rmul Γ g) :=
  measurable_rmul_uncurry.comp (measurable_id.prodMk measurable_const)

theorem measurePreserving_sec : MeasurePreserving (sec Γ) (quotMeasure Γ μ) (μ.restrict (stdDom Γ)) :=
  ⟨measurableEmbedding_sec.measurable, by
    rw [quotMeasure, Measure.map_map measurableEmbedding_sec.measurable measurable_mk]
    exact (Measure.map_congr ((ae_restrict_mem (measurableSet_stdDom Γ)).mono fun x hx => sec_eq hx rfl)).trans
      Measure.map_id⟩

instance [SigmaFinite μ] : SigmaFinite (quotMeasure Γ μ) :=
  SigmaFinite.of_map _ measurableEmbedding_sec.measurable.aemeasurable
    (by rw [measurePreserving_sec.map_eq]; infer_instance)

theorem quotMeasure_smul (c : ℝ≥0∞) : quotMeasure Γ (c • μ) = c • quotMeasure Γ μ := by
  rw [quotMeasure, Measure.restrict_smul, Measure.map_smul, quotMeasure]

variable [μ.IsMulLeftInvariant]

theorem quotMeasure_eq (h : IsFundamentalDomain Γ 𝓕 μ) : quotMeasure Γ μ = (μ.restrict 𝓕).map (mk Γ) := by
  ext s hs
  rw [quotMeasure, Measure.map_apply measurable_mk hs, Measure.map_apply measurable_mk hs,
    Measure.restrict_apply (measurable_mk hs), Measure.restrict_apply (measurable_mk hs)]
  refine (isFundamentalDomain_stdDom Γ μ).measure_set_eq h (measurable_mk hs) fun γ => ?_
  ext x
  exact iff_of_eq (congrArg (· ∈ s) (mk_mul γ x))

theorem measurePreserving_mk (h : IsFundamentalDomain Γ 𝓕 μ) :
    MeasurePreserving (mk Γ) (μ.restrict 𝓕) (quotMeasure Γ μ) := ⟨measurable_mk, (quotMeasure_eq h).symm⟩

theorem quotMeasure_univ (h : IsFundamentalDomain Γ 𝓕 μ) : quotMeasure Γ μ univ = μ 𝓕 := by
  rw [quotMeasure_eq h, Measure.map_apply measurable_mk .univ, preimage_univ, Measure.restrict_apply_univ]

instance [NeZero μ] : NeZero (quotMeasure Γ μ) :=
  ⟨Measure.measure_univ_ne_zero.1 <| by
    rw [quotMeasure_univ (isFundamentalDomain_stdDom Γ μ)]
    exact (isFundamentalDomain_stdDom Γ μ).measure_ne_zero (NeZero.ne μ)⟩

theorem ae_quotMeasure_iff {p : Quot Γ → Prop} : (∀ᵐ q ∂quotMeasure Γ μ, p q) ↔ ∀ᵐ g ∂μ, p (mk Γ g) := by
  have h : (∀ᵐ g ∂μ.restrict (stdDom Γ), p (mk Γ g)) ↔ ∀ᵐ q ∂quotMeasure Γ μ, p q := by
    rw [← measurePreserving_sec.map_eq, measurableEmbedding_sec.ae_map_iff]; simp
  refine h.symm.trans ⟨fun h' => ?_, ae_restrict_of_ae⟩
  refine (isFundamentalDomain_stdDom Γ μ).measure_zero_of_invariant _ (fun γ => ?_) ?_
  · ext x
    rw [mem_smul_set_iff_inv_smul_mem]
    exact iff_of_eq (congrArg (¬ p ·) (mk_mul γ⁻¹ x))
  · rwa [← Measure.restrict_apply' (measurableSet_stdDom Γ)]



theorem integral_quotMeasure {X : Type*} [NormedAddCommGroup X] [NormedSpace ℝ X] (h : IsFundamentalDomain Γ 𝓕 μ)
    (F : Quot Γ → X) : ∫ q, F q ∂quotMeasure Γ μ = ∫ g in 𝓕, F (mk Γ g) ∂μ := by
  rw [h.setIntegral_eq (isFundamentalDomain_stdDom Γ μ) fun γ x => congrArg F (mk_mul γ x),
    ← measurePreserving_sec.integral_comp measurableEmbedding_sec]
  simp

theorem aestronglyMeasurable_quotMeasure_iff (h : IsFundamentalDomain Γ 𝓕 μ) {F : Quot Γ → ℂ} :
    AEStronglyMeasurable F (quotMeasure Γ μ) ↔ AEStronglyMeasurable (lift Γ F) (μ.restrict 𝓕) := by
  rw [h.aestronglyMeasurable_on_iff (isFundamentalDomain_stdDom Γ μ) fun γ x => congrArg F (mk_mul γ x),
    ← measurePreserving_sec.aestronglyMeasurable_comp_iff measurableEmbedding_sec]
  simp [Function.comp_def, lift]


theorem memLp_quotMeasure_iff (h : IsFundamentalDomain Γ 𝓕 μ) {F : Quot Γ → ℂ} {p : ℝ≥0∞} :
    MemLp F p (quotMeasure Γ μ) ↔ MemLp (lift Γ F) p (μ.restrict 𝓕) :=
  ⟨fun h' => h'.comp_measurePreserving (measurePreserving_mk h), fun h' => by
    have hm := (aestronglyMeasurable_quotMeasure_iff h).2 h'.1
    exact ⟨hm, (eLpNorm_comp_measurePreserving hm (measurePreserving_mk h)).symm.trans_lt h'.2⟩⟩




theorem measurePreserving_rmul [μ.IsMulRightInvariant] (g : G) :
    MeasurePreserving (rmul Γ g) (quotMeasure Γ μ) (quotMeasure Γ μ) := by
  have h := isFundamentalDomain_stdDom Γ μ
  have h' : IsFundamentalDomain Γ ((· * g) ⁻¹' stdDom Γ) μ :=
    h.preimage_of_equiv (measurePreserving_mul_right μ g).quasiMeasurePreserving Function.bijective_id
      fun γ x => mul_assoc _ _ _
  refine ⟨measurable_rmul g, ?_⟩
  conv_lhs => rw [quotMeasure_eq h', Measure.map_map (measurable_rmul g) measurable_mk]
  exact ((measurePreserving_mk h).comp ((measurePreserving_mul_right μ g).restrict_preimage
    (measurableSet_stdDom Γ))).map_eq

end Measure

section L2

variable {G : Type*} [Group G] [TopologicalSpace G] [IsTopologicalGroup G] [SecondCountableTopology G]
  [MeasurableSpace G] [BorelSpace G] (Γ : Subgroup G) [DiscreteTopology Γ] (μ : Measure G)

abbrev L2 : Type _ := Lp ℂ 2 (quotMeasure Γ μ)

def MemL2Quotient (φ : G → ℂ) : Prop := LeftInv Γ φ ∧ MemLp (descend Γ φ) 2 (quotMeasure Γ μ)



def conv (f f' : G → ℂ) : G → ℂ := fun y => ∫ x, f x * f' (x⁻¹ * y) ∂μ

variable {Γ μ} {𝓕 : Set G} {φ ψ : G → ℂ}

def MemL2Quotient.toL2 (h : MemL2Quotient Γ μ φ) : L2 Γ μ := h.2.toLp _

theorem memL2_lift (F : L2 Γ μ) : MemL2Quotient Γ μ (lift Γ F) :=
  ⟨leftInv_lift _, by rw [descend_lift]; exact Lp.memLp F⟩

@[simp] theorem toL2_lift (F : L2 Γ μ) : (memL2_lift F).toL2 = F :=
  Lp.ext ((memL2_lift F).2.coeFn_toLp.trans (by rw [descend_lift]))

theorem MemL2Quotient.coeFn_toL2 (h : MemL2Quotient Γ μ φ) : h.toL2 =ᵐ[quotMeasure Γ μ] descend Γ φ := h.2.coeFn_toLp





variable [μ.IsMulLeftInvariant]



theorem memL2_iff_fundamental_domain (h : IsFundamentalDomain Γ 𝓕 μ) : MemL2Quotient Γ μ φ ↔ LeftInv Γ φ ∧ MemLp φ 2 (μ.restrict 𝓕) :=
  and_congr_right fun hφ => by rw [memLp_quotMeasure_iff h, hφ.lift_descend]


theorem MemL2Quotient.lift_toL2_ae_eq (h : MemL2Quotient Γ μ φ) : lift Γ h.toL2 =ᵐ[μ] φ :=
  (ae_quotMeasure_iff.1 h.coeFn_toL2).mono fun g e => e.trans (h.1.descend_mk g)

theorem l2DiscreteQuotient_ext_iff_lift_ae_eq {F F' : L2 Γ μ} : F = F' ↔ lift Γ F =ᵐ[μ] lift Γ F' :=
  Lp.ext_iff.trans ae_quotMeasure_iff


variable [μ.IsMulRightInvariant]

variable (Γ μ) in

def R : G →* (L2 Γ μ →L[ℂ] L2 Γ μ) where
  toFun g := (Lp.compMeasurePreservingₗᵢ ℂ (rmul Γ g) (measurePreserving_rmul g)).toContinuousLinearMap
  map_one' := ContinuousLinearMap.ext fun F => Lp.ext <|
    (Lp.coeFn_compMeasurePreserving F _).trans (.of_forall fun q => congrArg F (rmul_one q))
  map_mul' g h := ContinuousLinearMap.ext fun F => Lp.ext <|
    (Lp.coeFn_compMeasurePreserving F _).trans <| EventuallyEq.symm <|
      (Lp.coeFn_compMeasurePreserving _ (measurePreserving_rmul g)).trans <|
        ((measurePreserving_rmul g).quasiMeasurePreserving.ae
          (Lp.coeFn_compMeasurePreserving F (measurePreserving_rmul h))).mono fun q e =>
            e.trans (congrArg F (rmul_mul g h q).symm)



variable (Γ μ) in

abbrev L2disc : Submodule ℂ (L2 Γ μ) := disc (R Γ μ)



theorem coeFn_R (g : G) (F : L2 Γ μ) : R Γ μ g F =ᵐ[quotMeasure Γ μ] fun q => F (rmul Γ g q) :=
  Lp.coeFn_compMeasurePreserving F (measurePreserving_rmul g)

theorem lift_R (g : G) (F : L2 Γ μ) : lift Γ (R Γ μ g F) =ᵐ[μ] fun x => lift Γ F (x * g) :=
  ae_quotMeasure_iff.1 (coeFn_R g F)

















end L2

section Adelic

open Formalism.BasicNotions Formalism.BasicNotions.TH Formalism.L2.Theta Formalism.L2.Pj GlobalTheory.AdelicU

instance discreteTopology_ratPts {F E : Type} [Field F] [NumberField F] [Field E] [NumberField E] [Algebra F E]
    (σ : E →ₐ[F] E) {n : ℕ} (J : Matrix (Fin n) (Fin n) E) : DiscreteTopology (ratPts σ J) :=
  GlobalTheory.RationalDiscrete.discreteTopology_HFinIn σ J

attribute [local instance] Formalism.BasicNotions.Host.cmStar

variable {D : D7} (V : HSp D)

instance discreteTopology_GQ : DiscreteTopology (GQ V) := GlobalTheory.RationalDiscrete.discreteTopology_GQ D V

variable (μ : Measure (GA D V))

abbrev autMeasure : Measure (AutQ V) := quotMeasure (GQ V) μ

abbrev DividedPowerChartLift : Type := L2 (GQ V) μ











end Adelic

example {G : Type} [Group G] (f : G → ℂ) (x y : G) : kernel ⊥ f x y = f (x⁻¹ * y) := by
  rw [kernel, tsum_eq_single 1 fun γ h => absurd (Subsingleton.elim _ _) h]
  simp

example {G : Type} [Group G] [Countable G] [TopologicalSpace G] [DiscreteTopology G] [MeasurableSpace G]
    [BorelSpace G] : quotMeasure (⊤ : Subgroup G) Measure.count univ = 1 := by
  rw [quotMeasure_univ (Γ := ⊤) (𝓕 := {1}) (.mk' (measurableSet_singleton 1).nullMeasurableSet fun x =>
    ⟨⟨x⁻¹, Subgroup.mem_top _⟩, inv_mul_cancel x, fun γ h => Subtype.ext (eq_inv_of_mul_eq_one_left (show (γ : G) * x = 1 from h))⟩)]
  simp

example {G : Type} [Group G] [TopologicalSpace G] [IsTopologicalGroup G] [SecondCountableTopology G] [CompactSpace G]
    [MeasurableSpace G] [BorelSpace G] (μ : Measure G) [μ.IsHaarMeasure] [μ.IsMulRightInvariant]
    (χ : G →* ℂ) (hχ : Continuous χ) :
    ∃ F : L2 ⊥ μ, F ≠ 0 ∧ lift ⊥ F =ᵐ[μ] χ ∧ (∀ g, R ⊥ μ g F = χ g • F) ∧ F ∈ L2disc ⊥ μ := by
  have hD : IsFundamentalDomain (⊥ : Subgroup G) (univ : Set G) μ :=
    .mk' .univ fun _ => ⟨1, trivial, fun _ _ => Subsingleton.elim _ _⟩
  have h : MemL2Quotient ⊥ μ χ := (memL2_iff_fundamental_domain hD).2 ⟨fun γ hγ g => by rw [Subgroup.mem_bot.1 hγ, one_mul],
    hχ.memLp_of_hasCompactSupport (.of_compactSpace _)⟩
  have h0 : h.toL2 ≠ 0 := fun e => by
    have h1 := h.lift_toL2_ae_eq
    rw [e] at h1
    obtain ⟨x, hx⟩ := ((ae_quotMeasure_iff.1 (Lp.coeFn_zero ℂ 2 (quotMeasure ⊥ μ))).and h1).exists
    exact ((Group.isUnit x).map χ).ne_zero (hx.2.symm.trans hx.1)
  have h2 : ∀ g, R ⊥ μ g h.toL2 = χ g • h.toL2 := fun g => l2DiscreteQuotient_ext_iff_lift_ae_eq.2 <| by
    filter_upwards [lift_R g h.toL2, (measurePreserving_mul_right μ g).quasiMeasurePreserving.ae h.lift_toL2_ae_eq,
      ae_quotMeasure_iff.1 (Lp.coeFn_smul (χ g) h.toL2), h.lift_toL2_ae_eq] with x e1 e2 e3 e4
    rw [e1, e2, map_mul, mul_comm, ← e4]
    exact e3.symm
  exact ⟨_, h0, h.lift_toL2_ae_eq, h2,
    (isIrredSubrep_span_singleton h0 fun g => ⟨_, h2 g⟩).le_disc (Submodule.mem_span_singleton_self _)⟩

end GlobalTheory.AutomorphicL2Unitary

end
