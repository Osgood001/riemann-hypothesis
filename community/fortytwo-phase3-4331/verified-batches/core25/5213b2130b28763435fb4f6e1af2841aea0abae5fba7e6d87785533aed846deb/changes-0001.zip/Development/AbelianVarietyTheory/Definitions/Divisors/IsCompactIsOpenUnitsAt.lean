import Mathlib
import Development.AbelianVarietyTheory.BlockTheory.DivisorBase.WeilTensorModels
import Development.AbelianVarietyTheory.Definitions.Divisors.CTSmallCone
import Development.AbelianVarietyTheory.Definitions.Foundations.EventuallyNormFinLeOne
import Development.AbelianVarietyTheory.Definitions.Foundations.HermitianSpaceBaseLatticeEqFrameLattice
import Development.AbelianVarietyTheory.Definitions.Foundations.OfInfProjInfMulOfFinProjFin
import Development.AbelianVarietyTheory.Definitions.Foundations.T2SpaceTensorProductFiniteExtension
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LatAtVAtStable
import Development.AbelianVarietyTheory.Proofs.UnitaryExistence.LcscAdelicUnitaryGroup
import Formalism.SharpRestriction.GlobalSchurBounds.GeneralLinearActions.GenusMassVolumes

noncomputable section

namespace GlobalTheory.ThK

open scoped TensorProduct NNReal Matrix
open NumberField IsDedekindDomain MeasureTheory Filter Topology Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes
open GlobalTheory.WeilM GlobalTheory.AdelicU GlobalTheory.LFun GlobalTheory.IndefiniteRowSideFullHecke.WeilTensorModels
open GlobalTheory.Doubling (absE absEv unitFin ideleAt)

variable {F E : Type} [Field F] [NumberField F] [Field E] [NumberField E] [Algebra F E]

section Parts

variable {M : Type} [AddCommGroup M] [Module (AF F) M]

def partFin (v : Pl F) (z : M) : M := GlobalTheory.LatVac.liftV v 1 • z

theorem partFin_of_at {v : Pl F} {z : M} (hz : At (evFin F v) z) : partFin v z = z := by
  have h := hz (1 - GlobalTheory.LatVac.liftV v 1) (by rw [map_sub, map_one, GlobalTheory.LatVac.evFin_liftV, sub_self])
  rw [sub_smul, one_smul, sub_eq_zero] at h
  exact h.symm

end Parts

section Groups

variable {R : Type} [Zero R]

variable (E) in

def idelesAt (ev : AF F → R) : Subgroup (AE F E)ˣ where
  carrier := {l | At ev ((l : AE F E) - 1)}
  one_mem' := fun u _ => by rw [Units.val_one, sub_self, smul_zero]
  mul_mem' := by
    intro g h hg hh u hu
    have e : ((g * h : (AE F E)ˣ) : AE F E) - 1 = ((g : AE F E) - 1) * h + (h - 1) := by
      rw [Units.val_mul]; ring
    rw [e, smul_add, ← smul_mul_assoc, hg u hu, hh u hu, zero_mul, add_zero]
  inv_mem' := by
    intro g hg u hu
    have e : ((g⁻¹ : (AE F E)ˣ) : AE F E) - 1 = -(((g : AE F E) - 1) * (g⁻¹ : (AE F E)ˣ)) := by
      rw [sub_mul, Units.mul_inv]; ring
    rw [e, smul_neg, ← smul_mul_assoc, hg u hu, zero_mul, neg_zero]

variable (E) in

def unitsAt (v : Pl F) : Subgroup (AE F E)ˣ :=
  idelesAt E (evFin F v) ⊓ (intLoc F E v).toSubmonoid.units.comap (unitFin F E v)


theorem isClosed_idelesAt (ev : AF F → R) : IsClosed (idelesAt E ev : Set (AE F E)ˣ) := by
  haveI : Module.Finite F E := Module.Finite.of_restrictScalars_finite ℚ F E
  haveI := GlobalTheory.AdelicUnitaryTop.t2Space_adeleRing_numberField F
  haveI : IsTopologicalRing (AE F E) := GlobalTheory.Doubling.isTopologicalRing_tens
  haveI : T2Space (AE F E) := GlobalTheory.Doubling.t2Space_tensorProduct_finiteExtension
  change IsClosed {l : (AE F E)ˣ | ∀ u, ev u = 0 → u • ((l : AE F E) - 1) = 0}
  simp only [Set.setOf_forall]
  exact isClosed_iInter fun u => isClosed_iInter fun _ =>
    isClosed_eq ((Units.continuous_val.sub continuous_const).const_smul u) continuous_const

theorem compFin_smul (v : Pl F) (a : AF F) (z : AE F E) : compFin F E v (a • z) = evFin F v a • compFin F E v z := by
  induction z using TensorProduct.induction_on with
  | zero => simp
  | tmul b x => exact congrArg (· ⊗ₜ[F] x) (map_mul (evFin F v) a b)
  | add x y hx hy => rw [smul_add, map_add, map_add, hx, hy, smul_add]

theorem compInf_smul (w : InfinitePlace F) (a : AF F) (z : AE F E) :
    compInf F E w (a • z) = evInf F w a • compInf F E w z := by
  induction z using TensorProduct.induction_on with
  | zero => simp
  | tmul b x => exact congrArg (· ⊗ₜ[F] x) (map_mul (evInf F w) a b)
  | add x y hx hy => rw [smul_add, map_add, map_add, hx, hy, smul_add]

theorem at_evFin_iff {v : Pl F} {z : AE F E} : At (evFin F v) z ↔
    (∀ w, compInf F E w z = 0) ∧ ∀ w, w ≠ v → compFin F E w z = 0 := by
  constructor
  · intro hz
    rw [← partFin_of_at hz, partFin]
    refine ⟨fun w => ?_, fun w hw => ?_⟩
    · rw [compInf_smul, show evInf F w (GlobalTheory.LatVac.liftV v 1) = 0 from rfl, zero_smul]
    · rw [compFin_smul, show evFin F w (GlobalTheory.LatVac.liftV v 1) = 0 from evalV_singleFin_ne hw 1, zero_smul]
  · rintro ⟨h1, h2⟩ u hu
    refine GlobalTheory.Doubling.adele_ext (fun w => ?_) fun w => ?_
    · rw [compInf_smul, h1, smul_zero, map_zero]
    · rw [compFin_smul, map_zero]
      by_cases hw : w = v
      · subst hw; rw [hu, zero_smul]
      · rw [h2 w hw, smul_zero]

theorem ideleAt_mem (v : Pl F) (x : (Fv F v ⊗[F] E)ˣ) : ideleAt F E v x ∈ idelesAt E (evFin F v) := by
  refine at_evFin_iff.2 ⟨fun w => ?_, fun w hw => ?_⟩
  · rw [map_sub, map_one, sub_eq_zero]
    exact congrArg Units.val (GlobalTheory.Doubling.unitInf_ideleAt w v x)
  · rw [map_sub, map_one, sub_eq_zero]
    exact congrArg Units.val (GlobalTheory.Doubling.unitFin_ideleAt_ne hw x)

theorem ideleAt_unitFin {v : Pl F} {l : (AE F E)ˣ} (hl : l ∈ idelesAt E (evFin F v)) :
    ideleAt F E v (unitFin F E v l) = l := by
  obtain ⟨h1, h2⟩ := at_evFin_iff.1 hl
  refine GlobalTheory.Doubling.idele_ext (fun w => ?_) fun w => ?_
  · rw [GlobalTheory.Doubling.unitInf_ideleAt]
    have := h1 w
    rw [map_sub, map_one, sub_eq_zero] at this
    exact Units.ext this.symm
  · by_cases hw : w = v
    · subst hw; rw [GlobalTheory.Doubling.unitFin_ideleAt_self]
    · rw [GlobalTheory.Doubling.unitFin_ideleAt_ne hw]
      have := h2 w hw
      rw [map_sub, map_one, sub_eq_zero] at this
      exact Units.ext this.symm

variable (E) in

def idelesAtEquiv (v : Pl F) : idelesAt E (evFin F v) ≃ₜ* (Fv F v ⊗[F] E)ˣ where
  toFun l := unitFin F E v l.1
  invFun x := ⟨ideleAt F E v x, ideleAt_mem v x⟩
  left_inv l := Subtype.ext (ideleAt_unitFin l.2)
  right_inv x := GlobalTheory.Doubling.unitFin_ideleAt_self v x
  map_mul' a b := map_mul (unitFin F E v) a.1 b.1
  continuous_toFun := (GlobalTheory.Doubling.continuous_unitFin v).comp continuous_subtype_val
  continuous_invFun := (GlobalTheory.Doubling.continuous_ideleAt v).subtype_mk _



end Groups

section Haar

variable {R : Type} [Zero R] {n : ℕ}

variable (E) in

def IsNormE (v : Pl F) (μ : Measure (idelesAt E (evFin F v))) : Prop :=
  μ.IsHaarMeasure ∧ μ {l | l.1 ∈ unitsAt E v} = 1

variable (E) in

theorem idelesAt_facts (ev : AF F → R) : IsTopologicalGroup (idelesAt E ev) ∧ LocallyCompactSpace (idelesAt E ev) ∧
    SecondCountableTopology (idelesAt E ev) ∧ T2Space (idelesAt E ev) ∧ BorelSpace (idelesAt E ev) := by
  haveI : Module.Finite F E := Module.Finite.of_restrictScalars_finite ℚ F E
  haveI : IsTopologicalRing (AE F E) := GlobalTheory.Doubling.isTopologicalRing_tens
  haveI := GlobalTheory.AdelicUnitaryTop.t2Space_adeleRing_numberField F
  haveI := GlobalTheory.AdelicUnitaryTop.secondCountable_adele F
  obtain ⟨e⟩ := GlobalTheory.AdelicUnitaryTop.nonempty_homeomorph (F := F) (E := E) (AF F)
  haveI : LocallyCompactSpace (AE F E) := e.isClosedEmbedding.locallyCompactSpace
  haveI : SecondCountableTopology (AE F E) := e.secondCountableTopology
  haveI : T2Space (AE F E) := e.isEmbedding.t2Space
  haveI : LocallyCompactSpace (AE F E)ᵐᵒᵖ := MulOpposite.opHomeomorph.symm.isClosedEmbedding.locallyCompactSpace
  haveI : SecondCountableTopology (AE F E)ᵐᵒᵖ := MulOpposite.opHomeomorph.symm.isEmbedding.secondCountableTopology
  haveI : LocallyCompactSpace (AE F E)ˣ := Units.isClosedEmbedding_embedProduct.locallyCompactSpace
  haveI : SecondCountableTopology (AE F E)ˣ := Units.isEmbedding_embedProduct.secondCountableTopology
  haveI : BorelSpace (AE F E)ˣ := ⟨rfl⟩
  exact ⟨inferInstance, (isClosed_idelesAt ev).locallyCompactSpace, inferInstance, inferInstance, inferInstance⟩


end Haar

end GlobalTheory.ThK

end
