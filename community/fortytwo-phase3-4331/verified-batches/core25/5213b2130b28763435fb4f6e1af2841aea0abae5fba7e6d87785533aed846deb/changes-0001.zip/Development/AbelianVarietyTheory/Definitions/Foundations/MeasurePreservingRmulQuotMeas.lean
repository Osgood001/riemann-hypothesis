import Mathlib
import Development.AbelianVarietyTheory.Definitions.Foundations.AestronglyMeasurableQuotMeasureIffLift
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ExistsBruhatFunctionOfClosedEmbedding
import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.ExistsIsQuotientMeasureOfBruhatFunction
import Development.AbelianVarietyTheory.PublishedTheorems.TwistedTraceFormula.SchurOrthogonalitySquareIntegrable

open MeasureTheory Set GlobalTheory.AutomorphicL2Unitary
open scoped ENNReal NNReal Topology Pointwise

noncomputable section

namespace GlobalTheory.Orb

instance secondCountable_subgroup {H : Type*} [Group H] [TopologicalSpace H] [SecondCountableTopology H]
    (T : Subgroup H) : SecondCountableTopology T := TopologicalSpace.Subtype.secondCountableTopology (T : Set H)

section Weil

variable {H : Type} [Group H] [MeasurableSpace H] (T : Subgroup H) (dt : Measure T) (dh : Measure H)

def IsQuotMeasure (ν : Measure (Quot T)) : Prop :=
  ∀ f : H → ℝ≥0∞, Measurable f → ∫⁻ g, f g ∂dh = ∫⁻ q, ∫⁻ t : T, f (t * q.out) ∂dt ∂ν

open Classical in

def quotMeas : Measure (Quot T) := if h : ∃ ν, IsQuotMeasure T dt dh ν then h.choose else 0

def quotInt (φ : H → ℂ) : ℂ := ∫ q, descend T φ q ∂quotMeas T dt dh

def HasQuotInt (φ : H → ℂ) (c : ℂ) : Prop := Integrable (descend T φ) (quotMeas T dt dh) ∧ quotInt T dt dh φ = c

variable {T dt dh}

theorem IsQuotMeasure.quotMeas {ν : Measure (Quot T)} (h : IsQuotMeasure T dt dh ν) :
    IsQuotMeasure T dt dh (quotMeas T dt dh) := by
  have h' : ∃ ν, IsQuotMeasure T dt dh ν := ⟨ν, h⟩
  rw [Orb.quotMeas, dif_pos h']
  exact h'.choose_spec



theorem measurable_descend {X : Type*} [MeasurableSpace X] {φ : H → X} (h : LeftInv T φ) (hm : Measurable φ) :
    Measurable (descend T φ) :=
  measurable_from_quotient.2 (by rwa [show descend T φ ∘ Quotient.mk'' = φ from h.lift_descend])



variable [TopologicalSpace H] [IsTopologicalGroup H] [SecondCountableTopology H] [BorelSpace H]

theorem leftInv_lintegral [dt.IsMulRightInvariant] (f : H → ℝ≥0∞) :
    LeftInv T fun x => ∫⁻ t : T, f (t * x) ∂dt := fun s hs x => by
  simpa [mul_assoc] using lintegral_mul_right_eq_self (μ := dt) (fun t : T => f (t * x)) ⟨s, hs⟩

theorem leftInv_integral [dt.IsMulRightInvariant] (f : H → ℂ) :
    LeftInv T fun x => ∫ t : T, f (t * x) ∂dt := fun s hs x => by
  simpa [mul_assoc] using integral_mul_right_eq_self (μ := dt) (fun t : T => f (t * x)) ⟨s, hs⟩

theorem measurable_fiber [SFinite dt] {f : H → ℝ≥0∞} (hf : Measurable f) :
    Measurable fun x => ∫⁻ t : T, f (t * x) ∂dt :=
  (hf.comp ((measurable_subtype_coe.comp measurable_fst).mul measurable_snd)).lintegral_prod_left'

theorem IsQuotMeasure.eq_map {ν : Measure (Quot T)} (h : IsQuotMeasure T dt dh ν) {b : H → ℝ≥0∞}
    (hb : Measurable b) (h1 : ∀ x, ∫⁻ t : T, b (t * x) ∂dt = 1) : ν = (dh.withDensity b).map (mk T) := by
  ext A hA
  have hA' := measurable_mk hA
  rw [Measure.map_apply measurable_mk hA, withDensity_apply _ hA', ← lintegral_indicator hA',
    h _ (hb.indicator hA'), ← lintegral_indicator_one hA]
  refine lintegral_congr fun q => ?_
  have e : ∀ t : T, mk T (t * q.out) = q := fun t => (mk_mul _ _).trans (Quotient.out_eq q)
  by_cases hq : q ∈ A <;> simp [Set.indicator, e, hq, h1]

variable [LocallyCompactSpace H] [T2Space H]

theorem exists_bruhat (hT : IsClosed (T : Set H)) (dt : Measure T) [dt.IsHaarMeasure] [dt.IsMulRightInvariant] :
    ∃ b : H → ℝ≥0∞, Measurable b ∧ ∀ x, ∫⁻ t : T, b (t * x) ∂dt = 1 := by
  haveI : LocallyCompactSpace T := hT.locallyCompactSpace
  haveI := GlobalTheory.SqIntRep.isInvInvariant_of_unimodular dt
  exact GlobalTheory.exists_bruhat_function_closedEmbedding H T T.subtype hT.isClosedEmbedding_subtypeVal dt

variable (hT : IsClosed (T : Set H)) [dt.IsHaarMeasure] [dt.IsMulRightInvariant]
include hT



variable (dt dh) in

theorem isQuotMeasure_quotMeas [SFinite dh] [dh.IsMulLeftInvariant] : IsQuotMeasure T dt dh (quotMeas T dt dh) := by
  obtain ⟨b, hb, h1⟩ := exists_bruhat hT dt
  haveI : LocallyCompactSpace T := hT.locallyCompactSpace
  haveI := GlobalTheory.SqIntRep.isInvInvariant_of_unimodular dt
  have key : ∀ S : Subgroup H, S = T.subtype.range → ∃ ν : Measure (Quot S),
      ∀ f : H → ℝ≥0∞, Measurable f → ∫⁻ g, f g ∂dh = ∫⁻ q, ∫⁻ t : T, f (t * q.out) ∂dt ∂ν := by
    rintro S rfl
    exact GlobalTheory.exists_isQuotientMeasure_of_bruhatFunction H T T.subtype measurable_subtype_coe dh dt b hb h1
  obtain ⟨ν, hν⟩ := key T (T.range_subtype).symm
  exact IsQuotMeasure.quotMeas hν

variable [SFinite dh] [dh.IsMulLeftInvariant]




theorem weil_integral {f : H → ℂ} (hf : Integrable f dh) :
    (∀ᵐ q ∂quotMeas T dt dh, Integrable (fun t : T => f (t * q.out)) dt) ∧
      HasQuotInt T dt dh (fun x => ∫ t : T, f (t * x) ∂dt) (∫ g, f g ∂dh) := by
  haveI : LocallyCompactSpace T := hT.locallyCompactSpace
  obtain ⟨b, hb, h1⟩ := exists_bruhat hT dt
  have hW := isQuotMeasure_quotMeas dt dh hT
  have hν := hW.eq_map hb h1
  have hΦ : Measurable fun p : H × T => (p.2 : H) * p.1 :=
    (measurable_subtype_coe.comp measurable_snd).mul measurable_fst
  have hP : MeasurePreserving (fun p : H × T => (p.2 : H) * p.1) ((dh.withDensity b).prod dt) dh := by
    refine ⟨hΦ, Measure.ext_of_lintegral _ fun φ hφ => ?_⟩
    have hi := leftInv_lintegral (dt := dt) φ
    rw [lintegral_map hφ hΦ, lintegral_prod (fun p : H × T => φ (p.2 * p.1)) (hφ.comp hΦ).aemeasurable, hW φ hφ, hν]
    refine ((lintegral_map (measurable_descend hi (measurable_fiber hφ)) measurable_mk).trans ?_).symm
    simp only [hi.descend_mk]
  have hm := hf.1.stronglyMeasurable_mk
  set f' := hf.1.mk f
  have hff : f =ᵐ[dh] f' := hf.1.ae_eq_mk
  obtain ⟨N, hN, hNm, hN0⟩ := exists_measurable_superset_of_null hff
  have hae : ∀ᵐ q ∂quotMeas T dt dh, (fun t : T => f (t * q.out)) =ᵐ[dt] fun t : T => f' (t * q.out) := by
    have h2 := hW (N.indicator 1) (measurable_one.indicator hNm)
    rw [lintegral_indicator_one hNm, hN0] at h2
    filter_upwards [(lintegral_eq_zero_iff (measurable_descend (leftInv_lintegral (dt := dt) _)
      (measurable_fiber (measurable_one.indicator hNm)))).1 h2.symm] with q hq
    have h3 := (lintegral_eq_zero_iff (f := fun t : T => N.indicator (1 : H → ℝ≥0∞) (t * q.out))
      ((measurable_one.indicator hNm).comp (measurable_subtype_coe.mul_const _))).1 hq
    filter_upwards [h3] with t ht
    by_contra hne
    simp [Set.indicator_of_mem (hN hne)] at ht
  have hf' : Integrable f' dh := hf.congr hff
  have hI := hP.integrable_comp_of_integrable hf'
  have hi := leftInv_integral (dt := dt) f'
  have hFm : Measurable fun x => ∫ t : T, f' (t * x) ∂dt :=
    (StronglyMeasurable.integral_prod_right' (hm.comp_measurable hΦ)).measurable
  have hD := (measurable_descend hi hFm).aestronglyMeasurable (μ := (dh.withDensity b).map (mk T))
  have e : descend T (fun x => ∫ t : T, f (t * x) ∂dt) =ᵐ[quotMeas T dt dh]
      descend T fun x => ∫ t : T, f' (t * x) ∂dt := hae.mono fun q hq => integral_congr_ae hq
  refine ⟨?_, Integrable.congr ?_ e.symm, ?_⟩
  · have h2 := hW _ hm.measurable.enorm
    have h3 := ae_lt_top (measurable_descend (leftInv_lintegral (dt := dt) _) (measurable_fiber hm.measurable.enorm))
      (h2 ▸ hf'.2.ne :)
    filter_upwards [hae, h3] with q hq h4
    exact Integrable.congr ⟨(hm.comp_measurable (measurable_subtype_coe.mul_const _)).aestronglyMeasurable, h4⟩ hq.symm
  · rw [hν, integrable_map_measure hD measurable_mk.aemeasurable]
    exact hI.integral_prod_left.congr (.of_forall fun x => (hi.descend_mk x).symm)
  · rw [quotInt, integral_congr_ae e, hν, integral_map measurable_mk.aemeasurable hD, integral_congr_ae hff]
    conv_rhs => rw [← hP.map_eq, integral_map hΦ.aemeasurable hm.aestronglyMeasurable]
    simp only [hi.descend_mk]
    exact (integral_prod _ hI).symm




theorem hasQuotInt_of_finite [IsFiniteMeasure dt] {φ : H → ℂ} (hi : LeftInv T φ) (hφ : Integrable φ dh) :
    HasQuotInt T dt dh φ ((∫ g, φ g ∂dh) / dt.real univ) := by
  have h0 : (dt.real univ : ℂ) ≠ 0 := by
    exact_mod_cast ENNReal.toReal_ne_zero.2 ⟨(isOpen_univ.measure_pos dt univ_nonempty).ne', measure_ne_top _ _⟩
  have h := (weil_integral (dt := dt) hT hφ).2
  have e : (fun x => ∫ t : T, φ (t * x) ∂dt) = fun x => (dt.real univ : ℂ) * φ x := funext fun x => by
    simp [fun t : T => hi t t.2 x]
  rw [e] at h
  refine ⟨(integrable_const_mul_iff (IsUnit.mk0 _ h0) _).1 h.1, ?_⟩
  rw [eq_div_iff h0, ← h.2, mul_comm]
  exact (integral_const_mul _ _).symm

end Weil

section Transport

variable {H H' : Type} [Group H] [Group H'] [TopologicalSpace H] [TopologicalSpace H']

def subEquiv (e : H ≃ₜ* H') {T : Subgroup H} {T' : Subgroup H'} (h : ∀ x, e x ∈ T' ↔ x ∈ T) : T ≃ₜ* T' where
  toFun t := ⟨e t, (h _).2 t.2⟩
  invFun t := ⟨e.symm t, (h _).1 (by rw [e.apply_symm_apply]; exact t.2)⟩
  left_inv t := Subtype.ext (e.symm_apply_apply _)
  right_inv t := Subtype.ext (e.apply_symm_apply _)
  map_mul' s t := Subtype.ext (map_mul e _ _)
  continuous_toFun := (e.continuous.comp continuous_subtype_val).subtype_mk _
  continuous_invFun := (e.symm.continuous.comp continuous_subtype_val).subtype_mk _


variable [IsTopologicalGroup H] [SecondCountableTopology H] [LocallyCompactSpace H] [T2Space H] [MeasurableSpace H]
  [BorelSpace H] [IsTopologicalGroup H'] [SecondCountableTopology H'] [LocallyCompactSpace H'] [T2Space H']
  [MeasurableSpace H'] [BorelSpace H'] (e : H ≃ₜ* H') {T : Subgroup H} {T' : Subgroup H'}
  (h : ∀ x, e x ∈ T' ↔ x ∈ T) (hT : IsClosed (T : Set H)) (dt : Measure T) [dt.IsHaarMeasure]
  [dt.IsMulRightInvariant] (dh : Measure H) [SFinite dh] [dh.IsMulLeftInvariant]

omit [SecondCountableTopology H] [LocallyCompactSpace H] [T2Space H] [SecondCountableTopology H']
  [LocallyCompactSpace H'] [T2Space H'] in

instance isMulRightInvariant_map (μ : Measure H) [μ.IsMulRightInvariant] : (μ.map e).IsMulRightInvariant :=
  ⟨fun g => by
    have he : Measurable e := (map_continuous e).measurable
    rw [Measure.map_map (measurable_mul_const g) he]
    conv_rhs => rw [← map_mul_right_eq_self μ (e.symm g)]
    rw [Measure.map_map he (measurable_mul_const _)]
    congr 1
    ext x
    simp⟩







end Transport

section Orbital

variable {H : Type} [Group H]

abbrev cent (γ : H) : Subgroup H := Subgroup.centralizer {γ}

def conjFn (γ : H) (f : H → ℂ) : H → ℂ := fun x => f (x⁻¹ * γ * x)

theorem mem_cent {γ t : H} : t ∈ cent γ ↔ t * γ = γ * t := Subgroup.mem_centralizer_singleton_iff

theorem leftInv_conjFn {γ : H} {T : Subgroup H} (h : T ≤ cent γ) (f : H → ℂ) : LeftInv T (conjFn γ f) :=
  fun t ht x => by
    have : (t * x)⁻¹ * γ * (t * x) = x⁻¹ * (t⁻¹ * (γ * t)) * x := by group
    rw [conjFn, this, ← mem_cent.1 (h ht), inv_mul_cancel_left, conjFn]

def IsProperOrbit [TopologicalSpace H] (T : Subgroup H) (γ : H) : Prop :=
  ∀ K : Set H, IsCompact K → ∃ C : Set H, IsCompact C ∧ ∀ x, x⁻¹ * γ * x ∈ K → ∃ t ∈ T, t * x ∈ C

variable [MeasurableSpace H]


def HasOrbInt (dh : Measure H) (γ : H) (dt : Measure (cent γ)) (f : H → ℂ) (c : ℂ) : Prop :=
  HasQuotInt (cent γ) dt dh (conjFn γ f) c


variable {dh : Measure H} {γ : H} {dt : Measure (cent γ)} {f f' : H → ℂ}





variable [TopologicalSpace H] [IsTopologicalGroup H] [T2Space H]

omit [MeasurableSpace H] in

theorem isClosed_cent (γ : H) : IsClosed (cent γ : Set H) := by
  rw [show (cent γ : Set H) = {t | t * γ = γ * t} from Set.ext fun _ => mem_cent]
  exact isClosed_eq (by fun_prop) (by fun_prop)

omit [MeasurableSpace H] in

theorem isProperOrbit_of_isClosed [LocallyCompactSpace H] [SecondCountableTopology H]
    (h : IsClosed (range fun x : H => x⁻¹ * γ * x)) : IsProperOrbit (cent γ) γ := by
  intro K hK
  let X := range fun x : H => x⁻¹ * γ * x
  letI : MulAction H X :=
    { smul := fun g y => ⟨g * y * g⁻¹, by
        obtain ⟨_, x, rfl⟩ := y
        exact ⟨x * g⁻¹, by group⟩⟩
      one_smul := fun y => Subtype.ext (show 1 * y.1 * 1⁻¹ = y by group)
      mul_smul := fun a b y => Subtype.ext (show a * b * y.1 * (a * b)⁻¹ = a * (b * y.1 * b⁻¹) * a⁻¹ by group) }
  haveI : ContinuousSMul H X :=
    ⟨Continuous.subtype_mk (f := fun p : H × X => p.1 * p.2.1 * p.1⁻¹) (by fun_prop) _⟩
  haveI : MulAction.IsPretransitive H X := ⟨by
    rintro ⟨_, x, rfl⟩ ⟨_, y, rfl⟩
    exact ⟨y⁻¹ * x, Subtype.ext (show y⁻¹ * x * (x⁻¹ * γ * x) * (y⁻¹ * x)⁻¹ = y⁻¹ * γ * y by group)⟩⟩
  haveI : LocallyCompactSpace X := h.locallyCompactSpace
  let o : X := ⟨γ, 1, by simp⟩
  have ho : IsOpenMap fun g : H => g • o := isOpenMap_smul_of_sigmaCompact o
  have hK' : IsCompact (((↑) : X → H) ⁻¹' K) := h.isClosedEmbedding_subtypeVal.isCompact_preimage hK
  obtain ⟨n, hn⟩ := hK'.elim_directed_cover
    (fun n => (fun g : H => g • o) '' interior (CompactExhaustion.choice H n))
    (fun n => ho _ isOpen_interior) (fun y _ => by
      obtain ⟨g, rfl⟩ := MulAction.exists_smul_eq H o y
      obtain ⟨n, hn⟩ := (CompactExhaustion.choice H).exists_mem g
      exact mem_iUnion.2 ⟨n + 1, g, (CompactExhaustion.choice H).subset_interior_succ n hn, rfl⟩)
    (Monotone.directed_le fun a b hab => image_mono (interior_mono ((CompactExhaustion.choice H).subset hab)))
  refine ⟨_, ((CompactExhaustion.choice H).isCompact n).inv, fun x hx => ?_⟩
  obtain ⟨g, hg, e⟩ := hn (a := ⟨_, x, rfl⟩) hx
  have e' : g * γ * g⁻¹ = x⁻¹ * γ * x := congrArg Subtype.val e
  refine ⟨g⁻¹ * x⁻¹, mem_cent.2 ?_, by simpa using interior_subset hg⟩
  calc g⁻¹ * x⁻¹ * γ = g⁻¹ * (x⁻¹ * γ * x) * x⁻¹ := by group
    _ = _ := by rw [← e']; group

variable [LocallyCompactSpace H] [SecondCountableTopology H] [BorelSpace H] [dh.IsHaarMeasure] [dt.IsHaarMeasure]
  [dt.IsMulRightInvariant]


theorem hasOrbInt_of_finite [IsFiniteMeasure dt] (hf : Integrable (conjFn γ f) dh) :
    HasOrbInt dh γ dt f ((∫ x, f (x⁻¹ * γ * x) ∂dh) / dt.real univ) :=
  hasQuotInt_of_finite (isClosed_cent γ) (leftInv_conjFn le_rfl f) hf


omit [MeasurableSpace H] [IsTopologicalGroup H] [T2Space H] [LocallyCompactSpace H] [SecondCountableTopology H]
  [BorelSpace H] in

def centEquiv {H' : Type} [Group H'] [TopologicalSpace H'] (e : H ≃ₜ* H') (γ : H) {γ' : H'} (h : e γ = γ') :
    cent γ ≃ₜ* cent γ' :=
  subEquiv e fun x => by rw [mem_cent, mem_cent, ← h, ← map_mul, ← map_mul, e.injective.eq_iff]


omit [MeasurableSpace H] [T2Space H] [LocallyCompactSpace H] [SecondCountableTopology H] [BorelSpace H] in

def conjEquiv (g : H) : H ≃ₜ* H :=
  { MulAut.conj g with
    continuous_toFun := (continuous_const.mul continuous_id).mul continuous_const
    continuous_invFun := (continuous_const.mul continuous_id).mul continuous_const }


example [CompactSpace H] : HasOrbInt dh γ dt 1 (dh.real univ / dt.real univ) := by
  haveI : CompactSpace (cent γ) := isCompact_iff_compactSpace.1 (isClosed_cent γ).isCompact
  simpa using hasOrbInt_of_finite (dh := dh) (dt := dt) (f := 1) (integrable_const (1 : ℂ))

end Orbital

end GlobalTheory.Orb
