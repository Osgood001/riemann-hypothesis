import Mathlib
import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LaurentConstEqOfTendsto

noncomputable section

namespace GlobalTheory.Cont

open Filter Topology Set GlobalTheory.ThetaInner

def rightOf (σ : ℝ) : Set ℂ := {s | σ < s.re}

def IsRightDomain (U : Set ℂ) : Prop := (∃ σ, rightOf σ ⊆ U) ∧ ∀ s ∈ U, ∀ t : ℝ, 0 ≤ t → s + t ∈ U

def EqRight (H h : ℂ → ℂ) : Prop := ∃ σ, EqOn H h (rightOf σ)

variable {σ τ : ℝ} {U U' : Set ℂ} {h h' H H' : ℂ → ℂ} {s s₀ c c' : ℂ} {n : ℤ} {k : ℕ}

@[simp] theorem mem_rightOf : s ∈ rightOf σ ↔ σ < s.re := by exact Iff.rfl

theorem isOpen_rightOf (σ : ℝ) : IsOpen (rightOf σ) := isOpen_lt continuous_const Complex.continuous_re

theorem rightOf_subset (e : σ ≤ τ) : rightOf τ ⊆ rightOf σ := fun _ hs => lt_of_le_of_lt e hs

theorem isRightDomain_univ : IsRightDomain univ := ⟨⟨0, subset_univ _⟩, fun _ _ _ _ => mem_univ _⟩

theorem isRightDomain_rightOf (σ : ℝ) : IsRightDomain (rightOf σ) := by
  refine ⟨⟨σ, subset_rfl⟩, fun s hs t ht => ?_⟩
  simp only [mem_rightOf, Complex.add_re, Complex.ofReal_re] at hs ⊢
  linarith


theorem IsRightDomain.inter (a : IsRightDomain U) (b : IsRightDomain U') : IsRightDomain (U ∩ U') := by
  obtain ⟨⟨σ₁, h₁⟩, a₂⟩ := a
  obtain ⟨⟨σ₂, h₂⟩, b₂⟩ := b
  exact ⟨⟨max σ₁ σ₂, fun s hs => ⟨h₁ (rightOf_subset (le_max_left _ _) hs),
    h₂ (rightOf_subset (le_max_right _ _) hs)⟩⟩, fun s hs t ht => ⟨a₂ s hs.1 t ht, b₂ s hs.2 t ht⟩⟩

theorem IsRightDomain.preimage_add (a : IsRightDomain U) (z : ℂ) : IsRightDomain ((· + z) ⁻¹' U) := by
  obtain ⟨⟨σ₁, h₁⟩, a₂⟩ := a
  refine ⟨⟨σ₁ - z.re, fun s hs => ?_⟩, fun s hs t ht => ?_⟩
  · show s + z ∈ U
    apply h₁
    simp only [mem_rightOf, Complex.add_re] at hs ⊢
    linarith
  · show s + t + z ∈ U
    have := a₂ _ hs t ht
    rwa [add_right_comm] at this

theorem IsRightDomain.isPreconnected (a : IsRightDomain U) : IsPreconnected U := by
  obtain ⟨⟨σ, hσ⟩, a₂⟩ := a
  have hconv : IsPreconnected (rightOf σ) := (convex_halfSpace_re_gt σ).isPreconnected
  refine isPreconnected_of_forall ((σ + 1 : ℝ) : ℂ) fun y hy => ?_
  have hray : IsPreconnected ((fun t : ℝ => y + t) '' Ici 0) :=
    isPreconnected_Ici.image _ (by fun_prop : Continuous fun t : ℝ => y + (t : ℂ)).continuousOn
  have hT : (0 : ℝ) ≤ |σ - y.re| + 1 := by positivity
  have hmem : y + ((|σ - y.re| + 1 : ℝ) : ℂ) ∈ rightOf σ := by
    simp only [mem_rightOf, Complex.add_re, Complex.ofReal_re]
    have := le_abs_self (σ - y.re)
    linarith
  refine ⟨(fun t : ℝ => y + t) '' Ici 0 ∪ rightOf σ, union_subset ?_ hσ, Or.inr ?_,
    Or.inl ⟨0, mem_Ici.mpr le_rfl, by simp⟩, IsPreconnected.union _ ⟨_, hT, rfl⟩ hmem hray hconv⟩
  · rintro _ ⟨t, ht, rfl⟩
    exact a₂ y hy t ht
  · simp only [mem_rightOf, Complex.ofReal_re]
    linarith

namespace EqRight

@[refl] theorem refl (h : ℂ → ℂ) : EqRight h h := ⟨0, fun _ _ => rfl⟩

theorem symm (a : EqRight H h) : EqRight h H := by
  obtain ⟨σ, e⟩ := a
  exact ⟨σ, e.symm⟩

theorem map₂ (f : ℂ → ℂ → ℂ) (a : EqRight H h) (b : EqRight H' h') :
    EqRight (fun s => f (H s) (H' s)) fun s => f (h s) (h' s) := by
  obtain ⟨σ₁, e₁⟩ := a
  obtain ⟨σ₂, e₂⟩ := b
  refine ⟨max σ₁ σ₂, fun s hs => ?_⟩
  have h1 := e₁ (rightOf_subset (le_max_left _ _) hs)
  have h2 := e₂ (rightOf_subset (le_max_right _ _) hs)
  simp only [h1, h2]

theorem trans (a : EqRight H h) (b : EqRight h h') : EqRight H h' := by
  obtain ⟨σ₁, e₁⟩ := a
  obtain ⟨σ₂, e₂⟩ := b
  exact ⟨max σ₁ σ₂, fun s hs => (e₁ (rightOf_subset (le_max_left _ _) hs)).trans
    (e₂ (rightOf_subset (le_max_right _ _) hs))⟩

end EqRight

theorem eventuallyEq_of_isPreconnected (hU : IsPreconnected U) (hσ : rightOf σ ⊆ U) (a : MeromorphicOn H U)
    (b : MeromorphicOn H' U) (e : EqRight H H') (hs : s ∈ U) : H =ᶠ[𝓝[≠] s] H' := by
  obtain ⟨τ, eτ⟩ := e
  have hxσ : ((max σ τ + 1 : ℝ) : ℂ) ∈ rightOf σ := by
    simp only [mem_rightOf, Complex.ofReal_re]
    linarith [le_max_left σ τ]
  have hxτ : ((max σ τ + 1 : ℝ) : ℂ) ∈ rightOf τ := by
    simp only [mem_rightOf, Complex.ofReal_re]
    linarith [le_max_right σ τ]
  have hd : MeromorphicOn (H - H') U := a.sub b
  have htop : meromorphicOrderAt (H - H') ((max σ τ + 1 : ℝ) : ℂ) = ⊤ := by
    rw [meromorphicOrderAt_eq_top_iff]
    apply nhdsWithin_le_nhds
    filter_upwards [(isOpen_rightOf τ).mem_nhds hxτ] with z hz
    simp [eτ hz]
  have hs' : meromorphicOrderAt (H - H') s = ⊤ := by
    by_contra hne
    exact hd.meromorphicOrderAt_ne_top_of_isPreconnected hU hs (hσ hxσ) hne htop
  rw [meromorphicOrderAt_eq_top_iff] at hs'
  filter_upwards [hs'] with z hz
  simpa [sub_eq_zero] using hz

def LaurentCoeff (H : ℂ → ℂ) (s₀ : ℂ) (n : ℤ) (c : ℂ) : Prop := LaurentConst (fun s => (s - s₀) ^ (-n) * H s) s₀ c

theorem laurentConst_congr (a : LaurentConst H s₀ c) (e : H =ᶠ[𝓝[≠] s₀] H') : LaurentConst H' s₀ c := by
  obtain ⟨p, hp, t⟩ := a
  exact ⟨p, hp, t.congr' (e.mono fun s hs => by simp only [hs])⟩

theorem laurentConst_of_tendsto (a : Tendsto H (𝓝[≠] s₀) (𝓝 c)) : LaurentConst H s₀ c := ⟨0, by simp, by simpa using a⟩



theorem laurentConst_unique (a : LaurentConst H s₀ c) (b : LaurentConst H s₀ c') : c = c' := by
  obtain ⟨q, hq, tq⟩ := b
  obtain ⟨p, hp, tp⟩ := a
  refine laurentConst_eq_of_tendsto (fun s => H s - q.eval (s - s₀)⁻¹) s₀ c c'
    ⟨p - q, by simp [hp, hq], tp.congr fun s => ?_⟩ tq
  simp only [Polynomial.eval_sub]
  ring






@[simp] theorem laurentCoeff_zero : LaurentCoeff H s₀ 0 c ↔ LaurentConst H s₀ c := by
  unfold LaurentCoeff
  simp only [neg_zero, zpow_zero, one_mul]


def IsMerExt (h : ℂ → ℂ) (U : Set ℂ) (H : ℂ → ℂ) : Prop := IsRightDomain U ∧ MeromorphicOn H U ∧ EqRight H h

def IsHolExt (h : ℂ → ℂ) (U : Set ℂ) (H : ℂ → ℂ) : Prop := IsRightDomain U ∧ AnalyticOnNhd ℂ H U ∧ EqRight H h

def IsExtAt (h : ℂ → ℂ) (s₀ : ℂ) (H : ℂ → ℂ) : Prop := ∃ U, s₀ ∈ U ∧ IsMerExt h U H



def CoeffAt (h : ℂ → ℂ) (s₀ : ℂ) (n : ℤ) (c : ℂ) : Prop := ∃ H, IsExtAt h s₀ H ∧ LaurentCoeff H s₀ n c

def ValueAt (h : ℂ → ℂ) (s₀ c : ℂ) : Prop := ∃ H, IsExtAt h s₀ H ∧ LaurentConst H s₀ c

def HolValueAt (h : ℂ → ℂ) (s₀ c : ℂ) : Prop := ∃ H, IsExtAt h s₀ H ∧ AnalyticAt ℂ H s₀ ∧ H s₀ = c

abbrev ResidueAt (h : ℂ → ℂ) (s₀ c : ℂ) : Prop := CoeffAt h s₀ (-1) c

def PoleLE (h : ℂ → ℂ) (s₀ : ℂ) (k : ℕ) : Prop := ∃ H, IsExtAt h s₀ H ∧ ((-k : ℤ) : WithTop ℤ) ≤ meromorphicOrderAt H s₀

open Classical in

def laurent (h : ℂ → ℂ) (s₀ : ℂ) (n : ℤ) : ℂ := if e : ∃ c, CoeffAt h s₀ n c then e.choose else 0


theorem IsHolExt.isMerExt (a : IsHolExt h U H) : IsMerExt h U H := ⟨a.1, a.2.1.meromorphicOn, a.2.2⟩

theorem IsMerExt.isExtAt (a : IsMerExt h U H) (hs : s₀ ∈ U) : IsExtAt h s₀ H := ⟨U, hs, a⟩




namespace IsExtAt

theorem meromorphicAt (a : IsExtAt h s₀ H) : MeromorphicAt H s₀ := by
  obtain ⟨U, hs, hU⟩ := a
  exact hU.2.1 s₀ hs


theorem eventuallyEq (a : IsExtAt h s₀ H) (b : IsExtAt h s₀ H') : H =ᶠ[𝓝[≠] s₀] H' := by
  obtain ⟨U, hs, hU, hm, he⟩ := a
  obtain ⟨U', hs', hU', hm', he'⟩ := b
  have hI := hU.inter hU'
  obtain ⟨σ, hσ⟩ := hI.1
  exact eventuallyEq_of_isPreconnected hI.isPreconnected hσ (fun x hx => hm x hx.1) (fun x hx => hm' x hx.2)
    (he.trans he'.symm) ⟨hs, hs'⟩

theorem congr (a : IsExtAt h s₀ H) (e : EqRight h h') : IsExtAt h' s₀ H := by
  obtain ⟨U, hs, hU, hm, he⟩ := a
  exact ⟨U, hs, hU, hm, he.trans e⟩

theorem map₂ (f : ℂ → ℂ → ℂ) (hf : ∀ s, MeromorphicAt H s → MeromorphicAt H' s → MeromorphicAt (fun s => f (H s) (H' s)) s)
    (a : IsExtAt h s₀ H) (b : IsExtAt h' s₀ H') : IsExtAt (fun s => f (h s) (h' s)) s₀ fun s => f (H s) (H' s) := by
  obtain ⟨U, hs, hU, hm, he⟩ := a
  obtain ⟨U', hs', hU', hm', he'⟩ := b
  exact ⟨U ∩ U', ⟨hs, hs'⟩, hU.inter hU', fun x hx => hf x (hm x hx.1) (hm' x hx.2), he.map₂ f he'⟩

theorem add (a : IsExtAt h s₀ H) (b : IsExtAt h' s₀ H') : IsExtAt (fun s => h s + h' s) s₀ fun s => H s + H' s := map₂ (fun x y => x + y) (fun _ h1 h2 => h1.add h2) a b

theorem mul (a : IsExtAt h s₀ H) (b : IsExtAt h' s₀ H') : IsExtAt (fun s => h s * h' s) s₀ fun s => H s * H' s := map₂ (fun x y => x * y) (fun _ h1 h2 => h1.mul h2) a b

theorem div (a : IsExtAt h s₀ H) (b : IsExtAt h' s₀ H') : IsExtAt (fun s => h s / h' s) s₀ fun s => H s / H' s := map₂ (fun x y => x / y) (fun _ h1 h2 => h1.div h2) a b

theorem comp_add {z : ℂ} (a : IsExtAt h (s₀ + z) H) : IsExtAt (fun s => h (s + z)) s₀ fun s => H (s + z) := by
  obtain ⟨U, hs, hU, hm, σ, he⟩ := a
  refine ⟨(· + z) ⁻¹' U, hs, hU.preimage_add z, fun x hx => ?_, σ - z.re, fun x hx => he ?_⟩
  · exact (hm (x + z) hx).comp_analyticAt (g := fun w => w + z) (by fun_prop)
  · simp only [mem_rightOf, Complex.add_re] at hx ⊢
    linarith

theorem update (a : IsExtAt h s₀ H) (c : ℂ) : IsExtAt h s₀ (Function.update H s₀ c) := by
  obtain ⟨U, hs, hU, hm, σ, he⟩ := a
  have hev : ∀ x, Function.update H s₀ c =ᶠ[𝓝[≠] x] H := by
    intro x
    by_cases hx : x = s₀
    · rw [hx]
      filter_upwards [self_mem_nhdsWithin] with y hy
      exact Function.update_of_ne hy _ _
    · filter_upwards [nhdsWithin_le_nhds (isOpen_compl_singleton.mem_nhds hx)] with y hy
      exact Function.update_of_ne hy _ _
  refine ⟨U, hs, hU, fun x hx => (hm x hx).congr (hev x).symm, max σ s₀.re, fun x hx => ?_⟩
  have hne : x ≠ s₀ := by
    rintro rfl
    simp [mem_rightOf] at hx
  rw [Function.update_of_ne hne]
  exact he (rightOf_subset (le_max_left _ _) hx)






end IsExtAt

theorem isMerExt_self (a : IsRightDomain U) (b : MeromorphicOn h U) : IsMerExt h U h := ⟨a, b, EqRight.refl h⟩

theorem isExtAt_const (z s₀ : ℂ) : IsExtAt (fun _ => z) s₀ fun _ => z := ⟨univ, mem_univ _, isRightDomain_univ, fun x _ => MeromorphicAt.const z x, EqRight.refl _⟩


theorem IsExtAt.valueAt_iff (a : IsExtAt h s₀ H) : ValueAt h s₀ c ↔ LaurentConst H s₀ c := by
  constructor
  · rintro ⟨H', b, hc⟩
    exact laurentConst_congr hc (b.eventuallyEq a)
  · intro hc
    exact ⟨H, a, hc⟩

theorem IsExtAt.holValueAt_iff (a : IsExtAt h s₀ H) : HolValueAt h s₀ c ↔ Tendsto H (𝓝[≠] s₀) (𝓝 c) := by
  constructor
  · rintro ⟨H', b, han, hv⟩
    have t : Tendsto H' (𝓝[≠] s₀) (𝓝 c) := by
      rw [← hv]
      exact han.continuousAt.tendsto.mono_left nhdsWithin_le_nhds
    exact t.congr' (b.eventuallyEq a)
  · intro t
    refine ⟨Function.update H s₀ c, a.update c, ?_, by simp⟩
    exact (a.update c).meromorphicAt.analyticAt (continuousAt_update_same.mpr t)

theorem IsExtAt.poleLE_iff (a : IsExtAt h s₀ H) :
    PoleLE h s₀ k ↔ ∃ c, Tendsto (fun s => (s - s₀) ^ k * H s) (𝓝[≠] s₀) (𝓝 c) := by
  have hH := a.meromorphicAt
  have hP : MeromorphicAt (fun s : ℂ => (s - s₀) ^ k) s₀ := (analyticAt_id.sub analyticAt_const).meromorphicAt.pow k
  have hF : MeromorphicAt (fun s => (s - s₀) ^ k * H s) s₀ := hP.mul hH
  have hPord : meromorphicOrderAt (fun s : ℂ => (s - s₀) ^ k) s₀ = (k : WithTop ℤ) :=
    meromorphicOrderAt_pow_id_sub_const
  have hord : meromorphicOrderAt (fun s => (s - s₀) ^ k * H s) s₀ =
      (k : WithTop ℤ) + meromorphicOrderAt H s₀ := by
    rw [← hPord]
    exact meromorphicOrderAt_mul hP hH
  have key : ∀ o : WithTop ℤ, (0 ≤ (k : WithTop ℤ) + o ↔ ((-k : ℤ) : WithTop ℤ) ≤ o) := by
    intro o
    induction o using WithTop.recTopCoe with
    | top => simp
    | coe m =>
      norm_cast
      omega
  rw [tendsto_nhds_iff_meromorphicOrderAt_nonneg hF, hord, key]
  constructor
  · rintro ⟨H', b, hb⟩
    rwa [meromorphicOrderAt_congr (a.eventuallyEq b)]
  · intro hk
    exact ⟨H, a, hk⟩

theorem IsExtAt.coeffAt_of_tendsto (a : IsExtAt h s₀ H) (e : Tendsto (fun s => (s - s₀) ^ k * H s) (𝓝[≠] s₀) (𝓝 c)) :
    CoeffAt h s₀ (-k) c := ⟨H, a, laurentConst_of_tendsto (by simpa using e)⟩


@[simp] theorem coeffAt_zero : CoeffAt h s₀ 0 c ↔ ValueAt h s₀ c := by
  simp only [CoeffAt, ValueAt, laurentCoeff_zero]


theorem ValueAt.unique (a : ValueAt h s₀ c) (b : ValueAt h s₀ c') : c = c' := by
  obtain ⟨H, ha, hca⟩ := a
  exact laurentConst_unique hca (ha.valueAt_iff.mp b)

theorem HolValueAt.valueAt (a : HolValueAt h s₀ c) : ValueAt h s₀ c := by
  obtain ⟨H, ha, han, hv⟩ := a
  subst hv
  exact ⟨H, ha, laurentConst_of_tendsto (han.continuousAt.tendsto.mono_left nhdsWithin_le_nhds)⟩

theorem HolValueAt.unique (a : HolValueAt h s₀ c) (b : HolValueAt h s₀ c') : c = c' := ValueAt.unique a.valueAt b.valueAt


theorem IsHolExt.holValueAt (a : IsHolExt h U H) (hs : s₀ ∈ U) : HolValueAt h s₀ (H s₀) := ⟨H, a.isMerExt.isExtAt hs, a.2.1 s₀ hs, rfl⟩

theorem holValueAt_self (a : AnalyticOnNhd ℂ h (rightOf σ)) (hs : σ < s₀.re) : HolValueAt h s₀ (h s₀) := (show IsHolExt h (rightOf σ) h from ⟨isRightDomain_rightOf σ, a, EqRight.refl h⟩).holValueAt hs




theorem HolValueAt.congr (a : HolValueAt h s₀ c) (e : EqRight h h') : HolValueAt h' s₀ c := by
  obtain ⟨H, ha, han, hv⟩ := a
  exact ⟨H, ha.congr e, han, hv⟩







theorem holValueAt_const (z s₀ : ℂ) : HolValueAt (fun _ => z) s₀ z := ⟨fun _ => z, isExtAt_const z s₀, analyticAt_const, rfl⟩

theorem HolValueAt.add (a : HolValueAt h s₀ c) (b : HolValueAt h' s₀ c') : HolValueAt (fun s => h s + h' s) s₀ (c + c') := by
  obtain ⟨H, ha, han, rfl⟩ := a
  obtain ⟨H', hb, hbn, rfl⟩ := b
  exact ⟨fun s => H s + H' s, ha.add hb, han.add hbn, rfl⟩

theorem HolValueAt.mul (a : HolValueAt h s₀ c) (b : HolValueAt h' s₀ c') : HolValueAt (fun s => h s * h' s) s₀ (c * c') := by
  obtain ⟨H, ha, han, rfl⟩ := a
  obtain ⟨H', hb, hbn, rfl⟩ := b
  exact ⟨fun s => H s * H' s, ha.mul hb, han.mul hbn, rfl⟩



















theorem isMerExt_riemannZeta : IsMerExt (fun s => ∑' n : ℕ, 1 / ((n : ℂ) + 1) ^ s) univ riemannZeta := by
  refine ⟨isRightDomain_univ, fun s _ => ?_, ⟨1, fun s hs => zeta_eq_tsum_one_div_nat_add_one_cpow hs⟩⟩
  rcases eq_or_ne s 1 with rfl | hs
  · have hGa : AnalyticAt ℂ (Function.update (fun s => (s - 1) * riemannZeta s) 1 1) 1 := by
      refine Complex.analyticAt_of_differentiable_on_punctured_nhds_of_continuousAt ?_ ?_
      · filter_upwards [self_mem_nhdsWithin] with z hz
        refine DifferentiableAt.congr_of_eventuallyEq
          ((differentiableAt_id.sub_const 1).mul (differentiableAt_riemannZeta hz)) ?_
        filter_upwards [isOpen_compl_singleton.mem_nhds hz] with w hw
        exact Function.update_of_ne hw _ _
      · exact continuousAt_update_same.mpr riemannZeta_residue_one
    have hm : MeromorphicAt (fun s => Function.update (fun s => (s - 1) * riemannZeta s) 1 1 s * (s - 1)⁻¹) 1 :=
      hGa.meromorphicAt.mul (analyticAt_id.sub analyticAt_const).meromorphicAt.inv
    refine hm.congr ?_
    filter_upwards [self_mem_nhdsWithin] with z hz
    have hd : z - 1 ≠ 0 := sub_ne_zero.mpr hz
    rw [Function.update_of_ne hz]
    field_simp
  · have hd : DifferentiableOn ℂ riemannZeta {1}ᶜ := fun x hx => (differentiableAt_riemannZeta hx).differentiableWithinAt
    exact (hd.analyticAt (isOpen_compl_singleton.mem_nhds hs)).meromorphicAt

example : HolValueAt (fun s => ∑' n : ℕ, 1 / ((n : ℂ) + 1) ^ s) 0 (-1 / 2) ∧
    PoleLE (fun s => ∑' n : ℕ, 1 / ((n : ℂ) + 1) ^ s) 1 1 ∧ ResidueAt (fun s => ∑' n : ℕ, 1 / ((n : ℂ) + 1) ^ s) 1 1 ∧
    ValueAt (fun s => ∑' n : ℕ, 1 / ((n : ℂ) + 1) ^ s) 1 Real.eulerMascheroniConstant := by
  have h1 : Tendsto (fun s => (s - 1) ^ 1 * riemannZeta s) (𝓝[≠] 1) (𝓝 1) := by simpa using riemannZeta_residue_one
  have a := fun s => isMerExt_riemannZeta.isExtAt (mem_univ s)
  refine ⟨(a 0).holValueAt_iff.2 ?_, (a 1).poleLE_iff.2 ⟨1, h1⟩, (a 1).coeffAt_of_tendsto h1,
    _, a 1, Polynomial.X, by simp, by simpa using tendsto_riemannZeta_sub_one_div⟩
  exact riemannZeta_zero ▸ (differentiableAt_riemannZeta zero_ne_one).continuousAt.tendsto.mono_left nhdsWithin_le_nhds

example : ValueAt (fun s => s⁻¹) 0 0 ∧ ∀ c, ¬ HolValueAt (fun s => s⁻¹) 0 c := by
  have a : IsExtAt (fun s : ℂ => s⁻¹) 0 fun s => s⁻¹ :=
    (isMerExt_self isRightDomain_univ fun s _ => (MeromorphicAt.id s).inv).isExtAt trivial
  exact ⟨⟨_, a, Polynomial.X, by simp, by simp⟩, fun c e => not_tendsto_atTop_of_tendsto_nhds (a.holValueAt_iff.1 e).norm
    (tendsto_norm_cobounded_atTop.comp tendsto_inv₀_nhdsNE_zero)⟩

end GlobalTheory.Cont

end
