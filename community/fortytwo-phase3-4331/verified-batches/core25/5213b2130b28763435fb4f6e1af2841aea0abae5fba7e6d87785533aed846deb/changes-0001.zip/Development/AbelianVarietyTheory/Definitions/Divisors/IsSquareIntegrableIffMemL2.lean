import Mathlib
import Development.AbelianVarietyTheory.PublishedTheorems.Divisors₂.IsSmoothModerateOfIsAutFunSm
import Development.AbelianVarietyTheory.Definitions.Divisors.LocallyCompactUnipFlag
import Development.AbelianVarietyTheory.Proofs.FoundationProofs.ExistsIsLatticeFrameIsMajorantFrame

noncomputable section

open NumberField MeasureTheory Matrix Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes GlobalTheory.AdelicU GlobalTheory.SiegelSet
open GlobalTheory.AutomorphicL2Unitary (LeftInv MemL2Quotient stdDom isFundamentalDomain_stdDom)
open GlobalTheory.Cusp (Cocompact constTermOn)
open GlobalTheory.Orb (archMat)
open scoped TensorProduct NNReal ContDiff

namespace GlobalTheory.UAut

variable {F E : Type} [Field F] [NumberField F] [Field E] [NumberField E] [Algebra F E]
  (σ : E →ₐ[F] E) {n : ℕ} (J : Matrix (Fin n) (Fin n) E)

def IsSm (f : GAd σ J → ℂ) : Prop :=
  ∀ (k : ℕ) (γ : Fin k → ℝ → GAd σ J), (∀ i, IsRealLine σ J (γ i)) → ∀ g,
    ContDiff ℝ ∞ fun t : Fin k → ℝ => f (g * (List.ofFn fun i => γ i (t i)).prod)

variable {σ J} in

def dop (z : List (ℝ → GAd σ J) →₀ ℂ) (f : GAd σ J → ℂ) : GAd σ J → ℂ :=
  fun g => z.sum fun l c => c * l.foldr lineDer f g

def IsCentral (z : List (ℝ → GAd σ J) →₀ ℂ) : Prop :=
  (∀ l ∈ z.support, ∀ γ ∈ l, IsRealLine σ J γ) ∧
    ∀ f, IsSm σ J f → ∀ a ∈ infPts σ J, ∀ g, dop z (fun x => f (x * a)) g = dop z f (g * a)


structure IsAut (K : Subgroup (GAd σ J)) (φ : GAd σ J → ℂ) : Prop where
  mod : IsSmoothModerate σ J φ
  kfin : FiniteDimensional ℂ (Submodule.span ℂ (Set.range fun k : K => fun g => φ (g * k)))
  zfin : FiniteDimensional ℂ (Submodule.span ℂ {f | ∃ z, IsCentral σ J z ∧ f = dop z φ})

structure IsAutOn (H K : Subgroup (GAd σ J)) (φ : GAd σ J → ℂ) : Prop where
  left : LeftInv H φ
  level : ∃ U : Subgroup (GAd σ J), IsOpen (U : Set (GAd σ J)) ∧ ∀ k ∈ U, k ∈ finPts σ J → ∀ g, φ (g * k) = φ g
  cont : Continuous φ
  smooth : IsSm σ J φ
  growth : ∃ N : ℕ, ∀ l : List (ℝ → GAd σ J), (∀ γ ∈ l, IsRealLine σ J γ) →
    ∃ C : ℝ, ∀ g, ‖l.foldr lineDer φ g‖ ≤ C * (height σ J g : ℝ) ^ N
  kfin : GlobalTheory.Doubling.IsKFinite K φ
  zfin : FiniteDimensional ℂ (Submodule.span ℂ {f | ∃ z, IsCentral σ J z ∧ f = dop z φ})

def IsConstTerm {r : ℕ} (C : Matrix (Fin n) (Fin r) E) (φ c : GAd σ J → ℂ) : Prop :=
  ∀ (μ : Measure (unipRad σ J C)) (𝓕 : Set (unipRad σ J C)), μ.IsHaarMeasure →
    IsFundamentalDomain ((ratPts σ J).subgroupOf (unipRad σ J C)) 𝓕 μ → μ 𝓕 = 1 →
    ∀ g, c g = ∫ u in 𝓕, φ ((u : GAd σ J) * g) ∂μ

def IsConstTermOn (N : Subgroup (GAd σ J)) (φ c : GAd σ J → ℂ) : Prop :=
  ∀ (μ : Measure N) (𝓕 : Set N), μ.IsHaarMeasure → IsFundamentalDomain ((ratPts σ J).subgroupOf N) 𝓕 μ → μ 𝓕 = 1 →
    ∀ g, c g = ∫ u in 𝓕, φ ((u : GAd σ J) * g) ∂μ


variable {σ J} {r : ℕ} {H H' K K' N : Subgroup (GAd σ J)} {φ c c' : GAd σ J → ℂ} {C : Matrix (Fin n) (Fin r) E}

omit [NumberField E] in

theorem kfin_iff : FiniteDimensional ℂ (Submodule.span ℂ (Set.range fun k : K => fun g => φ (g * k))) ↔
    GlobalTheory.Doubling.IsKFinite K φ := by
  rw [show (Set.range fun k : K => fun g => φ (g * k)) = {Ψ | ∃ k ∈ K, Ψ = fun g => φ (g * k)} from
    Set.ext fun Ψ => ⟨fun ⟨k, e⟩ => ⟨k, k.2, e.symm⟩, fun ⟨k, hk, e⟩ => ⟨⟨k, hk⟩, e.symm⟩⟩]
  rfl

theorem isAut_iff_isAutOn : IsAut σ J K φ ↔ IsAutOn σ J (ratPts σ J) K φ :=
  ⟨fun h => ⟨h.mod.left, h.mod.level, h.mod.cont, h.mod.smooth, h.mod.growth, kfin_iff.1 h.kfin, h.zfin⟩,
    fun h => ⟨⟨h.left, h.level, h.cont, h.smooth, h.growth⟩, kfin_iff.2 h.kfin, h.zfin⟩⟩


omit [NumberField E] in

theorem foldr_lineDer_char (hφ : ∀ g h, φ (g * h) = φ g * φ h) (a : ℂ) (l : List (ℝ → GAd σ J)) :
    ∃ b : ℂ, l.foldr lineDer (a • φ) = b • φ := by
  induction l with
  | nil => exact ⟨a, rfl⟩
  | cons γ l ih =>
    obtain ⟨b, h⟩ := ih
    refine ⟨b * deriv (fun t => φ (γ t)) 0, ?_⟩
    rw [List.foldr_cons, h]
    funext g
    simp only [lineDer, Pi.smul_apply, smul_eq_mul, hφ, ← mul_assoc, deriv_const_mul_field']
    ring

theorem isAut_of_char (K : Subgroup (GAd σ J)) (hφ : ∀ g h, φ (g * h) = φ g * φ h) (a : ℂ)
    (hm : IsSmoothModerate σ J (a • φ)) : IsAut σ J K (a • φ) := by
  refine ⟨hm, ?_, ?_⟩ <;> refine Submodule.finiteDimensional_of_le (S₂ := Submodule.span ℂ {φ}) (Submodule.span_le.2 ?_)
  · rintro _ ⟨k, rfl⟩
    exact Submodule.mem_span_singleton.2 ⟨a * φ k, funext fun g => by simp only [Pi.smul_apply, smul_eq_mul, hφ]; ring⟩
  · rintro _ ⟨z, -, rfl⟩
    choose b hb using foldr_lineDer_char hφ a
    exact Submodule.mem_span_singleton.2 ⟨z.sum fun l x => x * b l, funext fun g => by
      simp [dop, hb, Finsupp.sum, Finset.sum_mul, mul_assoc]⟩

variable (σ J) in

theorem isAut_const (K : Subgroup (GAd σ J)) (a : ℂ) : IsAut σ J K fun _ => a := by
  have e : (fun _ => a) = a • fun _ : GAd σ J => (1 : ℂ) := funext fun _ => by simp
  exact e ▸ isAut_of_char K (by simp) a (e ▸ isSmoothModerate_const σ J a)

variable (σ J) in

theorem isAutOn_const (H K : Subgroup (GAd σ J)) (a : ℂ) : IsAutOn σ J H K fun _ => a :=
  { isAut_iff_isAutOn.1 (isAut_const σ J K a) with left := fun _ _ _ => rfl }

example : IsCentral σ J (Finsupp.single [] 1) :=
  ⟨by simp, fun f _ a _ g => by simp [dop]⟩







variable (σ J) in

def majCpt (c : ∀ w : InfinitePlace F, GL (Fin n) (w.Completion ⊗[F] E)) : Subgroup (GAd σ J) :=
  infPts σ J ⊓ ⨅ w, (stabArch σ J w (c w)).comap (projArch σ J w)




example (ξ : E) (hξ : σ ξ = -ξ) : ∃ g ∈ ratPts σ !![0, 1; 1, 0] ⊓
    unipFlag σ !![0, 1; 1, 0] (!![1; 0] : Matrix (Fin 2) (Fin 1) E) fun _ => 0,
      (matHom _ σ _ g).1 = adMat F !![1, ξ; 0, 1] := by
  let γ : GRat σ (!![0, 1; 1, 0] : Matrix (Fin 2) (Fin 2) E) := ⟨⟨!![1, ξ; 0, 1], !![1, -ξ; 0, 1], by simp [one_fin_two],
    by simp [one_fin_two]⟩, show _ * _ * _ = _ by
      ext i j; fin_cases i <;> fin_cases j <;> simp [Formalism.UG.cT, Matrix.mul_apply, Fin.sum_univ_two, hξ]⟩
  have e : (matHom _ σ _ (ratEmb σ _ γ)).1 = adMat F !![1, ξ; 0, 1] := rfl
  refine ⟨ratEmb σ _ γ, ⟨range_ratEmb σ _ ▸ ⟨γ, rfl⟩, Subgroup.subset_closure ⟨fun i => ⟨0, fun _ _ => rfl, ?_⟩,
    fun x _ => ⟨fun _ => inclR (AF F) (ξ * x 1), ?_⟩⟩⟩, e⟩ <;> rw [e] <;> funext k <;> fin_cases k <;>
    simp [Matrix.mulVec, dotProduct, Fin.sum_univ_two, Subsingleton.elim _ (0 : Fin 1)]



theorem isConstTerm_iff_unipFlag : IsConstTerm σ J C φ c ↔ IsConstTermOn σ J (unipFlag σ J C fun _ => 0) φ c := by
  rw [unipFlag_const]; rfl

omit [NumberField E] in

theorem isConstTermOn_const (N : Subgroup (GAd σ J)) (a : ℂ) : IsConstTermOn σ J N (fun _ => a) fun _ => a :=
  fun μ 𝓕 _ _ h _ => by simp [Measure.real, h]

theorem isConstTermOn_constTermOn [LocallyCompactSpace N] (hφ : LeftInv (ratPts σ J ⊓ N) φ) :
    IsConstTermOn σ J N φ (constTermOn (ratPts σ J) N φ) := fun μ 𝓕 _ h h1 g => by
  have hl : LeftInv ((ratPts σ J).subgroupOf N) fun u : N => φ (u * g) := fun γ hγ u => by
    simp only [Subgroup.coe_mul, mul_assoc]; exact hφ _ ⟨hγ, γ.2⟩ _
  rw [constTermOn, GlobalTheory.Cusp.probMeasure_eq μ, integral_smul_measure, GlobalTheory.AutomorphicL2Unitary.quotMeasure_univ h,
    GlobalTheory.AutomorphicL2Unitary.integral_quotMeasure h, h1, inv_one, ENNReal.toReal_one, one_smul]
  exact integral_congr_ae (.of_forall hl.descend_mk)

theorem exists_mass_one [LocallyCompactSpace N] (hc : Cocompact (ratPts σ J) N) : ∃ (μ : Measure N) (𝓕 : Set N),
    μ.IsHaarMeasure ∧ IsFundamentalDomain ((ratPts σ J).subgroupOf N) 𝓕 μ ∧ μ 𝓕 = 1 := by
  have h := isFundamentalDomain_stdDom ((ratPts σ J).subgroupOf N) (Measure.haar : Measure N)
  have h0 := h.measure_ne_zero (NeZero.ne _)
  have h1 := hc.measure_ne_top h
  exact ⟨(Measure.haar (stdDom ((ratPts σ J).subgroupOf N)))⁻¹ • Measure.haar, _,
    Measure.IsHaarMeasure.smul _ (ENNReal.inv_ne_zero.2 h1) (ENNReal.inv_ne_top.2 h0),
    h.mono Measure.smul_absolutelyContinuous, by simp [ENNReal.inv_mul_cancel h0 h1]⟩

theorem IsConstTermOn.unique [LocallyCompactSpace N] (hc : Cocompact (ratPts σ J) N) (h : IsConstTermOn σ J N φ c)
    (h' : IsConstTermOn σ J N φ c') : c = c' :=
  let ⟨μ, 𝓕, h1, h2, h3⟩ := exists_mass_one hc
  funext fun g => (h μ 𝓕 h1 h2 h3 g).trans (h' μ 𝓕 h1 h2 h3 g).symm

theorem isConstTermOn_iff [LocallyCompactSpace N] (hc : Cocompact (ratPts σ J) N) (hφ : LeftInv (ratPts σ J ⊓ N) φ) :
    IsConstTermOn σ J N φ c ↔ c = constTermOn (ratPts σ J) N φ :=
  ⟨fun h => h.unique hc (isConstTermOn_constTermOn hφ), fun h => h ▸ isConstTermOn_constTermOn hφ⟩

instance discreteTopology_ratPts_inf (P : Subgroup (GAd σ J)) : DiscreteTopology (ratPts σ J ⊓ P : Subgroup (GAd σ J)) :=
  .of_continuous_injective (f := Subgroup.inclusion (inf_le_left : ratPts σ J ⊓ P ≤ ratPts σ J))
    (continuous_subtype_val.subtype_mk _) (Subgroup.inclusion_injective _)

section Flag

variable (h : IsCMExt F E σ) (hJ : IsHermND σ J) (hC : IsIsoCols σ J C)
include h hJ hC

theorem existsUnique_isConstTermOn (d : Fin r → ℕ) (hφ : LeftInv (ratPts σ J ⊓ unipFlag σ J C d) φ) :
    ∃! c, IsConstTermOn σ J (unipFlag σ J C d) φ c :=
  haveI := locallyCompact_unipFlag hJ (sigma_sigma h) hC d
  ⟨_, isConstTermOn_constTermOn hφ, fun _ hc =>
    (isConstTermOn_iff (cocompact_unipFlag hJ (sigma_sigma h) hC d) hφ).1 hc⟩



theorem existsUnique_isConstTerm (hφ : LeftInv (ratPts σ J) φ) : ∃! c, IsConstTerm σ J C φ c := by
  simp only [isConstTerm_iff_unipFlag]
  exact existsUnique_isConstTermOn h hJ hC _ fun γ hγ => hφ γ hγ.1




end Flag

omit [NumberField F] [NumberField E] in

theorem isIsoCols_of_isWittFrame {X Y : Matrix (Fin n) (Fin r) E} (hW : IsWittFrame σ J X Y) (hσ : ∀ x, σ (σ x) = x)
    (hJ : IsHermND σ J) {k : ℕ} (hk : k ≤ r) : IsIsoCols σ J (X.submatrix id (Fin.castLE hk)) := by
  have yx : Formalism.UG.cT (σ : E →+* E) Y * J * X = 1 := by
    have := congrArg (Formalism.UG.cT (σ : E →+* E)) hW.xy
    rwa [Formalism.UG.cT_mul, Formalism.UG.cT_mul, show Formalism.UG.cT (σ : E →+* E) (Formalism.UG.cT (σ : E →+* E) X) = X from
      Matrix.ext fun i j => hσ _, cT_form hJ, Formalism.UG.cT_one, ← Matrix.mul_assoc] at this
  have hX : LinearIndependent E Xᵀ := Matrix.mulVec_injective_iff.1 fun a b e => by
    simpa only [Matrix.mulVec_mulVec, yx, Matrix.one_mulVec] using congrArg ((Formalism.UG.cT (σ : E →+* E) Y * J) *ᵥ ·) e
  exact ⟨hX.comp _ (Fin.castLE_injective hk), Matrix.ext fun i j => congrFun (congrFun hW.xx _) _⟩

example (h : IsCMExt F E σ) (a : ℂ) (c : GAd σ !![0, 1; 1, 0] → ℂ) :
    IsConstTerm σ !![0, 1; 1, 0] ((!![1; 0] : Matrix (Fin 2) (Fin 1) E).submatrix id (Fin.castLE le_rfl)) (fun _ => a) c ↔
      c = fun _ => a := by
  have hJ : IsHermND σ (!![0, 1; 1, 0] : Matrix (Fin 2) (Fin 2) E) :=
    ⟨fun i j => by fin_cases i <;> fin_cases j <;> simp, by simp⟩
  exact ⟨fun hc => (existsUnique_isConstTerm h hJ (isIsoCols_of_isWittFrame isWittFrame_plane (sigma_sigma h) hJ le_rfl)
    fun _ _ _ => rfl).unique hc (isConstTermOn_const _ a), fun e => e ▸ isConstTermOn_const _ a⟩

example : ∃ (μ : Measure (GAd σ J)) (𝓕 : Set (GAd σ J)), μ.IsHaarMeasure ∧ IsFundamentalDomain (ratPts σ J) 𝓕 μ :=
  ⟨Measure.haar, _, inferInstance, isFundamentalDomain_stdDom _ _⟩

end GlobalTheory.UAut

end
