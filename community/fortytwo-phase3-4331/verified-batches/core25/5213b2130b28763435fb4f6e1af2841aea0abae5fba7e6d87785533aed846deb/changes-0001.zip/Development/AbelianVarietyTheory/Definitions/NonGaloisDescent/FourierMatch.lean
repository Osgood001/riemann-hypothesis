import Mathlib

open Matrix MeasureTheory

noncomputable section

namespace GlobalTheory.JR

class Unram (F E : Type) [NontriviallyNormedField F] [NontriviallyNormedField E] [NormedAlgebra F E]
    [StarRing E] : Prop where
  charZero : CharZero F
  ultraF : IsUltrametricDist F
  ultraE : IsUltrametricDist E
  lcF : LocallyCompactSpace F
  lcE : LocallyCompactSpace E
  finrank_eq : Module.finrank F E = 2
  star_fix : ∀ x : F, star (algebraMap F E x) = algebraMap F E x
  star_ne : ∃ y : E, star y ≠ y
  norm_star : ∀ y : E, ‖star y‖ = ‖y‖
  unram : ∀ y : E, ∃ x : F, ‖y‖ = ‖x‖

def eta {F : Type} [NormedField F] (x : F) : ℂ := by
  classical exact if ∃ y : F, ‖x‖ = ‖y‖ ^ 2 then 1 else -1

def IsStdChar {F : Type} [NormedField F] (ψ : AddChar F ℂ) : Prop :=
  (∀ x : F, ‖x‖ ≤ 1 → ψ x = 1) ∧ ∃ x : F, ψ x ≠ 1 ∧ ∀ y : F, ‖y‖ < 1 → ‖x * y‖ ≤ 1

def IsTest {X : Type} [TopologicalSpace X] (f : X → ℂ) : Prop := IsLocallyConstant f ∧ HasCompactSupport f

abbrev Gl (r : ℕ) (k : Type) : Type := Matrix (Fin r) (Fin r) k × (Fin r → k) × (Fin r → k) × k


section Alg
variable {r : ℕ} {k : Type} [CommRing k]










def full (Y : Gl r k) : Matrix (Fin (r + 1)) (Fin (r + 1)) k :=
  Matrix.reindex finSumFinEquiv finSumFinEquiv
    (Matrix.fromBlocks Y.1 (Matrix.of fun i (_ : Fin 1) => Y.2.1 i) (Matrix.of fun (_ : Fin 1) j => Y.2.2.1 j)
      (Matrix.of fun _ _ => Y.2.2.2))

def lastDet (Y : Gl r k) : k :=
  (Matrix.of fun (i j : Fin (r + 1)) => (Pi.single (Fin.last r) (1 : k) ᵥ* (full Y ^ (i : ℕ))) j).det


end Alg


section Herm





end Herm

section Orb
variable {r : ℕ} {F E : Type} [NontriviallyNormedField F] [NontriviallyNormedField E] [NormedAlgebra F E] [StarRing E]

def omega (Y : Gl r F) : ℂ := eta (lastDet Y)

def glO (r : ℕ) (F : Type) [NormedField F] : Set (GL (Fin r) F) :=
  {g | ∀ i j, ‖(g : Matrix (Fin r) (Fin r) F) i j‖ ≤ 1 ∧ ‖((g⁻¹ : GL (Fin r) F) : Matrix (Fin r) (Fin r) F) i j‖ ≤ 1}

def uO (r : ℕ) (E : Type) [NormedField E] [StarRing E] : Set (Matrix.unitaryGroup (Fin r) E) :=
  {g | ∀ i j, ‖g.1 i j‖ ≤ 1}

structure Meas (r : ℕ) (F E : Type) [NontriviallyNormedField F] [NontriviallyNormedField E] [StarRing E] where
  [mG : MeasurableSpace (GL (Fin r) F)]
  [bG : BorelSpace (GL (Fin r) F)]
  [mU : MeasurableSpace (Matrix.unitaryGroup (Fin r) E)]
  [bU : BorelSpace (Matrix.unitaryGroup (Fin r) E)]
  [mF : MeasurableSpace F]
  [bF : BorelSpace F]
  [mE : MeasurableSpace E]
  [bE : BorelSpace E]
  μG : Measure (GL (Fin r) F)
  μU : Measure (Matrix.unitaryGroup (Fin r) E)
  μF : Measure F
  μE : Measure E
  haarG : μG.IsHaarMeasure
  haarU : μU.IsHaarMeasure
  haarF : μF.IsAddHaarMeasure
  haarE : μE.IsAddHaarMeasure
  volG : μG (glO r F) = 1
  volU : μU (uO r E) = 1
  volF : μF (Metric.closedBall 0 1) = 1
  volE : μE (Metric.closedBall 0 1) = 1









end Orb



end GlobalTheory.JR
