import Mathlib
import Development.AbelianVarietyTheory.Definitions.Foundations.EventuallyNormFinLeOne
import Development.AbelianVarietyTheory.Definitions.Foundations.OfInfProjInfMulOfFinProjFin
import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.QuotIntegrableIffCutoff
import Formalism.LocalRingCardinality.DataHost
import Formalism.LocalRingCardinality.DataTheta
import Formalism.LocalRingCardinality.RhoDetPrimeEqMuTildeMulChiPow
import Formalism.LocalToGlobal.BesselHermitianTheta.IsAutFunDef
import Formalism.LocalToGlobal.BesselHermitianTheta.TiedSmooth
import Formalism.SatakeDualWeyl.Statement
import Formalism.SharpRestriction.GlobalSchurBounds.GeneralLinearActions.GenusMassVolumes
import Formalism.SharpRestriction.RamificationFrobenius.TotientGaloisClasses.ConjEMemHostFIff

noncomputable section

namespace GlobalTheory.Grow

open scoped TensorProduct NNReal ENNReal Topology
open NumberField IsDedekindDomain MeasureTheory Filter Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.UG GlobalTheory.AdelicU

theorem continuous_of_le_mul {G : Type} [Group G] [TopologicalSpace G] [IsTopologicalGroup G] {q h : G → ℝ}
    (hh : Tendsto h (𝓝 1) (𝓝 1)) (hpos : ∀ k, 0 < h k) (hinv : ∀ k, h k⁻¹ = h k)
    (hq : ∀ g k, q (g * k) ≤ q g * h k) : Continuous q := by
  refine continuous_iff_continuousAt.2 fun g => ?_
  have h1 : Tendsto (fun x => h (g⁻¹ * x)) (𝓝 g) (𝓝 1) :=
    hh.comp (Continuous.tendsto' (by fun_prop) g 1 (inv_mul_cancel g))
  have h2 : Tendsto (fun x => q g * h (g⁻¹ * x)) (𝓝 g) (𝓝 (q g)) := by simpa using h1.const_mul (q g)
  have h3 : Tendsto (fun x => q g / h (g⁻¹ * x)) (𝓝 g) (𝓝 (q g)) := by
    have := (tendsto_const_nhds (x := q g)).div h1 one_ne_zero
    rwa [div_one] at this
  refine tendsto_of_tendsto_of_tendsto_of_le_of_le h3 h2 (fun x => ?_) fun x => ?_
  · have := hq x (g⁻¹ * x)⁻¹
    rw [hinv, mul_inv_rev, inv_inv, mul_inv_cancel_left] at this
    exact (div_le_iff₀ (hpos _)).2 this
  · simpa using hq g (g⁻¹ * x)

section GeneralLinearIntegers

variable (F : Type) [Field F] [NumberField F] {E : Type} [Field E] [NumberField E] [Algebra F E]

theorem eventually_absFin_tmul_le_one (x : E) :
    ∀ᶠ a in 𝓝 (0 : AF F), ∀ v, absFin F v (compFin F E v (a ⊗ₜ[F] x)) ≤ 1 := by
  obtain ⟨y, c, rfl⟩ : ∃ (y : 𝓞 E) (c : F), x = c • (y : E) := by
    obtain ⟨m, hm, hi⟩ := ((IsFractionRing.isAlgebraic_iff ℤ ℚ E).2
      (Algebra.IsAlgebraic.isAlgebraic x)).exists_integral_multiple
    refine ⟨⟨_, hi⟩, (m : F)⁻¹, ?_⟩
    change _ = (m : F)⁻¹ • (m • x)
    rw [← Int.cast_smul_eq_zsmul F, inv_smul_smul₀ (by exact_mod_cast hm)]
  have ho : IsOpen {a : Af F | ∀ v, a v ∈ v.adicCompletionIntegers F} :=
    RestrictedProduct.isOpen_forall_mem
      (A := fun v : HeightOneSpectrum (𝓞 F) => (v.adicCompletionIntegers F : Set (v.adicCompletion F)))
      fun _ => Valued.isOpen_valuationSubring _
  have hs : Continuous (sndA F) := continuous_snd
  have hc : Continuous fun a : AF F => sndA F (algebraMap F (AF F) c * a) :=
    hs.comp (continuous_const.mul continuous_id)
  have h1 : {a : Af F | ∀ v, a v ∈ v.adicCompletionIntegers F} ∈ 𝓝 (0 : Af F) :=
    ho.mem_nhds fun v => zero_mem (v.adicCompletionIntegers F)
  refine Eventually.mono (hc.tendsto' 0 0 (by rw [mul_zero, map_zero]) h1) fun a ha v => ?_
  rw [← TensorProduct.smul_tmul, Algebra.smul_def]
  refine (absFin_tmul_le F v (evFin F v (algebraMap F (AF F) c * a)) y).trans ?_
  exact Valued.toNormedField.norm_le_one_iff.2 (ha v)

theorem eventually_absFin_le_one_nhds :
    ∀ᶠ z in 𝓝 (0 : AF F ⊗[F] E), ∀ v, absFin F v (compFin F E v z) ≤ 1 := by
  have : Module.Finite F E := Module.Finite.of_restrictScalars_finite ℚ F E
  have : IsModuleTopology (AF F) (AF F ⊗[F] E) := ⟨rfl⟩
  have : IsTopologicalRing (AF F ⊗[F] E) := IsModuleTopology.isTopologicalRing (AF F) _
  let b := Module.finBasis F E
  let e := (Algebra.TensorProduct.basis (AF F) b).equivFun
  have h1 : Continuous e := IsModuleTopology.continuous_of_linearMap e.toLinearMap
  have h2 : ∀ i, ∀ᶠ z in 𝓝 (0 : AF F ⊗[F] E), ∀ v, absFin F v (compFin F E v (e z i ⊗ₜ[F] b i)) ≤ 1 := fun i =>
    (Continuous.tendsto' ((continuous_apply i).comp h1) 0 0 (by simp)).eventually
      (eventually_absFin_tmul_le_one F (b i))
  refine (eventually_all.2 h2).mono fun z hz v => ?_
  have h3 : z = ∑ i, e z i ⊗ₜ[F] b i := by
    conv_lhs => rw [← (Algebra.TensorProduct.basis (AF F) b).sum_equivFun z]
    refine Finset.sum_congr rfl fun i _ => ?_
    simp [e, TensorProduct.smul_tmul']
  rw [h3, map_sum]
  exact absFin_sum_le F v _ _ fun i _ => hz i v

theorem continuous_infEmb_compInf (w : InfinitePlace F) (τ : EmbOver E w) :
    Continuous fun z : AF F ⊗[F] E => infEmb τ (compInf F E w z) := by
  have : Module.Finite F E := Module.Finite.of_restrictScalars_finite ℚ F E
  have : IsModuleTopology (AF F) (AF F ⊗[F] E) := ⟨rfl⟩
  have : IsTopologicalRing (AF F ⊗[F] E) := IsModuleTopology.isTopologicalRing (AF F) _
  let b := Module.finBasis F E
  let e := (Algebra.TensorProduct.basis (AF F) b).equivFun
  have h1 : Continuous e := IsModuleTopology.continuous_of_linearMap e.toLinearMap
  have h2 : (fun z : AF F ⊗[F] E => infEmb τ (compInf F E w z)) =
      fun z => ∑ i, InfinitePlace.Completion.extensionEmbedding w ((e z i).1 w) * τ.1 (b i) := by
    funext z
    have h3 : z = ∑ i, e z i ⊗ₜ[F] b i := by
      conv_lhs => rw [← (Algebra.TensorProduct.basis (AF F) b).sum_equivFun z]
      refine Finset.sum_congr rfl fun i _ => ?_
      simp [e, TensorProduct.smul_tmul']
    conv_lhs => rw [h3, map_sum, map_sum]
    rfl
  rw [h2]
  refine continuous_finsetSum _ fun i _ => Continuous.mul ?_ continuous_const
  exact (InfinitePlace.Completion.isometry_extensionEmbedding w).continuous.comp
    ((continuous_apply w).comp (continuous_fst.comp ((continuous_apply i).comp h1)))

variable {n : Type} [Fintype n] [DecidableEq n]

theorem continuous_opNorm : Continuous (opNorm : Matrix n n ℂ → ℝ≥0) :=
  continuous_nnnorm.comp
    (Matrix.toEuclideanCLM (n := n) (𝕜 := ℂ)).toAlgEquiv.toLinearEquiv.toLinearMap.continuous_of_finiteDimensional

theorem continuous_htInf (w : InfinitePlace F) :
    Continuous fun g : GL n (AF F ⊗[F] E) => htInf F w (bc (compInf F E w) g) := by
  have h : Continuous fun y : Matrix n n (AF F ⊗[F] E) => normInf F w (y.map (compInf F E w)) := by
    classical
    exact Continuous.finset_sup_apply (s := Finset.univ)
      (f := fun (τ : EmbOver E w) (y : Matrix n n (AF F ⊗[F] E)) => opNorm ((y.map (compInf F E w)).map (infEmb τ)))
      fun τ _ => continuous_opNorm.comp (continuous_id.matrix_map (continuous_infEmb_compInf F w τ))
  exact continuous_const.max ((h.comp Units.continuous_val).max (h.comp Units.continuous_coe_inv))

theorem eventually_htFin_eq_one :
    ∀ᶠ g in 𝓝 (1 : GL n (AF F ⊗[F] E)), ∀ v, htFin F v (bc (compFin F E v) g) = 1 := by
  have : Module.Finite F E := Module.Finite.of_restrictScalars_finite ℚ F E
  have : IsModuleTopology (AF F) (AF F ⊗[F] E) := ⟨rfl⟩
  have : IsTopologicalRing (AF F ⊗[F] E) := IsModuleTopology.isTopologicalRing (AF F) _
  have h : ∀ᶠ y in 𝓝 (1 : Matrix n n (AF F ⊗[F] E)), ∀ v, normFin F v (y.map (compFin F E v)) ≤ 1 := by
    have h1 : ∀ i j, ∀ᶠ y in 𝓝 (1 : Matrix n n (AF F ⊗[F] E)),
        ∀ v, absFin F v (compFin F E v ((y - 1) i j)) ≤ 1 := fun i j =>
      (Continuous.tendsto' (f := fun y : Matrix n n (AF F ⊗[F] E) => (y - 1) i j)
        ((continuous_id.sub continuous_const).matrix_elem i j) 1 0 (by simp)).eventually
        (eventually_absFin_le_one_nhds F)
    refine (eventually_all.2 fun i => eventually_all.2 (h1 i)).mono fun y hy v => (normFin_le_iff F v).2 fun i j => ?_
    have e : (y.map (compFin F E v)) i j = compFin F E v ((y - 1) i j) + (1 : Matrix n n (Fv F v ⊗[F] E)) i j := by
      by_cases hij : i = j <;> simp [Matrix.one_apply, hij]
    rw [e]
    exact (absFin_add_le F v _ _).trans (max_le (hy i j v) ((absFin_le_normFin F v _ i j).trans (normFin_one_le F v)))
  have h1 := (Units.continuous_val.tendsto' (1 : GL n (AF F ⊗[F] E)) 1 rfl).eventually h
  have h2 := (Units.continuous_coe_inv.tendsto' (1 : GL n (AF F ⊗[F] E)) 1 rfl).eventually h
  exact (h1.and h2).mono fun g hg v => htOf_eq_one.2 ⟨hg.1 v, hg.2 v⟩

theorem continuous_heightGL : Continuous (heightGL F : GL n (AF F ⊗[F] E) → ℝ≥0) := by
  have : Module.Finite F E := Module.Finite.of_restrictScalars_finite ℚ F E
  have : IsModuleTopology (AF F) (AF F ⊗[F] E) := ⟨rfl⟩
  have : IsTopologicalRing (AF F ⊗[F] E) := IsModuleTopology.isTopologicalRing (AF F) _
  have h1 : Continuous fun g : GL n (AF F ⊗[F] E) => ∏ w, htInf F w (bc (compInf F E w) g) :=
    continuous_finsetProd _ fun w _ => continuous_htInf F w
  have h2 : Tendsto (heightGL F : GL n (AF F ⊗[F] E) → ℝ≥0) (𝓝 1) (𝓝 1) := by
    refine (h1.tendsto' 1 1 ?_).congr' ((eventually_htFin_eq_one F).mono fun g hg => ?_)
    · exact Finset.prod_eq_one fun w _ => ((heightGL_eq_one_iff F).1 (heightGL_one F)).1 w
    · simp [heightGL, hg]
  refine continuous_induced_rng.2 (continuous_of_le_mul (q := fun g => (heightGL F g : ℝ)) (h := fun g => (heightGL F g : ℝ))
    (NNReal.tendsto_coe.2 h2) (fun k => ?_) (fun k => by rw [heightGL_inv]) fun g k => ?_)
  · exact_mod_cast zero_lt_one.trans_le (one_le_heightGL F k)
  · exact_mod_cast heightGL_mul_le F g k

theorem htInf_le_heightGL (g : GL n (AF F ⊗[F] E)) (w : InfinitePlace F) :
    htInf F w (bc (compInf F E w) g) ≤ heightGL F g :=
  (Finset.single_le_prod' (f := fun w => htInf F w (bc (compInf F E w) g)) (fun _ _ => one_le_htOf _ _)
    (Finset.mem_univ w)).trans (le_mul_of_one_le_right' (one_le_finprod' fun _ => one_le_htOf _ _))

example : 2 ≤ heightGL F (Matrix.GeneralLinearGroup.scalar (Fin 1)
    (Units.map (inclR (F := F) (AF F) : E →+* _).toMonoidHom (Units.mk0 (2 : E) two_ne_zero))) := by
  obtain ⟨w⟩ : Nonempty (InfinitePlace F) := inferInstance
  obtain ⟨τ⟩ : Nonempty (EmbOver E w) := inferInstance
  refine le_trans ?_ (((normInf_le_iff F w).1 (le_htOf _ _) τ).trans (htInf_le_heightGL F _ w))
  refine le_of_eq_of_le ?_ (le_of_eq (congrArg opNorm (a₁ := (2 : ℂ) • 1) ?_))
  · unfold opNorm
    rw [map_smul, map_one, nnnorm_smul]
    simp
  · ext i j
    obtain rfl := Subsingleton.elim i j
    change _ = infEmb τ (compInf F E w (Matrix.scalar (Fin 1) (inclR (F := F) (AF F) (2 : E)) i i))
    rw [Matrix.scalar_apply, Matrix.diagonal_apply_eq, map_ofNat, map_ofNat, map_ofNat]
    simp

end GeneralLinearIntegers

section Quot

variable {G : Type} [Group G] [MeasurableSpace G] {R : Subgroup G}

def IsQuotIntL1 (μR : Measure R) (μG : Measure G) (f : G → ℂ) (z : ℂ) : Prop :=
  ∃ F : G → ℂ, Integrable F μG ∧ (∀ h, Integrable (fun r : R => F (r * h)) μR) ∧
    (∀ h, f h = ∫ r : R, F (r * h) ∂μR) ∧ z = ∫ g, F g ∂μG

variable {μR : Measure R} {μG : Measure G} {f f' : G → ℂ} {z z' : ℂ}






theorem IsQuotIntL1.left [MeasurableMul R] [μR.IsMulRightInvariant] (h : IsQuotIntL1 μR μG f z) {s : G} (hs : s ∈ R)
    (x : G) : f (s * x) = f x := by
  obtain ⟨F, -, -, h3, -⟩ := h
  rw [h3, h3, ← integral_mul_right_eq_self (μ := μR) (fun r : R => F (r * x)) ⟨s, hs⟩]
  simp [mul_assoc]

theorem integrable_of_lintegral_eq_one {α : Type} [MeasurableSpace α] {μ : Measure α} {b : α → ℝ≥0} (hm : Measurable b)
    (h : ∫⁻ x, b x ∂μ = 1) : Integrable (fun x => (b x : ℝ)) μ ∧ ∫ x, (b x : ℝ) ∂μ = 1 := by
  have hi : Integrable (fun x => (b x : ℝ)) μ :=
    integrable_toReal_of_lintegral_ne_top (f := fun x => (b x : ℝ≥0∞)) hm.coe_nnreal_ennreal.aemeasurable
      (by rw [h]; exact ENNReal.one_ne_top)
  exact ⟨hi, ENNReal.ofReal_eq_one.1 ((lintegral_coe_eq_integral b hi).symm.trans h)⟩

variable [TopologicalSpace G] [IsTopologicalGroup G] [SecondCountableTopology G] [BorelSpace G]

open GlobalTheory.Tw in

theorem IsQuotIntL1.cutoff [SFinite μG] [μG.IsMulLeftInvariant] [SFinite μR] [μR.IsInvInvariant]
    (h : IsQuotIntL1 μR μG f z) {β : G → ℝ≥0} (hβ : IsCosetCutoff R μR β) :
    Integrable (fun x => (β x : ℝ) • f x) μG ∧ z = ∫ x, (β x : ℝ) • f x ∂μG := by
  obtain ⟨F, h1, h2, h3, h4⟩ := h
  have hc : Measurable fun p : R × G => (p.1 : G) * p.2 :=
    (measurable_subtype_coe.comp measurable_fst).mul measurable_snd
  have hc' : Measurable fun p : R × G => ((p.1⁻¹ : R) : G) * p.2 :=
    (measurable_subtype_coe.comp measurable_fst.inv).mul measurable_snd
  have hb : ∀ x, Integrable (fun t : R => (β ((t⁻¹ : R) * x) : ℝ)) μR ∧ ∫ t : R, (β ((t⁻¹ : R) * x) : ℝ) ∂μR = 1 :=
    fun x => integrable_of_lintegral_eq_one (hβ.1.comp (hc'.comp measurable_prodMk_right))
      (by rw [lintegral_inv_eq_self (μ := μR) (fun t : R => (β (t * x) : ℝ≥0∞)), hβ.2])
  have hb' := fun x => (hb x).2
  have hT : MeasurePreserving (fun p : R × G => (p.1, (p.1 : G) * p.2)) (μR.prod μG) (μR.prod μG) :=
    (MeasurePreserving.id μR).skew_product hc (Eventually.of_forall fun r => map_mul_left_eq_self μG (r : G))
  have hm : AEStronglyMeasurable (fun p : R × G => (β ((p.1⁻¹ : R) * p.2) : ℝ) • F p.2) (μR.prod μG) :=
    (hβ.1.comp hc').coe_nnreal_real.aestronglyMeasurable.smul h1.1.comp_snd
  have hI : Integrable (fun p : R × G => (β ((p.1⁻¹ : R) * p.2) : ℝ) • F p.2) (μR.prod μG) := by
    refine (integrable_prod_iff' hm).2 ⟨Eventually.of_forall fun x => (hb x).1.smul_const (F x), ?_⟩
    simpa only [norm_smul, integral_mul_const, hb', one_mul, Real.norm_of_nonneg (NNReal.coe_nonneg _)] using h1.norm
  have hI' : Integrable (fun p : R × G => (β p.2 : ℝ) • F (p.1 * p.2)) (μR.prod μG) := by
    simpa [Function.comp_def] using (hT.integrable_comp hm).2 hI
  have e : ∀ x, ∫ r : R, (β x : ℝ) • F (r * x) ∂μR = (β x : ℝ) • f x := fun x => by rw [integral_smul, h3]
  refine ⟨by simpa only [e] using hI'.integral_prod_right, ?_⟩
  have e1 := integral_prod_symm _ hI
  have e2 := integral_prod_symm _ hI'
  have e3 : ∫ p : R × G, (β p.2 : ℝ) • F (p.1 * p.2) ∂μR.prod μG =
      ∫ p : R × G, (β ((p.1⁻¹ : R) * p.2) : ℝ) • F p.2 ∂μR.prod μG := by
    have := integral_map hT.aemeasurable (f := fun p : R × G => (β ((p.1⁻¹ : R) * p.2) : ℝ) • F p.2)
      (by rwa [hT.map_eq])
    rw [hT.map_eq] at this
    rw [this]
    simp
  simp only [e] at e2
  simp only [integral_smul_const, hb', one_smul] at e1
  rw [h4, ← e1, ← e3, e2]

variable [LocallyCompactSpace G] [T2Space G] [SFinite μG] [μG.IsMulLeftInvariant] [μR.IsHaarMeasure] [μR.IsInvInvariant]


open GlobalTheory.Tw in

theorem isQuotIntL1_iff (hR : IsClosed (R : Set G)) (hm : Measurable f) :
    IsQuotIntL1 μR μG f z ↔
      (∀ s ∈ R, ∀ x, f (s * x) = f x) ∧ QuotIntegrable R μG μR f ∧ z = quotInt R μG μR f := by
  obtain ⟨β, -, hβ⟩ := exists_isCosetCutoff (μT := μR) hR
  have : LocallyCompactSpace R := hR.locallyCompactSpace
  have : SecondCountableTopology R := TopologicalSpace.Subtype.secondCountableTopology (R : Set G)
  have : μR.IsMulRightInvariant := by rw [← Measure.inv_eq_self μR]; infer_instance
  constructor
  · intro h
    have hl : ∀ s ∈ R, ∀ x, f (s * x) = f x := fun s hs => h.left hs
    exact ⟨hl, (quotIntegrable_iff_cutoff hR hβ hm hl).2 (h.cutoff hβ).1,
      by rw [quotInt_eq_cutoff hR hβ hm hl, (h.cutoff hβ).2]⟩
  · rintro ⟨hl, hi, rfl⟩
    have hb := fun x => integrable_of_lintegral_eq_one (μ := μR) (b := fun t : R => β (t * x))
      (hβ.1.comp (measurable_subtype_coe.mul_const x)) (hβ.2 x)
    have hb' := fun x => (hb x).2
    refine ⟨fun x => (β x : ℝ) • f x, (quotIntegrable_iff_cutoff hR hβ hm hl).1 hi, fun x => ?_, fun x => ?_,
      quotInt_eq_cutoff hR hβ hm hl⟩
    · simpa only [hl _ (Subtype.property _)] using (hb x).1.smul_const (f x)
    · simp only [hl _ (Subtype.property _), integral_smul_const, hb', one_smul]

end Quot

section Unitary

open Formalism.BasicNotions Formalism.BasicNotions.TH Formalism.L2.Theta

attribute [local instance] Formalism.BasicNotions.Host.cmStar

variable {D : D7} (V W : HSp D)

def height (g : GA D V) : ℝ := heightGL D.host.F (Formalism.L2.Theta.matHom V g)

theorem one_le_height (g : GA D V) : 1 ≤ height V g := by
  unfold height; exact_mod_cast one_le_heightGL _ _

theorem height_pos (g : GA D V) : 0 < height V g := zero_lt_one.trans_le (one_le_height V g)

@[simp] theorem height_one : height V 1 = 1 := by
  unfold height; rw [map_one, heightGL_one, NNReal.coe_one]

@[simp] theorem height_inv (g : GA D V) : height V g⁻¹ = height V g := by
  unfold height; rw [map_inv, heightGL_inv]

theorem height_mul_le (g h : GA D V) : height V (g * h) ≤ height V g * height V h := by
  unfold height; rw [map_mul]; exact_mod_cast heightGL_mul_le _ _ _


theorem continuous_height : Continuous (height V) :=
  NNReal.continuous_coe.comp ((continuous_heightGL _).comp continuous_subtype_val)


def quotHeight (g : GA D V) : ℝ := ⨅ γ : GQ V, height V (γ * g)

theorem quotHeight_le (g : GA D V) {γ : GA D V} (hγ : γ ∈ GQ V) : quotHeight V g ≤ height V (γ * g) :=
  ciInf_le (f := fun γ : GQ V => height V (γ * g)) ⟨1, by rintro _ ⟨_, rfl⟩; exact one_le_height V _⟩ ⟨γ, hγ⟩


theorem le_quotHeight_iff {g : GA D V} {c : ℝ} : c ≤ quotHeight V g ↔ ∀ γ ∈ GQ V, c ≤ height V (γ * g) :=
  ⟨fun h _ hγ => h.trans (quotHeight_le V g hγ), fun h => le_ciInf fun γ => h γ γ.2⟩

theorem one_le_quotHeight (g : GA D V) : 1 ≤ quotHeight V g := (le_quotHeight_iff V).2 fun _ _ => one_le_height V _

theorem quotHeight_pos (g : GA D V) : 0 < quotHeight V g := zero_lt_one.trans_le (one_le_quotHeight V g)

theorem quotHeight_left {γ : GA D V} (hγ : γ ∈ GQ V) (g : GA D V) : quotHeight V (γ * g) = quotHeight V g := by
  refine le_antisymm ((le_quotHeight_iff V).2 fun δ hδ => ?_) ((le_quotHeight_iff V).2 fun δ hδ => ?_)
  · simpa [mul_assoc] using quotHeight_le V (γ * g) (mul_mem hδ (inv_mem hγ))
  · simpa [mul_assoc] using quotHeight_le V g (mul_mem hδ hγ)

theorem quotHeight_of_mem {γ : GA D V} (hγ : γ ∈ GQ V) : quotHeight V γ = 1 :=
  le_antisymm (by simpa using quotHeight_le V γ (inv_mem hγ)) (one_le_quotHeight V γ)

theorem quotHeight_mul_le (g h : GA D V) : quotHeight V (g * h) ≤ quotHeight V g * height V h := by
  rw [← div_le_iff₀ (height_pos V h)]
  refine (le_quotHeight_iff V).2 fun γ hγ => (div_le_iff₀ (height_pos V h)).2 ?_
  exact (quotHeight_le V _ hγ).trans (by rw [← mul_assoc]; exact height_mul_le V _ _)

theorem continuous_quotHeight : Continuous (quotHeight V) :=
  continuous_of_le_mul ((continuous_height V).tendsto' 1 1 (height_one V)) (height_pos V) (height_inv V)
    (quotHeight_mul_le V)


variable {X : Type} [NormedAddCommGroup X]

def ModGrowthExp (A : ℕ) (f : GA D V → X) : Prop := ∃ C : ℝ, ∀ g, ‖f g‖ ≤ C * height V g ^ A

def ModGrowth (f : GA D V → X) : Prop := ∃ (C : ℝ) (A : ℕ), ∀ g, ‖f g‖ ≤ C * height V g ^ A

def ModGrowth₂ (f : GA D V → GA D W → X) : Prop :=
  ∃ (C : ℝ) (A : ℕ), ∀ g h, ‖f g h‖ ≤ C * (height V g * height W h) ^ A


variable {V W}













theorem ModGrowth₂.right {f : GA D V → GA D W → X} (h : ModGrowth₂ V W f) (g : GA D V) : ModGrowth W (f g) := by
  obtain ⟨C, A, hC⟩ := h
  exact ⟨C * height V g ^ A, A, fun h => by rw [mul_assoc, ← mul_pow]; exact hC g h⟩

theorem ModGrowth₂.swap {f : GA D V → GA D W → X} (h : ModGrowth₂ V W f) : ModGrowth₂ W V fun h g => f g h := by
  obtain ⟨C, A, hC⟩ := h
  exact ⟨C, A, fun h g => by rw [mul_comm (height W h)]; exact hC g h⟩

theorem ModGrowth₂.left {f : GA D V → GA D W → X} (h : ModGrowth₂ V W f) (k : GA D W) : ModGrowth V fun g => f g k :=
  h.swap.right k

variable (V)

def RapidDec (Φ : GA D V → X) : Prop :=
  (∀ γ ∈ GQ V, ∀ g, Φ (γ * g) = Φ g) ∧ Continuous Φ ∧ ∀ N : ℕ, ∃ C : ℝ, ∀ g, ‖Φ g‖ * quotHeight V g ^ N ≤ C


theorem rapidDec_exp_neg : RapidDec V fun g => (Real.exp (-quotHeight V g) : ℂ) := by
  refine ⟨fun γ hγ g => by simp only [quotHeight_left V hγ],
    Complex.continuous_ofReal.comp (Real.continuous_exp.comp (continuous_quotHeight V).neg),
    fun N => ⟨N.factorial, fun g => ?_⟩⟩
  have h := Real.pow_div_factorial_le_exp _ (quotHeight_pos V g).le N
  rw [div_le_iff₀ (by positivity)] at h
  rw [Complex.norm_real, Real.norm_of_nonneg (Real.exp_pos _).le, Real.exp_neg, inv_mul_le_iff₀ (Real.exp_pos _)]
  exact h

variable {V}



theorem RapidDec.left {Φ : GA D V → X} (h : RapidDec V Φ) {γ : GA D V} (hγ : γ ∈ GQ V) (g : GA D V) :
    Φ (γ * g) = Φ g := h.1 γ hγ g














example : ModGrowthExp V 1 (height V) := ⟨1, fun g => by simp [abs_of_pos (height_pos V g)]⟩

example : ∃ Φ : GA D V → ℂ, RapidDec V Φ ∧ Φ 1 = Real.exp (-1) :=
  ⟨_, rapidDec_exp_neg V, by simp only [quotHeight_of_mem V (one_mem _)]⟩

end Unitary


example {G : Type} [Group G] [MeasurableSpace G] {R : Subgroup G} (μR : Measure R) (μG : Measure G)
    [IsProbabilityMeasure μR] [IsProbabilityMeasure μG] : IsQuotIntL1 μR μG 1 1 :=
  ⟨1, integrable_const _, fun _ => integrable_const _, fun _ => by simp, by simp⟩

end GlobalTheory.Grow

end
