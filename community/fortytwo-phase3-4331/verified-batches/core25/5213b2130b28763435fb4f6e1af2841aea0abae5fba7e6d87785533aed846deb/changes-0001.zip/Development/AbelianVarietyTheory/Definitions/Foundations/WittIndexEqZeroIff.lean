import Mathlib
import Development.AbelianVarietyTheory.Proofs.HeightProofs.IsCuspFunIffConstTerm
import Development.AbelianVarietyTheory.Definitions.Foundations.HermitianSpaceBaseLatticeEqFrameLattice

noncomputable section

namespace GlobalTheory.Cusp

open scoped TensorProduct
open NumberField IsDedekindDomain Matrix
open Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.BasicNotions Formalism.UG GlobalTheory.IndefiniteRowSideFullHecke.AdelicUnitaryGroups GlobalTheory.AutFunCompare

variable {F E : Type} [Field F] [NumberField F] [Field E] [NumberField E] [StarRing E] [Algebra F E]

section Perp

variable {V : HSpace E}

theorem mem_perp {W : Submodule E V.V} {y : V.V} : y ∈ perp V W ↔ ∀ x ∈ W, V.hD y x = 0 := by
  simp [perp, Submodule.mem_iInf, HSpace.hD]

theorem perp_anti {A B : Submodule E V.V} (h : A ≤ B) : perp V B ≤ perp V A :=
  fun _ hy => mem_perp.2 fun x hx => mem_perp.1 hy x (h hx)

@[simp] theorem perp_bot : perp V ⊥ = ⊤ :=
  eq_top_iff.2 fun y _ => mem_perp.2 fun x hx => by simp [(Submodule.mem_bot E).1 hx, HSpace.hD]

@[simp] theorem perp_top : perp V ⊤ = ⊥ :=
  eq_bot_iff.2 fun y hy => V.nondeg.2 y fun x => mem_perp.1 hy x trivial


end Perp

section Ext

variable (V : HSpace E) (R : Type) [CommRing R] [Algebra F R]

omit [NumberField F]

theorem coordR_mem {W : Submodule E V.V} {x : V.V} (hx : x ∈ W) : coordR (F := F) V R x ∈ extSub (F := F) V R W :=
  Submodule.subset_span ⟨x, hx, rfl⟩

theorem extSub_mono {A B : Submodule E V.V} (h : A ≤ B) : extSub (F := F) V R A ≤ extSub (F := F) V R B :=
  Submodule.span_mono (Set.image_mono h)

theorem mulVec_mem_extSub {W : Submodule E V.V} {r : ℕ} (M : Matrix (Fin V.rank) (Fin r) E)
    (h : ∀ k, vecOf V (Mᵀ k) ∈ W) (a : Fin r → R ⊗[F] E) :
    M.map (inclR (F := F) R) *ᵥ a ∈ extSub (F := F) V R W :=
  extSub_mono V R (Submodule.span_le.2 (by rintro _ ⟨k, rfl⟩; exact h k) : colSpan V M ≤ W)
    ((mem_extSub_colSpan V R M _).2 ⟨a, rfl⟩)

theorem map_mulVec_coordR {r : ℕ} (M : Matrix (Fin r) (Fin V.rank) E) (x : V.V) :
    M.map (inclR (F := F) R) *ᵥ coordR (F := F) V R x = fun i => inclR R ((M *ᵥ fun j => V.frame.repr x j) i) :=
  funext fun i => (RingHom.map_mulVec (inclR (F := F) R) M (fun j => V.frame.repr x j) i).symm

theorem mem_extSub_iff_of_ker {W : Submodule E V.V} {r : ℕ} (T : Matrix (Fin r) (Fin V.rank) E)
    (P : Matrix (Fin V.rank) (Fin r) E) (hP : T * P * T = T)
    (hW : ∀ x, x ∈ W ↔ (T *ᵥ fun j => V.frame.repr x j) = 0) (y : Fin V.rank → R ⊗[F] E) :
    y ∈ extSub (F := F) V R W ↔ T.map (inclR (F := F) R) *ᵥ y = 0 := by
  constructor
  · intro hy
    refine (Submodule.span_le (p := LinearMap.ker (T.map (inclR (F := F) R)).mulVecLin)).2 ?_ hy
    rintro _ ⟨x, hx, rfl⟩
    change T.map (inclR (F := F) R) *ᵥ coordR V R x = 0
    rw [map_mulVec_coordR, (hW x).1 hx]
    funext i; simp
  · intro hy
    have h := mulVec_mem_extSub (F := F) V R (W := W) (1 - P * T) (fun k => (hW _).2 (by
      have : T * (1 - P * T) = 0 := by rw [Matrix.mul_sub, ← Matrix.mul_assoc, hP, Matrix.mul_one, sub_self]
      funext i
      simp only [repr_vecOf]
      exact congrFun (congrFun this i) k)) y
    rwa [Matrix.map_sub _ (map_sub _), Matrix.map_one _ (map_zero _) (map_one _), Matrix.map_mul, Matrix.sub_mulVec,
      Matrix.one_mulVec, ← Matrix.mulVec_mulVec, hy, Matrix.mulVec_zero, sub_zero] at h

theorem exists_cut (W : Submodule E V.V) : ∃ T : Matrix (Fin V.rank) (Fin V.rank) E, T * 1 * T = T ∧
    ∀ x, x ∈ W ↔ (T *ᵥ fun j => V.frame.repr x j) = 0 := by
  obtain ⟨U, hU⟩ := W.exists_isCompl
  let π : V.V →ₗ[E] V.V := U.projection W hU.symm
  refine ⟨LinearMap.toMatrix V.frame V.frame π, ?_, fun x => ?_⟩
  · rw [Matrix.mul_one, ← LinearMap.toMatrix_mul, (Submodule.isIdempotentElem_projection hU.symm).eq]
  · have := LinearMap.toMatrix_mulVec_repr V.frame V.frame π x
    rw [show (fun j => V.frame.repr x j) = ⇑(V.frame.repr x) from rfl, this, Finsupp.coe_eq_zero,
      LinearEquiv.map_eq_zero_iff, Submodule.projection_apply_eq_zero_iff]

@[simp] theorem extSub_bot : extSub (F := F) V R ⊥ = ⊥ :=
  Submodule.span_eq_bot.2 (by rintro _ ⟨x, hx, rfl⟩; funext i; simp [coordR, (Submodule.mem_bot E).1 hx])

@[simp] theorem extSub_top : extSub (F := F) V R ⊤ = ⊤ :=
  eq_top_iff.2 fun y _ => (mem_extSub_iff_of_ker V R (r := 0) 0 0 (by simp) (fun _ => by simp [eq_iff_true_of_subsingleton]) y).2
    (Subsingleton.elim _ _)


variable {R} {R' : Type} [CommRing R'] [Algebra F R']

def mapVec (φ : R →ₐ[F] R') (y : Fin V.rank → R ⊗[F] E) : Fin V.rank → R' ⊗[F] E :=
  fun i => Algebra.TensorProduct.map φ (AlgHom.id F E) (y i)

@[simp] theorem mapVec_coordR (φ : R →ₐ[F] R') (x : V.V) : mapVec V φ (coordR V R x) = coordR V R' x := by
  funext i; simp [mapVec, coordR, inclR]




omit [NumberField E] [StarRing E] in

theorem repr_map {ι : Type} (b : Module.Basis ι F E) (φ : R →ₐ[F] R') (u : R ⊗[F] E) (j : ι) :
    (Algebra.TensorProduct.basis R' b).repr (Algebra.TensorProduct.map φ (AlgHom.id F E) u) j =
      φ ((Algebra.TensorProduct.basis R b).repr u j) := by
  induction u using TensorProduct.induction_on with
  | zero => simp
  | add x y hx hy => simp only [map_add, Finsupp.add_apply, hx, hy]
  | tmul a e => simp

end Ext

section Form

variable (hc : CMData F E) (V : HSpace E) {R : Type} [CommRing R] [Algebra F R]

theorem hR_eq (x y : Fin V.rank → R ⊗[F] E) : hR R hc.sig V.gram x y =
    (fun i => Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes.sigR R hc.sig (x i)) ⬝ᵥ (V.gram.map (inclR (F := F) R) *ᵥ y) := by
  simp only [hR, hform, JR, dotProduct, Matrix.mulVec, Finset.mul_sum, mul_assoc]

theorem hR_mulVec {r : ℕ} (M : Matrix (Fin V.rank) (Fin r) (R ⊗[F] E)) (a : Fin r → R ⊗[F] E)
    (y : Fin V.rank → R ⊗[F] E) : hR R hc.sig V.gram (M *ᵥ a) y = (fun i => Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes.sigR R hc.sig (a i)) ⬝ᵥ
      ((cT (Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes.sigR R hc.sig) M * V.gram.map (inclR (F := F) R)) *ᵥ y) := by
  rw [hR_eq, ← Matrix.mulVec_mulVec, Matrix.dotProduct_mulVec _ (cT _ M)]
  congr 1
  funext i
  exact (RingHom.map_mulVec _ M a i).trans (congrFun (Matrix.vecMul_transpose _ _).symm i)

theorem hR_act (g : HA R hc.sig V.gram) (x y : Fin V.rank → R ⊗[F] E) :
    hR R hc.sig V.gram (act hc V g x) (act hc V g y) = hR R hc.sig V.gram x y := by
  have hg : cT (Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes.sigR R hc.sig) (HA.mat R hc.sig V.gram g).1 * V.gram.map (inclR (F := F) R) *
    (HA.mat R hc.sig V.gram g).1 = V.gram.map (inclR (F := F) R) := g.2
  rw [act, hR_mulVec, act, Matrix.mulVec_mulVec, hg, hR_eq]

theorem hR_act_sub (g : HA R hc.sig V.gram) (x y : Fin V.rank → R ⊗[F] E) :
    hR R hc.sig V.gram x (act hc V g y - y) = hR R hc.sig V.gram (act hc V g⁻¹ x - x) y := by
  have h := hR_act hc V g (act hc V g⁻¹ x) y
  rw [← act_mul, mul_inv_cancel, act_one] at h
  simp only [hR_eq, Matrix.mulVec_sub, dotProduct_sub, Pi.sub_apply, map_sub] at h ⊢
  rw [h, ← sub_dotProduct]
  rfl

theorem mem_extSub_perp {W : Submodule E V.V} {y : Fin V.rank → R ⊗[F] E} :
    y ∈ extSub (F := F) V R (perp V W) ↔ ∀ x ∈ extSub (F := F) V R W, hR R hc.sig V.gram x y = 0 := by
  obtain ⟨r, C, hC, rfl⟩ := exists_colSpan V W
  obtain ⟨l, hl⟩ := LinearMap.exists_leftInverse_of_injective C.mulVecLin
    (LinearMap.ker_eq_bot.2 (Matrix.mulVec_injective_iff.2 hC))
  obtain ⟨L, hL⟩ : ∃ L : Matrix (Fin r) (Fin V.rank) E, L * C = 1 :=
    ⟨LinearMap.toMatrix' l, by
      apply Matrix.toLin'.injective
      rw [Matrix.toLin'_mul, Matrix.toLin'_toMatrix', Matrix.toLin'_one]; exact hl⟩
  have hT : cT (hc.sig : E →+* E) C * V.gram * (V.gram⁻¹ * cT (hc.sig : E →+* E) L) = 1 := by
    rw [← Matrix.mul_assoc, Matrix.mul_nonsing_inv_cancel_right _ _ (gram_det_isUnit V), ← cT_mul, hL, cT_one]
  rw [mem_extSub_iff_of_ker V R _ _ (by rw [hT, Matrix.one_mul]) (mem_perp_colSpan hc V C), Matrix.map_mul,
    ← GlobalTheory.AutFunCounterexample.cT_map_gen]
  simp only [mem_extSub_colSpan]
  constructor
  · rintro h _ ⟨a, rfl⟩
    rw [hR_mulVec, h, dotProduct_zero]
  · intro h
    funext k
    have := h _ ⟨Pi.single k 1, rfl⟩
    rw [hR_mulVec] at this
    simpa [dotProduct, Pi.single_apply, apply_ite] using this

end Form

section Step

variable (hc : CMData F E) (V : HSpace E) (R : Type) [CommRing R] [Algebra F R]

def trivOn (A B : Submodule E V.V) : Subgroup (HA R hc.sig V.gram) where
  carrier := {g | g ∈ parab hc V R A ∧ ∀ y ∈ extSub (F := F) V R B, act hc V g y - y ∈ extSub (F := F) V R A}
  one_mem' := ⟨one_mem _, fun y _ => by rw [act_one, sub_self]; exact zero_mem _⟩
  mul_mem' := fun {a b} ha hb => ⟨mul_mem ha.1 hb.1, fun y hy => by
    have e : act hc V (a * b) y - y = act hc V a (act hc V b y - y) + (act hc V a y - y) := by
      rw [act_sub, act_mul]; abel
    rw [e]; exact add_mem ((ha.1 _).1 (hb.2 y hy)) (ha.2 y hy)⟩
  inv_mem' := fun {a} ha => ⟨inv_mem ha.1, fun y hy => by
    have e : act hc V a⁻¹ y - y = -act hc V a⁻¹ (act hc V a y - y) := by rw [act_sub, act_inv]; abel
    rw [e]; exact neg_mem ((inv_mem ha.1 _).1 (ha.2 y hy))⟩

variable {hc V R} {A B W : Submodule E V.V} {g : HA R hc.sig V.gram}

theorem mem_parab_iff_maps : g ∈ parab hc V R W ↔ ∀ y ∈ extSub (F := F) V R W, act hc V g y ∈ extSub (F := F) V R W := by
  refine ⟨fun h y => (h y).1, fun h y => ⟨h y, fun hy => ?_⟩⟩
  let f := (HA.mat R hc.sig V.gram g).1.mulVecLin
  have hs : Function.Surjective ((extSub (F := F) V R W).mapQ (extSub (F := F) V R W) f h) := fun q => by
    obtain ⟨z, rfl⟩ := Submodule.Quotient.mk_surjective _ q
    refine ⟨Submodule.Quotient.mk (act hc V g⁻¹ z), congrArg Submodule.Quotient.mk ?_⟩
    change act hc V g _ = z
    rw [← act_mul, mul_inv_cancel, act_one]
  refine (Submodule.Quotient.mk_eq_zero _).1 (OrzechProperty.injective_of_surjective_endomorphism _ hs ?_)
  rw [map_zero]
  exact (Submodule.Quotient.mk_eq_zero _).2 hy

theorem mem_parab : g ∈ parab hc V R W ↔ ∀ x ∈ W, act hc V g (coordR V R x) ∈ extSub (F := F) V R W :=
  mem_parab_iff_maps.trans ⟨fun h _ hx => h _ (coordR_mem V R hx), fun h _ hy =>
    (Submodule.span_le (p := (extSub (F := F) V R W).comap (HA.mat R hc.sig V.gram g).1.mulVecLin)).2
      (by rintro _ ⟨x, hx, rfl⟩; exact h x hx) hy⟩

@[simp] theorem parab_bot : parab hc V R ⊥ = ⊤ :=
  eq_top_iff.2 fun g _ => mem_parab_iff_maps.2 fun y hy => by
    rw [extSub_bot, Submodule.mem_bot] at hy ⊢
    rw [hy, act, Matrix.mulVec_zero]

theorem parab_le_perp : parab hc V R W ≤ parab hc V R (perp V W) := fun g hg =>
  mem_parab_iff_maps.2 fun y hy => (mem_extSub_perp hc V).2 fun x hx => by
    rw [← hR_act hc V g⁻¹, act_inv]
    exact (mem_extSub_perp hc V).1 hy _ ((inv_mem hg x).1 hx)

theorem mem_trivOn_iff_maps (h : A ≤ B) :
    g ∈ trivOn hc V R A B ↔ ∀ y ∈ extSub (F := F) V R B, act hc V g y - y ∈ extSub (F := F) V R A :=
  ⟨fun h => h.2, fun h' => ⟨mem_parab_iff_maps.2 fun y hy => by
    simpa using add_mem (h' y (extSub_mono V R h hy)) hy, h'⟩⟩

theorem mem_trivOn (h : A ≤ B) : g ∈ trivOn hc V R A B ↔
    ∀ x ∈ B, act hc V g (coordR V R x) - coordR V R x ∈ extSub (F := F) V R A :=
  (mem_trivOn_iff_maps h).trans ⟨fun h _ hx => h _ (coordR_mem V R hx), fun h _ hy =>
    ((Submodule.span_le (p := (extSub (F := F) V R A).comap
      ((HA.mat R hc.sig V.gram g).1.mulVecLin - LinearMap.id))).2 (by rintro _ ⟨x, hx, rfl⟩; exact h x hx) hy :)⟩



theorem trivOn_le_trivOn_perp (h : A ≤ B) : trivOn hc V R A B ≤ trivOn hc V R (perp V B) (perp V A) := fun g hg =>
  (mem_trivOn_iff_maps (perp_anti h)).2 fun y hy => (mem_extSub_perp hc V).2 fun x hx => by
    rw [hR_act_sub]
    exact (mem_extSub_perp hc V).1 hy _ ((inv_mem hg).2 x hx)

theorem conj_mem_trivOn {p : HA R hc.sig V.gram} (hA : p ∈ parab hc V R A) (hB : p ∈ parab hc V R B)
    (hg : g ∈ trivOn hc V R A B) : p * g * p⁻¹ ∈ trivOn hc V R A B :=
  ⟨mul_mem (mul_mem hA hg.1) (inv_mem hA), fun y hy => by
    have := (hA _).1 (hg.2 _ ((inv_mem hB y).1 hy))
    rwa [act_sub, ← act_mul, ← act_mul, ← act_mul, mul_inv_cancel, act_one] at this⟩

@[simp] theorem trivOn_bot_top : trivOn hc V R ⊥ ⊤ = ⊥ :=
  eq_bot_iff.2 fun g hg => HA_ext _ _ fun r s => by
    have := hg.2 (Pi.single s 1) (by simp)
    rw [extSub_bot, Submodule.mem_bot, sub_eq_zero] at this
    have e := congrFun (this.trans (act_one hc V _).symm) r
    simpa only [act, Matrix.mulVec_single_one, Matrix.col_apply] using e






end Step

section Closed

variable {hc : CMData F E} {V : HSpace E} {R : Type} [CommRing R] [Algebra F R] [TopologicalSpace R]
  [IsTopologicalRing R] [T2Space R]

theorem isClosed_act_sub_mem (W : Submodule E V.V) (y z : Fin V.rank → R ⊗[F] E) :
    IsClosed {g : HA R hc.sig V.gram | act hc V g y - z ∈ extSub (F := F) V R W} := by
  obtain ⟨T, h1, h2⟩ := exists_cut V W
  have : IsModuleTopology R (R ⊗[F] E) := ⟨rfl⟩
  have : IsTopologicalRing (R ⊗[F] E) := IsModuleTopology.isTopologicalRing R _
  have : T2Space (R ⊗[F] E) :=
    .of_injective_continuous (f := (Algebra.TensorProduct.basis R (Module.finBasis F E)).equivFun)
      (LinearEquiv.injective _) (IsModuleTopology.continuous_of_linearMap
        (Algebra.TensorProduct.basis R (Module.finBasis F E)).equivFun.toLinearMap)
  have hm : Continuous fun g : HA R hc.sig V.gram => (HA.mat _ hc.sig V.gram g).1 :=
    Units.continuous_val.comp continuous_subtype_val
  simp only [mem_extSub_iff_of_ker V _ T 1 h1 h2]
  exact isClosed_eq (continuous_const.matrix_mulVec ((hm.matrix_mulVec continuous_const).sub continuous_const))
    continuous_const

theorem isClosed_parab (W : Submodule E V.V) : IsClosed (parab hc V R W : Set (HA R hc.sig V.gram)) := by
  convert isClosed_biInter fun x (_ : x ∈ W) => isClosed_act_sub_mem (hc := hc) W (coordR V R x) 0 using 1
  ext g
  simpa using mem_parab

theorem isClosed_trivOn {A B : Submodule E V.V} (h : A ≤ B) :
    IsClosed (trivOn hc V R A B : Set (HA R hc.sig V.gram)) := by
  convert isClosed_biInter fun x (_ : x ∈ B) => isClosed_act_sub_mem (hc := hc) A (coordR V R x) (coordR V R x) using 1
  ext g
  simpa using mem_trivOn h

end Closed

section Adelic








end Adelic

section Rat











end Rat

structure IsoFlag (V : HSpace E) where

  k : ℕ

  X : Fin (k + 1) → Submodule E V.V
  zero : X 0 = ⊥
  strictMono : StrictMono X
  iso : X (Fin.last k) ≤ perp V (X (Fin.last k))

namespace IsoFlag

variable {V : HSpace E} (𝔉 : IsoFlag V)


abbrev top : Submodule E V.V := 𝔉.X (Fin.last 𝔉.k)


theorem le_succ (i : Fin 𝔉.k) : 𝔉.X i.castSucc ≤ 𝔉.X i.succ := 𝔉.strictMono.monotone i.castSucc_le_succ




variable (V) in

def nil : IsoFlag V := ⟨0, fun _ => ⊥, rfl, Fin.strictMono_iff_lt_succ.2 fun i => i.elim0, bot_le⟩

def single {W : Submodule E V.V} (hW : IsIsotropic V W) : IsoFlag V :=
  ⟨1, ![⊥, W], rfl, Fin.strictMono_iff_lt_succ.2 fun i => by fin_cases i; exact bot_lt_iff_ne_bot.2 hW.1, hW.2⟩



section Points

variable (hc : CMData F E) (R : Type) [CommRing R] [Algebra F R]

def par : Subgroup (HA R hc.sig V.gram) := ⨅ i, parab hc V R (𝔉.X i)

def unip : Subgroup (HA R hc.sig V.gram) :=
  (⨅ i : Fin 𝔉.k, trivOn hc V R (𝔉.X i.castSucc) (𝔉.X i.succ)) ⊓ trivOn hc V R 𝔉.top (perp V 𝔉.top) ⊓
    ⨅ i : Fin 𝔉.k, trivOn hc V R (perp V (𝔉.X i.succ)) (perp V (𝔉.X i.castSucc))



variable {𝔉 hc R} {g : HA R hc.sig V.gram}

theorem mem_par : g ∈ 𝔉.par hc R ↔ ∀ i, g ∈ parab hc V R (𝔉.X i) := Subgroup.mem_iInf

theorem mem_unip : g ∈ 𝔉.unip hc R ↔ (∀ i : Fin 𝔉.k, g ∈ trivOn hc V R (𝔉.X i.castSucc) (𝔉.X i.succ)) ∧
    g ∈ trivOn hc V R 𝔉.top (perp V 𝔉.top) := by
  simp only [unip, Subgroup.mem_inf, Subgroup.mem_iInf]
  exact and_iff_left_of_imp fun h i => trivOn_le_trivOn_perp (𝔉.le_succ i) (h.1 i)


variable (𝔉 hc R)


variable {𝔉 hc R} in

theorem conj_mem_unip {p : HA R hc.sig V.gram} (hp : p ∈ 𝔉.par hc R) (hg : g ∈ 𝔉.unip hc R) :
    p * g * p⁻¹ ∈ 𝔉.unip hc R :=
  mem_unip.2 ⟨fun i => conj_mem_trivOn (mem_par.1 hp _) (mem_par.1 hp _) ((mem_unip.1 hg).1 i),
    conj_mem_trivOn (mem_par.1 hp _) (parab_le_perp (mem_par.1 hp _)) (mem_unip.1 hg).2⟩

instance normal_unip : ((𝔉.unip hc R).subgroupOf (𝔉.par hc R)).Normal :=
  ⟨fun _ hn p => conj_mem_unip p.2 hn⟩

@[simp] theorem par_nil : (nil V).par hc R = ⊤ := by simp [par, nil]

@[simp] theorem unip_nil : (nil V).unip hc R = ⊥ :=
  eq_bot_iff.2 fun g hg => by simpa [nil, top] using (mem_unip.1 hg).2

variable {W : Submodule E V.V} (hW : IsIsotropic V W)


theorem unip_single : (single hW).unip hc R = unipRad hc V R W :=
  Subgroup.ext fun g => mem_unip.trans (and_congr (Fin.forall_fin_one.trans ((mem_trivOn_iff_maps bot_le).trans
    (forall₂_congr fun y _ => by rw [extSub_bot, Submodule.mem_bot, sub_eq_zero]))) (mem_trivOn_iff_maps hW.2))




variable {𝔉 hc R} {R' : Type} [CommRing R'] [Algebra F R']







variable (𝔉 hc R) [TopologicalSpace R] [IsTopologicalRing R] [T2Space R]

theorem isClosed_par : IsClosed (𝔉.par hc R : Set (HA R hc.sig V.gram)) := by
  rw [par, Subgroup.coe_iInf]; exact isClosed_iInter fun _ => isClosed_parab _

theorem isClosed_unip : IsClosed (𝔉.unip hc R : Set (HA R hc.sig V.gram)) := by
  convert (isClosed_iInter fun i => isClosed_trivOn (hc := hc) (R := R) (𝔉.le_succ i)).inter (isClosed_trivOn 𝔉.iso) using 1
  ext g
  simpa using mem_unip

end Points

section Places

open GlobalTheory.AdelicU

variable (hc : CMData F E)

instance : LocallyCompactSpace (𝔉.par hc (AF F)) :=
  haveI := GlobalTheory.AdelicUnitaryTop.t2Space_adeleRing_numberField F
  (𝔉.isClosed_par hc _).locallyCompactSpace

instance : LocallyCompactSpace (𝔉.unip hc (AF F)) :=
  haveI := GlobalTheory.AdelicUnitaryTop.t2Space_adeleRing_numberField F
  (𝔉.isClosed_unip hc _).locallyCompactSpace

instance (v : HeightOneSpectrum (𝓞 F)) : LocallyCompactSpace (𝔉.par hc (Fv F v)) :=
  (𝔉.isClosed_par hc _).locallyCompactSpace

instance (v : HeightOneSpectrum (𝓞 F)) : LocallyCompactSpace (𝔉.unip hc (Fv F v)) :=
  (𝔉.isClosed_unip hc _).locallyCompactSpace







end Places

end IsoFlag

section Witt













end Witt

end GlobalTheory.Cusp

end
