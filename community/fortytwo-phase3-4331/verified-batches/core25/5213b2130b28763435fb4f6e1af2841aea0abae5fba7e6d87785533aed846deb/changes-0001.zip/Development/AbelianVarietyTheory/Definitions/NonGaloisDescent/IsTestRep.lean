import Mathlib
import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.FourierMatch

open Matrix MeasureTheory Filter Topology

noncomputable section

namespace GlobalTheory.JR

def fourB {V : Type} [MeasurableSpace V] (μ : Measure V) (B : V → V → ℂ) (f : V → ℂ) (y : V) : ℂ :=
  ∫ x, f x * B x y ∂μ

def SelfDual {V : Type} [AddCommGroup V] [TopologicalSpace V] [MeasurableSpace V] (μ : Measure V)
    (B : V → V → ℂ) : Prop :=
  μ.IsAddHaarMeasure ∧ ∀ f : V → ℂ, IsTest f → ∀ y, fourB μ B (fourB μ B f) y = f (-y)





structure Et (F E : Type) [NontriviallyNormedField F] [NontriviallyNormedField E] [NormedAlgebra F E]
    [StarRing E] where
  K : Type
  L : Type
  [crK : CommRing K]
  [algK : Algebra F K]
  [finK : Module.Finite F K]
  [redK : IsReduced K]
  [topK : TopologicalSpace K]
  [mtK : IsModuleTopology F K]
  [trK : IsTopologicalRing K]
  [lcK : LocallyCompactSpace K]
  [mK : MeasurableSpace K]
  [bK : BorelSpace K]
  [crL : CommRing L]
  [stL : StarRing L]
  [algFL : Algebra F L]
  [algKL : Algebra K L]
  [algEL : Algebra E L]
  [twK : IsScalarTower F K L]
  [twE : IsScalarTower F E L]
  [topL : TopologicalSpace L]
  [mtL : IsModuleTopology F L]
  [mL : MeasurableSpace L]
  [bL : BorelSpace L]
  push : Algebra.IsPushout F E K L
  star_K : ∀ x : K, star (algebraMap K L x) = algebraMap K L x
  star_E : ∀ y : E, star (algebraMap E L y) = algebraMap E L (star y)

attribute [instance] Et.crK Et.algK Et.finK Et.redK Et.topK Et.mtK Et.trK Et.lcK Et.mK Et.bK Et.crL Et.stL Et.algFL
  Et.algKL Et.algEL Et.twK Et.twE Et.topL Et.mtL Et.mL Et.bL

namespace Et
variable {F E : Type} [NontriviallyNormedField F] [NontriviallyNormedField E] [NormedAlgebra F E] [StarRing E]
  (A : Et F E)

def absK (t : A.K) : ℝ := by
  classical exact if h : IsUnit t then (distribHaarChar A.K h.unit : ℝ) else 0


def psiK (ψ : AddChar F ℂ) (t : A.K) : ℂ := ψ (Algebra.trace F A.K t)

def NL (y : A.L) : A.K := Algebra.norm A.K y

def kerK (ψ : AddChar F ℂ) (y y' : A.K) : ℂ := A.psiK ψ (y * y')

def kerL (ψ : AddChar F ℂ) (x : A.K) (y' y : A.L) : ℂ := A.psiK ψ (x * Algebra.trace A.K A.L (star y' * y))



def orbL (ν : Measure (unitary A.L)) (φ : A.L → ℂ) (y₀ : A.L) : ℂ := ∫ t : unitary A.L, φ (t.1 * y₀) ∂ν

def IsNat (μK : Measure A.K) (μL : Measure A.L) (ν : Measure (unitary A.L)) : Prop :=
  ν.IsHaarMeasure ∧ ∀ (s : A.K → A.L), (∀ y : A.L, IsUnit y → A.NL (s (A.NL y)) = A.NL y) →
    ∀ h : A.L → ℂ, IsTest h → tsupport h ⊆ {y | IsUnit y} →
      ∫ y, h y * ((A.absK (A.NL y) : ℂ))⁻¹ ∂μL =
        ∫ a in {a : A.K | ∃ y : A.L, IsUnit y ∧ A.NL y = a}, A.orbL ν h (s a) * ((A.absK a : ℂ))⁻¹ ∂μK

structure Meas (ψ : AddChar F ℂ) where
  μK : Measure A.K
  μL : A.Kˣ → Measure A.L
  ν : Measure (unitary A.L)
  sdK : SelfDual μK (A.kerK ψ)
  sdL : ∀ x : A.Kˣ, SelfDual (μL x) (A.kerL ψ x)
  nat : A.IsNat μK (μL 1) ν











end Et





end GlobalTheory.JR
