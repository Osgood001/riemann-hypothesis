import Mathlib
import Formalism.SharpRestriction.CuspSpanNormBounds.FractionFieldToGenericStalkAlgebraMapEq

noncomputable section

open ValuativeRel MeasureTheory ComplexConjugate Formalism.MainNotions.S.Loc Matrix

namespace GlobalTheory.SgDen

variable {F : Type} [Field F] [ValuativeRel F] [TopologicalSpace F]
variable {E : Type} [CommRing E] [Algebra F E] [TopologicalSpace E]









open scoped Classical in

def eta (E : Type) [CommRing E] : ℝ := if IsField E then -1 else 1


def densF (q : ℕ) (η : ℝ) (n a c : ℕ) : ℝ :=
  ∏ i ∈ Finset.Icc (n + 1 - a - c) n, (1 - (η * (q : ℝ)⁻¹) ^ i)













variable [MeasurableSpace E]










def IntR (M : Model F E) {m : ℕ} (Z : Matrix (Fin m) (Fin m) E) : Prop := ∀ a b, Z a b ∈ M.R

abbrev Mod (M : Model F E) {r : ℕ} (Z : Matrix (Fin (r + 1)) (Fin (r + 1)) E) : Type :=
  (Fin (r + 1) → M.R) ⧸
    Submodule.span M.R {v : Fin (r + 1) → M.R | ∃ j : Fin r, ∀ a, (v a : E) = Z a j.castSucc}

def IsoTh (M : Model F E) {r : ℕ} (Z Z' : Matrix (Fin (r + 1)) (Fin (r + 1)) E) : Type :=
  {φ : Mod M Z ≃ₗ[M.R] Mod M Z' //
    φ (Submodule.Quotient.mk (Pi.single (Fin.last r) 1)) =
      Submodule.Quotient.mk (Pi.single (Fin.last r) 1) ∧
    ∀ v v' : Fin (r + 1) → M.R, (∀ a, (v a : E) = Z a (Fin.last r)) →
      (∀ a, (v' a : E) = Z' a (Fin.last r)) →
        φ (Submodule.Quotient.mk v) = Submodule.Quotient.mk v'}

open scoped Classical in

def nTh (M : Model F E) {r : ℕ} (Z Z' : Matrix (Fin (r + 1)) (Fin (r + 1)) E) : ℕ :=
  if IntR M Z ∧ IntR M Z' then Nat.card (IsoTh M Z Z') else 0




end GlobalTheory.SgDen
