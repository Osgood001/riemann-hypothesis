import Mathlib
import CompanionTheory.SpectralGeometry.CountingDefinitions.AdelicEulerProducts.IsEulerProd
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.AdelesLocallyCompactSecondCountable
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.AdelicUnitaryGroupLocallyCompactStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.ArithmeticUnitaryGroupDiscrete
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.BlockOneDetHermitianGram
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.BlockOneRightInjective
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.HermitianMatricesLocallyCompactBorel
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.QuotientMeasureTowerStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.SiegelMeanValueNonnegative
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.TensorLocallyCompactRing
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.WittExtensionGlobalStatement
import Formalism.UnipotentAdelicQuotients.SWXSDefs
open HeckeCharacterZeroLocus.SiegelWeilU GlobalTheory.CompanionTheory.SW NumberField IsDedekindDomain MeasureTheory Topology
open scoped TensorProduct ENNReal NNReal Matrix

noncomputable section

namespace GlobalTheory.CompanionTheory.SW.ThetaStage

section Alg

theorem hform_eq_dot {A : Type} [CommRing A] (s : A →+* A) {M : ℕ} (J : Matrix (Fin M) (Fin M) A)
    (x y : Fin M → A) : hform s J x y = (fun i => s (x i)) ⬝ᵥ (J *ᵥ y) := by
  simp [hform, dotProduct, Matrix.mulVec, Finset.mul_sum, mul_assoc]

theorem hform_act {A : Type} [CommRing A] (s : A →+* A) {M : ℕ} (J g : Matrix (Fin M) (Fin M) A)
    (hg : cT s g * J * g = J) (x y : Fin M → A) : hform s J (g *ᵥ x) (g *ᵥ y) = hform s J x y := by
  have h1 : (fun i => s ((g *ᵥ x) i)) = (fun i => s (x i)) ᵥ* cT s g := by
    funext i
    simp [Matrix.vecMul, dotProduct, Matrix.mulVec, cT, map_sum, mul_comm]
  rw [hform_eq_dot, hform_eq_dot, h1, ← Matrix.dotProduct_mulVec, Matrix.mulVec_mulVec,
    Matrix.mulVec_mulVec, hg]

variable {F E : Type} [Field F] [Field E] [Algebra F E]

theorem gramE_act (σ : E →ₐ[F] E) {M n : ℕ} (J : Matrix (Fin M) (Fin M) E)
    (g : UJ (σ : E →+* E) J) (X : Fin n → Fin M → E) :
    gramE σ J (fun a => ((g : GL (Fin M) E) : Matrix (Fin M) (Fin M) E) *ᵥ X a) = gramE σ J X := by
  ext a b
  exact hform_act (σ : E →+* E) J _ g.2 (X a) (X b)

variable (R : Type) [CommRing R] [Algebra F R]

theorem bc_mem_HR (σ : E →ₐ[F] E) {M : ℕ} (J : Matrix (Fin M) (Fin M) E)
    (g : UJ (σ : E →+* E) J) : bc (inclR R) (g : GL (Fin M) E) ∈ HR R σ J := by
  have hg : cT (σ : E →+* E) ((g : GL (Fin M) E) : Matrix (Fin M) (Fin M) E) * J *
      ((g : GL (Fin M) E) : Matrix (Fin M) (Fin M) E) = J := g.2
  have h2 : cT (sigR R σ) (((g : GL (Fin M) E) : Matrix (Fin M) (Fin M) E).map (inclR R)) =
      (cT (σ : E →+* E) ((g : GL (Fin M) E) : Matrix (Fin M) (Fin M) E)).map (inclR R) := by
    ext i j
    simp [cT, sigR, inclR]
  change cT (sigR R σ) (((g : GL (Fin M) E) : Matrix (Fin M) (Fin M) E).map (inclR R)) * JR R J *
    (((g : GL (Fin M) E) : Matrix (Fin M) (Fin M) E).map (inclR R)) = JR R J
  rw [h2, JR, ← Matrix.map_mul, ← Matrix.map_mul, hg]

def ratH (σ : E →ₐ[F] E) {M : ℕ} (J : Matrix (Fin M) (Fin M) E) (g : UJ (σ : E →+* E) J) :
    HA R σ J :=
  (⟨bc (inclR R) (g : GL (Fin M) E), bc_mem_HR R σ J g⟩ : HR R σ J)


theorem ratH_inv (σ : E →ₐ[F] E) {M : ℕ} (J : Matrix (Fin M) (Fin M) E) (g : UJ (σ : E →+* E) J) :
    (ratH R σ J g)⁻¹ = ratH R σ J g⁻¹ := by
  apply Subtype.ext
  change (bc (inclR R) (g : GL (Fin M) E))⁻¹ = bc (inclR R) ((g : GL (Fin M) E)⁻¹)
  rw [map_inv]

theorem actW_ratH (σ : E →ₐ[F] E) {M n : ℕ} (J : Matrix (Fin M) (Fin M) E) (g : UJ (σ : E →+* E) J)
    (X : Fin n → Fin M → E) :
    actW R σ J (ratH R σ J g) (ratTup R X) =
      ratTup R (fun a => ((g : GL (Fin M) E) : Matrix (Fin M) (Fin M) E) *ᵥ X a) := by
  funext a i
  change (∑ j, inclR R (((g : GL (Fin M) E) : Matrix (Fin M) (Fin M) E) i j) * inclR R (X a j)) =
    inclR R (∑ j, ((g : GL (Fin M) E) : Matrix (Fin M) (Fin M) E) i j * X a j)
  rw [map_sum]
  simp only [map_mul]

theorem ratTup_consTup {M n : ℕ} (X : Fin n → Fin M → E) :
    ratTup (F := F) R (consTup X) = consTup (ratTup (F := F) R X) := by
  funext a i
  refine Fin.cases ?_ (fun a => ?_) a <;> refine Fin.cases ?_ (fun i => ?_) i <;>
    simp [ratTup, consTup]

theorem ratTup_first {M : ℕ} :
    ratTup (F := F) R (fun _ : Fin 1 => (Fin.cons 1 (fun _ => 0) : Fin (M + 1) → E)) =
      fun _ : Fin 1 => (Fin.cons 1 (fun _ => 0) : Fin (M + 1) → R ⊗[F] E) := by
  funext a i
  refine Fin.cases ?_ (fun i => ?_) i <;> simp [ratTup]

end Alg

section Tuples

variable {F E : Type} [Field F] [Field E] [Algebra F E]

def gact (σ : E →ₐ[F] E) {M n : ℕ} {J : Matrix (Fin M) (Fin M) E} (g : UJ (σ : E →+* E) J)
    (X : Fin n → Fin M → E) : Fin n → Fin M → E :=
  fun a => ((g : GL (Fin M) E) : Matrix (Fin M) (Fin M) E) *ᵥ X a

theorem gact_inv_gact (σ : E →ₐ[F] E) {M n : ℕ} {J : Matrix (Fin M) (Fin M) E}
    (g : UJ (σ : E →+* E) J) (X : Fin n → Fin M → E) : gact σ g⁻¹ (gact σ g X) = X := by
  funext a
  change (((g⁻¹ : UJ (σ : E →+* E) J) : GL (Fin M) E) : Matrix (Fin M) (Fin M) E) *ᵥ
    (((g : GL (Fin M) E) : Matrix (Fin M) (Fin M) E) *ᵥ X a) = X a
  rw [Matrix.mulVec_mulVec, ← Units.val_mul]
  simp

theorem gact_gact_inv (σ : E →ₐ[F] E) {M n : ℕ} {J : Matrix (Fin M) (Fin M) E}
    (g : UJ (σ : E →+* E) J) (X : Fin n → Fin M → E) : gact σ g (gact σ g⁻¹ X) = X := by
  have := gact_inv_gact σ g⁻¹ X
  rwa [inv_inv] at this

theorem gramE_gact (σ : E →ₐ[F] E) {M n : ℕ} {J : Matrix (Fin M) (Fin M) E}
    (g : UJ (σ : E →+* E) J) (X : Fin n → Fin M → E) : gramE σ J (gact σ g X) = gramE σ J X :=
  gramE_act σ J g X

theorem tsum_gact (σ : E →ₐ[F] E) {M n : ℕ} {J : Matrix (Fin M) (Fin M) E}
    (g : UJ (σ : E →+* E) J) (T : Matrix (Fin n) (Fin n) E) (f : (Fin n → Fin M → E) → ℝ≥0∞) :
    ∑' X : {X : Fin n → Fin M → E | gramE σ J X = T}, f (gact σ g X.1) =
      ∑' X : {X : Fin n → Fin M → E | gramE σ J X = T}, f X.1 := by
  let e : {X : Fin n → Fin M → E | gramE σ J X = T} ≃ {X : Fin n → Fin M → E | gramE σ J X = T} :=
    { toFun := fun X => ⟨gact σ g X.1, by
        change gramE σ J _ = T
        rw [gramE_gact]; exact X.2⟩
      invFun := fun X => ⟨gact σ g⁻¹ X.1, by
        change gramE σ J _ = T
        rw [gramE_gact]; exact X.2⟩
      left_inv := fun X => Subtype.ext (gact_inv_gact σ g X.1)
      right_inv := fun X => Subtype.ext (gact_gact_inv σ g X.1) }
  exact e.tsum_eq (fun X => f X.1)

theorem consTup_injective {K : Type} [Zero K] [One K] {M n : ℕ} :
    Function.Injective (consTup : (Fin n → Fin M → K) → Fin (n + 1) → Fin (M + 1) → K) := by
  intro X Y h
  funext a i
  exact congrFun (congrFun h a.succ) i.succ

theorem continuous_consTup {K : Type} [Zero K] [One K] [TopologicalSpace K] {M n : ℕ} :
    Continuous (consTup : (Fin n → Fin M → K) → Fin (n + 1) → Fin (M + 1) → K) := by
  refine continuous_pi fun a => continuous_pi fun i => ?_
  refine Fin.cases ?_ (fun a => ?_) a <;> refine Fin.cases ?_ (fun i => ?_) i
  · exact continuous_const
  · exact continuous_const
  · exact continuous_const
  · exact (continuous_apply i).comp (continuous_apply a)

theorem gram_first (σ : E →ₐ[F] E) {M : ℕ} (J : Matrix (Fin M) (Fin M) E) (t : E) :
    gramE σ (blockOne t J) (fun _ : Fin 1 => (Fin.cons 1 (fun _ => 0) : Fin (M + 1) → E)) =
      fun _ _ => t := by
  have hz : (fun _ : Fin M => (0 : E)) = 0 := rfl
  funext a b
  change hE σ (blockOne t J) (Fin.cons 1 (fun _ => 0)) (Fin.cons 1 (fun _ => 0)) = t
  rw [BlockAlg.hE_blockOne_cons, hz, BlockAlg.hE_zero_left]
  simp

theorem tsum_block (σ : E →ₐ[F] E) {M n : ℕ} (J : Matrix (Fin M) (Fin M) E) {t : E} (ht : t ≠ 0)
    (T : Matrix (Fin n) (Fin n) E)
    (rr : {y : Fin 1 → Fin (M + 1) → E | gramE σ (blockOne t J) y = fun _ _ => t} →
      UJ (σ : E →+* E) (blockOne t J))
    (hrr : ∀ q, gact σ (rr q) q.1 = fun _ => Fin.cons 1 (fun _ => 0))
    (f : (Fin (n + 1) → Fin (M + 1) → E) → ℝ≥0∞) :
    ∑' Y : {Y : Fin (n + 1) → Fin (M + 1) → E | gramE σ (blockOne t J) Y = blockOne t T}, f Y.1 =
      ∑' q : {y : Fin 1 → Fin (M + 1) → E | gramE σ (blockOne t J) y = fun _ _ => t},
        ∑' X : {X : Fin n → Fin M → E | gramE σ J X = T}, f (gact σ (rr q)⁻¹ (consTup X.1)) := by
  have hrow : ∀ (q : {y : Fin 1 → Fin (M + 1) → E | gramE σ (blockOne t J) y = fun _ _ => t})
      (X : Fin n → Fin M → E), gact σ (rr q)⁻¹ (consTup X) 0 = q.1 0 := by
    intro q X
    have h := congrArg (gact σ (rr q)⁻¹) (hrr q)
    rw [gact_inv_gact] at h
    exact (congrFun h 0).symm
  let m : {y : Fin 1 → Fin (M + 1) → E | gramE σ (blockOne t J) y = fun _ _ => t} ×
      {X : Fin n → Fin M → E | gramE σ J X = T} →
      {Y : Fin (n + 1) → Fin (M + 1) → E | gramE σ (blockOne t J) Y = blockOne t T} :=
    fun p => ⟨gact σ (rr p.1)⁻¹ (consTup p.2.1), by
      change gramE σ (blockOne t J) _ = _
      rw [gramE_gact, BlockAlg.gramE_consTup]
      exact congrArg (blockOne t) p.2.2⟩
  have hinj : Function.Injective m := by
    rintro ⟨q, X⟩ ⟨q', X'⟩ h
    have h1 : gact σ (rr q)⁻¹ (consTup X.1) = gact σ (rr q')⁻¹ (consTup X'.1) :=
      congrArg Subtype.val h
    have hq : q = q' := by
      apply Subtype.ext
      funext a
      have ha : a = 0 := Subsingleton.elim _ _
      subst ha
      rw [← hrow q X.1, ← hrow q' X'.1, h1]
    subst hq
    have h2 := congrArg (gact σ (rr q)) h1
    rw [gact_gact_inv, gact_gact_inv] at h2
    exact Prod.ext rfl (Subtype.ext (consTup_injective h2))
  have hsurj : Function.Surjective m := by
    rintro ⟨Y, hY⟩
    have hY' : gramE σ (blockOne t J) Y = blockOne t T := hY
    have hy : gramE σ (blockOne t J) (fun _ : Fin 1 => Y 0) = fun _ _ => t := by
      funext a b
      exact congrFun (congrFun hY' 0) 0
    let q : {y : Fin 1 → Fin (M + 1) → E | gramE σ (blockOne t J) y = fun _ _ => t} := ⟨_, hy⟩
    have h0 : gact σ (rr q) Y 0 = Fin.cons 1 (fun _ => 0) := congrFun (hrr q) 0
    have hG : gramE σ (blockOne t J) (gact σ (rr q) Y) = blockOne t T := by
      rw [gramE_gact]; exact hY'
    obtain ⟨X, hX, hYX⟩ := BlockAlg.exists_consTup_of_gramE σ J ht T _ h0 hG
    refine ⟨(q, ⟨X, hX⟩), Subtype.ext ?_⟩
    change gact σ (rr q)⁻¹ (consTup X) = Y
    rw [← hYX, gact_inv_gact]
  let e := Equiv.ofBijective m ⟨hinj, hsurj⟩
  rw [← e.tsum_eq (fun Y => f Y.1), ENNReal.tsum_prod']
  rfl

end Tuples

section Rat

variable {F E : Type} [Field F] [Field E] [Algebra F E] (R : Type) [CommRing R] [Algebra F R]

theorem mem_HFinIn_iff (σ : E →ₐ[F] E) {M : ℕ} (J : Matrix (Fin M) (Fin M) E) (h : HA R σ J) :
    h ∈ HFinIn R σ J ↔ HA.mat R σ J h ∈ HFin R σ J :=
  Subgroup.mem_subgroupOf

theorem ratH_mem (σ : E →ₐ[F] E) {M : ℕ} (J : Matrix (Fin M) (Fin M) E) (g : UJ (σ : E →+* E) J) :
    ratH R σ J g ∈ HFinIn R σ J :=
  (mem_HFinIn_iff R σ J _).2 ⟨g.1, g.2, rfl⟩

theorem exists_ratH (σ : E →ₐ[F] E) {M : ℕ} (J : Matrix (Fin M) (Fin M) E) (h : HA R σ J)
    (hh : h ∈ HFinIn R σ J) : ∃ g, h = ratH R σ J g := by
  obtain ⟨g, hg, e⟩ := (mem_HFinIn_iff R σ J h).1 hh
  exact ⟨⟨g, hg⟩, Subtype.ext e.symm⟩

theorem actW_ratH' (σ : E →ₐ[F] E) {M n : ℕ} (J : Matrix (Fin M) (Fin M) E)
    (g : UJ (σ : E →+* E) J) (X : Fin n → Fin M → E) :
    actW R σ J (ratH R σ J g) (ratTup R X) = ratTup R (gact σ g X) :=
  actW_ratH R σ J g X

end Rat

theorem ratTup_adele_injective {F E : Type} [Field F] [NumberField F] [Field E] [Algebra F E]
    {M n : ℕ} : Function.Injective (ratTup (F := F) (E := E) (M := M) (n := n) (AF F)) := by
  intro X Y h
  have hi : Function.Injective (inclR (F := F) (E := E) (AF F)) :=
    Algebra.TensorProduct.includeRight_injective (AdeleRing.algebraMap_injective _ _)
  funext a i
  exact hi (congrFun (congrFun h a) i)


end GlobalTheory.CompanionTheory.SW.ThetaStage
