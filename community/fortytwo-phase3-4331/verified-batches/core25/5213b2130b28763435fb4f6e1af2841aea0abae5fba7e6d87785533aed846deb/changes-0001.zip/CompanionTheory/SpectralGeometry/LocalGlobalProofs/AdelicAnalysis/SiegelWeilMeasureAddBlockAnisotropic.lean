import Mathlib
import CompanionTheory.SpectralGeometry.CountingDefinitions.AdelicEulerProducts.IsEulerProd
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.BlockOneDetHermitianGram
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.CompletionIsLocalRing
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.CoordinateHaarMeasure
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.EulerProductLocalDensitiesConverges
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.EulerProductMeasureZeroStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.ExistsGramFiberMeasuresStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.GramFiberMeasuresContinuityStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.InfiniteAdelesLocalRingTotallyReal
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.SiegelWeilMeasureRankOne
import Formalism.UnipotentAdelicQuotients.SWXSDefs
open HeckeCharacterZeroLocus.SiegelWeilU GlobalTheory.CompanionTheory.SW NumberField IsDedekindDomain MeasureTheory Topology
open scoped TensorProduct ENNReal NNReal Matrix

namespace GlobalTheory.CompanionTheory.SW.SwEmpty

variable {F E : Type} [Field F] [NumberField F] [Field E] [NumberField E] [Algebra F E]

theorem thetaMeas_of_empty (σ : E →ₐ[F] E) {M n : ℕ} (J : Matrix (Fin M) (Fin M) E)
    (μ : Measure (HA (AF F) σ J)) (𝓕 : Set (HA (AF F) σ J)) (S : Set (Fin n → Fin M → E))
    (hS : S = ∅) : thetaMeas σ J μ 𝓕 S = 0 := by
  subst hS
  have : IsEmpty ((∅ : Set (Fin n → Fin M → E))) := by simp
  unfold thetaMeas
  rw [Measure.sum_of_isEmpty, smul_zero]

theorem fibre_zero_of_one (σ : E →ₐ[F] E) (hCM : IsCMExt F E σ) {M : ℕ}
    (J : Matrix (Fin M) (Fin M) E) (hJ : IsHermND σ J) (R : Type) [CommRing R] [Algebra F R]
    [TopologicalSpace R] [MeasurableSpace R] [BorelSpace R] (hLoc : IsLocR R)
    {d : ℕ} (b : Module.Basis (Fin d) F E) (lam : Measure R) (hlam : lam.IsAddHaarMeasure)
    (t : F) (ht : t ≠ 0) {n : ℕ} (T : Matrix (Fin n) (Fin n) E)
    (hT' : ∀ a b, σ (blockOne (algebraMap F E t) T b a) = blockOne (algebraMap F E t) T a b)
    (T1 : Matrix (Fin 1) (Fin 1) E) (hT1e : T1 = fun _ _ => algebraMap F E t)
    (hT1 : ∀ a b, σ (T1 b a) = T1 a b)
    (m1 : HermR R σ 1 → Measure (Fin 1 → Fin M → R ⊗[F] E))
    (m : HermR R σ (n + 1) → Measure (Fin (n + 1) → Fin M → R ⊗[F] E))
    (hm1 : IsGramFib R σ J 1 (coordW R b lam 1 M) (coordHerm R σ b lam 1) m1)
    (hm : IsGramFib R σ J (n + 1) (coordW R b lam (n + 1) M) (coordHerm R σ b lam (n + 1)) m)
    (h0 : m1 (hermOf R σ T1 hT1) = 0) :
    m (hermOf R σ (blockOne (algebraMap F E t) T) hT') = 0 := by
  have hLoc' := hLoc
  obtain ⟨hTR, hLC, hSC, hT2, -⟩ := hLoc'
  have hH := GlobalTheory.CompanionTheory.SW.coord_measures_haar F E σ hCM R d b lam hlam
  have hempty : (gramR R σ J ⁻¹' {(hermOf R σ (blockOne (algebraMap F E t) T) hT').1} ∩
      {X | IsUnit (gramR R σ J X).det}) = ∅ := by
    ext Y
    simp only [Set.mem_inter_iff, Set.mem_preimage, Set.mem_singleton_iff, Set.mem_setOf_eq,
      Set.mem_empty_iff_false, iff_false, not_and]
    intro hY _
    have h00 : hR R σ J (Y 0) (Y 0) = inclR R (algebraMap F E t) := by
      have := congrFun (congrFun hY 0) 0
      simpa [gramR, hermOf, blockOne] using this
    let x : Fin 1 → Fin M → R ⊗[F] E := fun _ => Y 0
    have hx : gramR R σ J x = (hermOf R σ T1 hT1).1 := by
      funext a c
      subst hT1e
      exact h00
    have hu : IsUnit (gramR R σ J x).det := by
      rw [hx]
      subst hT1e
      simp only [hermOf, Matrix.det_fin_one, Matrix.map_apply]
      exact (IsUnit.mk0 _ ((map_ne_zero _).2 ht)).map (inclR R)
    have := (GlobalTheory.T.gram_fiber_measure_locallyFinite_and_ne_zero_of_isOpen F E σ hCM M J hJ R hLoc 1 _ _ m1 (hH.2.1 1 M) (hH.2.2 1) hm1
      (hermOf R σ T1 hT1)).2 Set.univ isOpen_univ ⟨x, trivial, hx, hu⟩
    exact this (by rw [h0]; rfl)
  have h1 := hm.1 (hermOf R σ (blockOne (algebraMap F E t) T) hT')
  rw [hempty, Set.compl_empty] at h1
  exact Measure.measure_univ_eq_zero.1 h1

end GlobalTheory.CompanionTheory.SW.SwEmpty

namespace GlobalTheory.CompanionTheory.SW


end GlobalTheory.CompanionTheory.SW
