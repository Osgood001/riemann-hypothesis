import Mathlib
import CompanionTheory.SpectralGeometry.CountingDefinitions.AdelicEulerProducts.IsEulerProd
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.CompletionIsLocalRing
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.CoordinateHaarMeasureStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.EulerProductLocallyFiniteStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.ExistsGramFiberMeasuresStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.ExistsIsCharAF
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.ExistsStandardLocalMeasuresStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.ExistsUnitScalingSelfdualAdelicMeasures
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.ExistsUnitScalingSelfdualHermMeasures
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.GramFiberMeasuresContinuityStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.GramFiberMeasuresScalingStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.GramFiberMeasuresTransitivityStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.InfiniteAdelesLocalRingTotallyReal
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.SiegelMeanValueIntegrable
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.SiegelWeilMeasureOfRankSmallOrZero
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.UnitProductClosurePropertiesStatement
import Formalism.UnipotentAdelicQuotients.SWXSDefs
import Formalism.UnipotentAdelicQuotients.SiegelWeilUnitaryConvergent

open HeckeCharacterZeroLocus.SiegelWeilU GlobalTheory.CompanionTheory.SW NumberField IsDedekindDomain MeasureTheory Topology
open scoped TensorProduct ENNReal NNReal Matrix

namespace GlobalTheory.CompanionTheory.SW.TopDens

theorem rescale_tprod {ι : Type} (a : ℝ≥0) (r : ι → ℝ≥0) (h1 : ∀ᶠ v in Filter.cofinite, r v = 1)
    (h2 : a * ∏ᶠ v, r v = 1) (y : ℂ) (x : ι → ℂ) (hx : Multipliable x) :
    Multipliable (fun v => r v • x v) ∧ (a • y) * ∏' v, r v • x v = y * ∏' v, x v := by
  have hfin : (Function.mulSupport r).Finite := by
    simpa [Filter.eventually_cofinite, Function.mulSupport] using h1
  let φ : ℝ≥0 →* ℂ := (Complex.ofRealHom.comp NNReal.toRealHom).toMonoidHom
  have hφ : ∀ t : ℝ≥0, φ t = ((t : ℝ) : ℂ) := fun _ => rfl
  have hs : ∀ (t : ℝ≥0) (z : ℂ), t • z = φ t * z := by
    intro t z
    rw [hφ, NNReal.smul_def, Complex.real_smul]
  have hfin' : (Function.mulSupport fun v => φ (r v)).Finite := by
    refine hfin.subset ?_
    intro v hv hv'
    exact hv (by simp [hv'])
  have hm : Multipliable fun v => φ (r v) := multipliable_of_hasFiniteMulSupport hfin'
  simp only [hs]
  refine ⟨hm.mul hx, ?_⟩
  rw [hm.tprod_mul hx, tprod_eq_finprod hfin', ← φ.map_finprod hfin]
  calc φ a * y * (φ (∏ᶠ v, r v) * ∏' v, x v) = φ (a * ∏ᶠ v, r v) * (y * ∏' v, x v) := by
        rw [map_mul]; ring
    _ = _ := by rw [h2, map_one, one_mul]


end GlobalTheory.CompanionTheory.SW.TopDens
