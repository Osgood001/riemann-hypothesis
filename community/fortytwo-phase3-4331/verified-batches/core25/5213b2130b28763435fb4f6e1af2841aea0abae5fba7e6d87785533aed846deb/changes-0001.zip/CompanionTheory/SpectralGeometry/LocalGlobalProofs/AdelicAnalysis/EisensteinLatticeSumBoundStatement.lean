import Mathlib
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.EisensteinLatticeSumBound

abbrev _root_.GlobalTheory.T.eisenstein_lattice_sum_bound := @_root_.GlobalTheory.CompanionTheory.SW.LatSum.lattice_sum
