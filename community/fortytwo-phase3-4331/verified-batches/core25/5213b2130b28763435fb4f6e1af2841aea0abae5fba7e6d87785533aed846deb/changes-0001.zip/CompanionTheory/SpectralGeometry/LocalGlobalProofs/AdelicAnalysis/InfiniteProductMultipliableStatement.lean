import Mathlib
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.InfiniteProductMultipliable

abbrev _root_.GlobalTheory.T.infinite_product_multipliable := @_root_.GlobalTheory.CompanionTheory.SW.AbsTprod.abs_tprod
