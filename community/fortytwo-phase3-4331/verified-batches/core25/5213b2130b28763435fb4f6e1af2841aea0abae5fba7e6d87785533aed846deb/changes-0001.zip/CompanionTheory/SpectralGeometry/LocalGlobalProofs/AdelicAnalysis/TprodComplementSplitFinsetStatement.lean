import Mathlib
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.TprodComplementSplitFinset
import Mathlib

abbrev _root_.GlobalTheory.T.tprod_complement_split_finset := @_root_.GlobalTheory.CompanionTheory.SW.TailCut.tprod_tail_cut
