import Mathlib
import CompanionTheory.SpectralGeometry.CountingDefinitions.AdelicEulerProducts.IsEulerProd
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.AdelesLocallyCompactSecondCountable
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.AdelicUnitaryGroupLocallyCompactStatement
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.ArithmeticUnitaryGroupDiscrete
import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.FiniteCovolumeUnimodular
import Formalism.UnipotentAdelicQuotients.SWXSDefs

open HeckeCharacterZeroLocus.SiegelWeilU GlobalTheory.CompanionTheory.SW NumberField IsDedekindDomain MeasureTheory Topology
open scoped TensorProduct ENNReal NNReal Matrix

noncomputable section

namespace GlobalTheory.CompanionTheory.SW.ZeroTuple

theorem lintegral_unique {V : Type} [MeasurableSpace V] [Unique V] (m : Measure V)
    (h : m Set.univ = 1) (φ : V → ℝ≥0∞) : ∫⁻ x, φ x ∂m = φ default := by
  have : φ = fun _ => φ default := funext fun x => by rw [Subsingleton.elim x default]
  rw [this, lintegral_const, h, mul_one]

section Loc

variable {F E : Type} [Field F] [Field E] [Algebra F E]
variable (R : Type) [CommRing R] [Algebra F R]

instance uniqueHerm (σ : E →ₐ[F] E) : Unique (HermR R σ 0) :=
  ⟨⟨0⟩, fun S => Subtype.ext (Matrix.ext fun a => a.elim0)⟩

variable [TopologicalSpace R] [MeasurableSpace R]

theorem coordW_univ {d : ℕ} (b : Module.Basis (Fin d) F E) (lam : Measure R) (M : ℕ) :
    coordW R b lam 0 M Set.univ = 1 := by
  unfold coordW
  rw [Measure.pi_of_empty]
  simp

theorem coordHerm_univ (σ : E →ₐ[F] E) {d : ℕ} (b : Module.Basis (Fin d) F E) (lam : Measure R) :
    coordHerm R σ b lam 0 Set.univ = 1 := by
  unfold coordHerm
  haveI : IsEmpty {p : Fin 0 × Fin 0 // p.1 < p.2} := ⟨fun p => p.1.1.elim0⟩
  rw [Measure.comap_apply _ (fun x y _ => Subsingleton.elim x y)
    (fun s _ => Subsingleton.measurableSet) _ MeasurableSet.univ]
  rw [Measure.pi_of_empty, Measure.pi_of_empty]
  have : (fun S : HermR R σ 0 =>
      ((fun i : Fin 0 => algebraMap F R (1 / 2) *
          Algebra.trace R (R ⊗[F] E) ((S : Matrix (Fin 0) (Fin 0) (R ⊗[F] E)) i i)),
        (fun p : {p : Fin 0 × Fin 0 // p.1 < p.2} =>
          (S : Matrix (Fin 0) (Fin 0) (R ⊗[F] E)) p.1.1 p.1.2))) '' Set.univ = Set.univ :=
    Set.eq_univ_of_forall fun x => ⟨default, Set.mem_univ _, Subsingleton.elim _ _⟩
  rw [this]
  simp

omit [MeasurableSpace R] in

theorem fib_univ (σ : E →ₐ[F] E) {M : ℕ} (J : Matrix (Fin M) (Fin M) E)
    (μ : Measure (Fin 0 → Fin M → R ⊗[F] E)) (ν : Measure (HermR R σ 0))
    (m : HermR R σ 0 → Measure (Fin 0 → Fin M → R ⊗[F] E))
    (hμ : μ Set.univ = 1) (hν : ν Set.univ = 1) (h : IsGramFib R σ J 0 μ ν m)
    (S : HermR R σ 0) : m S Set.univ = 1 := by
  obtain ⟨-, h2, -⟩ := h
  have h3 := h2 (fun _ => 1) measurable_const
  have hU : {X : Fin 0 → Fin M → R ⊗[F] E | IsUnit (gramR R σ J X).det} = Set.univ :=
    Set.eq_univ_of_forall fun X => by simp
  rw [hU, Measure.restrict_univ, lintegral_one, hμ] at h3
  simp only [lintegral_one] at h3
  rw [lintegral_unique ν hν (fun b => m b Set.univ)] at h3
  rw [Subsingleton.elim S default]
  exact h3.symm

end Loc

section Glob

variable {F E : Type} [Field F] [NumberField F] [Field E] [Algebra F E]

theorem theta_univ (σ : E →ₐ[F] E) {M : ℕ} (J : Matrix (Fin M) (Fin M) E)
    (μ : Measure (HA (AF F) σ J)) (𝓕 : Set (HA (AF F) σ J))
    (h0 : μ 𝓕 ≠ 0) (h1 : μ 𝓕 ≠ ⊤) (T : Matrix (Fin 0) (Fin 0) E) :
    thetaMeas σ J μ 𝓕 {X | gramE σ J X = T} Set.univ = 1 := by
  have hS : {X : Fin 0 → Fin M → E | gramE σ J X = T} = Set.univ :=
    Set.eq_univ_of_forall fun X => Subsingleton.elim _ _
  unfold thetaMeas
  rw [hS, Measure.smul_apply, Measure.sum_apply _ MeasurableSet.univ]
  have h2 : ∀ X : (Set.univ : Set (Fin 0 → Fin M → E)),
      ((μ.restrict 𝓕).map fun h => actW (AF F) σ J h⁻¹
        (ratTup (AF F) (X : Fin 0 → Fin M → E))) Set.univ = μ 𝓕 := fun X => by
    rw [Measure.map_apply (measurable_of_subsingleton_codomain _) MeasurableSet.univ]
    simp
  simp only [h2]
  rw [tsum_fintype]
  simp [ENNReal.inv_mul_cancel h0 h1]

end Glob


end GlobalTheory.CompanionTheory.SW.ZeroTuple
