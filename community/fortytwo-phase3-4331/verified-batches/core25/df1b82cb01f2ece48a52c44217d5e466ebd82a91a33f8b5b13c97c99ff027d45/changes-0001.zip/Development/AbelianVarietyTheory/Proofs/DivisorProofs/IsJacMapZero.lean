import Mathlib

noncomputable section



namespace GlobalTheory.JacLine





end GlobalTheory.JacLine

end
