import Mathlib
import Formalism.LocalRingCardinality.DataHost
open Formalism.BasicNotions Matrix
open scoped TensorProduct ContDiff ComplexOrder
attribute [local instance] Formalism.BasicNotions.Host.cmStar

namespace GlobalTheory.FockCompare





end GlobalTheory.FockCompare
