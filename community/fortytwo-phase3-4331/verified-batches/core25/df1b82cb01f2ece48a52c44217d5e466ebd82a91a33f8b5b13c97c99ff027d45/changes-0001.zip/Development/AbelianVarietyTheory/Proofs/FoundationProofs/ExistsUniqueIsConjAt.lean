import Mathlib
import Formalism.SatakeDualWeyl.KpqSubgroupCompact
import Development.AbelianVarietyTheory.Definitions.Foundations.NotIsSplitOfIsInertAt
import Development.AbelianVarietyTheory.Proofs.FoundationProofs.ExistsIsLatticeFrameIsMajorantFrame
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ExistsNormEqXModMonicOfAdicCompleteInvolution
import Development.AbelianVarietyTheory.Proofs.SatakeParameters.UnitaryMemIntegralUnitaryDoubleCosetOfGLnDoubleC

noncomputable section

namespace GlobalTheory.LFun

open scoped TensorProduct Matrix
open NumberField IsDedekindDomain Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.UG GlobalTheory.AdelicU
open Formalism.MainNotions.SchurIrreducible (IsSplit IsUnram)

variable {F E : Type} [Field F] [NumberField F] [Field E] [NumberField E] [Algebra F E]
  {v : HeightOneSpectrum (𝓞 F)} {w : HeightOneSpectrum (𝓞 E)}

namespace InertChart

theorem under_eq_iff (hw : IsInertAt F E v w) (u : HeightOneSpectrum (𝓞 E)) : u.under (𝓞 F) = v ↔ u = w := by
  have h' : Ideal.map (algebraMap (𝓞 F) (𝓞 E)) v.asIdeal = w.asIdeal := hw
  constructor
  · rintro rfl
    exact (HeightOneSpectrum.ext (w.isMaximal.eq_of_le u.isPrime.ne_top (h' ▸ Ideal.map_comap_le))).symm
  · rintro rfl
    exact (HeightOneSpectrum.ext (v.isMaximal.eq_of_le (u.under (𝓞 F)).isPrime.ne_top
      (Ideal.map_le_iff_le_comap.1 h'.le))).symm

theorem absNorm_eq (h2 : Module.finrank F E = 2) (hw : IsInertAt F E v w) :
    Ideal.absNorm w.asIdeal = Ideal.absNorm v.asIdeal ^ 2 := by
  rw [← show Ideal.map _ v.asIdeal = w.asIdeal from hw, Ideal.absNorm_algebraMap, ← h2]
  congr 1
  exact (Algebra.IsAlgebraic.finrank_of_isFractionRing (𝓞 F) F (𝓞 E) E).symm

theorem not_map_le_sq (hw : IsInertAt F E v w) :
    ¬ Ideal.map (algebraMap (𝓞 F) (𝓞 E)) v.asIdeal ≤ w.asIdeal ^ 2 := by
  rw [show Ideal.map _ v.asIdeal = w.asIdeal from hw]
  exact (Ideal.pow_lt_self _ w.ne_bot w.isPrime.ne_top 2 le_rfl).not_ge

theorem isSplit_or_isInertAt (hv : IsUnram (E := E) v) : IsSplit (E := E) v ∨ ∃ w, IsInertAt F E v w := by
  classical
  refine (em _).imp_right fun hs => ?_
  set I := Ideal.map (algebraMap (𝓞 F) (𝓞 E)) v.asIdeal with hI
  have hI0 : I ≠ ⊥ := by
    rw [hI, Ne, Ideal.map_eq_bot_iff_of_injective (FaithfulSMul.algebraMap_injective _ _)]
    exact v.ne_bot
  have := v.isMaximal
  obtain ⟨Q, hQ, hQv⟩ := Ideal.exists_maximal_ideal_liesOver_of_isIntegral (S := 𝓞 E) v.asIdeal
  have hle : I ≤ Q := Ideal.map_le_iff_le_comap.2 hQv.over.le
  let P : HeightOneSpectrum (𝓞 E) := ⟨Q, hQ.isPrime, fun h0 => hI0 (le_bot_iff.1 (h0 ▸ hle))⟩
  have h1 := hv P hQv.over.symm
  rw [← Ideal.ramificationIdx'_eq_ramificationIdx v.asIdeal Q v.ne_bot] at h1
  have h2 : ¬ I ≤ Q ^ 2 := fun h => (Ideal.ramificationIdx'_ne_one_iff hle).2 h h1
  have hfac : ∀ p ∈ UniqueFactorizationMonoid.normalizedFactors I, p = Q := by
    intro p hp
    obtain ⟨hpp, hpl⟩ := (Ideal.mem_normalizedFactors_iff hI0).1 hp
    by_contra hne
    exact hs ⟨⟨p, hpp, fun h0 => hI0 (le_bot_iff.1 (h0 ▸ hpl))⟩, P, fun e => hne (congrArg (·.asIdeal) e),
      (v.isMaximal.eq_of_le (Ideal.comap_ne_top _ hpp.ne_top) (Ideal.map_le_iff_le_comap.1 hpl)).symm,
      hQv.over.symm⟩
  obtain ⟨n, hn⟩ : ∃ n, I = Q ^ n := by
    refine ⟨Multiset.card (UniqueFactorizationMonoid.normalizedFactors I), ?_⟩
    conv_lhs => rw [← Ideal.prod_normalizedFactors_eq_self hI0]
    rw [Multiset.eq_replicate_card.2 hfac, Multiset.prod_replicate, Multiset.card_replicate]
  refine ⟨P, ?_⟩
  rcases n with _ | _ | n
  · rw [hn, pow_zero, Ideal.one_eq_top, top_le_iff] at hle
    exact absurd hle hQ.ne_top
  · exact hn.trans (pow_one _)
  · exact absurd (hn ▸ Ideal.pow_le_pow_right (by omega)) h2

variable {σ : E →ₐ[F] E}

theorem conj_conj (h : IsCMExt F E σ) (x : E) : σ (σ x) = x := by
  obtain ⟨τ⟩ : Nonempty (E →+* ℂ) := inferInstance
  apply τ.injective
  rw [h.2.2.2, h.2.2.2, star_star]

theorem conj_ne (h : IsCMExt F E σ) : ¬ ∀ x, σ x = x := fun h1 => by
  have := h.2.1
  obtain ⟨τ⟩ : Nonempty (E →+* ℂ) := inferInstance
  apply IsTotallyComplex.complexEmbedding_not_isReal τ
  rw [ComplexEmbedding.isReal_iff]
  ext y
  exact (h.2.2.2 τ y).symm.trans (congrArg τ (h1 y))

theorem exists_conj_sub_unit (h : IsCMExt F E σ) (hw : IsInertAt F E v w) :
    ∃ x : 𝓞 E, w.valuation E (σ x - x) = 1 := by
  have : Algebra.IsQuadraticExtension F E := { finrank_eq_two' := h.2.2.1 }
  have : IsGalois F E := inferInstance
  have : w.asIdeal.LiesOver v.asIdeal := ⟨congrArg (·.asIdeal) ((under_eq_iff hw w).2 rfl).symm⟩
  have := v.isPrime
  have := w.isPrime
  have hcard := Ideal.card_inertia_eq_ramificationIdxIn (G := E ≃ₐ[F] E) v.asIdeal w.asIdeal
  rw [Ideal.ramificationIdxIn_eq_ramificationIdx v.asIdeal w.asIdeal (E ≃ₐ[F] E),
    ← Ideal.ramificationIdx'_eq_ramificationIdx v.asIdeal w.asIdeal v.ne_bot,
    not_ne_iff.1 (mt (Ideal.ramificationIdx'_ne_one_iff (le_of_eq hw)).1 (not_map_le_sq hw))] at hcard
  let s : E ≃ₐ[F] E := AlgEquiv.ofAlgHom σ σ (AlgHom.ext (conj_conj h)) (AlgHom.ext (conj_conj h))
  by_contra hn
  have hs : s ∈ w.asIdeal.inertia (E ≃ₐ[F] E) := AddSubgroup.mem_inertia.2 fun x => by
    by_contra hx
    exact hn ⟨x, (HeightOneSpectrum.valuation_eq_one_iff_notMem (K := E) w).2 hx⟩
  rw [Subgroup.eq_bot_of_card_eq _ hcard, Subgroup.mem_bot] at hs
  exact conj_ne h fun x => congrArg (fun t : E ≃ₐ[F] E => t x) hs


theorem toCompl_surjective (h : w.under (𝓞 F) = v) : Function.Surjective (toCompl h) := fun y => by
  obtain ⟨Y, hY⟩ := (finAdEquiv F E).surjective (singleFin w y)
  exact ⟨_, (finAdEquiv_apply h Y).symm.trans (hY ▸ evalV_singleFin_self w y)⟩

theorem exists_adele (hw : IsInertAt F E v w) (h : w.under (𝓞 F) = v) (y : Fv F v ⊗[F] E) :
    ∃ Y : Af F ⊗[F] E, Algebra.TensorProduct.map (Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes.evalV F v) (AlgHom.id F E) Y = y ∧
      finAdEquiv F E Y w = toCompl h y ∧ ∀ u, u ≠ w → finAdEquiv F E Y u = 0 := by
  have h1 := GlobalTheory.AutFunCompare.map_tensNU_self _ _ (singleFin_mul v) (evalV_singleFin_self v) y
  refine ⟨_, h1, by rw [finAdEquiv_apply h, h1], fun u hu => ?_⟩
  rw [finAdEquiv_apply rfl, GlobalTheory.AutFunCompare.map_tensNU_zero _ _ _
    (evalV_singleFin_ne (mt (under_eq_iff hw u).1 hu)), map_zero]

theorem toCompl_bijective (hw : IsInertAt F E v w) (h : w.under (𝓞 F) = v) : Function.Bijective (toCompl h) := by
  refine ⟨(injective_iff_map_eq_zero _).2 fun y hy => ?_, toCompl_surjective h⟩
  obtain ⟨Y, h1, h2, h3⟩ := exists_adele hw h y
  have : finAdEquiv F E Y = 0 := FiniteAdeleRing.ext _ fun u => by
    by_cases e : u = w
    · subst e; exact h2.trans hy
    · exact h3 u e
  rw [← h1, (map_eq_zero_iff _ (finAdEquiv F E).injective).1 this, map_zero]

theorem toCompl_mem (h : w.under (𝓞 F) = v) {y : Fv F v ⊗[F] E} (hy : y ∈ intLoc F E v) : toCompl h y ∈ Ov E w :=
  intLoc_induction (p := fun y => toCompl h y ∈ Ov E w)
    (fun _ ha x => mul_mem (complMap_mem h ha) (GlobalTheory.AdeleBaseChange.algebraMap_int_mem x w))
    (by rw [map_zero]; exact zero_mem _) (fun _ _ h h' => by rw [map_add]; exact add_mem h h')
    (fun _ h => by rw [map_neg]; exact neg_mem h) hy

theorem mem_intLoc_iff (hw : IsInertAt F E v w) (h : w.under (𝓞 F) = v) (y : Fv F v ⊗[F] E) :
    y ∈ intLoc F E v ↔ toCompl h y ∈ Ov E w := by
  refine ⟨toCompl_mem h, fun hy => ?_⟩
  obtain ⟨Y, h1, h2, h3⟩ := exists_adele hw h y
  let c := (Algebra.TensorProduct.comm F E (Af F)).toRingEquiv
  have hι : ∀ x a, ((toFinAd F E).comp c.toRingHom) (x ⊗ₜ[F] a) =
      algebraMap E _ x * GlobalTheory.AdeleBaseChange.adMap F E a := fun x a => (toFinAd_tmul a x).trans (mul_comm _ _)
  have h4 := GlobalTheory.AdeleBaseChange.mem_int_of_map hι (y := c.symm Y) fun u => by
    change finAdEquiv F E (c (c.symm Y)) u ∈ _
    rw [c.apply_symm_apply]
    by_cases e : u = w
    · subst e; rw [h2]; exact hy
    · rw [h3 u e]; exact zero_mem _
  obtain ⟨m, g, hg⟩ := Module.Finite.exists_fin (R := ℤ) (M := 𝓞 E)
  obtain ⟨r, hr, e⟩ := P.levelaf_decomp g hg h4
  rw [← h1, ← c.apply_symm_apply Y, e, map_sum, map_sum]
  exact sum_mem fun j _ => tmul_mem_intLoc (hr j v) (g j)

def complEquiv (hw : IsInertAt F E v w) (h : w.under (𝓞 F) = v) : Fv F v ⊗[F] E ≃+* w.adicCompletion E :=
  RingEquiv.ofBijective _ (toCompl_bijective hw h)


theorem existsUnique_isConjAt (σ : E →ₐ[F] E) (hw : IsInertAt F E v w) (h : w.under (𝓞 F) = v) :
    ∃! c, IsConjAt σ h c := by
  let e := complEquiv hw h
  refine ⟨(toCompl h).comp ((Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes.sigR _ σ).comp e.symm.toRingHom), fun y =>
    congrArg (fun z => toCompl h (Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes.sigR _ σ z)) (e.symm_apply_apply y), fun c hc => RingHom.ext fun x => ?_⟩
  obtain ⟨y, rfl⟩ := toCompl_surjective h x
  exact (hc y).trans (congrArg (fun z => toCompl h (Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes.sigR _ σ z)) (e.symm_apply_apply y)).symm

variable {h : w.under (𝓞 F) = v} {c : w.adicCompletion E →+* w.adicCompletion E}

theorem conj_algebraMap (hc : IsConjAt σ h c) (x : E) : c (algebraMap E _ x) = algebraMap E _ (σ x) := by
  have := hc (1 ⊗ₜ x)
  rwa [show Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes.sigR _ σ ((1 : Fv F v) ⊗ₜ[F] x) = 1 ⊗ₜ σ x from rfl, toCompl_tmul, toCompl_tmul,
    map_one, one_mul, one_mul] at this

theorem conj_mem (hw : IsInertAt F E v w) (hc : IsConjAt σ h c) {x : w.adicCompletion E} (hx : x ∈ Ov E w) :
    c x ∈ Ov E w := by
  obtain ⟨y, rfl⟩ := toCompl_surjective h x
  rw [hc]
  exact toCompl_mem h (sigR_mem_intLoc σ ((mem_intLoc_iff hw h y).2 hx))

theorem exists_isUnramInv (hσ : IsCMExt F E σ) (hw : IsInertAt F E v w) (hc : IsConjAt σ h c) :
    ∃ ϖ, IsUnramInv ϖ c (qV F v) := by
  have hval : ∀ a : E, Valued.v (algebraMap E (w.adicCompletion E) a) = w.valuation E a := fun a =>
    HeightOneSpectrum.valuedAdicCompletion_eq_valuation' w _
  obtain ⟨s, hs, hs2⟩ := SetLike.not_le_iff_exists.1 (mt Ideal.map_le_iff_le_comap.2 (not_map_le_sq hw))
  have hs1 : algebraMap (𝓞 F) (𝓞 E) s ∈ w.asIdeal := hw ▸ Ideal.mem_map_of_mem _ hs
  set ϖ : w.adicCompletion E := algebraMap E _ (algebraMap (𝓞 F) (𝓞 E) s : E) with hϖ
  have h1 : c ϖ = ϖ := (conj_algebraMap hc _).trans (congrArg _ (σ.commutes (s : F)))
  have h2 : Valued.v ϖ = WithZero.exp (-1 : ℤ) := by
    rw [hϖ, hval, HeightOneSpectrum.valuation_of_algebraMap]
    have a := (w.intValuation_le_pow_iff_mem _ 1).2 (by rwa [pow_one])
    have b := not_le.1 (mt (w.intValuation_le_pow_iff_mem _ 2).1 hs2)
    have h0 : w.intValuation (algebraMap (𝓞 F) (𝓞 E) s) ≠ 0 := b.ne_bot
    rw [← WithZero.exp_log h0] at a b ⊢
    rw [WithZero.exp_le_exp] at a
    rw [WithZero.exp_lt_exp] at b
    congr 1
    omega
  have h3 : ∀ u, Valued.v u = 1 → Valued.v (c u) = 1 := fun u hu => by
    have a : Valued.v (c u) ≤ 1 := conj_mem hw hc hu.le
    have b : Valued.v (c u⁻¹) ≤ 1 := conj_mem hw hc (show Valued.v u⁻¹ ≤ 1 by rw [map_inv₀, hu, inv_one])
    have h0 : u ≠ 0 := fun h0 => by simp [h0] at hu
    rw [map_inv₀, map_inv₀, inv_le_one₀ (by simpa [pos_iff_ne_zero] using h0)] at b
    exact le_antisymm a b
  refine ⟨ϖ, fun x => ?_, fun x => ?_, h1, h2, ?_, one_lt_absNorm v, ?_⟩
  · obtain ⟨y, rfl⟩ := toCompl_surjective h x
    rw [hc, hc]
    congr 1
    induction y using TensorProduct.induction_on with
    | zero => simp
    | tmul a x => exact congrArg (a ⊗ₜ[F] ·) (conj_conj hσ x)
    | add x y hx hy => simp only [map_add, hx, hy]
  · by_cases h0 : x = 0
    · simp [h0]
    have h0' : Valued.v x ≠ 0 := by simpa using h0
    have a : Valued.v (x * ϖ ^ WithZero.log (Valued.v x)) = 1 := by
      rw [map_mul, map_zpow₀, h2, ← WithZero.exp_zsmul, ← WithZero.exp_log h0', ← WithZero.exp_add]
      simp
    have b := h3 _ a
    rw [map_mul, map_zpow₀, h1, ← a, map_mul, map_mul] at b
    exact mul_right_cancel₀ (by rw [map_zpow₀, h2]; exact zpow_ne_zero _ WithZero.exp_ne_zero) b
  · obtain ⟨x, hx⟩ := exists_conj_sub_unit hσ hw
    exact ⟨algebraMap E _ (x : E), GlobalTheory.AdeleBaseChange.algebraMap_int_mem x w, by
      rw [conj_algebraMap hc, ← map_sub, hval, hx]⟩
  · exact (P.tjcosets_card_residue w).trans (absNorm_eq hσ.2.2.1 hw)





















end InertChart



end GlobalTheory.LFun

end
