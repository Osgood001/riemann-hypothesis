import Mathlib
import Formalism.SatakeDualWeyl.Statement

noncomputable section

open scoped TensorProduct Matrix
open NumberField IsDedekindDomain

namespace GlobalTheory.UnitVectorStabiliser

section General

open Formalism.UG

variable {A : Type} [CommRing A] {n : Type} [Fintype n] [DecidableEq n]
  (s : A →+* A) (J : Matrix n n A)

theorem hf_add_right (x y z : n → A) : hform s J x (y + z) = hform s J x y + hform s J x z := by
  simp only [hform, Pi.add_apply, mul_add, Finset.sum_add_distrib]


theorem hf_smul_right (c : A) (x y : n → A) : hform s J x (c • y) = c * hform s J x y := by
  simp only [hform, Finset.mul_sum, Pi.smul_apply, smul_eq_mul]
  exact Finset.sum_congr rfl fun i _ => Finset.sum_congr rfl fun j _ => by ring


theorem hf_herm (hs : ∀ a, s (s a) = a) (hJ : ∀ i j, s (J j i) = J i j) (x y : n → A) :
    s (hform s J x y) = hform s J y x := by
  simp only [hform, map_sum, map_mul, hs]
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun i _ => Finset.sum_congr rfl fun j _ => ?_
  rw [hJ]
  ring

theorem hf_eq (x y : n → A) : hform s J x y = (fun i => s (x i)) ⬝ᵥ (J *ᵥ y) := by
  simp only [hform, dotProduct, Matrix.mulVec, Finset.mul_sum, mul_assoc]



def hfLin (x : n → A) : (n → A) →ₗ[A] A where
  toFun := hform s J x
  map_add' := hf_add_right s J x
  map_smul' c y := hf_smul_right s J c x y

theorem exists_proj (x : n → A) (hx : IsUnit (hform s J x x)) (P : Submodule A (n → A))
    (hP : ∀ y, y ∈ P ↔ hform s J x y = 0) :
    ∃ (c : (n → A) →ₗ[A] A) (p : (n → A) →ₗ[A] P), (∀ y, y = c y • x + (p y : n → A)) ∧
      c x = 1 ∧ ∀ y : P, c y = 0 := by
  obtain ⟨b, hb⟩ := hx.exists_left_inv
  refine ⟨b • hfLin s J x,
    LinearMap.codRestrict P (LinearMap.id - (b • hfLin s J x).smulRight x) fun y => ?_,
    fun y => ?_, hb, fun y => ?_⟩
  · rw [hP]
    show hfLin s J x (y - (b * hfLin s J x y) • x) = 0
    rw [map_sub, map_smul, smul_eq_mul]
    have : b * hfLin s J x x = 1 := hb
    linear_combination (- hfLin s J x y) * this
  · show y = (b * hfLin s J x y) • x + (y - (b * hfLin s J x y) • x)
    abel
  · show b * hform s J x y = 0
    rw [(hP y).1 y.2, mul_zero]


end General

section Place

variable {F E : Type} [Field F] [NumberField F] [Field E] [NumberField E] [Algebra F E]
  (σ : E →ₐ[F] E) {M : ℕ} (J : Matrix (Fin M) (Fin M) E) (v : HeightOneSpectrum (𝓞 F))










end Place


end GlobalTheory.UnitVectorStabiliser
