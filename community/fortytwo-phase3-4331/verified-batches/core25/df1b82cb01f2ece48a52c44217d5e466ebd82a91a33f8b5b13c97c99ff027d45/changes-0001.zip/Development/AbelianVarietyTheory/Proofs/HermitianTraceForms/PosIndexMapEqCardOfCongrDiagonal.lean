import Mathlib
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.Signature

namespace GlobalTheory.Inertia

open Module Matrix ReciprocityTheory.ChartRestriction.G
open scoped ComplexConjugate

section Complex

variable {n m : Type*} [Fintype n] [Fintype m]

def posDims (G : Matrix n n ℂ) : Set ℕ :=
  {d | ∃ W : Submodule ℂ (n → ℂ), finrank ℂ W = d ∧
    ∀ x ∈ W, x ≠ 0 → 0 < (x ⬝ᵥ G *ᵥ star x).re}

noncomputable def posIndex (G : Matrix n n ℂ) : ℕ := sSup (posDims G)

noncomputable def negIndex (G : Matrix n n ℂ) : ℕ := posIndex (-G)

theorem zero_mem_posDims (G : Matrix n n ℂ) : 0 ∈ posDims G :=
  ⟨⊥, finrank_bot ℂ _, fun x hx hx0 => (hx0 (by simpa using hx)).elim⟩

theorem le_card_of_mem_posDims {G : Matrix n n ℂ} {d : ℕ} (hd : d ∈ posDims G) :
    d ≤ Fintype.card n := by
  obtain ⟨W, rfl, -⟩ := hd
  simpa using W.finrank_le

theorem isGreatest_posIndex (G : Matrix n n ℂ) : IsGreatest (posDims G) (posIndex G) := by
  have hb : BddAbove (posDims G) := ⟨_, fun _ hd => le_card_of_mem_posDims hd⟩
  exact ⟨Nat.sSup_mem ⟨0, zero_mem_posDims G⟩ hb, fun _ hd => le_csSup hb hd⟩




@[simp] theorem posIndex_neg (G : Matrix n n ℂ) : posIndex (-G) = negIndex G := rfl

@[simp] theorem negIndex_neg (G : Matrix n n ℂ) : negIndex (-G) = posIndex G := by
  rw [negIndex, neg_neg]

theorem dotProduct_congr_mulVec_star (G : Matrix n n ℂ) (P : Matrix n m ℂ) (x y : m → ℂ) :
    x ⬝ᵥ (Pᵀ * G * P.map conj) *ᵥ star y = (P *ᵥ x) ⬝ᵥ G *ᵥ star (P *ᵥ y) := by
  have h : star (P *ᵥ y) = P.map conj *ᵥ star y := by
    ext k
    simp [mulVec, dotProduct]
  rw [h, ← mulVec_mulVec, ← mulVec_mulVec, dotProduct_mulVec x, vecMul_transpose]

theorem posIndex_congr_le (G : Matrix n n ℂ) {P : Matrix n m ℂ}
    (hP : Function.Injective P.mulVec) : posIndex (Pᵀ * G * P.map conj) ≤ posIndex G := by
  obtain ⟨W, hW, hpos⟩ := (isGreatest_posIndex (Pᵀ * G * P.map conj)).1
  refine (isGreatest_posIndex G).2 ⟨W.map P.mulVecLin, ?_, ?_⟩
  · rw [← hW]
    exact (Submodule.equivMapOfInjective P.mulVecLin hP W).finrank_eq.symm
  · rintro _ ⟨x, hx, rfl⟩ hx0
    have := hpos x hx (by rintro rfl; simp at hx0)
    rwa [dotProduct_congr_mulVec_star] at this

theorem congr_mul {l : Type*} (G : Matrix n n ℂ) (P : Matrix n m ℂ) (Q : Matrix m l ℂ) :
    (P * Q)ᵀ * G * (P * Q).map conj = Qᵀ * (Pᵀ * G * P.map conj) * Q.map conj := by
  rw [transpose_mul, Matrix.map_mul]
  simp only [Matrix.mul_assoc]



variable [DecidableEq n]

theorem posIndex_congr (G : Matrix n n ℂ) {P : Matrix n n ℂ} (hP : P.det ≠ 0) :
    posIndex (Pᵀ * G * P.map conj) = posIndex G := by
  have hu : IsUnit P.det := hP.isUnit
  refine le_antisymm (posIndex_congr_le G (mulVec_injective_iff_isUnit.2
    ((isUnit_iff_isUnit_det P).2 hu))) ?_
  have h := posIndex_congr_le (Pᵀ * G * P.map conj) (P := P⁻¹)
    (mulVec_injective_iff_isUnit.2 ((isUnit_iff_isUnit_det _).2 (isUnit_nonsing_inv_det P hu)))
  rw [← congr_mul, mul_nonsing_inv P hu] at h
  simpa using h


theorem re_dotProduct_diagonal_mulVec_star (d x : n → ℂ) :
    (x ⬝ᵥ diagonal d *ᵥ star x).re = ∑ k, (d k).re * Complex.normSq (x k) := by
  simp only [dotProduct, mulVec_diagonal, Complex.re_sum, Pi.star_apply]
  refine Finset.sum_congr rfl fun k _ => ?_
  rw [mul_left_comm, Complex.star_def, Complex.mul_conj, Complex.re_mul_ofReal]

theorem posIndex_diagonal (d : n → ℂ) :
    posIndex (diagonal d) = (Finset.univ.filter fun k => 0 < (d k).re).card := by
  refine (isGreatest_posIndex _).unique
    ⟨⟨Pi.spanSubset ℂ {k | 0 < (d k).re}, ?_, fun x hx hx0 => ?_⟩, ?_⟩
  · rw [Pi.dim_spanSubset, Set.ncard_eq_toFinset_card']
    simp
  · rw [re_dotProduct_diagonal_mulVec_star]
    have hx' := Pi.mem_spanSubset_iff.1 hx
    obtain ⟨k, hk⟩ := Function.ne_iff.1 hx0
    refine Finset.sum_pos' (fun j _ => ?_) ⟨k, Finset.mem_univ _, ?_⟩
    · by_cases hj : 0 < (d j).re
      · exact mul_nonneg hj.le (Complex.normSq_nonneg _)
      · simp [hx' j hj]
    · have hk' : 0 < (d k).re := by
        by_contra h
        exact hk (hx' k h)
      exact mul_pos hk' (Complex.normSq_pos.2 hk)
  · rintro _ ⟨W, rfl, hW⟩
    set S := Finset.univ.filter fun k => 0 < (d k).re with hS
    let f : W →ₗ[ℂ] (S → ℂ) := (LinearMap.funLeft ℂ ℂ (Subtype.val : S → n)).comp W.subtype
    have hf : Function.Injective f := by
      rw [injective_iff_map_eq_zero]
      intro x hx
      refine Subtype.ext ?_
      by_contra hx0
      refine (hW x x.2 hx0).not_ge ?_
      rw [re_dotProduct_diagonal_mulVec_star]
      refine Finset.sum_nonpos fun k _ => ?_
      by_cases hk : 0 < (d k).re
      · have : (x : n → ℂ) k = 0 := congrFun hx ⟨k, by simpa [hS] using hk⟩
        simp [this]
      · exact mul_nonpos_of_nonpos_of_nonneg (not_lt.1 hk) (Complex.normSq_nonneg _)
    simpa using LinearMap.finrank_le_finrank_of_injective hf



















end Complex

section NormalForm













end NormalForm

section CM

open NumberField

variable {E : Type} [Field E] [NumberField E] [IsCMField E]

theorem embedding_cc (τ : E →+* ℂ) (x : E) : τ (FD.cc x) = conj (τ x) :=
  IsCMField.complexEmbedding_complexConj E τ x


omit [NumberField E] [IsCMField E] in
theorem det_map_ne_zero {n : Type*} [Fintype n] [DecidableEq n] (τ : E →+* ℂ) {G : Matrix n n E}
    (hG0 : G.det ≠ 0) : (G.map τ).det ≠ 0 := by
  have h : (G.map τ).det = τ G.det := (RingHom.map_det τ G).symm
  rw [h]
  exact (map_ne_zero τ).2 hG0








variable {n : Type*} [Fintype n] [DecidableEq n]



omit [DecidableEq n] in

theorem map_congr {m : Type*} (τ : E →+* ℂ) (G : Matrix n n E) (P : Matrix n m E) :
    (Pᵀ * G * P.map FD.cc).map τ = (P.map τ)ᵀ * G.map τ * (P.map τ).map conj := by
  have h : (P.map FD.cc).map τ = (P.map τ).map conj := by
    ext a b
    exact embedding_cc τ _
  rw [Matrix.map_mul, Matrix.map_mul, transpose_map, h]

theorem posIndex_map_congr (τ : E →+* ℂ) (G : Matrix n n E) {P : Matrix n n E} (hP : P.det ≠ 0) :
    posIndex ((Pᵀ * G * P.map FD.cc).map τ) = posIndex (G.map τ) := by
  rw [map_congr, posIndex_congr _ (det_map_ne_zero τ hP)]




end CM



end GlobalTheory.Inertia
