import Mathlib
import Development.AbelianVarietyTheory.Proofs.AdelicLatticeProofs.FiniteResidueFieldAdicCompletionIntegers
import Development.AbelianVarietyTheory.Proofs.UnitaryExistence.LcscAdelicUnitaryGroup

open scoped TensorProduct
open NumberField IsDedekindDomain MeasureTheory Topology Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes

noncomputable section
namespace GlobalTheory.LatticeDensity



section Generator

variable {F E : Type} [Field F] [NumberField F] [Field E] [NumberField E] [Algebra F E]
  {σ : E →ₐ[F] E} (v : HeightOneSpectrum (𝓞 F))


end Generator

section Volumes

variable {F : Type} [Field F] [NumberField F] (v : HeightOneSpectrum (𝓞 F))


theorem ball_compact_open (m : ℤ) : IsCompact {x : Fv F v | Valued.v x ≤ WithZero.exp m} ∧
    IsOpen {x : Fv F v | Valued.v x ≤ WithZero.exp m} := by
  obtain ⟨c, hc⟩ := HeightOneSpectrum.valuedAdicCompletion_surjective F v (WithZero.exp m)
  have hc0 : c ≠ 0 := by
    rintro rfl
    simp at hc
    exact WithZero.exp_ne_zero hc.symm
  have hO : IsOpen (v.adicCompletionIntegers F : Set (Fv F v)) := Valued.isOpen_valuationSubring _
  have hC : IsCompact (v.adicCompletionIntegers F : Set (Fv F v)) :=
    isCompact_iff_compactSpace.2 (AdelicUnitaryTop.compactSpace_adicCompletionIntegers F v)
  have e : {x : Fv F v | Valued.v x ≤ WithZero.exp m} =
      (Homeomorph.mulLeft₀ c⁻¹ (inv_ne_zero hc0)) ⁻¹' (v.adicCompletionIntegers F) := by
    ext x
    change _ ↔ Valued.v (c⁻¹ * x) ≤ 1
    rw [map_mul, map_inv₀, hc, inv_mul_le_iff₀ WithZero.exp_pos, mul_one]
    rfl
  rw [e]
  exact ⟨(Homeomorph.isCompact_preimage _).2 hC, (Homeomorph.isOpen_preimage _).2 hO⟩

variable {V : Type} [AddCommGroup V] [Module (Fv F v) V] [TopologicalSpace V]
  {ι : Type} [Fintype ι] (e : V ≃L[Fv F v] (ι → Fv F v))

def box (m : ℤ) : AddSubgroup V where
  carrier := {x | ∀ i, Valued.v (e x i) ≤ WithZero.exp m}
  zero_mem' := by intro i; simp
  add_mem' := by
    intro a b ha hb i
    rw [map_add]
    exact Valuation.map_add_le _ (ha i) (hb i)
  neg_mem' := by
    intro a ha i
    rw [map_neg, Pi.neg_apply, Valuation.map_neg]
    exact ha i



end Volumes

section Line







end Line



end GlobalTheory.LatticeDensity
