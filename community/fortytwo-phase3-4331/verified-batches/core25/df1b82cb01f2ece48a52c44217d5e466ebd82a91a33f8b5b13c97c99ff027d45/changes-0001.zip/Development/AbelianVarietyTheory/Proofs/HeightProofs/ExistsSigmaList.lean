import Mathlib
import Development.AbelianVarietyTheory.Proofs.HeightProofs.EnvelopingMapSurjectiveStatement
import Development.AbelianVarietyTheory.Proofs.HeightProofs.ExistsEnvelopingAlgHomUnitaryLieAlgebraStatement
import Development.AbelianVarietyTheory.Proofs.HeightProofs.HasSmoothLogNearOneOfIsUnitaryLieExpDataStatement
import Development.AbelianVarietyTheory.Proofs.HeightProofs.PolarConjTranspose
import Mathlib.Algebra.Order.BigOperators.Ring.Finset
import Mathlib.Algebra.Order.Field.Basic
import Mathlib.Analysis.Fourier.FiniteAbelian.PontryaginDuality
import Mathlib.Analysis.InnerProductSpace.Positive
import Mathlib.Analysis.Matrix.Order
import Mathlib.Analysis.Matrix.PosDef
import Mathlib.Data.Finset.Lattice.Fold
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Real.Basic
import Mathlib.LinearAlgebra.PiTensorProduct.Basis
import Mathlib.NumberTheory.LSeries.RiemannZeta
import Mathlib.RingTheory.Localization.Module
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

noncomputable section

open Formalism.BasicNotions Formalism.BasicNotions.TH Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.MainNotions.StandardLattice Formalism.L2.Theta GlobalTheory.IndefiniteRowSideFullHecke.LieAlgebraExponentialFamilies Matrix
open scoped TensorProduct ContDiff

namespace GlobalTheory.SmoothForms

attribute [local instance] Formalism.BasicNotions.Host.cmStar
attribute [local instance 100] LieRing.ofAssociativeRing

variable {D : D7}

def AlgInf (V : HSp D) : Type := D.what₂.Tau → Matrix (Fin V.rank) (Fin V.rank) ℂ

def LieN (V : HSp D) : Type := ∀ τ : D.what₂.Tau, (lieU (gramAt D V τ)).toSubmodule

section Inst1

attribute [local instance] Matrix.linftyOpNormedRing Matrix.linftyOpNormedAlgebra

instance (V : HSp D) : NormedRing (AlgInf V) :=
  inferInstanceAs (NormedRing (D.what₂.Tau → Matrix (Fin V.rank) (Fin V.rank) ℂ))

instance (V : HSp D) : NormedAlgebra ℝ (AlgInf V) :=
  inferInstanceAs (NormedAlgebra ℝ (D.what₂.Tau → Matrix (Fin V.rank) (Fin V.rank) ℂ))

instance (V : HSp D) : FiniteDimensional ℝ (AlgInf V) :=
  inferInstanceAs (FiniteDimensional ℝ (D.what₂.Tau → Matrix (Fin V.rank) (Fin V.rank) ℂ))


end Inst1

section Inst2

attribute [local instance] Matrix.normedAddCommGroup Matrix.normedSpace

instance (V : HSp D) : NormedAddCommGroup (LieN V) :=
  inferInstanceAs (NormedAddCommGroup (∀ τ : D.what₂.Tau, (lieU (gramAt D V τ)).toSubmodule))

instance (V : HSp D) : NormedSpace ℝ (LieN V) :=
  inferInstanceAs (NormedSpace ℝ (∀ τ : D.what₂.Tau, (lieU (gramAt D V τ)).toSubmodule))

end Inst2



variable (θ : D.what₂.Tau → (Ainf D.host.F ⊗[D.host.F] D.host.E →+* ℂ))

open Classical in

def secInf (V : HSp D) (u : AlgInf V) : GA D V :=
  if h : ∃ g ∈ GinfC V, ∀ τ, infMat D.sp.cm.sig V.gram (θ τ) g = u τ then h.choose else 1

















































end GlobalTheory.SmoothForms

end
