import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.IsotropicUnipotentRadicalsRationalCocompact
import Mathlib
import Development.AbelianVarietyTheory.Counterexamples.HeightSurvey.EmbRelExistsUnique
import Development.AbelianVarietyTheory.Proofs.HeightProofs.IsCuspFunIffConstTerm
import Development.AbelianVarietyTheory.Proofs.HeightProofs.TwoStepUnipotentCompactModSubring
import Development.AbelianVarietyTheory.Proofs.UnitaryExistence.LcscAdelicUnitaryGroup
import Formalism.SatakeDualWeyl.Statement
import Formalism.SharpRestriction.GlobalSchurBounds.GeneralLinearActions.GenusMassVolumes

noncomputable section

set_option linter.unusedSectionVars false

namespace GlobalTheory.UnipFlagCore

abbrev cay := @GlobalTheory.Mem.UnipCocompact.cay
alias cay_unitary := GlobalTheory.Mem.UnipCocompact.cay_unitary
alias cay_sub := GlobalTheory.Mem.UnipCocompact.cay_sub
alias compact_mod_of_filtration := GlobalTheory.Mem.UnipCocompact.compact_mod_of_filtration
abbrev raise := @GlobalTheory.Mem.UnipCocompact.raise
alias raise_mul := GlobalTheory.Mem.UnipCocompact.raise_mul
alias raise_le := GlobalTheory.Mem.UnipCocompact.raise_le
alias raise_st := GlobalTheory.Mem.UnipCocompact.raise_st
alias compact_mod_of_weights := GlobalTheory.Mem.UnipCocompact.compact_mod_of_weights
abbrev fam := @GlobalTheory.Mem.UnipCocompact.fam
abbrev wt := @GlobalTheory.Mem.UnipCocompact.wt
alias fam_complete := GlobalTheory.Mem.UnipCocompact.fam_complete
alias fam_st := GlobalTheory.Mem.UnipCocompact.fam_st
alias mem_raise_fam := GlobalTheory.Mem.UnipCocompact.mem_raise_fam
alias sandwich_eq_zero := GlobalTheory.Mem.UnipCocompact.sandwich_eq_zero
alias triangular_inv := GlobalTheory.Mem.UnipCocompact.triangular_inv

open scoped TensorProduct
open NumberField IsDedekindDomain Matrix
open Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.UG
open GlobalTheory.AutFunCompare (tens_cocompact inclA_injective)

variable {F E : Type} [Field F] [NumberField F] [Field E] [NumberField E] [Algebra F E] {σ : E →ₐ[F] E} {n : ℕ}
  {J : Matrix (Fin n) (Fin n) E}

theorem cT_gram (hJ : IsHermND σ J) : cT (σ : E →+* E) J = J := by
  ext i j; exact hJ.1 i j

theorem det_isUnit (hJ : IsHermND σ J) : IsUnit J.det := hJ.2.isUnit

variable (hσ : ∀ x, σ (σ x) = x) (hJ : IsHermND σ J)
include hσ hJ

theorem cT_cT' {m p : Type} (A : Matrix m p E) : cT (σ : E →+* E) (cT (σ : E →+* E) A) = A := by
  ext i j; exact hσ (A i j)

theorem cT_gram_inv : cT (σ : E →+* E) J⁻¹ = J⁻¹ := by
  refine (Matrix.inv_eq_left_inv ?_).symm
  conv_lhs => rw [← cT_gram hJ]
  rw [cT_gram hJ, ← cT_gram hJ, cT_gram hJ]
  nth_rewrite 2 [← cT_gram hJ]
  rw [← cT_mul, Matrix.mul_nonsing_inv _ (det_isUnit hJ), cT_one]

theorem exists_dual {r : ℕ} (C : Matrix (Fin n) (Fin r) E) (hC : LinearIndependent E Cᵀ)
    (h0 : cT (σ : E →+* E) C * J * C = 0) :
    ∃ L : Matrix (Fin r) (Fin n) E, L * C = 1 ∧ L * J⁻¹ * cT (σ : E →+* E) L = 0 := by
  obtain ⟨l, hl⟩ := LinearMap.exists_leftInverse_of_injective C.mulVecLin
    (LinearMap.ker_eq_bot.2 (Matrix.mulVec_injective_iff.2 hC))
  obtain ⟨L, hL⟩ : ∃ L : Matrix (Fin r) (Fin n) E, L * C = 1 :=
    ⟨LinearMap.toMatrix' l, by
      apply Matrix.toLin'.injective
      rw [Matrix.toLin'_mul, Matrix.toLin'_toMatrix', Matrix.toLin'_one]; exact hl⟩
  set c := cT (m := Fin n) (p := Fin r) (σ : E →+* E) C with hcd
  set d := cT (σ : E →+* E) L with hd
  set s := L * J⁻¹ * d with hs
  have hu := det_isUnit hJ
  have hcd1 : c * d = 1 := by rw [hcd, hd, ← cT_mul, hL, cT_one]
  have hss : cT (σ : E →+* E) s = s := by
    rw [hs, cT_mul, cT_mul, hd, cT_cT' hσ hJ, cT_gram_inv hσ hJ, Matrix.mul_assoc]
  refine ⟨L - (1 / 2 : E) • (s * (c * J)), ?_, ?_⟩
  · rw [Matrix.sub_mul, Matrix.smul_mul, Matrix.mul_assoc, h0, hL]; simp
  · have e : cT (σ : E →+* E) (L - (1 / 2 : E) • (s * (c * J))) =
        d - (1 / 2 : E) • (J * C * s) := by
      have : J * C * s = cT (σ : E →+* E) (s * (c * J)) := by
        rw [cT_mul, cT_mul, hss, cT_gram hJ, hcd, cT_cT' hσ hJ]
      rw [this, hd]
      generalize s * (c * J) = X
      ext i j
      simp [cT, map_ofNat]
    have e1 : L * J⁻¹ * (J * C * s) = s := by
      rw [← Matrix.mul_assoc _ (J * C), ← Matrix.mul_assoc _ J,
        Matrix.nonsing_inv_mul_cancel_right _ _ hu, hL, Matrix.one_mul]
    have e2 : s * (c * J) * J⁻¹ = s * c := by
      rw [← Matrix.mul_assoc, Matrix.mul_nonsing_inv_cancel_right _ _ hu]
    have e3 : s * c * (J * C * s) = 0 := by
      rw [Matrix.mul_assoc, ← Matrix.mul_assoc c, ← Matrix.mul_assoc c, h0]; simp
    rw [e, Matrix.sub_mul, Matrix.smul_mul, e2, Matrix.sub_mul, Matrix.mul_sub, Matrix.mul_sub, Matrix.mul_smul, e1,
      Matrix.smul_mul, Matrix.smul_mul, Matrix.mul_smul, e3, Matrix.mul_assoc s, hcd1, ← hs, Matrix.mul_one]
    module

variable (σ J) in

def adj : Matrix (Fin n) (Fin n) (AF F ⊗[F] E) →+ Matrix (Fin n) (Fin n) (AF F ⊗[F] E) where
  toFun X := J⁻¹.map (inclR (F := F) (AF F)) * cT (Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes.sigR (AF F) σ) X *
    J.map (inclR (F := F) (AF F))
  map_zero' := by simp [cT]
  map_add' X Y := by
    simp [cT, Matrix.map_add _ (map_add _), Matrix.mul_add, Matrix.add_mul]

omit hσ hJ in
theorem adj_apply (X : Matrix (Fin n) (Fin n) (AF F ⊗[F] E)) : adj σ J X =
    J⁻¹.map (inclR (F := F) (AF F)) * cT (Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes.sigR (AF F) σ) X *
    J.map (inclR (F := F) (AF F)) := rfl

theorem gram_mul_inv : J.map (inclR (F := F) (AF F)) * J⁻¹.map (inclR (F := F) (AF F)) = 1 := by
  rw [← Matrix.map_mul, Matrix.mul_nonsing_inv _ (det_isUnit hJ), Matrix.map_one _ (map_zero _) (map_one _)]

theorem inv_mul_gram : J⁻¹.map (inclR (F := F) (AF F)) * J.map (inclR (F := F) (AF F)) = 1 :=
  mul_eq_one_comm.1 (gram_mul_inv hσ hJ)

omit hσ hJ in
theorem adj_map (X : Matrix (Fin n) (Fin n) E) : adj σ J (X.map (inclR (F := F) (AF F))) =
    (J⁻¹ * cT (σ : E →+* E) X * J).map (inclR (F := F) (AF F)) := by
  rw [adj_apply, GlobalTheory.AutFunCounterexample.cT_map_gen, Matrix.map_mul, Matrix.map_mul]

theorem adj_mul (X Y : Matrix (Fin n) (Fin n) (AF F ⊗[F] E)) :
    adj σ J (X * Y) = adj σ J Y * adj σ J X := by
  simp only [adj_apply, cT_mul, Matrix.mul_assoc]
  rw [← Matrix.mul_assoc (J.map _), gram_mul_inv hσ hJ, Matrix.one_mul]

theorem adj_adj (X : Matrix (Fin n) (Fin n) (AF F ⊗[F] E)) : adj σ J (adj σ J X) = X := by
  have h : cT (Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes.sigR (AF F) σ) (cT (Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes.sigR (AF F) σ) X) = X := by
    ext i j
    show Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes.sigR (AF F) σ (Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes.sigR (AF F) σ (X i j)) = X i j
    induction X i j using TensorProduct.induction_on with
    | zero => simp
    | tmul a x => exact congrArg (a ⊗ₜ[F] ·) (hσ x)
    | add x y hx hy => simp only [map_add, hx, hy]
  simp only [adj_apply, cT_mul, GlobalTheory.AutFunCounterexample.cT_map_gen, cT_gram hJ, cT_gram_inv hσ hJ, h, Matrix.mul_assoc]
  rw [inv_mul_gram hσ hJ, Matrix.mul_one, ← Matrix.mul_assoc, inv_mul_gram hσ hJ, Matrix.one_mul]

theorem adj_mul_self_iff (g : GL (Fin n) (AF F ⊗[F] E)) :
    adj σ J g.1 * g.1 = 1 ↔ g ∈ HR (AF F) σ J := by
  change _ ↔ cT _ g.1 * J.map _ * g.1 = J.map _
  rw [adj_apply, Matrix.mul_assoc, Matrix.mul_assoc, ← Matrix.mul_assoc (cT _ _)]
  constructor
  · intro h
    have := congrArg (J.map (inclR (F := F) (AF F)) * ·) h
    simpa only [← Matrix.mul_assoc, gram_mul_inv hσ hJ, Matrix.one_mul, Matrix.mul_one] using this
  · intro h
    rw [h, inv_mul_gram hσ hJ]

theorem perp_iff_idem {r : ℕ} (C : Matrix (Fin n) (Fin r) E) (L : Matrix (Fin r) (Fin n) E)
    (hL : L * C = 1) (m : Matrix (Fin n) (Fin n) (AF F ⊗[F] E)) :
    (∀ x : Fin n → E, (cT (σ : E →+* E) C * J) *ᵥ x = 0 →
        ∃ a, m *ᵥ (fun i => inclR (F := F) (AF F) (x i)) = C.map (inclR (F := F) (AF F)) *ᵥ a) ↔
      (1 - (C * L).map (inclR (F := F) (AF F))) * m * (1 - adj σ J ((C * L).map (inclR (F := F) (AF F)))) = 0 := by
  rw [adj_map]
  set φ := inclR (F := F) (E := E) (AF F)
  have hL' : L.map φ * C.map φ = 1 := by rw [← Matrix.map_mul, hL, Matrix.map_one _ (map_zero _) (map_one _)]
  have e : J⁻¹ * cT (σ : E →+* E) (C * L) * J =
      J⁻¹ * cT (σ : E →+* E) L * (cT (σ : E →+* E) C * J) := by
    rw [cT_mul]; simp only [Matrix.mul_assoc]
  have hT : cT (σ : E →+* E) C * J * (J⁻¹ * cT (σ : E →+* E) L) = 1 := by
    rw [← Matrix.mul_assoc, Matrix.mul_nonsing_inv_cancel_right _ _ (det_isUnit hJ), ← cT_mul, hL, cT_one]
  rw [e]
  generalize cT (σ : E →+* E) C * J = T at hT ⊢
  generalize J⁻¹ * cT (σ : E →+* E) L = P at hT ⊢
  have e1 : 1 - (P * T).map φ = (1 - P * T).map φ := by
    rw [Matrix.map_sub _ (map_sub _), Matrix.map_one _ (map_zero _) (map_one _)]
  constructor
  · intro h
    ext i k
    obtain ⟨a, ha⟩ := h (fun j => (1 - P * T : Matrix (Fin n) (Fin n) E) j k) (by
      have : T * (1 - P * T) = 0 := by
        rw [Matrix.mul_sub, ← Matrix.mul_assoc, hT, Matrix.mul_one, Matrix.one_mul, sub_self]
      funext j; exact congrFun (congrFun this j) k)
    have h2 : (1 - (C * L).map φ) * C.map φ = 0 := by
      rw [Matrix.sub_mul, Matrix.map_mul, Matrix.mul_assoc, hL', Matrix.mul_one, Matrix.one_mul, sub_self]
    have h3 := congrArg ((1 - (C * L).map φ) *ᵥ ·) ha
    simp only [Matrix.mulVec_mulVec, h2, Matrix.zero_mulVec] at h3
    rw [e1]
    exact congrFun h3 i
  · intro h x hx
    refine ⟨(L.map φ * m) *ᵥ fun i => φ (x i), ?_⟩
    have h1 : (T.map φ) *ᵥ (fun i => φ (x i)) = 0 := by
      funext i
      have := RingHom.map_mulVec φ T x i
      rw [hx] at this
      simpa [Function.comp_def] using this.symm
    have h2 := congrArg (· *ᵥ fun i => φ (x i)) h
    simp only [Matrix.zero_mulVec] at h2
    rw [← Matrix.mulVec_mulVec, Matrix.sub_mulVec, Matrix.one_mulVec, Matrix.map_mul (L := P),
      ← Matrix.mulVec_mulVec _ (P.map φ), h1, Matrix.mulVec_zero, sub_zero, Matrix.sub_mul, Matrix.one_mul,
      Matrix.sub_mulVec, sub_eq_zero, Matrix.map_mul, Matrix.mul_assoc] at h2
    rw [h2, Matrix.mulVec_mulVec]

variable (σ J) in

def radSet {r : ℕ} (C : Matrix (Fin n) (Fin r) E) (d : Fin r → ℕ) : Set (HA (AF F) σ J) :=
  {g | (∀ i, ∃ a : Fin r → AF F ⊗[F] E, (∀ j, d i ≤ d j → a j = 0) ∧
      ((HA.mat _ σ J g).1 - 1) *ᵥ (fun k => inclR (F := F) (AF F) (C k i)) = C.map (inclR (F := F) (AF F)) *ᵥ a) ∧
    ∀ x : Fin n → E, (cT (σ : E →+* E) C * J) *ᵥ x = 0 →
      ∃ a, ((HA.mat _ σ J g).1 - 1) *ᵥ (fun i => inclR (F := F) (AF F) (x i)) = C.map (inclR (F := F) (AF F)) *ᵥ a}

noncomputable def idem {r : ℕ} (C : Matrix (Fin n) (Fin r) E) (L : Matrix (Fin r) (Fin n) E) (j : Fin r) :
    Matrix (Fin n) (Fin n) (AF F ⊗[F] E) := (C * single j j (1 : E) * L).map (inclR (F := F) (AF F))

omit hσ hJ in
theorem idem_eq {r : ℕ} (C : Matrix (Fin n) (Fin r) E) (L : Matrix (Fin r) (Fin n) E) (j : Fin r) :
    idem (F := F) C L j = C.map (inclR (F := F) (AF F)) * single j j (1 : AF F ⊗[F] E) * L.map (inclR (F := F) (AF F)) := by
  rw [idem, Matrix.map_mul, Matrix.map_mul, Matrix.map_single, map_one]

omit hσ hJ in
theorem sum_idem {r : ℕ} (C : Matrix (Fin n) (Fin r) E) (L : Matrix (Fin r) (Fin n) E) :
    ∑ j, idem (F := F) C L j = (C * L).map (inclR (F := F) (AF F)) := by
  simp only [idem_eq]
  rw [← Matrix.sum_mul, ← Matrix.mul_sum, Matrix.sum_single_one, Matrix.mul_one, Matrix.map_mul]

theorem idem_complete {r : ℕ} (C : Matrix (Fin n) (Fin r) E) (L : Matrix (Fin r) (Fin n) E) (hL : L * C = 1)
    (h0 : cT (σ : E →+* E) C * J * C = 0) (hLL : L * J⁻¹ * cT (σ : E →+* E) L = 0) :
    CompleteOrthogonalIdempotents (fam (adj σ J) (idem C L)) := by
  have e : ∀ j : Fin r, J⁻¹ * cT (σ : E →+* E) (C * single j j (1 : E) * L) * J =
      J⁻¹ * cT (σ : E →+* E) L * cT (σ : E →+* E) (single j j (1 : E)) *
        (cT (σ : E →+* E) C * J) := fun j => by
    rw [cT_mul, cT_mul]; simp only [Matrix.mul_assoc]
  have e2 : ∀ i j : Fin r, C * single i i (1 : E) * L * (C * single j j (1 : E) * L) = C * (single i i (1 : E) * single j j (1 : E)) * L :=
    fun i j => by
      simp only [Matrix.mul_assoc]
      rw [← Matrix.mul_assoc L C, hL, Matrix.one_mul]
  refine fam_complete (adj_mul hσ hJ) ⟨fun j => ?_, fun i j hij => ?_⟩ (fun i j => ?_) (fun i j => ?_)
  · show _ * _ = _
    rw [idem, ← Matrix.map_mul, e2, Matrix.single_mul_single_same, one_mul]
  · show _ * _ = _
    rw [idem, idem, ← Matrix.map_mul, e2, Matrix.single_mul_single_of_ne (h := hij)]
    simp
  · rw [idem, idem, adj_map, e, ← Matrix.map_mul]
    simp only [Matrix.mul_assoc] at hLL ⊢
    rw [← Matrix.mul_assoc J⁻¹, ← Matrix.mul_assoc L, hLL]
    simp
  · rw [idem, idem, adj_map, e, ← Matrix.map_mul]
    simp only [Matrix.mul_assoc] at h0 ⊢
    rw [← Matrix.mul_assoc J C, ← Matrix.mul_assoc (cT _ C), h0]
    simp

theorem adj_mat (g : HA (AF F) σ J) : adj σ J (HA.mat _ σ J g).1 = (HA.mat _ σ J g⁻¹).1 := by
  have h := (adj_mul_self_iff hσ hJ g.1).2 g.2
  exact (Units.inv_eq_of_mul_eq_one_left h).symm

theorem mem_radSet_iff {r : ℕ} (C : Matrix (Fin n) (Fin r) E) (L : Matrix (Fin r) (Fin n) E) (hL : L * C = 1)
    (h0 : cT (σ : E →+* E) C * J * C = 0) (hLL : L * J⁻¹ * cT (σ : E →+* E) L = 0)
    {d : Fin r → ℕ} {M : ℕ} (hd : ∀ j, d j < M) (g : HA (AF F) σ J) :
    g ∈ radSet σ J C d ↔ (HA.mat _ σ J g).1 - 1 ∈ raise (fam (adj σ J) (idem C L)) (wt d M) 0 := by
  rw [mem_raise_fam (adj_mul hσ hJ) (adj_adj hσ hJ) (idem_complete hσ hJ C L hL h0 hLL) hd, sum_idem,
    ← perp_iff_idem hσ hJ C L hL, map_sub, adj_mat hσ hJ, GlobalTheory.TwoStepUnipotent.st_one (adj_mul hσ hJ) (adj_adj hσ hJ)]
  have hinv : (HA.mat _ σ J g⁻¹).1 * (HA.mat _ σ J g).1 = 1 := Units.inv_mul g.1
  unfold radSet
  rw [Set.mem_ofPred_eq]
  generalize (HA.mat _ σ J g⁻¹).1 = y at hinv ⊢
  generalize (HA.mat _ σ J g).1 = x at hinv ⊢
  set φ := inclR (F := F) (E := E) (AF F)
  have hL' : L.map φ * C.map φ = 1 := by rw [← Matrix.map_mul, hL, Matrix.map_one _ (map_zero _) (map_one _)]
  have sw : ∀ (m : Matrix (Fin n) (Fin n) (AF F ⊗[F] E)) (i j : Fin r),
      idem C L j * m * idem C L i = 0 ↔ (L.map φ * m * C.map φ : Matrix (Fin r) (Fin r) (AF F ⊗[F] E)) j i = 0 :=
    fun m i j => by rw [idem_eq, idem_eq]; exact sandwich_eq_zero hL' m i j
  simp only [sw]
  have co : ∀ (i : Fin r) (a : Fin r → AF F ⊗[F] E), (x - 1) *ᵥ (fun k => φ (C k i)) = C.map φ *ᵥ a → ∀ j, (L.map φ * (x - 1) * C.map φ : Matrix (Fin r) (Fin r) (AF F ⊗[F] E)) j i = a j :=
    fun i a ha j => by
      have := congrArg (L.map φ *ᵥ ·) ha
      simp only [Matrix.mulVec_mulVec, hL', Matrix.one_mulVec] at this
      exact congrFun this j
  constructor
  · rintro ⟨h1, h2⟩
    have k : ∀ i j : Fin r, d i ≤ d j → (L.map φ * (x - 1) * C.map φ : Matrix (Fin r) (Fin r) (AF F ⊗[F] E)) j i = 0 := fun i j hij => by
      obtain ⟨a, ha, ha'⟩ := h1 i
      rw [co i a ha', ha j hij]
    refine ⟨h2, k, triangular_inv d _ _ ?_ k⟩
    have e : (x - 1) * C.map φ = C.map φ * (L.map φ * (x - 1) * C.map φ) := by
      ext k i
      obtain ⟨a, -, ha'⟩ := h1 i
      rw [Matrix.mul_apply (M := C.map φ)]
      simp only [co i a ha']
      exact congrFun ha' k
    have e' : y - 1 = -(x - 1) - (y - 1) * (x - 1) := by
      rw [sub_mul, mul_sub, hinv]; noncomm_ring
    rw [Matrix.mul_assoc (L.map φ * (y - 1)), ← e]
    conv_lhs => rw [e']
    simp only [Matrix.mul_sub, Matrix.sub_mul, Matrix.mul_neg, Matrix.neg_mul, Matrix.mul_assoc]
  · rintro ⟨h2, h1, -⟩
    refine ⟨fun i => ?_, h2⟩
    obtain ⟨a, ha⟩ := h2 (fun k => C k i) (funext fun j => congrFun (congrFun h0 j) i)
    exact ⟨a, fun j hij => by rw [← co i a ha, h1 i j hij], ha⟩

theorem closure_radSet_cocompact {r : ℕ} (C : Matrix (Fin n) (Fin r) E) (hC : LinearIndependent E Cᵀ)
    (h0 : cT (σ : E →+* E) C * J * C = 0) (d : Fin r → ℕ) :
    ∃ K : Set (Subgroup.closure (radSet σ J C d)), IsCompact K ∧
      ∀ m, ∃ γ : Subgroup.closure (radSet σ J C d), HA.mat _ σ J γ.1 ∈ HFin (AF F) σ J ∧ ∃ k ∈ K, m = γ * k := by
  obtain ⟨L, hL, hLL⟩ := exists_dual hσ hJ C hC h0
  obtain ⟨M, hd⟩ : ∃ M, ∀ j, d j < M := by
    obtain ⟨M, hM⟩ := (Set.finite_range d).bddAbove
    exact ⟨M + 1, fun j => Nat.lt_succ_of_le (hM ⟨j, rfl⟩)⟩
  obtain ⟨K, hK, hKs⟩ := tens_cocompact (F := F) (E := E)
  have : IsModuleTopology (AF F) (AF F ⊗[F] E) := ⟨rfl⟩
  have : IsTopologicalRing (AF F ⊗[F] E) := IsModuleTopology.isTopologicalRing (AF F) _
  set φ := inclR (F := F) (E := E) (AF F) with hφ
  have he := idem_complete hσ hJ C L hL h0 hLL
  have hs := fam_st (adj_mul hσ hJ) (adj_adj hσ hJ) (idem (F := F) C L) d M
  have h1 := GlobalTheory.TwoStepUnipotent.st_one (adj_mul hσ hJ) (adj_adj hσ hJ)
  have hcont : Continuous (adj σ J) := (continuous_const.matrix_mul (continuous_id.matrix_map
      (GlobalTheory.AdelicUnitaryTop.continuous_sigR (AF F) σ)).matrix_transpose).matrix_mul continuous_const
  have hst0 : ∀ x ∈ (φ.mapMatrix (m := Fin n)).range, adj σ J x ∈ (φ.mapMatrix (m := Fin n)).range := by
    rintro _ ⟨X, rfl⟩; exact ⟨_, (adj_map X).symm⟩
  have hmem : ∀ g, g ∈ Subgroup.closure (radSet σ J C d) ↔
      (HA.mat _ σ J g).1 - 1 ∈ raise (fam (adj σ J) (idem C L)) (wt d M) 0 := fun g => by
    refine ⟨fun hg => ?_, fun hg => Subgroup.subset_closure ((mem_radSet_iff hσ hJ C L hL h0 hLL hd g).2 hg)⟩
    induction hg using Subgroup.closure_induction with
    | mem x hx => exact (mem_radSet_iff hσ hJ C L hL h0 hLL hd x).1 hx
    | one => exact (sub_self (1 : Matrix (Fin n) (Fin n) (AF F ⊗[F] E))).symm ▸ zero_mem _
    | mul x y _ _ hx hy =>
      have e : (HA.mat _ σ J (x * y)).1 = (HA.mat _ σ J x).1 * (HA.mat _ σ J y).1 := rfl
      rw [e]
      generalize (HA.mat _ σ J x).1 = a at hx ⊢
      generalize (HA.mat _ σ J y).1 = b at hy ⊢
      have : a * b - 1 = (a - 1) * (b - 1) + (a - 1) + (b - 1) := by noncomm_ring
      rw [this]
      exact add_mem (add_mem (raise_le 0 (raise_mul he 0 hx hy)) hx) hy
    | inv x _ hx =>
      have := raise_st (adj_mul hσ hJ) (adj_adj hσ hJ) hs 0 hx
      rwa [map_sub, adj_mat hσ hJ, h1] at this
  obtain ⟨K', hK', k1, k2⟩ := compact_mod_of_weights (st := adj σ J) (w := wt d M)
    (φ.mapMatrix (m := Fin n)).range
    (Matrix.scalar _ (φ (1 / 2))) (Set.pi Set.univ fun _ => Set.pi Set.univ fun _ => K) hcont
    (adj_mul hσ hJ) (adj_adj hσ hJ) hst0
    ⟨Matrix.scalar _ (1 / 2), by ext i j; by_cases h : i = j <;> simp [h]⟩
    (by rw [← map_add, ← map_add, add_halves, map_one, map_one])
    (fun x => (Matrix.scalar_commute _ (fun _ => Commute.all _ _) x).eq)
    (isCompact_univ_pi fun _ => isCompact_univ_pi fun _ => hK)
    (fun X => by
      choose y hy using fun i j => hKs (X i j)
      exact ⟨_, ⟨Matrix.of y, rfl⟩, fun i _ j _ => hy i j⟩) he
    (by
      have hu : ∀ j, idem (F := F) C L j ∈ (φ.mapMatrix (m := Fin n)).range := fun j => ⟨_, rfl⟩
      have hv : ∀ j : Fin r ⊕ Fin r, Sum.elim (idem (F := F) C L) (fun j => adj σ J (idem C L j)) j ∈
          (φ.mapMatrix (m := Fin n)).range := by
        rintro (j | j)
        exacts [hu j, hst0 _ (hu j)]
      rintro (_ | j)
      exacts [sub_mem (one_mem _) (sum_mem fun j _ => hv j), hv j]) hs
  let lift : ∀ x : Matrix (Fin n) (Fin n) (AF F ⊗[F] E), (adj σ J x * x = 1 ∧ x * adj σ J x = 1) ∧
      x - 1 ∈ raise (fam (adj σ J) (idem C L)) (wt d M) 0 → Subgroup.closure (radSet σ J C d) := fun x hx =>
    ⟨⟨⟨x, adj σ J x, hx.1.2, hx.1.1⟩, (adj_mul_self_iff hσ hJ _).1 hx.1.1⟩, (hmem _).2 hx.2⟩
  let f : Subgroup.closure (radSet σ J C d) → _ := fun m => Units.embedProduct _ (HA.mat _ σ J m.1)
  have hf : Topology.IsInducing f :=
    Units.isInducing_embedProduct.comp (Topology.IsInducing.subtypeVal.comp Topology.IsInducing.subtypeVal)
  refine ⟨f ⁻¹' ((fun x => (x, MulOpposite.op (adj σ J x))) '' K'),
    hf.isCompact_preimage' (hK'.image (continuous_id.prodMk (MulOpposite.continuous_op.comp hcont))) ?_, fun m => ?_⟩
  · rintro _ ⟨x, hx, rfl⟩
    exact ⟨lift x (k1 x hx), rfl⟩
  · have u := (adj_mul_self_iff hσ hJ _).2 m.1.2
    obtain ⟨γ, ⟨a, ha⟩, p1, k, hk, p2⟩ := k2 (HA.mat _ σ J m.1).1 ⟨⟨u, mul_eq_one_comm.1 u⟩, (hmem _).1 m.2⟩
    obtain ⟨b, hb⟩ := hst0 γ ⟨a, ha⟩
    refine ⟨lift γ p1, ?_, lift k (k1 k hk), ⟨k, hk, rfl⟩, Subtype.ext (Subtype.ext (Units.ext p2))⟩
    have inj : Function.Injective (φ.mapMatrix (m := Fin n)) := Matrix.map_injective inclA_injective
    have hab : a * b = 1 := inj (by rw [map_mul, ha, hb, map_one, p1.1.2])
    refine ⟨⟨a, b, hab, mul_eq_one_comm.1 hab⟩, inj ?_, Units.ext ha⟩
    have hγ' : cT (Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes.sigR (AF F) σ) γ * J.map φ * γ = J.map φ := (lift γ p1).1.2
    rw [← ha] at hγ'
    rw [map_mul, map_mul]
    exact (congrArg (· * J.map φ * a.map φ) (GlobalTheory.AutFunCounterexample.cT_map_gen σ a).symm).trans hγ'


omit hσ hJ in
theorem dual_mulVec {A : Type} [CommRing A] (s : A →+* A) (G : Matrix (Fin n) (Fin n) A) {r : ℕ} (e : Fin r → Fin n → A)
    (x : Fin n → A) (a : Fin r) : ((cT s (Matrix.of e)ᵀ * G) *ᵥ x) a = hform s G (e a) x := by
  rw [hform, Finset.sum_comm]
  simp [Matrix.mulVec, dotProduct, Matrix.mul_apply, cT, Finset.sum_mul]




omit hσ hJ in

theorem conj_invol (h : IsCMExt F E σ) (x : E) : σ (σ x) = x := by
  obtain ⟨τ⟩ : Nonempty (E →+* ℂ) := inferInstance
  exact τ.injective (by rw [h.2.2.2, h.2.2.2, star_star])



end GlobalTheory.UnipFlagCore
