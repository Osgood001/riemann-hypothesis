import Mathlib
import Development.AbelianVarietyTheory.Proofs.AdelicLatticeProofs.ExistsUniqueIdeleOfLinearEquivQuotientLocal

open NumberField IsDedekindDomain IsDedekindDomain.HeightOneSpectrum WithZero Polynomial


namespace GlobalTheory.LocalDifferentProduct

section Local

variable {K : Type} [Field K] [NumberField K] (v : HeightOneSpectrum (𝓞 K))

open NumberField IsDedekindDomain IsDedekindDomain.HeightOneSpectrum WithZero Polynomial in
variable {K : Type} [Field K] [NumberField K] (v : HeightOneSpectrum (𝓞 K)) in
theorem _root_.GlobalTheory.LocalDifferentProduct.valued_coe_algebraMap (x : 𝓞 K) :
    Valued.v ((algebraMap (𝓞 K) (v.adicCompletionIntegers K) x : v.adicCompletionIntegers K) :
      v.adicCompletion K) = v.intValuation x := by
  simp [valuation_of_algebraMap]








end Local



section Relative

variable {F E : Type} [Field F] [NumberField F] [Field E] [NumberField E] [Algebra F E]
  {σ : E →ₐ[F] E}

end Relative



end GlobalTheory.LocalDifferentProduct
