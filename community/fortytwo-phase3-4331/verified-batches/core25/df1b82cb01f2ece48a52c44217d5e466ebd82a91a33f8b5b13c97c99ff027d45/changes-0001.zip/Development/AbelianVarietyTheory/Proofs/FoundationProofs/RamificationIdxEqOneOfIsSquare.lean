import Mathlib
import Development.AbelianVarietyTheory.Definitions.Foundations.NotIsSplitOfIsInertAt
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.MemNormGroupIffEverywhereNorm
import Development.AbelianVarietyTheory.PublishedTheorems.TwistedTraceFormula.QuadraticClassFieldTheory
import Formalism.LocalRingCardinality.DataHost
import Formalism.LocalRingCardinality.RhoDetPrimeEqMuTildeMulChiPow
import Formalism.LocalToGlobal.BesselHermitianTheta.DefsReal
import Formalism.LocalToGlobal.UnitaryNorms.IsUnitaryNormOf
import Formalism.SatakeDualWeyl.StatementG
import Formalism.SharpRestriction.Divisibility.SchurIrreducible
import Formalism.SharpRestriction.GlobalSchurBounds.GeneralLinearActions.GenusMassVolumes
import Formalism.SharpRestriction.RamificationFrobenius.TotientGaloisClasses.ConjEMemHostFIff
import ReciprocityTheory.NeutralLocalFields.Reciprocity

noncomputable section

namespace GlobalTheory.LFun

open scoped TensorProduct
open NumberField IsDedekindDomain Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes
open Formalism.UG (IsInertAt)
open Formalism.MainNotions.SchurIrreducible (IsSplit IsUnram)
open Formalism.L2.Host (HChar IsUnitAt IsUnifAt atFin unif unif_spec aboveF upF)
open Neutral.B1 (finiteSingle localIdele)

variable {F E : Type} [Field F] [NumberField F] [Field E] [NumberField E] [Algebra F E]

section Idele

end Idele

section Record

open Formalism.BasicNotions Formalism.BasicNotions.TH Formalism.L2.Theta

attribute [local instance] Formalism.BasicNotions.Host.cmStar





end Record

section Local

open GlobalTheory.QuadSymbol (normGroup mem_normGroup_iff_form)

variable {v : HeightOneSpectrum (𝓞 F)} {w w' : HeightOneSpectrum (𝓞 E)}

theorem comap_eq_iff : w.asIdeal.comap (algebraMap (𝓞 F) (𝓞 E)) = v.asIdeal ↔ w.under (𝓞 F) = v :=
  ⟨fun h => HeightOneSpectrum.ext h, fun h => h ▸ rfl⟩

theorem isSplit_iff : IsSplit (E := E) v ↔
    ∃ w w' : HeightOneSpectrum (𝓞 E), w ≠ w' ∧ w.under (𝓞 F) = v ∧ w'.under (𝓞 F) = v := by
  simp only [IsSplit, comap_eq_iff]

theorem isUnram_iff : IsUnram (E := E) v ↔
    ∀ w : HeightOneSpectrum (𝓞 E), w.under (𝓞 F) = v → w.asIdeal.ramificationIdx (𝓞 F) = 1 := by
  simp only [IsUnram, comap_eq_iff]

section Basis



end Basis

end Local

section Eta

open GlobalTheory.QuadSymbol (normGroup)
open GlobalTheory.IdeleNormChar (normSign signToCircle finComp infComp)





end Eta

end GlobalTheory.LFun

end
