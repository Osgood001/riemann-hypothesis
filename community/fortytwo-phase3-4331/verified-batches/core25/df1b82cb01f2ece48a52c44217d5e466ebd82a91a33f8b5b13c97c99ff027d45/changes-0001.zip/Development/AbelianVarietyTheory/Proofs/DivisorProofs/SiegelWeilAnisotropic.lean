import Mathlib

noncomputable section

namespace GlobalTheory.ThetaInner
open Filter Topology

def LaurentConst (h : ℂ → ℂ) (s₀ c : ℂ) : Prop :=
  ∃ p : Polynomial ℂ, p.coeff 0 = 0 ∧ Tendsto (fun s => h s - p.eval (s - s₀)⁻¹) (𝓝[≠] s₀) (𝓝 c)

end GlobalTheory.ThetaInner

end
