import Mathlib
import Development.AbelianVarietyTheory.Proofs.HeightProofs.ExistsCompactAdeleRingModNumberField

noncomputable section

namespace GlobalTheory.Eis.Conv









end GlobalTheory.Eis.Conv

end
