import Mathlib
import Formalism.LocalToGlobal.BesselHermitianTheta.TiedKfin
import Formalism.LocalToGlobal.BesselHermitianTheta.LemmasWeil
import Formalism.LocalToGlobal.BesselHermitianTheta.LemmasSign
import Development.AbelianVarietyTheory.BlockTheory.HeightDefect.FockOrthogonalDecomposition

noncomputable section

open Formalism.BasicNotions Formalism.BasicNotions.TH Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.MainNotions.StandardLattice Formalism.L2.Theta Matrix
open scoped TensorProduct ContDiff ComplexOrder

namespace GlobalTheory.FockCompare

attribute [local instance] Formalism.BasicNotions.Host.cmStar

section Abstract






end Abstract

variable {D : D7}

open GlobalTheory.IndefiniteRowSideFullHecke.FockOrthogonalDecomposition

structure Chart (θ : InfFam D) (σ : (D.what₂.Tau → ℂ) →+ AE D) : Prop where
  inf : IsInfFam θ
  cont : Continuous σ
  fin : ∀ z, finPart D (σ z) = 0
  comp : ∀ z τ, θ τ (infPart D (σ z)) = z τ
  ext : ∀ a : AE D, finPart D a = 0 → (∀ τ, θ τ (infPart D a) = 0) → a = 0

















variable {θ : InfFam D}






instance isModuleTopology_AE : IsModuleTopology (AF D.host.F) (AE D) := ⟨rfl⟩

instance isTopologicalRing_AE : IsTopologicalRing (AE D) := IsModuleTopology.isTopologicalRing (AF D.host.F) (AE D)



theorem tauE_star (τ : D.what₂.Tau) (x : D.host.E) : tauE D τ (star x) = starRingEnd ℂ (tauE D τ x) := by
  have := D.host.isCMField_hostE
  exact NumberField.IsCMField.complexEmbedding_complexConj D.host.E _ x

theorem comp_incA (hθ : IsInfFam θ) (τ : D.what₂.Tau) (e : D.host.E) : θ τ (infPart D (incA D e)) = tauE D τ e :=
  (hθ τ).1 e

theorem conj_tmul_one (hθ : IsInfFam θ) (τ : D.what₂.Tau) (a : Ainf D.host.F) :
    starRingEnd ℂ (θ τ (a ⊗ₜ[D.host.F] (1 : D.host.E))) = θ τ (a ⊗ₜ[D.host.F] (1 : D.host.E)) := by
  have h := hθ τ
  refine DenseRange.induction_on (NumberField.InfiniteAdeleRing.denseRange_algebraMap D.host.F) a
    (isClosed_eq (Complex.continuous_conj.comp h.2) h.2) fun f => ?_
  have e : (algebraMap D.host.F (Ainf D.host.F) f) ⊗ₜ[D.host.F] (1 : D.host.E) =
      (1 : Ainf D.host.F) ⊗ₜ[D.host.F] (algebraMap D.host.F D.host.E f) := by
    exact (Algebra.TensorProduct.includeLeft (R := D.host.F) (S := D.host.F) (A := Ainf D.host.F) (B := D.host.E)).commutes f |>.trans
      ((Algebra.TensorProduct.includeRight (R := D.host.F) (A := Ainf D.host.F) (B := D.host.E)).commutes f).symm
  erw [e, h.1, ← tauE_star]
  rw [(D.sp.cm.fixed _).2 ⟨f, rfl⟩]

theorem comp_cA (hθ : IsInfFam θ) (τ : D.what₂.Tau) (z : AE D) :
    θ τ (infPart D (cA D z)) = starRingEnd ℂ (θ τ (infPart D z)) := by
  induction z using TensorProduct.induction_on with
  | zero => simp only [RingHom.map_zero]
  | add a b ha hb => simp only [RingHom.map_add, ha, hb]
  | tmul a x =>
    have e : ∀ y : D.host.E, fstA D.host.F a ⊗ₜ[D.host.F] y =
        (fstA D.host.F a ⊗ₜ[D.host.F] (1 : D.host.E)) * ((1 : Ainf D.host.F) ⊗ₜ[D.host.F] y) := by
      intro y; simp
    have e2 : infPart D (cA D (a ⊗ₜ[D.host.F] x)) = fstA D.host.F a ⊗ₜ[D.host.F] (star x) := rfl
    have e3 : infPart D (a ⊗ₜ[D.host.F] x) = fstA D.host.F a ⊗ₜ[D.host.F] x := rfl
    rw [e2, e3, e (star x), e x, map_mul, map_mul, map_mul, conj_tmul_one hθ, (hθ τ).1, (hθ τ).1, tauE_star]




end GlobalTheory.FockCompare

end
