import Mathlib

noncomputable section

open scoped ContDiff Topology
open Matrix

namespace GlobalTheory.SmoothForms

section Centre












end Centre

section Operators

variable {𝔸 L G : Type} [NormedRing 𝔸] [NormedAlgebra ℝ 𝔸] [FiniteDimensional ℝ 𝔸] [NormedAddCommGroup L]
  [NormedSpace ℝ L] [Group G] {σ : 𝔸 →ₗ[ℝ] 𝔸} {j : L →ₗ[ℝ] 𝔸} {s : 𝔸 → G}








end Operators

end GlobalTheory.SmoothForms

end
