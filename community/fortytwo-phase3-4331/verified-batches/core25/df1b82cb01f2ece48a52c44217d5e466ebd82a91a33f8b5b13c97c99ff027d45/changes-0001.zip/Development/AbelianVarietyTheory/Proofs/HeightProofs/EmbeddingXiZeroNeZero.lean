import Mathlib
import Formalism.LocalRingCardinality.DataHost
import Formalism.LocalRingCardinality.DataRows
import Formalism.LocalRingCardinality.DataSpaces
import Formalism.LocalRingCardinality.DataTheta
import Formalism.LocalRingCardinality.RankBoundMonotoneInDimension
import Formalism.LocalRingCardinality.RhoDetPrimeEqMuTildeMulChiPow
import Formalism.LocalToGlobal.BesselHermitianTheta.DefsReal
import Formalism.LocalToGlobal.BesselHermitianTheta.IsAutFunDef
import Formalism.LocalToGlobal.BesselHermitianTheta.LemmasSign
import Formalism.LocalToGlobal.BesselHermitianTheta.LemmasWeil
import Formalism.SharpRestriction.GlobalSchurBounds.GeneralLinearActions.GenusMassVolumes
import Formalism.SharpRestriction.GlobalSchurBounds.StandardLattice
import Formalism.SharpRestriction.RamificationFrobenius.TotientGaloisClasses.ConjEMemHostFIff
import Development.AbelianVarietyTheory.Counterexamples.HeightSurvey.StarPurelyImaginaryEqNeg

noncomputable section

open Formalism.BasicNotions Formalism.BasicNotions.TH Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.MainNotions.StandardLattice Formalism.L2.Theta MeasureTheory IsDedekindDomain NumberField Matrix
open scoped TensorProduct ContDiff

namespace GlobalTheory.DualPairCompare

attribute [local instance] Formalism.BasicNotions.Host.cmStar

variable {D : D7}

section Gen




end Gen



instance modTop (D : D7) : IsModuleTopology (AF D.host.F) (AE D) := ⟨rfl⟩















def plF (D : D7) (ρ : D.what₂.Tau) : InfinitePlace D.host.F :=
  InfinitePlace.mk ((tauE D ρ).comp (algebraMap D.host.F D.host.E))

theorem emb_mk (D : D7) (φ : D.host.F →+* ℂ) : (InfinitePlace.mk φ).embedding = φ :=
  haveI := D.sp.cm.totReal
  InfinitePlace.embedding_mk_eq_of_isReal (IsTotallyReal.complexEmbedding_isReal φ)


section Gen
variable {F E : Type} [Field F] [NumberField F] [Field E] [NumberField E] [Algebra F E]

theorem gen_inf_val (τ : E →+* ℂ) (w : InfinitePlace F) (hw : w.embedding = τ.comp (algebraMap F E))
    (θ : Ainf F ⊗[F] E →+* ℂ) (h : IsInfEmb τ θ) (x : Ainf F) :
    θ (x ⊗ₜ[F] (1 : E)) = InfinitePlace.Completion.extensionEmbedding w (x w) := by
  have key : (fun a : Ainf F => θ (a ⊗ₜ[F] (1 : E))) =
      fun a : Ainf F => InfinitePlace.Completion.extensionEmbedding w (a w) := by
    refine (InfiniteAdeleRing.denseRange_algebraMap F).equalizer h.2
      ((InfinitePlace.Completion.isometry_extensionEmbedding w).continuous.comp (continuous_apply w)) ?_
    funext y
    have e : (algebraMap F (Ainf F) y) ⊗ₜ[F] (1 : E) = (1 : Ainf F) ⊗ₜ[F] (algebraMap F E y) := by
      rw [Algebra.algebraMap_eq_smul_one, Algebra.algebraMap_eq_smul_one, TensorProduct.smul_tmul]
    show θ (algebraMap F (Ainf F) y ⊗ₜ[F] (1 : E)) =
      InfinitePlace.Completion.extensionEmbedding w (algebraMap F (Ainf F) y w)
    rw [e, h.1, InfiniteAdeleRing.algebraMap_apply]
    exact ((InfinitePlace.Completion.extensionEmbedding_coe w _).trans (DFunLike.congr_fun hw y)).symm
  exact congrFun key x

theorem gen_inf_exists (τ : E →+* ℂ) (w : InfinitePlace F) (hw : w.embedding = τ.comp (algebraMap F E)) :
    ∃ θ : Ainf F ⊗[F] E →+* ℂ, IsInfEmb τ θ := by
  let _ : Algebra F ℂ := (τ.comp (algebraMap F E)).toAlgebra
  let f : Ainf F →ₐ[F] ℂ :=
    { toRingHom := (InfinitePlace.Completion.extensionEmbedding w).comp (Pi.evalRingHom _ w)
      commutes' := fun x =>
        (InfinitePlace.Completion.extensionEmbedding_coe w _).trans (DFunLike.congr_fun hw x) }
  let g : E →ₐ[F] ℂ := { toRingHom := τ, commutes' := fun _ => rfl }
  refine ⟨(Algebra.TensorProduct.lift f g (fun _ _ => Commute.all _ _)).toRingHom, fun x => ?_, ?_⟩
  · show f 1 * g x = τ x
    rw [map_one, one_mul]
    rfl
  · have : (fun a : Ainf F => (Algebra.TensorProduct.lift f g (fun _ _ => Commute.all _ _)).toRingHom
        (a ⊗ₜ[F] (1 : E))) = fun a => InfinitePlace.Completion.extensionEmbedding w (a w) := by
      funext a
      show f a * g 1 = _
      rw [map_one, mul_one]
      rfl
    rw [this]
    exact (InfinitePlace.Completion.isometry_extensionEmbedding w).continuous.comp (continuous_apply w)

end Gen

theorem exists_infFam (D : D7) : ∃ θ, IsInfFam (D := D) θ := by
  choose θ hθ using fun ρ => gen_inf_exists (tauE D ρ) (plF D ρ) (emb_mk D _)
  exact ⟨θ, hθ⟩


end GlobalTheory.DualPairCompare

end
