import Mathlib
import Development.AbelianVarietyTheory.Definitions.Foundations.HermitianSpaceBaseLatticeEqFrameLattice
import Formalism.LocalRingCardinality.DataHost
import Formalism.LocalRingCardinality.DataSpaces
import Formalism.SatakeDualWeyl.Statement
import Formalism.SharpRestriction.GlobalSchurBounds.GeneralLinearActions.GenusMassVolumes

noncomputable section

namespace GlobalTheory.AdelicU.SelfDual

open scoped TensorProduct Matrix
open NumberField IsDedekindDomain Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes Formalism.UG

theorem exists_dualFamily_of_isLattice {O K V : Type} [CommRing O] [IsDedekindDomain O] [Field K] [Algebra O K]
    [IsFractionRing O K] [AddCommGroup V] [Module K V] [Module O V] [IsScalarTower O K V]
    (L : Submodule O V) (hL : Submodule.IsLattice K L) :
    ∃ (k : ℕ) (s : Fin k → V) (φ : Fin k → V →ₗ[K] K), (∀ j, s j ∈ L) ∧
      (∀ x ∈ L, ∀ j, φ j x ∈ (algebraMap O K).range) ∧ ∀ x, ∑ j, φ j x • s j = x := by
  have := Module.IsTorsionFree.trans_faithfulSMul O K V
  have : Module.FinitePresentation O L := Module.finitePresentation_of_finite _ _
  have : Module.Projective O L := Module.Flat.projective_of_finitePresentation
  have : IsLocalizedModule (nonZeroDivisors O) L.subtype :=
    { map_units := fun s => by
        have := isLocalizedModule_id (nonZeroDivisors O) V K
        exact IsLocalizedModule.map_units (S := nonZeroDivisors O) (LinearMap.id : V →ₗ[O] V) s
      surj := fun y => by
        have hy : y ∈ Submodule.span K (L : Set V) := hL.span_eq_top ▸ Submodule.mem_top
        obtain ⟨t, ht⟩ := multiple_mem_span_of_mem_localization_span (nonZeroDivisors O) K _ y hy
        rw [Submodule.span_eq] at ht
        exact ⟨(⟨_, ht⟩, t), rfl⟩
      exists_of_eq := fun {a b} h => ⟨1, by rw [L.injective_subtype h]⟩ }
  obtain ⟨m, π, hπ⟩ := Module.Finite.exists_fin' O L
  obtain ⟨s, hs⟩ := Module.projective_lifting_property π LinearMap.id hπ
  let f : Fin m → V →ₗ[K] K := fun i =>
    LinearMap.extendScalarsOfIsLocalization (nonZeroDivisors O) K
      (IsLocalizedModule.lift (nonZeroDivisors O) L.subtype
        (Algebra.linearMap O K ∘ₗ LinearMap.proj i ∘ₗ s) (IsLocalizedModule.map_units (Algebra.linearMap O K)))
  have hf : ∀ i (y : L), f i y = algebraMap O K (s y i) := fun i y =>
    IsLocalizedModule.lift_apply (nonZeroDivisors O) L.subtype _ (IsLocalizedModule.map_units (Algebra.linearMap O K)) y
  let x : Fin m → V := fun i => (π (Pi.single i 1) : L)
  refine ⟨m, x, f, fun i => (π (Pi.single i 1)).2, fun y hy i => ⟨_, (hf i ⟨y, hy⟩).symm⟩, fun y => ?_⟩
  have : (∑ i, (f i).smulRight (x i)) = LinearMap.id := by
    apply LinearMap.ext_on hL.span_eq_top
    intro y hy
    have h1 : π (s ⟨y, hy⟩) = ⟨y, hy⟩ := LinearMap.congr_fun hs ⟨y, hy⟩
    have h2 : (π (s ⟨y, hy⟩) : V) = y := by rw [h1]
    rw [pi_eq_sum_univ' (s ⟨y, hy⟩)] at h2
    simp only [map_sum, map_smul, Submodule.coe_sum, Submodule.coe_smul] at h2
    simp only [LinearMap.sum_apply, LinearMap.smulRight_apply, LinearMap.id_apply]
    refine Eq.trans (Finset.sum_congr rfl fun i _ => ?_) h2
    rw [hf i ⟨y, hy⟩, algebraMap_smul]
  simpa using LinearMap.congr_fun this y

variable {F E : Type} [Field F] [NumberField F] [Field E] [NumberField E] [Algebra F E]



omit [NumberField E] in
theorem valuation_le_one_of_intLoc {v : HeightOneSpectrum (𝓞 F)} (φ : E →ₗ[F] F)
    (hφ : ∀ x : 𝓞 E, φ x ∈ (algebraMap (𝓞 F) F).range) {e : E} (h : inclR (Fv F v) e ∈ intLoc F E v) :
    v.valuation F (φ e) ≤ 1 := by
  obtain ⟨P, hP0⟩ : ∃ P : Fv F v ⊗[F] E →ₗ[F] Fv F v, ∀ a x, P (a ⊗ₜ x) = algebraMap F _ (φ x) * a :=
    ⟨(TensorProduct.rid F (Fv F v)).toLinearMap ∘ₗ φ.lTensor (Fv F v), fun a x => by simp [Algebra.smul_def]⟩
  have hP : ∀ z ∈ intLoc F E v, P z ∈ v.adicCompletionIntegers F := fun z hz => by
    refine intLoc_induction (p := fun z => P z ∈ v.adicCompletionIntegers F) (fun a ha x => ?_) ?_
        (fun y z hy hz => ?_) (fun y hy => ?_) hz
    · obtain ⟨r, hr⟩ := hφ x
      rw [hP0, ← hr]
      exact mul_mem (v.coe_mem_adicCompletionIntegers r) ha
    · rw [map_zero]; exact zero_mem _
    · rw [map_add]; exact add_mem hy hz
    · rw [map_neg]; exact neg_mem hy
  have h1 : P ((1 : Fv F v) ⊗ₜ e) ∈ v.adicCompletionIntegers F := hP _ h
  rw [hP0, mul_one, HeightOneSpectrum.mem_adicCompletionIntegers] at h1
  rw [← HeightOneSpectrum.valuedAdicCompletion_eq_valuation']
  exact h1


omit [NumberField E] in
theorem inclR_mem_intLoc (v : HeightOneSpectrum (𝓞 F)) {e : E} (h : e ∈ (algebraMap (𝓞 E) E).range) :
    inclR (Fv F v) e ∈ intLoc F E v := by
  obtain ⟨r, rfl⟩ := h
  exact tmul_mem_intLoc (one_mem _) r


variable {n : ℕ}

theorem exists_frame (L : Submodule (𝓞 E) (Fin n → E)) (hL : Submodule.IsLattice E L) :
    ∃ (k : ℕ) (S : Matrix (Fin n) (Fin k) E) (Φ : Matrix (Fin k) (Fin n) E), S * Φ = 1 ∧ (∀ j, (fun i => S i j) ∈ L) ∧
      ∀ x ∈ L, ∀ j, (Φ *ᵥ x) j ∈ (algebraMap (𝓞 E) E).range := by
  obtain ⟨k, s, φ, hs, hφ, hsum⟩ := exists_dualFamily_of_isLattice L hL
  refine ⟨k, Matrix.of fun i j => s j i, Matrix.of fun j i => φ j (Pi.single i 1), ?_, hs, fun x hx j => ?_⟩
  · ext a b
    have := congrFun (hsum (Pi.single b 1)) a
    simpa [Matrix.mul_apply, Matrix.one_apply, Pi.single_apply, mul_comm] using this
  · convert hφ x hx j using 1
    conv_rhs => rw [pi_eq_sum_univ' x]
    simp [Matrix.mulVec, dotProduct, mul_comm]

section Frame

omit [NumberField E]

variable {k : ℕ} {S : Matrix (Fin n) (Fin k) E} {Φ : Matrix (Fin k) (Fin n) E}

theorem eq_sum_col {A : Type} [CommRing A] {S : Matrix (Fin n) (Fin k) A} {Φ : Matrix (Fin k) (Fin n) A}
    (h1 : S * Φ = 1) (y : Fin n → A) : y = ∑ j, (Φ *ᵥ y) j • fun i => S i j := by
  conv_lhs => rw [← Matrix.one_mulVec y, ← h1, ← Matrix.mulVec_mulVec]
  funext i
  simp [Matrix.mulVec, dotProduct, mul_comm]

omit [NumberField F] in
theorem map_mul_eq_one (R : Type) [CommRing R] [Algebra F R] (h1 : S * Φ = 1) :
    S.map (inclR (F := F) R) * Φ.map (inclR (F := F) R) = 1 := by
  rw [← Matrix.map_mul, h1, Matrix.map_one _ (map_zero _) (map_one _)]




theorem hform_col {A : Type} [CommRing A] (σ : A →+* A) (J : Matrix (Fin n) (Fin n) A)
    (S : Matrix (Fin n) (Fin k) A) (j : Fin k) (y : Fin n → A) :
    hform σ J (fun i => S i j) y = (((S.map σ)ᵀ * J) *ᵥ y) j := by
  simp only [hform, Matrix.mulVec, dotProduct, Matrix.mul_apply, Matrix.transpose_apply, Matrix.map_apply,
    Finset.sum_mul]
  exact Finset.sum_comm

end Frame

variable (σ : E →ₐ[F] E) (J : Matrix (Fin n) (Fin n) E)

omit [NumberField F] [NumberField E] in
theorem sig_mem_range {e : E} (h : e ∈ (algebraMap (𝓞 E) E).range) : σ e ∈ (algebraMap (𝓞 E) E).range := by
  obtain ⟨r, rfl⟩ := h
  exact ⟨RingOfIntegers.mapRingHom (σ : E →+* E) r, rfl⟩

def dualGlob (L : Submodule (𝓞 E) (Fin n → E)) : Submodule (𝓞 E) (Fin n → E) where
  carrier := {y | ∀ x ∈ L, hE σ J x y ∈ (algebraMap (𝓞 E) E).range}
  zero_mem' := fun x _ => by simp [hE, hform]
  add_mem' := fun {y y'} hy hy' x hx => by
    have : hE σ J x (y + y') = hE σ J x y + hE σ J x y' := by simp [hE, hform, mul_add, Finset.sum_add_distrib]
    rw [this]; exact add_mem (hy x hx) (hy' x hx)
  smul_mem' := fun c y hy x hx => by
    have : hE σ J x (c • y) = algebraMap (𝓞 E) E c * hE σ J x y := by
      simp only [hE, hform, Pi.smul_apply, Algebra.smul_def, Finset.mul_sum]
      exact Finset.sum_congr rfl fun i _ => Finset.sum_congr rfl fun j _ => by ring
    rw [this]; exact mul_mem ⟨c, rfl⟩ (hy x hx)

omit [NumberField F] [NumberField E] in
theorem mem_dualGlob {L : Submodule (𝓞 E) (Fin n → E)} {y : Fin n → E} :
    y ∈ dualGlob σ J L ↔ ∀ x ∈ L, hE σ J x y ∈ (algebraMap (𝓞 E) E).range := Iff.rfl

section DualFrame

omit [NumberField E]

variable {σ J} {L : Submodule (𝓞 E) (Fin n → E)} {k : ℕ} {S : Matrix (Fin n) (Fin k) E}
  {Φ : Matrix (Fin k) (Fin n) E}

omit [NumberField F] in
theorem dual_mul_eq_one (hJ : J.det ≠ 0) (h1 : S * Φ = 1) :
    (J⁻¹ * (Φ.map (σ : E →+* E))ᵀ) * ((S.map (σ : E →+* E))ᵀ * J) = 1 := by
  rw [Matrix.mul_assoc, ← Matrix.mul_assoc _ _ J, ← Matrix.transpose_mul, ← Matrix.map_mul, h1,
    Matrix.map_one _ (map_zero _) (map_one _), Matrix.transpose_one, Matrix.one_mul,
    Matrix.nonsing_inv_mul _ (Ne.isUnit hJ)]

omit [NumberField F] in
theorem dual_col_mem (hJ : J.det ≠ 0) (hΦ : ∀ x ∈ L, ∀ j, (Φ *ᵥ x) j ∈ (algebraMap (𝓞 E) E).range) (j : Fin k) :
    (fun i => (J⁻¹ * (Φ.map (σ : E →+* E))ᵀ) i j) ∈ dualGlob σ J L := fun x hx => by
  have h2 : ∀ a, ∑ b, J a b * (J⁻¹ * (Φ.map (σ : E →+* E))ᵀ) b j = σ (Φ j a) := fun a => by
    rw [← Matrix.mul_apply, ← Matrix.mul_assoc, Matrix.mul_nonsing_inv _ (Ne.isUnit hJ), Matrix.one_mul]; rfl
  have : hE σ J x (fun i => (J⁻¹ * (Φ.map (σ : E →+* E))ᵀ) i j) = σ ((Φ *ᵥ x) j) := by
    simp only [hE, hform, mul_assoc, ← Finset.mul_sum, h2]
    simp [Matrix.mulVec, dotProduct, mul_comm]
  rw [this]
  exact sig_mem_range σ (hΦ x hx j)

omit [NumberField F] in
theorem dual_integral (hS : ∀ j, (fun i => S i j) ∈ L) (y : Fin n → E) (hy : y ∈ dualGlob σ J L) (j : Fin k) :
    (((S.map (σ : E →+* E))ᵀ * J) *ᵥ y) j ∈ (algebraMap (𝓞 E) E).range := by
  rw [← hform_col]
  exact hy _ (hS j)


end DualFrame

variable {σ J} {L L' : Submodule (𝓞 E) (Fin n → E)}

omit [NumberField F] in

theorem isLattice_dualGlob (hJ : J.det ≠ 0) (hL : Submodule.IsLattice E L) :
    Submodule.IsLattice E (dualGlob σ J L) := by
  classical
  obtain ⟨k, S, Φ, h1, hS, hΦ⟩ := exists_frame L hL
  have h2 := dual_mul_eq_one (σ := σ) hJ h1
  have h3 := dual_col_mem (σ := σ) hJ hΦ
  refine ⟨⟨Finset.univ.image fun j i => (J⁻¹ * (Φ.map (σ : E →+* E))ᵀ) i j, le_antisymm ?_ fun y hy => ?_⟩,
    eq_top_iff.2 fun y _ => ?_⟩
  · rw [Submodule.span_le]
    intro y hy
    obtain ⟨j, -, rfl⟩ := Finset.mem_image.1 hy
    exact h3 j
  · rw [eq_sum_col h2 y]
    refine sum_mem fun j _ => ?_
    obtain ⟨r, hr⟩ := dual_integral hS y hy j
    rw [← hr, algebraMap_smul]
    exact Submodule.smul_mem _ r (Submodule.subset_span (Finset.mem_image.2 ⟨j, Finset.mem_univ j, rfl⟩))
  · rw [eq_sum_col h2 y]
    exact sum_mem fun j _ => Submodule.smul_mem _ _ (Submodule.subset_span (h3 j))


omit [NumberField F] [NumberField E] in
theorem map_mulVec_inclR (R : Type) [CommRing R] [Algebra F R] {k : ℕ} (Φ : Matrix (Fin k) (Fin n) E) (y : Fin n → E)
    (j : Fin k) : (Φ.map (inclR (F := F) R) *ᵥ fun i => inclR R (y i)) j = inclR R ((Φ *ᵥ y) j) :=
  (RingHom.map_mulVec (inclR (F := F) R) Φ y j).symm








section Record

open Formalism.BasicNotions Formalism.BasicNotions.TH Formalism.L2.Theta

theorem isLattice_frameLat {E : Type} [Field E] [NumberField E] [StarRing E] (V : HSpace E) :
    Submodule.IsLattice E (frameLat V) := by
  refine ⟨frameLat_fg V, ?_⟩
  have : (frameLat V : Set (Fin V.rank → E)) = V.frame.equivFun.toLinearMap '' (V.L0 : Set V.V) :=
    (V.frame.equivFun.toEquiv.image_eq_preimage_symm _).symm
  rw [this, ← Submodule.map_span, V.standardTuple_isLattice.span_eq_top, Submodule.map_top, LinearEquiv.range]


attribute [local instance] Formalism.BasicNotions.Host.cmStar


end Record

end GlobalTheory.AdelicU.SelfDual

end
