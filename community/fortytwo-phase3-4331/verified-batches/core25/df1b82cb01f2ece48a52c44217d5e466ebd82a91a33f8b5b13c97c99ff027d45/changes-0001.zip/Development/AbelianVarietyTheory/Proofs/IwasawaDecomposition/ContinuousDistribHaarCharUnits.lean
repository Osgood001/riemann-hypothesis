import Mathlib
import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.T2SpaceNumberFieldInfiniteAdeles
open NumberField IsDedekindDomain MeasureTheory Topology Formalism.MainNotions.GlobalTheoryTheory.GenusMassVolumes GlobalTheory.GaugeEx Filter
open scoped TensorProduct NNReal ENNReal Pointwise

namespace GlobalTheory.GaugeEx


theorem modu_units (S : Type) [CommRing S] [TopologicalSpace S] [IsTopologicalRing S]
    [LocallyCompactSpace S] (u : Sˣ) : modu S (u : S) = distribHaarChar S u := by
  simp [modu]


end GlobalTheory.GaugeEx
