import Mathlib
import Development.AbelianVarietyTheory.Definitions.Foundations.ExistsFinsetOfEventually
import Development.AbelianVarietyTheory.Proofs.UnitaryExistence.LcscAdelicUnitaryGroup

noncomputable section

open MeasureTheory MeasureTheory.Measure Filter Set Topology
open scoped ENNReal

namespace GlobalTheory.RestrMeas

section Pi

theorem lintegral_fin_prod_eq_prod {n : ℕ} {E : Fin n → Type} {mE : ∀ i, MeasurableSpace (E i)}
    {μ : ∀ i, Measure (E i)} [∀ i, SigmaFinite (μ i)] {f : ∀ i, E i → ℝ≥0∞} (hf : ∀ i, AEMeasurable (f i) (μ i)) :
    ∫⁻ x : ∀ i, E i, ∏ i, f i (x i) ∂(Measure.pi μ) = ∏ i, ∫⁻ x, f i x ∂(μ i) := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [← ((measurePreserving_piFinSuccAbove μ 0).symm).lintegral_comp_emb (MeasurableEquiv.measurableEmbedding _),
      Fin.prod_univ_succ, ← ih fun i => hf _, ← lintegral_prod_mul (hf 0)]
    · refine lintegral_congr fun a => ?_
      rw [Fin.prod_univ_succ]
      rfl
    · exact Finset.aemeasurable_fun_prod _ fun i _ =>
        (hf _).comp_quasiMeasurePreserving (quasiMeasurePreserving_eval (fun i : Fin n => μ i.succ) i)

theorem lintegral_fintype_prod_eq_prod {ι : Type} [Fintype ι] {E : ι → Type} {mE : ∀ i, MeasurableSpace (E i)}
    {μ : ∀ i, Measure (E i)} [∀ i, SigmaFinite (μ i)] {f : ∀ i, E i → ℝ≥0∞} (hf : ∀ i, AEMeasurable (f i) (μ i)) :
    ∫⁻ x : ∀ i, E i, ∏ i, f i (x i) ∂(Measure.pi μ) = ∏ i, ∫⁻ x, f i x ∂(μ i) := by
  let e := (Fintype.equivFin ι).symm
  rw [← (measurePreserving_piCongrLeft _ e).lintegral_comp_emb (MeasurableEquiv.measurableEmbedding _)]
  simp_rw [← e.prod_comp, MeasurableEquiv.coe_piCongrLeft, Equiv.piCongrLeft_apply_apply]
  exact lintegral_fin_prod_eq_prod fun i => hf _

end Pi

theorem one_add_sum_le_prod_one_add {ι : Type} (s : Finset ι) {a : ι → ℝ} (ha : ∀ i, 0 ≤ a i) :
    1 + ∑ i ∈ s, a i ≤ ∏ i ∈ s, (1 + a i) := by
  induction s using Finset.cons_induction with
  | empty => simp
  | cons i s hi ih =>
    rw [Finset.sum_cons, Finset.prod_cons]
    nlinarith [ha i, Finset.sum_nonneg fun j (_ : j ∈ s) => ha j]

variable {X W V : Type} {Ya : W → Type} {Yf : V → Type} {pa : ∀ w, X → Ya w} {pf : ∀ v, X → Yf v}
  {K : ∀ v, Set (Yf v)}






variable [MeasurableSpace X] [∀ w, MeasurableSpace (Ya w)] [∀ v, MeasurableSpace (Yf v)] [Countable V]


variable [Fintype W] {μa : ∀ w, Measure (Ya w)} {μf : ∀ v, Measure (Yf v)} {μ : Measure X}
  [∀ w, SigmaFinite (μa w)] [∀ v, SigmaFinite (μf v)]

omit [Countable V] in

theorem IsCylProd.measurePreserving_level (h : IsCylProd pa pf K μa μf μ) (ha : ∀ w, Measurable (pa w))
    (hf : ∀ v, Measurable (pf v)) {S : Finset V} (hS : ∀ v ∉ S, μf v (K v) = 1) :
    MeasurePreserving (fun x => (fun w => pa w x, fun v : S => pf v x)) (μ.restrict {x | ∀ v ∉ S, pf v x ∈ K v})
      ((Measure.pi μa).prod (Measure.pi fun v : S => μf v)) := by
  classical
  have hπ : Measurable fun x => (fun w => pa w x, fun v : S => pf v x) :=
    (measurable_pi_lambda _ ha).prodMk (measurable_pi_lambda _ fun v => hf v)
  refine ⟨hπ, (prod_eq_generateFrom generateFrom_pi generateFrom_pi isPiSystem_pi isPiSystem_pi
    (FiniteSpanningSetsIn.pi fun w => (μa w).toFiniteSpanningSetsIn)
    (FiniteSpanningSetsIn.pi fun v : S => (μf v).toFiniteSpanningSetsIn) ?_).symm⟩
  rintro _ ⟨A, hA, rfl⟩ _ ⟨B, hB, rfl⟩
  have hm := (MeasurableSet.univ_pi fun w => hA w (mem_univ _)).prod (MeasurableSet.univ_pi fun v => hB v (mem_univ _))
  have e := h.2 S hS A (fun v => if hv : v ∈ S then B ⟨v, hv⟩ else univ) (fun w => hA w (mem_univ _))
    fun v hv => by simp only [dif_pos hv]; exact hB ⟨v, hv⟩ (mem_univ _)
  rw [Measure.map_apply hπ hm, Measure.restrict_apply (hπ hm), Measure.pi_pi, Measure.pi_pi]
  convert e using 2
  · ext x
    simp only [mem_inter_iff, mem_preimage, mem_prod, mem_univ_pi, mem_cyl, mem_setOf_eq, and_assoc, Subtype.forall]
    exact and_congr_right fun _ => and_congr_left fun _ => forall₂_congr fun v hv => by rw [dif_pos hv]
  · rw [← Finset.prod_coe_sort S]
    exact Finset.prod_congr rfl fun v _ => by rw [dif_pos v.2]

variable (h : IsCylProd pa pf K μa μf μ) (ha : ∀ w, Measurable (pa w)) (hf : ∀ v, Measurable (pf v))
  (hK : ∀ v, MeasurableSet (K v))

include h ha hf hK

section Nonneg






end Nonneg

variable {𝕜 : Type} [RCLike 𝕜] {ff : ∀ v, Yf v → 𝕜}





omit h ha hf [Countable V] [∀ v, SigmaFinite (μf v)] in

theorem multipliable_integral {S₀ : Finset V} (hS : ∀ v ∉ S₀, μf v (K v) = 1)
    (h1 : ∀ v ∉ S₀, ∀ y ∈ K v, ff v y = 1) (hff : ∀ v, Integrable (ff v) (μf v)) {C : ℝ}
    (hC : ∀ S : Finset V, S₀ ⊆ S → ∏ v ∈ S, ∫ y, ‖ff v y‖ ∂μf v ≤ C) :
    Multipliable fun v => ∫ y, ff v y ∂μf v := by
  classical
  have h0 : ∀ v, 0 ≤ ∫ y, ‖ff v y‖ ∂μf v := fun v => integral_nonneg fun _ => norm_nonneg _
  rcases (Finset.prod_nonneg fun v (_ : v ∈ S₀) => h0 v).eq_or_lt with hP | hP
  · obtain ⟨v, -, hv⟩ := Finset.prod_eq_zero_iff.1 hP.symm
    exact multipliable_of_exists_eq_zero ⟨v, norm_le_zero_iff.1 ((norm_integral_le_integral_norm _).trans hv.le)⟩
  have hb : ∀ v ∉ S₀, 1 + ‖∫ y, ff v y ∂μf v - 1‖ ≤ ∫ y, ‖ff v y‖ ∂μf v := fun v hv => by
    have e1 : ∫ y in K v, ff v y ∂μf v = 1 := by
      rw [setIntegral_congr_fun (hK v) (g := fun _ => 1) (h1 v hv)]
      simp [measureReal_def, hS v hv]
    have e2 : ∫ y in K v, ‖ff v y‖ ∂μf v = 1 := by
      rw [setIntegral_congr_fun (hK v) (g := fun _ => 1) fun y hy => by simp [h1 v hv y hy]]
      simp [measureReal_def, hS v hv]
    rw [← integral_add_compl (hK v) (hff v), ← integral_add_compl (hK v) (hff v).norm, e1, e2, add_sub_cancel_left]
    exact add_le_add_right (norm_integral_le_integral_norm _) _
  have hs : Summable fun v => ‖∫ y, ff v y ∂μf v - 1‖ := by
    refine summable_of_sum_le (c := ∑ v ∈ S₀, ‖∫ y, ff v y ∂μf v - 1‖ + C / ∏ v ∈ S₀, ∫ y, ‖ff v y‖ ∂μf v)
      (fun _ => norm_nonneg _) fun T => ?_
    refine (Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_union_right (s₁ := S₀))
      fun _ _ _ => norm_nonneg _).trans ?_
    rw [← Finset.union_sdiff_self_eq_union, Finset.sum_union Finset.disjoint_sdiff]
    refine add_le_add_right ?_ _
    have e := hC (S₀ ∪ T \ S₀) Finset.subset_union_left
    rw [Finset.prod_union Finset.disjoint_sdiff, ← le_div_iff₀' hP] at e
    refine le_trans ?_ ((Finset.prod_le_prod (fun v _ => by positivity)
      fun v hv => hb v (Finset.mem_sdiff.1 hv).2).trans e)
    exact (le_add_of_nonneg_left zero_le_one).trans (one_add_sum_le_prod_one_add _ fun _ => norm_nonneg _)
  simpa using multipliable_one_add_of_summable hs


end GlobalTheory.RestrMeas

namespace GlobalTheory.AdelicU




end GlobalTheory.AdelicU

end
